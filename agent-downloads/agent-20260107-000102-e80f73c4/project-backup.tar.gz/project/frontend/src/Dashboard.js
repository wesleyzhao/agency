import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all'); // all, disclosed, not_disclosed

  // Search/Filter state - Feature #14
  const [searchMode, setSearchMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState({
    outlet: '',
    candidate: '',
    confidence: '',
    verified_only: false,
    has_ballot: ''
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/dashboard?season=2024-25`);

      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }

      const data = await response.json();
      setDashboardData(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Search function - Feature #14
  const performSearch = async () => {
    try {
      setSearchLoading(true);

      // Build query parameters
      const params = new URLSearchParams();
      params.append('season', '2024-25');

      if (searchQuery.trim()) {
        params.append('q', searchQuery.trim());
      }
      if (advancedFilters.outlet) {
        params.append('outlet', advancedFilters.outlet);
      }
      if (advancedFilters.candidate) {
        params.append('candidate_name', advancedFilters.candidate);
      }
      if (advancedFilters.confidence) {
        params.append('confidence', advancedFilters.confidence);
      }
      if (advancedFilters.verified_only) {
        params.append('verified_only', 'true');
      }
      if (advancedFilters.has_ballot) {
        params.append('has_ballot', advancedFilters.has_ballot);
      }

      const response = await fetch(`${API_URL}/api/search?${params.toString()}`);

      if (!response.ok) {
        throw new Error('Search failed');
      }

      const data = await response.json();
      setSearchResults(data);
      setSearchMode(true);
    } catch (err) {
      console.error('Error searching:', err);
      alert('Search failed: ' + err.message);
    } finally {
      setSearchLoading(false);
    }
  };

  // Export functions - Feature #15
  const handleExport = (type, format) => {
    const url = `${API_URL}/api/export/${type}?format=${format}&season=2024-25`;
    window.open(url, '_blank');
  };

  const clearSearch = () => {
    setSearchMode(false);
    setSearchQuery('');
    setSearchResults(null);
    setAdvancedFilters({
      outlet: '',
      candidate: '',
      confidence: '',
      verified_only: false,
      has_ballot: ''
    });
  };

  const handleSearchKeyPress = (e) => {
    if (e.key === 'Enter') {
      performSearch();
    }
  };

  const filteredVoters = () => {
    // If in search mode, use search results
    if (searchMode && searchResults) {
      const results = searchResults.results;

      // Apply status filter on top of search results
      if (filterStatus === 'all') {
        return results;
      } else if (filterStatus === 'disclosed') {
        return results.filter(v => v.status === 'disclosed');
      } else {
        return results.filter(v => v.status === 'not_disclosed');
      }
    }

    // Normal dashboard mode
    if (!dashboardData || !dashboardData.voters) return [];

    if (filterStatus === 'all') {
      return dashboardData.voters;
    } else if (filterStatus === 'disclosed') {
      return dashboardData.voters.filter(v => v.status === 'disclosed');
    } else {
      return dashboardData.voters.filter(v => v.status === 'not_disclosed');
    }
  };

  const renderVoterCard = (voter) => {
    const hasFullBallot = voter.ballot && voter.ballot.length >= 5;
    const hasPartialBallot = voter.ballot && voter.ballot.length > 0 && voter.ballot.length < 5;

    return (
      <div key={voter.id} className={`voter-card ${voter.status}`}>
        <div className="voter-header">
          <Link to={`/voter/${voter.id}`} className="voter-name-link">
            <h3>{voter.name}</h3>
          </Link>
          {voter.outlet && <p className="outlet">{voter.outlet}</p>}
          {voter.twitter_handle && (
            <a
              href={`https://twitter.com/${voter.twitter_handle.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="twitter-handle"
            >
              {voter.twitter_handle}
            </a>
          )}
        </div>

        {voter.status === 'disclosed' ? (
          <div className="ballot">
            {hasFullBallot && <p><strong>Full Ballot:</strong></p>}
            {hasPartialBallot && <p><strong>Partial Ballot:</strong></p>}

            <ol>
              {voter.ballot.map((vote, idx) => (
                <li key={idx}>
                  {vote.candidate}
                  {vote.team && <span className="team"> ({vote.team})</span>}
                  {vote.source_url && (
                    <a
                      href={vote.source_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="source-link"
                      title="View source"
                    >
                      🔗
                    </a>
                  )}
                </li>
              ))}
            </ol>

            {voter.ballot.some(v => v.verified) && (
              <span className="verified">✓ Verified</span>
            )}
            {hasPartialBallot && (
              <p className="partial">Partial ballot revealed</p>
            )}

            <Link to={`/voter/${voter.id}`} className="view-details-link">
              View Full Details →
            </Link>
          </div>
        ) : (
          <div className="no-vote">
            <p>Vote not yet disclosed</p>
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="App">
        <header className="App-header">
          <h1>NFL MVP Voter Tracker</h1>
        </header>
        <main className="App-main">
          <div className="loading">Loading dashboard data...</div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="App">
        <header className="App-header">
          <h1>NFL MVP Voter Tracker</h1>
        </header>
        <main className="App-main">
          <div className="error">
            <p>Error loading data: {error}</p>
            <button onClick={fetchDashboardData}>Retry</button>
          </div>
        </main>
      </div>
    );
  }

  const stats = dashboardData?.stats || {};
  const voters = filteredVoters();
  const candidateStats = dashboardData?.candidate_stats || [];

  return (
    <div className="App">
      <header className="App-header">
        <div className="header-content">
          <div>
            <h1>NFL MVP Voter Tracker</h1>
            <p>Track the 50 AP voters and their publicly announced MVP picks</p>
            <p className="season-badge">2024-25 Season</p>
          </div>
          <div className="header-buttons">
            <Link to="/statistics" className="view-statistics-btn">
              📊 View Statistics
            </Link>
            <Link to="/visualizations" className="view-visualizations-btn">
              📈 View Visualizations
            </Link>
            <Link to="/timeline" className="view-timeline-btn">
              📅 Timeline
            </Link>
            <Link to="/historical" className="view-historical-btn">
              📜 View Historical
            </Link>
            <Link to="/admin" className="view-admin-btn">
              🔧 Admin Panel
            </Link>
            <div className="export-dropdown">
              <button className="export-btn">
                📥 Export Data
              </button>
              <div className="export-menu">
                <button onClick={() => handleExport('voters', 'csv')}>Voters (CSV)</button>
                <button onClick={() => handleExport('voters', 'json')}>Voters (JSON)</button>
                <button onClick={() => handleExport('votes', 'csv')}>Votes (CSV)</button>
                <button onClick={() => handleExport('votes', 'json')}>Votes (JSON)</button>
                <button onClick={() => handleExport('candidates', 'csv')}>Candidates (CSV)</button>
                <button onClick={() => handleExport('candidates', 'json')}>Candidates (JSON)</button>
                <button onClick={() => handleExport('full-report', 'json')}>Full Report (JSON)</button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="App-main">
        <div className="dashboard">
          <div className="stats-card">
            <h3>Total AP Voters</h3>
            <div className="stat-value">{stats.total_voters || 50}</div>
          </div>

          <div className="stats-card">
            <h3>Known Voters</h3>
            <div className="stat-value">{stats.known_voters || 0}</div>
          </div>

          <div className="stats-card">
            <h3>Votes Disclosed</h3>
            <div className="stat-value">{stats.voters_with_disclosed_votes || 0}</div>
          </div>

          <div className="stats-card">
            <h3>Completion</h3>
            <div className="stat-value">{stats.completion_percentage || 0}%</div>
          </div>
        </div>

        {candidateStats.length > 0 && (
          <section className="candidate-stats-section">
            <h2>Current Vote Leaders</h2>
            <div className="candidate-list">
              {candidateStats.slice(0, 5).map((candidate, idx) => (
                <div key={idx} className="candidate-card">
                  <div className="candidate-rank">#{idx + 1}</div>
                  <div className="candidate-info">
                    <h3>{candidate.name}</h3>
                    <p className="candidate-team">{candidate.team} • {candidate.position}</p>
                  </div>
                  <div className="candidate-votes">
                    <div className="vote-count">{candidate.first_place_votes}</div>
                    <div className="vote-label">1st place votes</div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="search-section">
          <h2>🔍 Search & Filter Voters</h2>
          <div className="search-container">
            <div className="search-bar">
              <input
                type="text"
                placeholder="Search by name, outlet, or Twitter handle..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleSearchKeyPress}
                className="search-input"
              />
              <button onClick={performSearch} disabled={searchLoading} className="search-button">
                {searchLoading ? 'Searching...' : 'Search'}
              </button>
              {searchMode && (
                <button onClick={clearSearch} className="clear-button">
                  Clear
                </button>
              )}
            </div>

            <details className="advanced-filters">
              <summary>Advanced Filters</summary>
              <div className="filter-grid">
                <div className="filter-group">
                  <label>Outlet:</label>
                  <input
                    type="text"
                    placeholder="e.g., ESPN, NBC Sports"
                    value={advancedFilters.outlet}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, outlet: e.target.value})}
                  />
                </div>

                <div className="filter-group">
                  <label>Voted for candidate:</label>
                  <input
                    type="text"
                    placeholder="e.g., Josh Allen, Saquon Barkley"
                    value={advancedFilters.candidate}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, candidate: e.target.value})}
                  />
                </div>

                <div className="filter-group">
                  <label>Confidence level:</label>
                  <select
                    value={advancedFilters.confidence}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, confidence: e.target.value})}
                  >
                    <option value="">Any</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>

                <div className="filter-group">
                  <label>Ballot status:</label>
                  <select
                    value={advancedFilters.has_ballot}
                    onChange={(e) => setAdvancedFilters({...advancedFilters, has_ballot: e.target.value})}
                  >
                    <option value="">Any</option>
                    <option value="full">Full ballot (5 votes)</option>
                    <option value="partial">Partial ballot (1-4 votes)</option>
                    <option value="any">Any votes</option>
                    <option value="none">No votes yet</option>
                  </select>
                </div>

                <div className="filter-group checkbox-group">
                  <label>
                    <input
                      type="checkbox"
                      checked={advancedFilters.verified_only}
                      onChange={(e) => setAdvancedFilters({...advancedFilters, verified_only: e.target.checked})}
                    />
                    Verified votes only
                  </label>
                </div>
              </div>
            </details>

            {searchMode && searchResults && (
              <div className="search-results-info">
                <p>Found <strong>{searchResults.count}</strong> voters matching your search</p>
              </div>
            )}
          </div>
        </section>

        <section className="voters-section">
          <div className="section-header">
            <h2>{searchMode ? 'Search Results' : 'AP Voters'} ({voters.length})</h2>
            <div className="filter-buttons">
              <button
                className={filterStatus === 'all' ? 'active' : ''}
                onClick={() => setFilterStatus('all')}
              >
                All ({searchMode && searchResults ? searchResults.results.length : dashboardData?.voters?.length || 0})
              </button>
              <button
                className={filterStatus === 'disclosed' ? 'active' : ''}
                onClick={() => setFilterStatus('disclosed')}
              >
                Disclosed ({searchMode && searchResults ? searchResults.results.filter(v => v.status === 'disclosed').length : dashboardData?.voters?.filter(v => v.status === 'disclosed').length || 0})
              </button>
              <button
                className={filterStatus === 'not_disclosed' ? 'active' : ''}
                onClick={() => setFilterStatus('not_disclosed')}
              >
                Not Disclosed ({searchMode && searchResults ? searchResults.results.filter(v => v.status === 'not_disclosed').length : dashboardData?.voters?.filter(v => v.status === 'not_disclosed').length || 0})
              </button>
            </div>
          </div>

          <div className="voter-list">
            {voters.length > 0 ? (
              voters.map(voter => renderVoterCard(voter))
            ) : (
              <div className="no-data">
                <p>No voters found matching this filter.</p>
              </div>
            )}
          </div>
        </section>

        <section className="info-section">
          <h2>About This Project</h2>
          <p>
            The AP NFL MVP award is voted on by 50 sportswriters. The full voter list
            is typically not disclosed until after winners are announced. However, some
            voters publicly share their selections on social media or in articles.
          </p>
          <p>
            This tracker aggregates publicly available information to identify voters
            and their disclosed votes. Data is automatically collected from Twitter,
            Reddit, news articles, and other public sources.
          </p>
          <button onClick={fetchDashboardData} className="refresh-button">
            🔄 Refresh Data
          </button>
        </section>
      </main>
    </div>
  );
}

export default Dashboard;
