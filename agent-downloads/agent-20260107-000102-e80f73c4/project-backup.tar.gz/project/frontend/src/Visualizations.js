import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
import './Visualizations.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

function Visualizations() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('http://localhost:5000/api/statistics?season=2024-25');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      setData(result);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="visualizations-container">
        <div className="loading-message">Loading visualizations...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="visualizations-container">
        <div className="error-message">
          <p>Error loading data: {error}</p>
          <button onClick={fetchData} className="retry-button">Retry</button>
        </div>
      </div>
    );
  }

  if (!data || !data.candidate_breakdown || data.candidate_breakdown.length === 0) {
    return (
      <div className="visualizations-container">
        <div className="empty-state">No data available for visualizations</div>
      </div>
    );
  }

  // Prepare data for Candidate Vote Distribution chart
  const candidateLabels = data.candidate_breakdown.map(c => c.name);
  const firstPlaceVotes = data.candidate_breakdown.map(c => c.first_place_votes);
  const secondPlaceVotes = data.candidate_breakdown.map(c => c.second_place_votes);
  const thirdPlaceVotes = data.candidate_breakdown.map(c => c.third_place_votes);
  const fourthPlaceVotes = data.candidate_breakdown.map(c => c.fourth_place_votes);
  const fifthPlaceVotes = data.candidate_breakdown.map(c => c.fifth_place_votes);
  const totalMentions = data.candidate_breakdown.map(c => c.total_mentions);

  const voteDistributionData = {
    labels: candidateLabels,
    datasets: [
      {
        label: '1st Place Votes (10 pts)',
        data: firstPlaceVotes,
        backgroundColor: 'rgba(255, 215, 0, 0.8)', // Gold
        borderColor: 'rgba(255, 215, 0, 1)',
        borderWidth: 1,
      },
      {
        label: '2nd Place Votes (7 pts)',
        data: secondPlaceVotes,
        backgroundColor: 'rgba(192, 192, 192, 0.8)', // Silver
        borderColor: 'rgba(192, 192, 192, 1)',
        borderWidth: 1,
      },
      {
        label: '3rd Place Votes (5 pts)',
        data: thirdPlaceVotes,
        backgroundColor: 'rgba(205, 127, 50, 0.8)', // Bronze
        borderColor: 'rgba(205, 127, 50, 1)',
        borderWidth: 1,
      },
      {
        label: '4th Place Votes (3 pts)',
        data: fourthPlaceVotes,
        backgroundColor: 'rgba(59, 130, 246, 0.8)', // Blue
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
      {
        label: '5th Place Votes (1 pt)',
        data: fifthPlaceVotes,
        backgroundColor: 'rgba(147, 51, 234, 0.8)', // Purple
        borderColor: 'rgba(147, 51, 234, 1)',
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for First Place Votes chart (top 10 candidates)
  const top10Candidates = data.candidate_breakdown
    .filter(c => c.first_place_votes > 0)
    .sort((a, b) => b.first_place_votes - a.first_place_votes)
    .slice(0, 10);

  const firstPlaceData = {
    labels: top10Candidates.map(c => c.name),
    datasets: [
      {
        label: 'First Place Votes',
        data: top10Candidates.map(c => c.first_place_votes),
        backgroundColor: [
          'rgba(255, 215, 0, 0.8)',
          'rgba(192, 192, 192, 0.8)',
          'rgba(205, 127, 50, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(147, 51, 234, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(236, 72, 153, 0.8)',
          'rgba(14, 165, 233, 0.8)',
        ],
        borderColor: [
          'rgba(255, 215, 0, 1)',
          'rgba(192, 192, 192, 1)',
          'rgba(205, 127, 50, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(147, 51, 234, 1)',
          'rgba(16, 185, 129, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(236, 72, 153, 1)',
          'rgba(14, 165, 233, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for Weighted Points chart (top 10)
  const top10ByPoints = data.candidate_breakdown
    .sort((a, b) => b.weighted_points - a.weighted_points)
    .slice(0, 10);

  const weightedPointsData = {
    labels: top10ByPoints.map(c => c.name),
    datasets: [
      {
        label: 'Weighted Points',
        data: top10ByPoints.map(c => c.weighted_points),
        backgroundColor: 'rgba(102, 126, 234, 0.8)',
        borderColor: 'rgba(102, 126, 234, 1)',
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for Confidence Distribution pie chart
  const confidenceData = {
    labels: ['High Confidence', 'Medium Confidence', 'Low Confidence', 'Unknown'],
    datasets: [
      {
        label: 'Votes by Confidence',
        data: [
          data.confidence_distribution.high || 0,
          data.confidence_distribution.medium || 0,
          data.confidence_distribution.low || 0,
          data.confidence_distribution.unknown || 0,
        ],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)', // Green
          'rgba(245, 158, 11, 0.8)', // Yellow
          'rgba(239, 68, 68, 0.8)',  // Red
          'rgba(156, 163, 175, 0.8)', // Gray
        ],
        borderColor: [
          'rgba(16, 185, 129, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(156, 163, 175, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for Source Type Distribution pie chart
  const sourceData = {
    labels: ['Official', 'Social Media', 'News Article', 'Reddit', 'Speculation'],
    datasets: [
      {
        label: 'Votes by Source',
        data: [
          data.source_distribution.official || 0,
          data.source_distribution.social_media || 0,
          data.source_distribution.news_article || 0,
          data.source_distribution.reddit || 0,
          data.source_distribution.speculation || 0,
        ],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)',  // Green
          'rgba(59, 130, 246, 0.8)',  // Blue
          'rgba(147, 51, 234, 0.8)',  // Purple
          'rgba(245, 158, 11, 0.8)',  // Orange
          'rgba(156, 163, 175, 0.8)', // Gray
        ],
        borderColor: [
          'rgba(16, 185, 129, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(147, 51, 234, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(156, 163, 175, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
        },
      },
    },
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
      },
      title: {
        display: false,
      },
    },
  };

  return (
    <div className="visualizations-container">
      <div className="visualizations-header">
        <div className="header-content">
          <a href="/" className="back-link">← Back to Dashboard</a>
          <h1>📊 NFL MVP Vote Visualizations</h1>
          <button onClick={fetchData} className="refresh-button">🔄 Refresh Data</button>
        </div>
        <div className="season-badge">Season: 2024-25</div>
      </div>

      <div className="visualizations-grid">
        {/* Vote Distribution by Ranking */}
        <div className="chart-card large-chart">
          <h2>Vote Distribution by Ranking Position</h2>
          <p className="chart-description">
            Stacked view showing 1st through 5th place votes for each candidate
          </p>
          <div className="chart-container">
            <Bar data={voteDistributionData} options={chartOptions} />
          </div>
        </div>

        {/* First Place Votes */}
        <div className="chart-card">
          <h2>Top 10 Candidates by First Place Votes</h2>
          <p className="chart-description">
            Candidates receiving the most #1 votes (10 points each)
          </p>
          <div className="chart-container">
            <Bar data={firstPlaceData} options={chartOptions} />
          </div>
        </div>

        {/* Weighted Points */}
        <div className="chart-card">
          <h2>Top 10 Candidates by Weighted Points</h2>
          <p className="chart-description">
            Total points using AP scoring system (10-7-5-3-1)
          </p>
          <div className="chart-container">
            <Bar data={weightedPointsData} options={chartOptions} />
          </div>
        </div>

        {/* Confidence Distribution */}
        <div className="chart-card">
          <h2>Confidence Level Distribution</h2>
          <p className="chart-description">
            Breakdown of vote reliability across all disclosed votes
          </p>
          <div className="chart-container">
            <Pie data={confidenceData} options={pieOptions} />
          </div>
        </div>

        {/* Source Type Distribution */}
        <div className="chart-card">
          <h2>Source Type Distribution</h2>
          <p className="chart-description">
            Where vote information was discovered
          </p>
          <div className="chart-container">
            <Pie data={sourceData} options={pieOptions} />
          </div>
        </div>

        {/* Summary Statistics */}
        <div className="chart-card summary-card">
          <h2>Key Metrics</h2>
          <div className="summary-grid">
            <div className="summary-item">
              <span className="summary-label">Total Candidates</span>
              <span className="summary-value">{data.candidate_breakdown.length}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Candidates with Votes</span>
              <span className="summary-value">
                {data.candidate_breakdown.filter(c => c.total_mentions > 0).length}
              </span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Total Votes Cast</span>
              <span className="summary-value">{data.overview.total_votes_disclosed || 0}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">First Place Votes</span>
              <span className="summary-value">{data.overview.first_place_votes_disclosed}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Current Leader</span>
              <span className="summary-value">
                {top10ByPoints.length > 0 ? top10ByPoints[0].name : 'N/A'}
              </span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Leader Points</span>
              <span className="summary-value">
                {top10ByPoints.length > 0 ? top10ByPoints[0].weighted_points : 0}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="visualizations-footer">
        <a href="/" className="back-link">← Back to Dashboard</a>
        <a href="/statistics" className="stats-link">📈 View Statistics Table</a>
      </div>
    </div>
  );
}

export default Visualizations;
