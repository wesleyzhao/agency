import React, { useState, useEffect } from 'react';
import './Statistics.css';
import { Link } from 'react-router-dom';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function Statistics() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [selectedSeason, setSelectedSeason] = useState('2024-25');

  useEffect(() => {
    fetchStatistics();
  }, [selectedSeason]);

  const fetchStatistics = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`${API_URL}/api/statistics?season=${selectedSeason}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const result = await response.json();
      setData(result);
    } catch (err) {
      console.error('Error fetching statistics:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatSourceType = (type) => {
    if (!type) return 'Unknown';
    return type.split('_').map(word =>
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  // Export functions - Feature #15
  const handleExport = (type, format) => {
    const url = `${API_URL}/api/export/${type}?format=${format}&season=${selectedSeason}`;
    window.open(url, '_blank');
  };

  if (loading) {
    return (
      <div className="statistics-container">
        <div className="loading">Loading statistics...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="statistics-container">
        <div className="error">
          <p>Error loading statistics: {error}</p>
          <button onClick={fetchStatistics}>Retry</button>
        </div>
      </div>
    );
  }

  if (!data) {
    return null;
  }

  const { overview, candidate_breakdown, top_candidates, source_distribution,
          confidence_distribution, disclosure_breakdown, timeline, recent_activity } = data;

  return (
    <div className="statistics-container">
      {/* Header */}
      <div className="statistics-header">
        <div className="header-left">
          <Link to="/" className="back-link">← Back to Dashboard</Link>
          <h1>Summary Statistics</h1>
          <span className="season-badge">{selectedSeason} Season</span>
        </div>
        <div className="header-actions">
          <Link to="/visualizations" className="view-visualizations-btn">
            📈 View Charts
          </Link>
          <Link to="/timeline" className="view-timeline-btn">
            📅 Timeline
          </Link>
          <div className="export-dropdown">
            <button className="export-btn">
              📥 Export Data
            </button>
            <div className="export-menu">
              <button onClick={() => handleExport('voters', 'csv')}>Voters (CSV)</button>
              <button onClick={() => handleExport('voters', 'json')}>Voters (JSON)</button>
              <button onClick={() => handleExport('votes', 'csv')}>Votes (CSV)</button>
              <button onClick={() => handleExport('votes', 'json')}>Votes (JSON)</button>
              <button onClick={() => handleExport('candidates', 'csv')}>Candidates (CSV)</button>
              <button onClick={() => handleExport('candidates', 'json')}>Candidates (JSON)</button>
              <button onClick={() => handleExport('full-report', 'json')}>Full Report (JSON)</button>
            </div>
          </div>
          <button onClick={fetchStatistics} className="refresh-btn">
            Refresh Data
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="overview-section">
        <h2>Overview</h2>
        <div className="overview-grid">
          <div className="stat-card overview-card">
            <div className="stat-number">{overview.total_voters}</div>
            <div className="stat-label">Total AP Voters</div>
          </div>
          <div className="stat-card overview-card">
            <div className="stat-number">{overview.known_voters}</div>
            <div className="stat-label">Known Voters</div>
          </div>
          <div className="stat-card overview-card highlight">
            <div className="stat-number">{overview.voters_with_disclosed_votes}</div>
            <div className="stat-label">Voters with Disclosed Votes</div>
          </div>
          <div className="stat-card overview-card">
            <div className="stat-number">{overview.total_votes_disclosed}</div>
            <div className="stat-label">Total Votes Disclosed</div>
          </div>
          <div className="stat-card overview-card">
            <div className="stat-number">{overview.first_place_votes_disclosed}</div>
            <div className="stat-label">First Place Votes</div>
          </div>
          <div className="stat-card overview-card">
            <div className="stat-number">{overview.verified_votes}</div>
            <div className="stat-label">Verified Votes</div>
          </div>
          <div className="stat-card overview-card completion">
            <div className="stat-number">{overview.completion_percentage}%</div>
            <div className="stat-label">Completion Rate</div>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${overview.completion_percentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Candidates */}
      <div className="top-candidates-section">
        <h2>Current MVP Leaders</h2>
        <div className="candidates-grid">
          {top_candidates.map((candidate, index) => (
            <div key={index} className="candidate-card">
              <div className="rank-badge">{index + 1}</div>
              <div className="candidate-info">
                <h3>{candidate.name}</h3>
                <p className="team">{candidate.team} • {candidate.position}</p>
              </div>
              <div className="candidate-stats">
                <div className="stat-item">
                  <span className="stat-value">{candidate.first_place_votes}</span>
                  <span className="stat-name">1st Place</span>
                </div>
                <div className="stat-item">
                  <span className="stat-value">{candidate.weighted_points}</span>
                  <span className="stat-name">Points</span>
                </div>
                <div className="stat-item">
                  <span className="stat-value">{candidate.total_mentions}</span>
                  <span className="stat-name">Total</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Full Candidate Breakdown */}
      <div className="full-breakdown-section">
        <h2>Complete Candidate Breakdown</h2>
        <div className="table-container">
          <table className="candidates-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Candidate</th>
                <th>Team</th>
                <th>Position</th>
                <th>1st</th>
                <th>2nd</th>
                <th>3rd</th>
                <th>4th</th>
                <th>5th</th>
                <th>Total</th>
                <th>Points</th>
              </tr>
            </thead>
            <tbody>
              {candidate_breakdown.map((candidate, index) => (
                <tr key={index} className={index < 3 ? 'top-three' : ''}>
                  <td className="rank-col">{index + 1}</td>
                  <td className="candidate-col">{candidate.name}</td>
                  <td>{candidate.team}</td>
                  <td>{candidate.position}</td>
                  <td className="vote-col">{candidate.first_place_votes || '-'}</td>
                  <td className="vote-col">{candidate.second_place_votes || '-'}</td>
                  <td className="vote-col">{candidate.third_place_votes || '-'}</td>
                  <td className="vote-col">{candidate.fourth_place_votes || '-'}</td>
                  <td className="vote-col">{candidate.fifth_place_votes || '-'}</td>
                  <td className="total-col">{candidate.total_mentions}</td>
                  <td className="points-col"><strong>{candidate.weighted_points}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="points-legend">
          <p><strong>Points System:</strong> 1st = 10 pts • 2nd = 7 pts • 3rd = 5 pts • 4th = 3 pts • 5th = 1 pt</p>
        </div>
      </div>

      {/* Two Column Layout for Distributions */}
      <div className="distributions-section">
        <div className="distribution-column">
          <h2>Source Type Distribution</h2>
          <div className="distribution-card">
            {Object.keys(source_distribution).length > 0 ? (
              <div className="distribution-list">
                {Object.entries(source_distribution).map(([type, count]) => (
                  <div key={type} className="distribution-item">
                    <div className="distribution-bar-container">
                      <div className="distribution-label">
                        {formatSourceType(type)}
                      </div>
                      <div className="distribution-bar">
                        <div
                          className={`distribution-fill source-${type.replace('_', '-')}`}
                          style={{
                            width: `${(count / overview.total_votes_disclosed) * 100}%`
                          }}
                        ></div>
                      </div>
                      <div className="distribution-count">{count}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="no-data">No source data available</p>
            )}
          </div>
        </div>

        <div className="distribution-column">
          <h2>Confidence Level Distribution</h2>
          <div className="distribution-card">
            <div className="distribution-list">
              {['high', 'medium', 'low', 'unknown'].map((level) => (
                <div key={level} className="distribution-item">
                  <div className="distribution-bar-container">
                    <div className="distribution-label">
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </div>
                    <div className="distribution-bar">
                      <div
                        className={`distribution-fill confidence-${level}`}
                        style={{
                          width: overview.total_votes_disclosed > 0
                            ? `${(confidence_distribution[level] / overview.total_votes_disclosed) * 100}%`
                            : '0%'
                        }}
                      ></div>
                    </div>
                    <div className="distribution-count">{confidence_distribution[level]}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Voter Disclosure Status */}
      <div className="disclosure-section">
        <h2>Voter Disclosure Status</h2>
        <div className="disclosure-grid">
          <div className="disclosure-card">
            <div className="disclosure-icon">📊</div>
            <div className="disclosure-number">{disclosure_breakdown.full_ballot}</div>
            <div className="disclosure-label">Full Ballot</div>
            <div className="disclosure-desc">(5 votes)</div>
          </div>
          <div className="disclosure-card">
            <div className="disclosure-icon">📝</div>
            <div className="disclosure-number">{disclosure_breakdown.partial_ballot}</div>
            <div className="disclosure-label">Partial Ballot</div>
            <div className="disclosure-desc">(2-4 votes)</div>
          </div>
          <div className="disclosure-card">
            <div className="disclosure-icon">🥇</div>
            <div className="disclosure-number">{disclosure_breakdown.first_place_only}</div>
            <div className="disclosure-label">First Place Only</div>
            <div className="disclosure-desc">(1st rank only)</div>
          </div>
          <div className="disclosure-card">
            <div className="disclosure-icon">❓</div>
            <div className="disclosure-number">{disclosure_breakdown.no_disclosure}</div>
            <div className="disclosure-label">No Disclosure</div>
            <div className="disclosure-desc">(0 votes)</div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      {timeline && timeline.length > 0 && (
        <div className="timeline-section">
          <h2>Vote Announcement Timeline</h2>
          <div className="timeline-card">
            <div className="timeline-chart">
              {timeline.map((entry, index) => (
                <div key={index} className="timeline-entry">
                  <div className="timeline-date">{formatDate(entry.date)}</div>
                  <div className="timeline-bar-container">
                    <div
                      className="timeline-bar"
                      style={{ height: `${(entry.count / Math.max(...timeline.map(t => t.count))) * 100}px` }}
                    >
                      <span className="timeline-count">{entry.count}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Recent Activity */}
      <div className="recent-activity-section">
        <h2>Recent Activity</h2>
        <div className="activity-card">
          {recent_activity && recent_activity.length > 0 ? (
            <div className="activity-list">
              {recent_activity.map((activity, index) => (
                <div key={index} className="activity-item">
                  <div className="activity-rank">#{activity.ranking}</div>
                  <div className="activity-details">
                    <div className="activity-main">
                      <strong>{activity.voter_name}</strong> voted for{' '}
                      <strong>{activity.candidate_name}</strong>
                    </div>
                    <div className="activity-meta">
                      <span className={`confidence-badge-small ${activity.confidence}`}>
                        {activity.confidence}
                      </span>
                      {activity.verified && (
                        <span className="verified-badge-small">✓ Verified</span>
                      )}
                      {activity.announcement_date && (
                        <span className="activity-date">
                          {formatDate(activity.announcement_date)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="no-data">No recent activity</p>
          )}
        </div>
      </div>

      {/* Footer Actions */}
      <div className="statistics-footer">
        <Link to="/" className="btn-secondary">← Back to Dashboard</Link>
        <button onClick={fetchStatistics} className="btn-primary">Refresh Statistics</button>
      </div>
    </div>
  );
}

export default Statistics;
