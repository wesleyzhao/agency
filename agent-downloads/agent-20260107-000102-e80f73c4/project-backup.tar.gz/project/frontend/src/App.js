import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from './Dashboard';
import VoterDetail from './VoterDetail';
import Statistics from './Statistics';
import Visualizations from './Visualizations';
import Timeline from './Timeline';
import Historical from './Historical';
import Admin from './Admin';
import './App.css';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/voter/:voterId" element={<VoterDetail />} />
      <Route path="/statistics" element={<Statistics />} />
      <Route path="/visualizations" element={<Visualizations />} />
      <Route path="/timeline" element={<Timeline />} />
      <Route path="/historical" element={<Historical />} />
      <Route path="/admin" element={<Admin />} />
    </Routes>
  );
}

export default App;
