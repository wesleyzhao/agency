import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Admin.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function Admin() {
  const [stats, setStats] = useState(null);
  const [unverifiedVotes, setUnverifiedVotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [season, setSeason] = useState('2024-25');
  const [editingVote, setEditingVote] = useState(null);
  const [filterConfidence, setFilterConfidence] = useState('');
  const [filterSource, setFilterSource] = useState('');

  useEffect(() => {
    fetchAdminData();
  }, [season, filterConfidence, filterSource]);

  const fetchAdminData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch admin stats
      const statsResponse = await fetch(`${API_URL}/api/admin/stats?season=${season}`);
      if (!statsResponse.ok) throw new Error('Failed to fetch admin stats');
      const statsData = await statsResponse.json();
      setStats(statsData);

      // Fetch unverified votes with filters
      let unverifiedUrl = `${API_URL}/api/admin/unverified?season=${season}`;
      if (filterConfidence) unverifiedUrl += `&confidence=${filterConfidence}`;
      if (filterSource) unverifiedUrl += `&source_type=${filterSource}`;

      const unverifiedResponse = await fetch(unverifiedUrl);
      if (!unverifiedResponse.ok) throw new Error('Failed to fetch unverified votes');
      const unverifiedData = await unverifiedResponse.json();
      setUnverifiedVotes(unverifiedData.unverified_votes);

      setLoading(false);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleVerify = async (voteId, verified, credibilityTier = null) => {
    try {
      const body = { verified };
      if (credibilityTier) body.credibility_tier = credibilityTier;

      const response = await fetch(`${API_URL}/api/admin/votes/${voteId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to verify vote');
      }

      // Refresh data
      fetchAdminData();
      alert('Vote verification status updated!');
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleDelete = async (voteId, voterName, candidateName) => {
    if (!window.confirm(`Delete vote: ${voterName} → ${candidateName}?\n\nThis action cannot be undone.`)) {
      return;
    }

    try {
      const response = await fetch(`${API_URL}/api/admin/votes/${voteId}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete vote');
      }

      // Refresh data
      fetchAdminData();
      alert('Vote deleted successfully!');
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleEdit = (vote) => {
    setEditingVote({
      id: vote.id,
      ranking: vote.ranking,
      source_url: vote.source_url || '',
      source_type: vote.source_type || 'speculation',
      confidence: vote.confidence || 'medium',
      confidence_score: vote.confidence_score || 50,
      credibility_tier: vote.credibility_tier || 'unverified',
      extracted_text: vote.extracted_text || ''
    });
  };

  const handleSaveEdit = async () => {
    if (!editingVote) return;

    try {
      const response = await fetch(`${API_URL}/api/admin/votes/${editingVote.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ranking: parseInt(editingVote.ranking),
          source_url: editingVote.source_url,
          source_type: editingVote.source_type,
          confidence: editingVote.confidence,
          confidence_score: parseFloat(editingVote.confidence_score),
          credibility_tier: editingVote.credibility_tier,
          extracted_text: editingVote.extracted_text
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update vote');
      }

      setEditingVote(null);
      fetchAdminData();
      alert('Vote updated successfully!');
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  if (loading) {
    return (
      <div className="admin-container">
        <div className="loading">Loading admin data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="admin-container">
        <div className="error">
          <h2>Error Loading Admin Panel</h2>
          <p>{error}</p>
          <button onClick={fetchAdminData}>Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-container">
      <header className="admin-header">
        <div className="admin-header-content">
          <h1>🔧 Admin Panel</h1>
          <div className="admin-header-actions">
            <Link to="/" className="back-link">← Back to Dashboard</Link>
            <button onClick={fetchAdminData} className="refresh-btn">🔄 Refresh</button>
          </div>
        </div>
        <span className="season-badge">{season}</span>
      </header>

      {/* Admin Statistics */}
      <section className="admin-stats-section">
        <h2>Data Quality Overview</h2>
        <div className="admin-stats-grid">
          <div className="admin-stat-card">
            <div className="admin-stat-value">{stats.total_votes}</div>
            <div className="admin-stat-label">Total Votes</div>
          </div>
          <div className="admin-stat-card verified">
            <div className="admin-stat-value">{stats.verified_votes}</div>
            <div className="admin-stat-label">Verified Votes</div>
          </div>
          <div className="admin-stat-card unverified">
            <div className="admin-stat-value">{stats.unverified_votes}</div>
            <div className="admin-stat-label">Need Review</div>
          </div>
          <div className="admin-stat-card rate">
            <div className="admin-stat-value">{stats.verification_rate}%</div>
            <div className="admin-stat-label">Verification Rate</div>
          </div>
        </div>

        <div className="admin-breakdown-grid">
          <div className="breakdown-card">
            <h3>Confidence Breakdown</h3>
            <div className="breakdown-items">
              <div className="breakdown-item">
                <span className="confidence-badge high">High</span>
                <span className="breakdown-count">{stats.confidence_breakdown.high}</span>
              </div>
              <div className="breakdown-item">
                <span className="confidence-badge medium">Medium</span>
                <span className="breakdown-count">{stats.confidence_breakdown.medium}</span>
              </div>
              <div className="breakdown-item">
                <span className="confidence-badge low">Low</span>
                <span className="breakdown-count">{stats.confidence_breakdown.low}</span>
              </div>
            </div>
          </div>

          <div className="breakdown-card">
            <h3>Source Type Breakdown</h3>
            <div className="breakdown-items">
              {Object.entries(stats.source_breakdown).map(([type, count]) => (
                <div className="breakdown-item" key={type}>
                  <span className="source-badge">{type.replace('_', ' ')}</span>
                  <span className="breakdown-count">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="filters-section">
        <h2>Unverified Votes ({unverifiedVotes.length})</h2>
        <div className="filters">
          <div className="filter-group">
            <label>Confidence:</label>
            <select value={filterConfidence} onChange={(e) => setFilterConfidence(e.target.value)}>
              <option value="">All</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
          <div className="filter-group">
            <label>Source Type:</label>
            <select value={filterSource} onChange={(e) => setFilterSource(e.target.value)}>
              <option value="">All</option>
              <option value="official">Official</option>
              <option value="social_media">Social Media</option>
              <option value="news_article">News Article</option>
              <option value="reddit">Reddit</option>
              <option value="speculation">Speculation</option>
            </select>
          </div>
          {(filterConfidence || filterSource) && (
            <button
              className="clear-filters-btn"
              onClick={() => { setFilterConfidence(''); setFilterSource(''); }}
            >
              Clear Filters
            </button>
          )}
        </div>
      </section>

      {/* Unverified Votes List */}
      <section className="unverified-votes-section">
        {unverifiedVotes.length === 0 ? (
          <div className="no-data">
            <p>✅ No unverified votes found! All caught up.</p>
          </div>
        ) : (
          <div className="votes-list">
            {unverifiedVotes.map((vote) => (
              <div key={vote.id} className="vote-card">
                <div className="vote-header">
                  <div className="vote-title">
                    <span className="rank-badge">#{vote.ranking}</span>
                    <strong>{vote.voter.name}</strong> → <strong>{vote.candidate.name}</strong>
                  </div>
                  <div className="vote-meta">
                    <span className={`confidence-badge ${vote.confidence}`}>
                      {vote.confidence} {vote.confidence_score && `(${vote.confidence_score})`}
                    </span>
                    <span className="source-type-badge">{vote.source_type?.replace('_', ' ')}</span>
                  </div>
                </div>

                <div className="vote-details">
                  <div className="vote-info">
                    <div className="info-row">
                      <span className="info-label">Voter:</span>
                      <span>{vote.voter.name} ({vote.voter.outlet})</span>
                    </div>
                    <div className="info-row">
                      <span className="info-label">Candidate:</span>
                      <span>{vote.candidate.name} - {vote.candidate.team} ({vote.candidate.position})</span>
                    </div>
                    {vote.source_url && (
                      <div className="info-row">
                        <span className="info-label">Source:</span>
                        <a href={vote.source_url} target="_blank" rel="noopener noreferrer">
                          View Source 🔗
                        </a>
                      </div>
                    )}
                    {vote.announcement_date && (
                      <div className="info-row">
                        <span className="info-label">Date:</span>
                        <span>{new Date(vote.announcement_date).toLocaleDateString()}</span>
                      </div>
                    )}
                    {vote.extracted_text && (
                      <div className="info-row">
                        <span className="info-label">Extracted Text:</span>
                        <div className="extracted-text">{vote.extracted_text}</div>
                      </div>
                    )}
                    <div className="info-row">
                      <span className="info-label">Credibility:</span>
                      <span className={`credibility-tier ${vote.credibility_tier}`}>
                        {vote.credibility_tier}
                        {vote.credibility_score && ` (${vote.credibility_score})`}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="vote-actions">
                  <button
                    className="btn-verify"
                    onClick={() => handleVerify(vote.id, true, 'verified')}
                    title="Approve and mark as verified"
                  >
                    ✓ Approve & Verify
                  </button>
                  <button
                    className="btn-edit"
                    onClick={() => handleEdit(vote)}
                    title="Edit vote details"
                  >
                    ✏️ Edit
                  </button>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(vote.id, vote.voter.name, vote.candidate.name)}
                    title="Delete this vote (false positive)"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Edit Modal */}
      {editingVote && (
        <div className="modal-overlay" onClick={() => setEditingVote(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Edit Vote</h2>
            <form onSubmit={(e) => { e.preventDefault(); handleSaveEdit(); }}>
              <div className="form-group">
                <label>Ranking (1-5):</label>
                <input
                  type="number"
                  min="1"
                  max="5"
                  value={editingVote.ranking}
                  onChange={(e) => setEditingVote({...editingVote, ranking: e.target.value})}
                  required
                />
              </div>

              <div className="form-group">
                <label>Source URL:</label>
                <input
                  type="url"
                  value={editingVote.source_url}
                  onChange={(e) => setEditingVote({...editingVote, source_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>

              <div className="form-group">
                <label>Source Type:</label>
                <select
                  value={editingVote.source_type}
                  onChange={(e) => setEditingVote({...editingVote, source_type: e.target.value})}
                >
                  <option value="official">Official</option>
                  <option value="social_media">Social Media</option>
                  <option value="news_article">News Article</option>
                  <option value="reddit">Reddit</option>
                  <option value="speculation">Speculation</option>
                </select>
              </div>

              <div className="form-group">
                <label>Confidence Level:</label>
                <select
                  value={editingVote.confidence}
                  onChange={(e) => setEditingVote({...editingVote, confidence: e.target.value})}
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>

              <div className="form-group">
                <label>Confidence Score (0-100):</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={editingVote.confidence_score}
                  onChange={(e) => setEditingVote({...editingVote, confidence_score: e.target.value})}
                />
              </div>

              <div className="form-group">
                <label>Credibility Tier:</label>
                <select
                  value={editingVote.credibility_tier}
                  onChange={(e) => setEditingVote({...editingVote, credibility_tier: e.target.value})}
                >
                  <option value="verified">Verified</option>
                  <option value="official">Official</option>
                  <option value="reliable">Reliable</option>
                  <option value="unverified">Unverified</option>
                  <option value="speculation">Speculation</option>
                </select>
              </div>

              <div className="form-group">
                <label>Extracted Text:</label>
                <textarea
                  rows="4"
                  value={editingVote.extracted_text}
                  onChange={(e) => setEditingVote({...editingVote, extracted_text: e.target.value})}
                  placeholder="Original text where vote was found..."
                />
              </div>

              <div className="modal-actions">
                <button type="submit" className="btn-save">💾 Save Changes</button>
                <button type="button" onClick={() => setEditingVote(null)} className="btn-cancel">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <footer className="admin-footer">
        <Link to="/" className="back-link">← Back to Dashboard</Link>
      </footer>
    </div>
  );
}

export default Admin;
