import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './VoterDetail.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function VoterDetail() {
  const { voterId } = useParams();
  const [voterData, setVoterData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const season = '2024-25';

  useEffect(() => {
    fetchVoterDetails();
  }, [voterId]);

  const fetchVoterDetails = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/voters/${voterId}?season=${season}`);

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Voter not found');
        }
        throw new Error('Failed to fetch voter details');
      }

      const data = await response.json();
      setVoterData(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching voter details:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="voter-detail-container">
        <div className="loading">Loading voter details...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="voter-detail-container">
        <div className="error">
          <p>Error loading voter: {error}</p>
          <Link to="/" className="back-link">← Back to Dashboard</Link>
        </div>
      </div>
    );
  }

  if (!voterData) {
    return (
      <div className="voter-detail-container">
        <div className="error">
          <p>Voter not found</p>
          <Link to="/" className="back-link">← Back to Dashboard</Link>
        </div>
      </div>
    );
  }

  const stats = voterData.statistics || {};
  const ballot = voterData.ballot || [];
  const hasVotes = ballot.length > 0;

  const getConfidenceBadgeClass = (confidence) => {
    switch (confidence) {
      case 'high': return 'confidence-badge high';
      case 'medium': return 'confidence-badge medium';
      case 'low': return 'confidence-badge low';
      default: return 'confidence-badge';
    }
  };

  const getSourceTypeLabel = (sourceType) => {
    if (!sourceType) return 'Unknown';
    return sourceType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  // Feature #16: Credibility badge styling
  const getCredibilityBadgeClass = (tier) => {
    switch (tier) {
      case 'verified': return 'credibility-badge verified';
      case 'official': return 'credibility-badge official';
      case 'reliable': return 'credibility-badge reliable';
      case 'unverified': return 'credibility-badge unverified';
      case 'speculation': return 'credibility-badge speculation';
      default: return 'credibility-badge';
    }
  };

  const getCredibilityIcon = (tier) => {
    switch (tier) {
      case 'verified': return '✓';
      case 'official': return '★';
      case 'reliable': return '◆';
      case 'unverified': return '?';
      case 'speculation': return '~';
      default: return '•';
    }
  };

  const getCredibilityLabel = (tier) => {
    if (!tier) return 'Unverified';
    return tier.charAt(0).toUpperCase() + tier.slice(1);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="voter-detail-container">
      <div className="voter-detail-header">
        <Link to="/" className="back-link">← Back to Dashboard</Link>

        <div className="voter-info-header">
          <div className="voter-main-info">
            <h1>{voterData.name}</h1>
            {voterData.outlet && <p className="voter-outlet">{voterData.outlet}</p>}
            {voterData.location && <p className="voter-location">📍 {voterData.location}</p>}
          </div>

          <div className="voter-meta">
            {voterData.twitter_handle && (
              <a
                href={`https://twitter.com/${voterData.twitter_handle.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="twitter-link"
              >
                <span className="twitter-icon">🐦</span> {voterData.twitter_handle}
              </a>
            )}
          </div>
        </div>

        {voterData.bio && (
          <div className="voter-bio">
            <p>{voterData.bio}</p>
          </div>
        )}
      </div>

      <div className="voter-stats-grid">
        <div className="stat-card">
          <div className="stat-label">Total Votes</div>
          <div className="stat-value">{stats.total_votes || 0}</div>
        </div>

        <div className="stat-card">
          <div className="stat-label">Verified Votes</div>
          <div className="stat-value">{stats.verified_votes || 0}</div>
        </div>

        <div className="stat-card">
          <div className="stat-label">High Confidence</div>
          <div className="stat-value">{stats.high_confidence_votes || 0}</div>
        </div>

        <div className="stat-card">
          <div className="stat-label">Ballot Status</div>
          <div className="stat-value">
            {stats.has_full_ballot ? (
              <span className="badge success">Full</span>
            ) : hasVotes ? (
              <span className="badge partial">Partial</span>
            ) : (
              <span className="badge none">None</span>
            )}
          </div>
        </div>
      </div>

      <div className="voter-ballot-section">
        <h2>
          {season} Season MVP Ballot
          {stats.first_place_pick && <span className="first-pick-badge">1st: {stats.first_place_pick}</span>}
        </h2>

        {hasVotes ? (
          <div className="ballot-list">
            {ballot.map((vote, idx) => (
              <div key={vote.id || idx} className="ballot-item">
                <div className="ballot-rank">
                  <div className="rank-number">#{vote.ranking || '?'}</div>
                </div>

                <div className="ballot-content">
                  <div className="ballot-candidate">
                    <h3>{vote.candidate}</h3>
                    {vote.team && (
                      <p className="candidate-team">
                        {vote.team} {vote.position && `• ${vote.position}`}
                      </p>
                    )}
                  </div>

                  <div className="ballot-meta">
                    <div className="ballot-badges">
                      {vote.verified && <span className="badge verified">✓ Verified</span>}
                      <span className={getConfidenceBadgeClass(vote.confidence)}>
                        {vote.confidence || 'unknown'}
                      </span>
                      {vote.confidence_score && (
                        <span className="confidence-score">
                          Score: {vote.confidence_score.toFixed(1)}
                        </span>
                      )}
                      {/* Feature #16: Credibility badge */}
                      {vote.credibility_tier && (
                        <span className={getCredibilityBadgeClass(vote.credibility_tier)} title={`Credibility: ${getCredibilityLabel(vote.credibility_tier)}`}>
                          {getCredibilityIcon(vote.credibility_tier)} {getCredibilityLabel(vote.credibility_tier)}
                        </span>
                      )}
                      {vote.has_direct_quote && (
                        <span className="badge info-badge" title="Source contains direct quote">
                          💬 Direct Quote
                        </span>
                      )}
                    </div>

                    <div className="ballot-info">
                      <p className="source-type">
                        <strong>Source:</strong> {getSourceTypeLabel(vote.source_type)}
                      </p>
                      {vote.announcement_date && (
                        <p className="announcement-date">
                          <strong>Announced:</strong> {formatDate(vote.announcement_date)}
                        </p>
                      )}
                    </div>

                    {vote.source_url && (
                      <a
                        href={vote.source_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="source-link-button"
                      >
                        🔗 View Source
                      </a>
                    )}

                    {vote.extracted_text && (
                      <details className="extracted-text-details">
                        <summary>View extracted text</summary>
                        <p className="extracted-text">{vote.extracted_text}</p>
                      </details>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="no-ballot">
            <p>This voter has not publicly disclosed their MVP ballot yet.</p>
            <p>Check back later or follow them on social media for updates.</p>
          </div>
        )}
      </div>

      {voterData.all_seasons && voterData.all_seasons.length > ballot.length && (
        <div className="historical-votes-section">
          <h2>Historical Votes (All Seasons)</h2>
          <div className="historical-list">
            {voterData.all_seasons.map((vote, idx) => (
              <div key={idx} className="historical-item">
                <span className="historical-season">{vote.season}</span>
                <span className="historical-rank">#{vote.ranking}</span>
                <span className="historical-candidate">{vote.candidate}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="voter-actions">
        <Link to="/" className="action-button">
          ← Back to All Voters
        </Link>
        <button onClick={fetchVoterDetails} className="action-button refresh">
          🔄 Refresh Data
        </button>
      </div>
    </div>
  );
}

export default VoterDetail;
