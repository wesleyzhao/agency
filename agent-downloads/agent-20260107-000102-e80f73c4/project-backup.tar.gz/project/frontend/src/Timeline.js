import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Timeline.css';

function Timeline() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timelineData, setTimelineData] = useState(null);
  const [groupBy, setGroupBy] = useState('day');
  const [expandedDates, setExpandedDates] = useState(new Set());

  const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

  useEffect(() => {
    fetchTimelineData();
  }, [groupBy]);

  const fetchTimelineData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_URL}/api/timeline?season=2024-25&group_by=${groupBy}`);
      if (!response.ok) {
        throw new Error('Failed to fetch timeline data');
      }
      const data = await response.json();
      setTimelineData(data);
      // Auto-expand first 3 dates
      if (data.timeline && data.timeline.length > 0) {
        const firstThree = new Set(data.timeline.slice(0, 3).map(entry => entry.date));
        setExpandedDates(firstThree);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleExpand = (date) => {
    const newExpanded = new Set(expandedDates);
    if (newExpanded.has(date)) {
      newExpanded.delete(date);
    } else {
      newExpanded.add(date);
    }
    setExpandedDates(newExpanded);
  };

  const expandAll = () => {
    const allDates = new Set(timelineData.timeline.map(entry => entry.date));
    setExpandedDates(allDates);
  };

  const collapseAll = () => {
    setExpandedDates(new Set());
  };

  if (loading) {
    return (
      <div className="timeline-container">
        <div className="loading">Loading timeline data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="timeline-container">
        <div className="error">
          <h3>Error loading timeline</h3>
          <p>{error}</p>
          <button onClick={fetchTimelineData}>Retry</button>
        </div>
      </div>
    );
  }

  if (!timelineData || !timelineData.timeline || timelineData.timeline.length === 0) {
    return (
      <div className="timeline-container">
        <div className="timeline-header">
          <h1>📅 Vote Announcement Timeline</h1>
          <Link to="/" className="back-link">← Back to Dashboard</Link>
        </div>
        <div className="empty-state">
          <p>No vote announcements with dates found for this season.</p>
          <Link to="/" className="button">Go to Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="timeline-container">
      <div className="timeline-header">
        <div className="header-left">
          <h1>📅 Vote Announcement Timeline</h1>
          <span className="season-badge">{timelineData.season}</span>
        </div>
        <div className="header-right">
          <Link to="/" className="back-link">← Back to Dashboard</Link>
        </div>
      </div>

      <div className="timeline-summary">
        <div className="summary-card">
          <div className="summary-label">Timeline Entries</div>
          <div className="summary-value">{timelineData.summary.total_timeline_entries}</div>
        </div>
        <div className="summary-card">
          <div className="summary-label">Total Votes</div>
          <div className="summary-value">{timelineData.summary.total_votes}</div>
        </div>
        <div className="summary-card">
          <div className="summary-label">First Place Votes</div>
          <div className="summary-value">{timelineData.summary.total_first_place_votes}</div>
        </div>
        <div className="summary-card">
          <div className="summary-label">Unique Voters</div>
          <div className="summary-value">{timelineData.summary.unique_voters}</div>
        </div>
        <div className="summary-card">
          <div className="summary-label">Candidates Mentioned</div>
          <div className="summary-value">{timelineData.summary.unique_candidates}</div>
        </div>
      </div>

      <div className="timeline-controls">
        <div className="group-by-controls">
          <label>Group by:</label>
          <button
            className={groupBy === 'day' ? 'active' : ''}
            onClick={() => setGroupBy('day')}
          >
            Day
          </button>
          <button
            className={groupBy === 'week' ? 'active' : ''}
            onClick={() => setGroupBy('week')}
          >
            Week
          </button>
          <button
            className={groupBy === 'month' ? 'active' : ''}
            onClick={() => setGroupBy('month')}
          >
            Month
          </button>
        </div>
        <div className="expand-controls">
          <button onClick={expandAll}>Expand All</button>
          <button onClick={collapseAll}>Collapse All</button>
          <button onClick={fetchTimelineData}>Refresh</button>
        </div>
      </div>

      <div className="timeline">
        {timelineData.timeline.map((entry, index) => (
          <div key={entry.date} className="timeline-entry">
            <div className="timeline-marker">
              <div className="timeline-dot"></div>
              {index < timelineData.timeline.length - 1 && <div className="timeline-line"></div>}
            </div>
            <div className="timeline-content">
              <div
                className="timeline-date-header"
                onClick={() => toggleExpand(entry.date)}
              >
                <h3>{entry.display_date}</h3>
                <div className="date-stats">
                  <span className="stat-badge">{entry.stats.total_votes} votes</span>
                  <span className="stat-badge">{entry.stats.first_place_votes} first place</span>
                  <span className="stat-badge">{entry.stats.unique_voters} voters</span>
                  {entry.stats.verified_votes > 0 && (
                    <span className="stat-badge verified">{entry.stats.verified_votes} verified</span>
                  )}
                </div>
                <div className="expand-icon">
                  {expandedDates.has(entry.date) ? '▼' : '▶'}
                </div>
              </div>

              {expandedDates.has(entry.date) && (
                <div className="timeline-votes">
                  {entry.votes.map((vote) => (
                    <div key={vote.id} className="timeline-vote-card">
                      <div className="vote-header">
                        <div className="rank-badge rank-{vote.ranking}">#{vote.ranking}</div>
                        <div className="vote-info">
                          <Link to={`/voter/${vote.voter_id}`} className="voter-name">
                            {vote.voter_name}
                          </Link>
                          {vote.voter_outlet && (
                            <span className="voter-outlet"> ({vote.voter_outlet})</span>
                          )}
                          <span className="vote-arrow"> → </span>
                          <span className="candidate-name">{vote.candidate_name}</span>
                          {vote.candidate_team && (
                            <span className="candidate-team"> ({vote.candidate_team})</span>
                          )}
                        </div>
                      </div>
                      <div className="vote-meta">
                        {vote.confidence && (
                          <span className={`confidence-badge confidence-${vote.confidence}`}>
                            {vote.confidence}
                          </span>
                        )}
                        {vote.source_type && (
                          <span className="source-type-badge">
                            {vote.source_type.replace('_', ' ')}
                          </span>
                        )}
                        {vote.verified && (
                          <span className="verified-badge">✓ verified</span>
                        )}
                        {vote.source_url && (
                          <a
                            href={vote.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="source-link"
                          >
                            🔗 source
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="timeline-footer">
        <div className="date-range">
          {timelineData.summary.earliest_announcement && timelineData.summary.latest_announcement && (
            <p>
              Showing announcements from <strong>{timelineData.summary.earliest_announcement}</strong> to <strong>{timelineData.summary.latest_announcement}</strong>
            </p>
          )}
        </div>
        <Link to="/" className="button">← Back to Dashboard</Link>
      </div>
    </div>
  );
}

export default Timeline;
