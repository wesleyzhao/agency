/**
 * Historical MVP Voting Data Page - Feature #17
 *
 * This component displays historical NFL MVP voting data from previous seasons,
 * showing winners, vote distributions, and voter ballots.
 */
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Historical.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function Historical() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [historicalData, setHistoricalData] = useState([]);
  const [allSeasons, setAllSeasons] = useState([]);
  const [selectedSeason, setSelectedSeason] = useState('all');
  const [expandedSeasons, setExpandedSeasons] = useState(new Set());

  // Fetch historical data
  useEffect(() => {
    fetchHistoricalData();
  }, [selectedSeason]);

  const fetchHistoricalData = async () => {
    setLoading(true);
    setError(null);

    try {
      const url = selectedSeason === 'all'
        ? `${API_URL}/api/historical`
        : `${API_URL}/api/historical?season=${selectedSeason}`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setHistoricalData(data.historical_data || []);
      setAllSeasons(data.all_seasons || []);

      // Auto-expand the first season
      if (data.historical_data && data.historical_data.length > 0) {
        setExpandedSeasons(new Set([data.historical_data[0].season]));
      }
    } catch (err) {
      setError(err.message);
      console.error('Error fetching historical data:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleSeasonExpanded = (season) => {
    const newExpanded = new Set(expandedSeasons);
    if (newExpanded.has(season)) {
      newExpanded.delete(season);
    } else {
      newExpanded.add(season);
    }
    setExpandedSeasons(newExpanded);
  };

  const handleRefresh = () => {
    fetchHistoricalData();
  };

  if (loading) {
    return (
      <div className="historical-page">
        <div className="loading">
          <div className="spinner"></div>
          <p>Loading historical data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="historical-page">
        <div className="error-container">
          <h2>⚠️ Error Loading Data</h2>
          <p>{error}</p>
          <button onClick={handleRefresh} className="retry-button">
            Try Again
          </button>
          <Link to="/" className="back-link">← Back to Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="historical-page">
      {/* Header */}
      <div className="historical-header">
        <div className="header-content">
          <Link to="/" className="back-link">← Back to Dashboard</Link>
          <h1>📜 Historical MVP Voting Data</h1>
          <p className="subtitle">View past NFL MVP voting results and voter ballots</p>
        </div>
        <div className="header-actions">
          <select
            value={selectedSeason}
            onChange={(e) => setSelectedSeason(e.target.value)}
            className="season-filter"
          >
            <option value="all">All Seasons</option>
            {allSeasons.map(season => (
              <option key={season} value={season}>{season}</option>
            ))}
          </select>
          <button onClick={handleRefresh} className="refresh-button">
            🔄 Refresh
          </button>
        </div>
      </div>

      {/* No data message */}
      {historicalData.length === 0 && (
        <div className="no-data">
          <p>No historical voting data available.</p>
          <p className="hint">Historical data can be seeded using the backend script.</p>
        </div>
      )}

      {/* Historical seasons */}
      {historicalData.map((seasonData) => (
        <div key={seasonData.season} className="season-card">
          {/* Season header */}
          <div
            className="season-header"
            onClick={() => toggleSeasonExpanded(seasonData.season)}
          >
            <div className="season-info">
              <h2 className="season-title">
                {seasonData.season} Season
                {expandedSeasons.has(seasonData.season) ? ' ▼' : ' ▶'}
              </h2>
              <div className="season-meta">
                <span className="winner-badge">🏆 Winner: {seasonData.winner}</span>
                <span className="voter-count">👥 {seasonData.total_voters} voters</span>
                <span className="candidate-count">🎯 {seasonData.candidates.length} candidates</span>
              </div>
            </div>
          </div>

          {/* Season content (expandable) */}
          {expandedSeasons.has(seasonData.season) && (
            <div className="season-content">
              {/* Candidates table */}
              <div className="candidates-section">
                <h3>Final Results</h3>
                <div className="table-wrapper">
                  <table className="candidates-table">
                    <thead>
                      <tr>
                        <th>Rank</th>
                        <th>Candidate</th>
                        <th>Team</th>
                        <th>Pos</th>
                        <th>1st</th>
                        <th>2nd</th>
                        <th>3rd</th>
                        <th>4th</th>
                        <th>5th</th>
                        <th>Points</th>
                      </tr>
                    </thead>
                    <tbody>
                      {seasonData.candidates.map((candidate, index) => (
                        <tr key={index} className={index === 0 ? 'winner-row' : ''}>
                          <td className="rank-cell">
                            {index === 0 && <span className="trophy">🏆</span>}
                            {index + 1}
                          </td>
                          <td className="candidate-name">{candidate.name}</td>
                          <td>{candidate.team}</td>
                          <td>{candidate.position}</td>
                          <td className="vote-count">{candidate.first_place_votes}</td>
                          <td className="vote-count">{candidate.second_place_votes}</td>
                          <td className="vote-count">{candidate.third_place_votes}</td>
                          <td className="vote-count">{candidate.fourth_place_votes}</td>
                          <td className="vote-count">{candidate.fifth_place_votes}</td>
                          <td className="points-cell">{candidate.total_points}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="points-legend">
                  Points System: 1st = 10pts, 2nd = 7pts, 3rd = 5pts, 4th = 3pts, 5th = 1pt
                </p>
              </div>

              {/* Voter ballots */}
              {seasonData.voter_ballots && seasonData.voter_ballots.length > 0 && (
                <div className="ballots-section">
                  <h3>Voter Ballots ({seasonData.voter_ballots.length})</h3>
                  <div className="ballots-grid">
                    {seasonData.voter_ballots.map((voterBallot, idx) => (
                      <div key={idx} className="ballot-card">
                        <div className="ballot-header">
                          <h4>{voterBallot.voter_name}</h4>
                          <p className="outlet">{voterBallot.outlet}</p>
                          {voterBallot.twitter_handle && (
                            <a
                              href={`https://twitter.com/${voterBallot.twitter_handle.replace('@', '')}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="twitter-link"
                            >
                              {voterBallot.twitter_handle}
                            </a>
                          )}
                        </div>
                        <div className="ballot-votes">
                          {voterBallot.ballot.map((vote, vIdx) => (
                            <div key={vIdx} className="ballot-vote">
                              <span className="vote-rank">#{vote.ranking}</span>
                              <div className="vote-info">
                                <span className="vote-candidate">{vote.candidate}</span>
                                <span className="vote-team">{vote.team} • {vote.position}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ))}

      {/* Footer */}
      {historicalData.length > 0 && (
        <div className="historical-footer">
          <Link to="/" className="back-link">← Back to Dashboard</Link>
          <p className="data-note">
            Historical data represents publicly available NFL MVP voting results.
          </p>
        </div>
      )}
    </div>
  );
}

export default Historical;
