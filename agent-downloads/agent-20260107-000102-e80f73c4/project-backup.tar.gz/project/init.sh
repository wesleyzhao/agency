#!/bin/bash

echo "=========================================="
echo "NFL MVP Voter Tracker - Initialization"
echo "=========================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✓ Python 3 found"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Warning: Node.js is not installed. Frontend will not be available."
    echo "Install Node.js from https://nodejs.org/"
    SKIP_FRONTEND=1
else
    echo "✓ Node.js found"
fi

# Create virtual environment for Python
echo ""
echo "Creating Python virtual environment..."
python3 -m venv venv

if [ $? -ne 0 ]; then
    echo "Error: Failed to create virtual environment"
    exit 1
fi

echo "✓ Virtual environment created"

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install Python dependencies
echo ""
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r backend/requirements.txt

if [ $? -ne 0 ]; then
    echo "Warning: Some Python packages failed to install"
    echo "You may need to install them manually"
fi

echo "✓ Python dependencies installed"

# Create data directories
echo ""
echo "Creating data directories..."
mkdir -p data/raw
mkdir -p data/processed
touch data/raw/.gitkeep
touch data/processed/.gitkeep
echo "✓ Data directories created"

# Initialize database
echo ""
echo "Initializing database..."
cd backend/database
python init_db.py
cd ../..

if [ $? -eq 0 ]; then
    echo "✓ Database initialized with seed data"
else
    echo "Warning: Database initialization had issues"
fi

# Install frontend dependencies
if [ -z "$SKIP_FRONTEND" ]; then
    echo ""
    echo "Installing frontend dependencies..."
    cd frontend
    npm install
    
    if [ $? -eq 0 ]; then
        echo "✓ Frontend dependencies installed"
    else
        echo "Warning: Frontend dependencies installation failed"
    fi
    cd ..
fi

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo ""
    echo "Creating .env file..."
    cat > .env << 'ENVEOF'
# Database
DATABASE_URL=sqlite:///./data/mvp_tracker.db

# API
API_PORT=5000
API_HOST=0.0.0.0

# Frontend
REACT_APP_API_URL=http://localhost:5000

# Reddit API (optional - get from https://www.reddit.com/prefs/apps)
REDDIT_CLIENT_ID=
REDDIT_CLIENT_SECRET=
REDDIT_USER_AGENT=NFL_MVP_Tracker/1.0

# Web Scraping
SCRAPE_DELAY=2
USER_AGENT=Mozilla/5.0 (compatible; MVPTracker/1.0)
ENVEOF
    echo "✓ .env file created"
fi

# Make scripts executable
echo ""
echo "Making scripts executable..."
chmod +x scripts/initial_research.py
chmod +x init.sh

echo ""
echo "=========================================="
echo "Initialization Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo ""
echo "1. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "2. Run the initial research script:"
echo "   python scripts/initial_research.py"
echo ""
echo "3. Start the backend server:"
echo "   cd backend && python app.py"
echo ""
if [ -z "$SKIP_FRONTEND" ]; then
    echo "4. Start the frontend (in a new terminal):"
    echo "   cd frontend && npm start"
    echo ""
fi
echo "5. Open http://localhost:3000 in your browser"
echo ""
echo "For more information, see README.md"
echo ""
