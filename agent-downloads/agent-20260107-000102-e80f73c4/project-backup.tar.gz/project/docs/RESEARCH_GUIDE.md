# NFL MVP Voter Research Guide

This guide helps you manually research and find NFL MVP voters and their publicly announced votes.

## Research Strategy

### 1. Google News Search

Use these search queries:
- `"NFL MVP voter" ballot revealed 2025`
- `"AP NFL MVP" voting breakdown`
- `sportswriter MVP vote announced`
- `[journalist name] MVP ballot`

### 2. Reddit Research

Search these subreddits:
- r/nfl - Main NFL discussion
- r/ravens - Lamar Jackson fans
- r/buffalobills - Josh Allen fans
- r/eagles - Saquon Barkley fans

Search terms:
- "MVP voter"
- "ballot revealed"
- "who voted for"

### 3. Twitter/X Research

**Search Syntax:**
```
MVP vote from:minakimes
MVP ballot from:TomBrady
"my MVP vote" filter:verified
```

**Known/Potential Voter Handles:**
- @minakimes (ESPN)
- @TomBrady (Fox Sports)
- @TonyDungy (NBC Sports)
- @TedyBruschi (ESPN)
- @AdamSchefter (ESPN)
- @RapSheet (NFL Network)
- @PeterKingNFL (NBC Sports)
- @AlbertBreer (Sports Illustrated)
- @ProFootballTalk (NBC Sports)

### 4. News Outlet Sites

Check these sites directly:
- **ESPN**: espn.com/nfl
- **Fox Sports**: foxsports.com/nfl
- **NBC Sports**: nbcsports.com/nfl
- **CBS Sports**: cbssports.com/nfl
- **The Athletic**: theathletic.com/nfl
- **The Ringer**: theringer.com/nfl
- **Sports Illustrated**: si.com/nfl

### 5. Historical Voter Research

Check Pro Football Reference for previous years' voters:
- https://www.pro-football-reference.com/awards/

Many voters are consistent year-over-year.

## How to Verify Information

### High Confidence Sources
- Direct tweet from the voter
- Article written by the voter announcing their ballot
- Official announcement on their media outlet

### Medium Confidence Sources
- News article citing the voter's ballot
- Podcast where they discuss their vote
- Radio show mention

### Low Confidence Sources
- Speculation in comments
- Unverified social media claims
- "I heard that..." statements

## Adding New Voters

When you find a new voter:

1. **Verify the source** - Is it credible?
2. **Document everything**:
   - Voter name
   - Their media outlet
   - Full ballot if available (1st through 5th place)
   - Source URL
   - Date of announcement
   - Confidence level

3. **Add to database** via:
   - Web interface (manual entry)
   - Direct database update
   - API endpoint

## Key Dates

- **Regular Season End**: January 5, 2025
- **Voting Deadline**: Week after regular season
- **Award Announcement**: February 7, 2025
- **Ballots Released**: After announcement

## Tips

1. **Search around award announcement dates** - Many voters reveal their picks after the winner is announced
2. **Check article comment sections** - Sometimes voters engage in comments
3. **Follow NFL insiders** - They often RT voter announcements
4. **Be patient** - Not all 50 voters will publicly reveal their ballots
5. **Cross-reference** - Verify findings across multiple sources

## Common Voter Outlets

AP NFL MVP voters typically come from:
- Major newspapers (NYT, Washington Post, LA Times, etc.)
- Local beat writers (one from each team's market)
- National media (ESPN, Fox, NBC, CBS)
- Sports websites (The Athletic, SI, etc.)

## Known Voters (2024-25 Season)

Based on research:

1. **Tom Brady** (Fox Sports) - Full ballot revealed
2. **Mina Kimes** (ESPN) - Full ballot revealed
3. **Tony Dungy** (NBC Sports) - Partial ballot
4. **Tedy Bruschi** (ESPN) - Partial ballot

**Status: 4 of 50 voters identified (8%)**

## Next Steps

Continue research focusing on:
- Local beat writers for each NFL team
- Prominent NFL journalists who have been voters before
- Award show coverage and post-show interviews
