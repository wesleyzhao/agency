# NFL MVP Voter Research - 2024 Season

## Research Date: January 7, 2026

## Summary
This document contains research on the 2024 NFL MVP voting, including the complete list of 50 voters and all publicly disclosed ballots.

---

## VOTING RESULTS

**Final Results:**
- **Winner: Josh Allen (Buffalo Bills)** - 27 first-place votes, 21 second-place votes, 1 third-place vote = 378 points
- **Runner-up: Lamar Jackson (Baltimore Ravens)** - 22 first-place votes, 26 second-place votes, 1 fourth-place vote = 352 points
- Saquon Barkley, Joe Burrow, Jared Goff, and others also received votes

**Note:** There was an error in the initial tabulation. Tony Dungy's ballot was accidentally replaced by a duplicate of Diante Lee's ballot, reducing the total from 50 to 49 voters. The AP corrected this after the fact by removing the duplicate.

---

## COMPLETE LIST OF 50 AP NFL MVP VOTERS (2024)

1. Emmanuel Acho - FS1
2. Greg Auman - Fox Sports
3. Howard Balzer - PHNX radio
4. Jarrett Bell - USA Today
5. Dave Birkett - Detroit Free Press
6. Tom Brady - Fox Sports
7. Tedy Bruschi - ESPN
8. Vic Carucci - WGRZ radio
9. Mark Craig - Minneapolis Star Tribune
10. Tom Curran - NBC Sports Boston
11. Charles Davis - CBS Sports
12. Nate Davis - USA Today
13. Howard Deneroff - Westwood One
14. Tony Dungy - NBC Sports (ballot removed due to error)
15. Jori Epstein - Yahoo Sports
16. Boomer Esiason - CBS Sports
17. Doug Farrar - USA Today Sports Media
18. Mike Florio - Pro Football Talk
19. Reuben Frank - NBC Sports Philadelphia
20. Rich Gannon - SiriusXM
21. Jonathan Jones - CBS Sports
22. Lindsay Jones - The Ringer
23. Mike Jones - The Athletic
24. Clark Judge - Talk of Fame Network
25. Ira Kaufman - JoeBucsFan.com
26. Mina Kimes - ESPN
27. Peter King - NBC Sports
28. Pat Kirwan - SiriusXM
29. Diante Lee - The Ringer (ballot counted twice by error)
30. Jeff Legwold - ESPN
31. Jim Miller - SiriusXM
32. Sam Monson - The 33rd Team (formerly Pro Football Focus)
33. Bruce Murray - SiriusXM
34. Gary Myers - NFL author
35. Laura Okmin - Fox Sports
36. Dan Orlovsky - ESPN
37. Nick Pavlatos - SiriusXM
38. Dan Pompei - The Athletic
39. Nora Princiotti - The Ringer
40. Lorenzo Reyes - USA Today
41. Charles Robinson - Yahoo Sports
42. Dianna Russini - The Athletic
43. Mike Sando - The Athletic
44. Aaron Schatz - FTN Network
45. Adam Schein - CBS Sports
46. Tom Silverstein - Milwaukee Journal-Sentinel
47. Chris Simms - NBC Sports
48. Armando Salguero - Outkick.com
49. Mike Tirico - NBC Sports
50. Ben Volin - Boston Globe
51. Charean Williams - Pro Football Talk

---

## BALLOTS THAT WERE PUBLICLY DISCLOSED

### 1. JIM MILLER (SiriusXM) - CONTROVERSIAL 4TH PLACE VOTE FOR JACKSON
**Ballot:**
1. Josh Allen
2. Saquon Barkley
3. Joe Burrow
4. Lamar Jackson
5. Patrick Mahomes

**Notes:**
- Only voter to rank Jackson outside the top 2
- Has history of controversial votes (denied Peyton Manning unanimous MVP in 2014, left Jackson off All-Pro in 2019)
- Defended his vote saying "I sleep very good with how I voted"

### 2. TOM BRADY (Fox Sports)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Saquon Barkley
4. Ja'Marr Chase
5. Joe Burrow

**Notes:**
- One of only 2 voters (with Tedy Bruschi) to rank Ja'Marr Chase 4th
- Chose Chase over his QB Joe Burrow

### 3. TEDY BRUSCHI (ESPN)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Saquon Barkley
4. Ja'Marr Chase
5. Patrick Mahomes

**Notes:**
- Former Patriots teammate of Tom Brady
- Also ranked Chase 4th like Brady
- Left Joe Burrow completely off his ballot

### 4. MIKE FLORIO (Pro Football Talk)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Saquon Barkley
4. Jared Goff
5. Joe Burrow

**Notes:**
- Had previously expressed uncertainty about his vote
- Voted for Jackson despite Allen being the betting favorite

### 5. AARON SCHATZ (FTN Network)
**Ballot:**
1. Lamar Jackson (confirmed for All-Pro 1st team QB)
2. Josh Allen (confirmed for All-Pro 2nd team QB)
3-5. Not fully disclosed in search results

**Notes:**
- Uses advanced analytics (DVOA, DYAR) in his voting
- In 2023, was the lone voter who denied Jackson a unanimous MVP (voted for Allen)
- In 2024, his analytics favored Jackson

### 6. DAN ORLOVSKY (ESPN)
**Ballot:**
1. Josh Allen
2-5. Not disclosed

**Notes:**
- Publicly stated he voted for Josh Allen over Lamar Jackson

### 7. EMMANUEL ACHO (FS1)
**Ballot:**
1. Josh Allen
2-5. Not disclosed

**Notes:**
- Publicly revealed his vote on "The Facility"
- Reasoning: "Josh Allen has to do just as much, if not more, with less"
- Stated Bills offense "just has Josh Allen" while Ravens have "two Hall of Famers"

### 8. PETER KING (NBC Sports)
**Ballot:**
Top 3: Josh Allen, Lamar Jackson, Patrick Mahomes (order disclosed)
Full ranking not disclosed

**Notes:**
- Explained his vote emphasizes "Most Valuable Player" not "Most Outstanding Player"
- Acknowledged Jackson had best statistical year but prioritized Allen's value to his team

### 9. DIANNA RUSSINI (The Athletic)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Joe Burrow
4. Saquon Barkley
5. Jared Goff

**Notes:**
- Did not know votes would be made public
- Faced backlash after her ballot was revealed
- Defended her vote: "I felt like there were games in which the defense in Buffalo helped Josh more"
- One of 23 voters who had Jackson first

### 10. SAM MONSON (The 33rd Team, formerly PFF)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Joe Burrow
4. Saquon Barkley
5. Sam Darnold

**Notes:**
- One of 3 voters who included Sam Darnold on their MVP ballot
- Left PFF to join The 33rd Team in 2024

### 11. BEN VOLIN (Boston Globe)
**Ballot:**
1. Josh Allen
2-4. Not fully disclosed
5. Sam Darnold (confirmed)

**Notes:**
- Published full explanation in Boston Globe article
- One of 3 voters who included Sam Darnold on their MVP ballot
- Defended Darnold inclusion for his role in Vikings' 14-3 record

### 12. DOUG FARRAR (USA Today Sports Media)
**Ballot:**
1. Lamar Jackson
2. Josh Allen
3. Joe Burrow
4. Saquon Barkley
5. Patrick Mahomes

### 13. CHARLES ROBINSON (Yahoo Sports)
**Ballot:**
1. Josh Allen
2-3. Not disclosed
4-5. Ja'Marr Chase listed 5th, Joe Burrow in 3rd place

**Notes:**
- Published his full 2024 NFL awards ballot in January 2025

### 14. TONY DUNGY (NBC Sports) - BALLOT NOT COUNTED
**What Actually Happened:**
- Dungy's ballot was accidentally replaced by a duplicate of Diante Lee's ballot
- Dungy noticed the error when published ballots showed him voting for Lamar Jackson 1st, which he denied
- AP removed his ballot from tabulation entirely, reducing total to 49 voters
- His actual ballot was never counted

**Controversy:**
- AP didn't explain why Dungy's actual ballot wasn't used instead of removing it
- Dungy's actual vote could have altered the outcome

### 15. DIANTE LEE (The Ringer)
**Ballot:**
- Counted twice due to AP error
- One copy replaced Tony Dungy's ballot
- Exact ballot choices not disclosed in search results

---

## VOTERS WHOSE BALLOTS WERE NOT FOUND/DISCLOSED

The following voters' specific ballots were not found in the research:

1. Greg Auman (Fox Sports)
2. Howard Balzer (PHNX radio)
3. Jarrett Bell (USA Today)
4. Dave Birkett (Detroit Free Press)
5. Vic Carucci (WGRZ radio)
6. Mark Craig (Minneapolis Star Tribune)
7. Tom Curran (NBC Sports Boston)
8. Charles Davis (CBS Sports)
9. Nate Davis (USA Today)
10. Howard Deneroff (Westwood One)
11. Jori Epstein (Yahoo Sports)
12. Boomer Esiason (CBS Sports)
13. Reuben Frank (NBC Sports Philadelphia)
14. Rich Gannon (SiriusXM)
15. Jonathan Jones (CBS Sports)
16. Lindsay Jones (The Ringer)
17. Mike Jones (The Athletic)
18. Clark Judge (Talk of Fame Network)
19. Ira Kaufman (JoeBucsFan.com)
20. Mina Kimes (ESPN)
21. Pat Kirwan (SiriusXM)
22. Jeff Legwold (ESPN)
23. Bruce Murray (SiriusXM)
24. Gary Myers (NFL author)
25. Laura Okmin (Fox Sports)
26. Nick Pavlatos (SiriusXM)
27. Dan Pompei (The Athletic)
28. Nora Princiotti (The Ringer)
29. Lorenzo Reyes (USA Today)
30. Mike Sando (The Athletic)
31. Adam Schein (CBS Sports)
32. Tom Silverstein (Milwaukee Journal-Sentinel)
33. Chris Simms (NBC Sports)
34. Armando Salguero (Outkick.com)
35. Mike Tirico (NBC Sports)
36. Charean Williams (Pro Football Talk)

**Note:** The AP released all ballots according to reports, but many individual ballots were not found through web searches. They may be available on Pro Football Reference or in the official AP voting records.

---

## KEY FINDINGS

### Sam Darnold Votes
Three voters included Sam Darnold on their MVP ballot (all 5th place):
1. Sam Monson (The 33rd Team)
2. Ben Volin (Boston Globe)
3. Third voter not identified in search results

Darnold finished 10th in MVP voting overall.

### Ja'Marr Chase Votes
At least 4 voters included Ja'Marr Chase on their ballots:
1. Tom Brady (4th place)
2. Tedy Bruschi (4th place)
3. Two others who left Joe Burrow off their ballots entirely

11 voters left Joe Burrow completely off their ballot.

### The "Invalid Ballot" Mystery - SOLVED
- During tabulation, Diante Lee's ballot from The Ringer was counted twice
- The duplicate replaced Tony Dungy's ballot
- Dungy noticed because it showed him voting for Jackson, which he denied
- AP removed the duplicate, reducing total from 50 to 49 voters
- However, AP removed Dungy's ballot entirely rather than counting his actual vote
- This may have affected the final outcome

### Voting Transparency Controversy
- This was the first year the AP publicly disclosed all individual ballots
- Voters were NOT informed beforehand that their ballots would be made public
- This caused controversy, especially for voters like Dianna Russini who faced backlash
- The AP updated their procedures to inform voters going forward

---

## VOTING BREAKDOWN

**First-Place Votes:**
- Josh Allen: 27
- Lamar Jackson: 22 (or 23 depending on source - discrepancy due to ballot error)

**Margin of Victory:**
- Allen won by just 26 points (378-352)
- One of the closest MVP races in NFL history since 2003

**Jim Miller's Impact:**
- Miller's 4th place vote for Jackson likely cost Jackson the MVP
- If Miller had voted Jackson 1st or 2nd, the race would have been even closer or Jackson might have won

---

## SOURCES CONSULTED

1. Pro Football Reference - 2024 Awards Voting
2. NBC Sports / Pro Football Talk - Multiple articles on voting
3. CBS Sports - Voting analysis and voter disclosures
4. The Athletic - Voter ballots and analysis
5. Yahoo Sports - Individual voter ballots
6. FTN Fantasy - Aaron Schatz's ballot
7. Sports Illustrated - Various voter disclosures
8. Boston Globe - Ben Volin's ballot
9. Awful Announcing - Coverage of controversial votes and ballot errors

---

## REMAINING QUESTIONS

1. Where can the complete individual ballots for all 49 voters be accessed?
2. Who was the third voter who included Sam Darnold on their ballot?
3. What were the exact choices on Tony Dungy's actual ballot that was not counted?
4. What were the exact choices on Diante Lee's ballot that was counted twice?
5. Several voters' complete ballots (all 5 positions) were not fully disclosed in public sources

---

## NOTES

- The AP uses a weighted voting system: 5 points for 1st place, 3 for 2nd, 2 for 3rd, 1 for 4th, 0.5 for 5th
- This voting format started in 2022
- Voters are selected based on expertise covering the NFL regularly
- The mix includes traditional journalists, former players, and analysts
- Some voters (like Tom Brady) are active broadcasters with limited journalism experience, which has been controversial
