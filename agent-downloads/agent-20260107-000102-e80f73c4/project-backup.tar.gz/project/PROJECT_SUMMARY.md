# NFL MVP Voter Tracker - Project Summary

## Overview

This application is designed to research, track, and identify the 50 Associated Press (AP) NFL MVP voters and their publicly announced votes. The AP doesn't disclose the full voter list until after winners are announced, but some voters share their selections through social media, articles, and other public channels. This tool aggregates that information.

## Current Status

### ✅ Completed Setup Tasks

1. **Feature List** - Created comprehensive list of 30 features in `feature_list.json`
2. **Project Structure** - Set up organized directory structure with backend, frontend, scripts, and data folders
3. **Database Models** - Implemented SQLAlchemy models for voters, candidates, votes, and logging
4. **Backend API** - Created Flask API with endpoints for voter/candidate/vote queries
5. **Frontend UI** - Built React dashboard showing voter statistics and confirmed voters
6. **Initialization Script** - Created `init.sh` for automated project setup
7. **Git Repository** - Initialized git with initial commits
8. **Research Tool** - Built initial research script with search strategies
9. **Documentation** - Added README, research guide, and configuration files

### 📊 Research Findings (So Far)

**Confirmed Voters: 4 of 50 (8%)**

1. **Tom Brady** (Fox Sports) ✓
   - Full ballot: Lamar Jackson, Josh Allen, Saquon Barkley, Ja'Marr Chase, Joe Burrow
   - Source: Multiple news articles
   - Confidence: HIGH

2. **Mina Kimes** (ESPN) ✓
   - Full ballot: Lamar Jackson, Josh Allen, Joe Burrow, Saquon Barkley, Jayden Daniels
   - Source: Twitter/X
   - Confidence: HIGH

3. **Tony Dungy** (NBC Sports) ✓
   - Voted for: Lamar Jackson (ranking unknown)
   - Confidence: MEDIUM

4. **Tedy Bruschi** (ESPN) ✓
   - Voted for: Lamar Jackson (ranking unknown)
   - Confidence: MEDIUM

**Remaining to find: 46 voters**

## Project Structure

```
.
├── backend/
│   ├── app.py                 # Flask API server
│   ├── database/
│   │   ├── models.py         # SQLAlchemy database models
│   │   └── init_db.py        # Database initialization & seed data
│   ├── requirements.txt      # Python dependencies
│   ├── api/                  # API endpoints (to be implemented)
│   ├── scrapers/             # Web scraping modules (to be implemented)
│   ├── nlp/                  # NLP extraction (to be implemented)
│   └── utils/                # Utility functions (to be implemented)
│
├── frontend/
│   ├── src/
│   │   ├── App.js            # Main React component
│   │   ├── App.css           # Styling
│   │   ├── index.js          # React entry point
│   │   └── index.css         # Global styles
│   ├── public/
│   │   └── index.html        # HTML template
│   ├── package.json          # Node dependencies
│   ├── components/           # React components (to be implemented)
│   ├── pages/                # Page components (to be implemented)
│   └── services/             # API services (to be implemented)
│
├── scripts/
│   └── initial_research.py   # Research tool for finding voters
│
├── data/
│   ├── research_findings.json # Current research results
│   ├── raw/                  # Raw scraped data
│   └── processed/            # Processed data
│
├── config/
│   └── scraper_config.yaml   # Scraping configuration
│
├── docs/
│   └── RESEARCH_GUIDE.md     # Manual research strategies
│
├── tests/                    # Test suites (to be implemented)
│
├── feature_list.json         # Complete feature list
├── init.sh                   # Setup script
├── README.md                 # Main documentation
└── .gitignore               # Git ignore rules
```

## Tech Stack

### Backend
- **Python 3.8+**
- **Flask** - Web framework
- **SQLAlchemy** - ORM
- **BeautifulSoup** - Web scraping
- **PRAW** - Reddit API
- **spaCy** - NLP processing

### Frontend
- **React 18** - UI framework
- **Axios** - HTTP client
- **Chart.js** - Data visualization

### Database
- **SQLite** (development)
- **PostgreSQL** (production ready)

## Getting Started

### Quick Start

```bash
# 1. Run the initialization script
./init.sh

# 2. Activate virtual environment
source venv/bin/activate

# 3. Run initial research
python scripts/initial_research.py

# 4. Start backend (terminal 1)
cd backend && python app.py

# 5. Start frontend (terminal 2)
cd frontend && npm start

# 6. Open browser
http://localhost:3000
```

## Key Features Implemented

### Database Schema
- **Voters Table**: Store voter information (name, outlet, social media)
- **Candidates Table**: NFL MVP candidates by season
- **Votes Table**: Voter ballots with ranking, sources, confidence scores
- **Sources Table**: URL deduplication
- **Scraping Logs**: Activity tracking

### API Endpoints
- `GET /api/voters` - List all voters
- `GET /api/voters/:id` - Voter details with votes
- `GET /api/candidates` - List candidates
- `GET /api/votes` - All votes for a season
- `GET /api/stats` - Summary statistics

### Research Tools
- Search strategy recommendations
- Reddit search queries
- Twitter/X search patterns
- News outlet checklist
- Historical voter reference

## Next Steps for Development

### Phase 1: Core Functionality (Current)
- [x] Project setup
- [x] Database models
- [x] Basic API
- [x] Frontend shell
- [x] Research tool
- [ ] Database initialization with full setup
- [ ] Complete API integration with frontend

### Phase 2: Automation
- [ ] Reddit scraper implementation
- [ ] Google News scraper
- [ ] NLP extraction module
- [ ] Scheduled scraping jobs
- [ ] Automated voter detection

### Phase 3: Enhanced Features
- [ ] Advanced search and filtering
- [ ] Data visualizations
- [ ] Export functionality
- [ ] Admin verification interface
- [ ] Notification system

### Phase 4: Polish
- [ ] Comprehensive testing
- [ ] Performance optimization
- [ ] Mobile responsiveness
- [ ] Production deployment
- [ ] Documentation completion

## Research Strategy

### Manual Research Areas
1. **Twitter/X Advanced Search**
   - Search journalist handles around award dates
   - Look for "MVP vote" or "ballot" keywords
   
2. **Reddit Analysis**
   - Monitor r/nfl, team subreddits
   - Post-award announcement discussions
   
3. **News Outlets**
   - ESPN, Fox Sports, NBC Sports, CBS Sports
   - The Athletic, Sports Illustrated, The Ringer
   - Local beat writers from each team

4. **Historical Data**
   - Pro Football Reference voting records
   - Previous year voter lists

### Automated Research (To Implement)
- Scheduled Reddit scraping
- Google News aggregation
- Social media monitoring
- NLP-based extraction

## 2024-25 MVP Final Results

- **Winner**: Josh Allen (Buffalo Bills) - 383 points, 27 first-place votes
- **Runner-up**: Lamar Jackson (Baltimore Ravens) - 362 points, 23 first-place votes
- **Third**: Saquon Barkley (Philadelphia Eagles) - 120 points
- **Fourth**: Joe Burrow (Cincinnati Bengals) - 82 points
- **Fifth**: Jared Goff (Detroit Lions) - 47 points

## Contact & Resources

- **Project Documentation**: See README.md
- **Research Guide**: See docs/RESEARCH_GUIDE.md
- **Feature Tracking**: See feature_list.json

## License

MIT License - See LICENSE file for details

---

**Last Updated**: January 7, 2026
**Status**: Initial Setup Complete, Ready for Development
**Next Milestone**: Implement automated scrapers and complete API integration
