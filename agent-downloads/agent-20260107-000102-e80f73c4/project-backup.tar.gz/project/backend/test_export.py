"""
Test suite for export functionality - Feature #15
Tests CSV and JSON export endpoints for voters, votes, candidates, and full reports
"""
import requests
import json
import csv
import io
import sys

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
CYAN = '\033[96m'
RESET = '\033[0m'

BASE_URL = 'http://localhost:5000'

def print_success(message):
    print(f"{GREEN}✓ {message}{RESET}")

def print_error(message):
    print(f"{RED}✗ {message}{RESET}")

def print_info(message):
    print(f"{CYAN}{message}{RESET}")

def print_section(message):
    print(f"\n{YELLOW}{'='*60}")
    print(f"{message}")
    print(f"{'='*60}{RESET}\n")

def test_health_check():
    """Test if backend server is running"""
    try:
        response = requests.get(f'{BASE_URL}/api/voters')
        if response.status_code == 200:
            print_success("Backend server is running")
            return True
        else:
            print_error(f"Backend returned status {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print_error("Cannot connect to backend server")
        print_info("Please start the backend with: cd backend && python3 app.py")
        return False

def test_export_voters_json():
    """Test exporting voters as JSON"""
    print_info("\n📋 Testing voters export (JSON)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/voters?format=json&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Check headers
        if 'application/json' not in response.headers.get('Content-Type', ''):
            print_error("Content-Type is not JSON")
            return False

        if 'attachment' not in response.headers.get('Content-Disposition', ''):
            print_error("Response is not a downloadable file")
            return False

        # Parse JSON
        data = response.json()

        if not isinstance(data, list):
            print_error("JSON data is not a list")
            return False

        print_success(f"Voters export (JSON) works - {len(data)} voters exported")

        # Show sample data
        if len(data) > 0:
            print_info(f"\nSample voter data:")
            sample = data[0]
            print(f"  Name: {sample.get('name')}")
            print(f"  Outlet: {sample.get('outlet')}")
            print(f"  Twitter: {sample.get('twitter_handle')}")
            print(f"  Vote Count: {sample.get('vote_count')}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_voters_csv():
    """Test exporting voters as CSV"""
    print_info("\n📊 Testing voters export (CSV)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/voters?format=csv&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Check headers
        if 'text/csv' not in response.headers.get('Content-Type', ''):
            print_error("Content-Type is not CSV")
            return False

        # Parse CSV
        csv_data = response.text
        reader = csv.DictReader(io.StringIO(csv_data))
        rows = list(reader)

        if len(rows) == 0:
            print_error("CSV is empty")
            return False

        # Check required columns
        required_columns = ['id', 'name', 'outlet', 'twitter_handle', 'vote_count']
        first_row = rows[0]
        for col in required_columns:
            if col not in first_row:
                print_error(f"Missing column: {col}")
                return False

        print_success(f"Voters export (CSV) works - {len(rows)} voters exported")
        print_info(f"Columns: {', '.join(first_row.keys())}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_votes_json():
    """Test exporting votes as JSON"""
    print_info("\n🗳️  Testing votes export (JSON)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/votes?format=json&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Parse JSON
        data = response.json()

        if not isinstance(data, list):
            print_error("JSON data is not a list")
            return False

        print_success(f"Votes export (JSON) works - {len(data)} votes exported")

        # Show sample data
        if len(data) > 0:
            print_info(f"\nSample vote data:")
            sample = data[0]
            print(f"  Voter: {sample.get('voter_name')}")
            print(f"  Candidate: {sample.get('candidate_name')}")
            print(f"  Ranking: {sample.get('ranking')}")
            print(f"  Confidence: {sample.get('confidence')} (Score: {sample.get('confidence_score')})")
            print(f"  Verified: {sample.get('verified')}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_votes_csv():
    """Test exporting votes as CSV"""
    print_info("\n📊 Testing votes export (CSV)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/votes?format=csv&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Parse CSV
        csv_data = response.text
        reader = csv.DictReader(io.StringIO(csv_data))
        rows = list(reader)

        print_success(f"Votes export (CSV) works - {len(rows)} votes exported")

        if len(rows) > 0:
            print_info(f"Columns: {', '.join(rows[0].keys())}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_candidates_json():
    """Test exporting candidates as JSON"""
    print_info("\n🏈 Testing candidates export (JSON)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/candidates?format=json&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Parse JSON
        data = response.json()

        if not isinstance(data, list):
            print_error("JSON data is not a list")
            return False

        print_success(f"Candidates export (JSON) works - {len(data)} candidates exported")

        # Show sample data
        if len(data) > 0:
            print_info(f"\nTop 3 candidates:")
            for i, candidate in enumerate(data[:3]):
                print(f"  #{i+1}: {candidate.get('name')} ({candidate.get('team')})")
                print(f"      1st place votes: {candidate.get('first_place_votes')}")
                print(f"      Weighted points: {candidate.get('weighted_points')}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_candidates_csv():
    """Test exporting candidates as CSV"""
    print_info("\n📊 Testing candidates export (CSV)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/candidates?format=csv&season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Parse CSV
        csv_data = response.text
        reader = csv.DictReader(io.StringIO(csv_data))
        rows = list(reader)

        print_success(f"Candidates export (CSV) works - {len(rows)} candidates exported")

        if len(rows) > 0:
            required_columns = ['name', 'team', 'first_place_votes', 'weighted_points']
            first_row = rows[0]
            print_info(f"Columns present: {all(col in first_row for col in required_columns)}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_export_full_report():
    """Test exporting full comprehensive report"""
    print_info("\n📑 Testing full report export (JSON)...")

    try:
        response = requests.get(f'{BASE_URL}/api/export/full-report?season=2024-25')

        if response.status_code != 200:
            print_error(f"Export failed with status {response.status_code}")
            return False

        # Parse JSON
        data = response.json()

        # Check structure
        required_keys = ['metadata', 'statistics', 'voters', 'candidates', 'votes']
        for key in required_keys:
            if key not in data:
                print_error(f"Missing key in report: {key}")
                return False

        print_success("Full report export works")

        # Display metadata
        print_info(f"\nReport Metadata:")
        metadata = data['metadata']
        print(f"  Season: {metadata.get('season')}")
        print(f"  Export Date: {metadata.get('export_date')}")
        print(f"  Total Voters: {metadata.get('total_voters')}")
        print(f"  Known Voters: {metadata.get('known_voters')}")
        print(f"  Total Votes: {metadata.get('total_votes')}")
        print(f"  Total Candidates: {metadata.get('total_candidates')}")

        # Display statistics
        print_info(f"\nReport Statistics:")
        stats = data['statistics']
        print(f"  Voters with Disclosed Votes: {stats.get('voters_with_disclosed_votes')}")
        print(f"  First Place Votes: {stats.get('first_place_votes_disclosed')}")
        print(f"  Verified Votes: {stats.get('verified_votes')}")
        print(f"  High Confidence Votes: {stats.get('high_confidence_votes')}")
        print(f"  Completion: {stats.get('completion_percentage'):.1f}%")

        # Check data arrays
        print_info(f"\nReport Data:")
        print(f"  Voters in report: {len(data['voters'])}")
        print(f"  Candidates in report: {len(data['candidates'])}")
        print(f"  Votes in report: {len(data['votes'])}")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False

def test_filename_generation():
    """Test that export endpoints generate proper filenames"""
    print_info("\n📁 Testing filename generation...")

    tests = [
        ('/api/export/voters?format=json&season=2024-25', 'voters_2024-25.json'),
        ('/api/export/voters?format=csv&season=2024-25', 'voters_2024-25.csv'),
        ('/api/export/votes?format=json&season=2024-25', 'votes_2024-25.json'),
        ('/api/export/candidates?format=csv&season=2024-25', 'candidates_2024-25.csv'),
        ('/api/export/full-report?season=2024-25', 'mvp_full_report_2024-25.json')
    ]

    all_passed = True

    for endpoint, expected_filename in tests:
        try:
            response = requests.get(f'{BASE_URL}{endpoint}')
            content_disposition = response.headers.get('Content-Disposition', '')

            if expected_filename in content_disposition:
                print_success(f"Filename correct: {expected_filename}")
            else:
                print_error(f"Filename incorrect for {endpoint}")
                print_info(f"  Expected: {expected_filename}")
                print_info(f"  Got: {content_disposition}")
                all_passed = False

        except Exception as e:
            print_error(f"Exception testing {endpoint}: {e}")
            all_passed = False

    return all_passed

def main():
    print_section("Testing Export Functionality - Feature #15")

    # Track results
    tests = [
        ("Health Check", test_health_check),
        ("Voters JSON Export", test_export_voters_json),
        ("Voters CSV Export", test_export_voters_csv),
        ("Votes JSON Export", test_export_votes_json),
        ("Votes CSV Export", test_export_votes_csv),
        ("Candidates JSON Export", test_export_candidates_json),
        ("Candidates CSV Export", test_export_candidates_csv),
        ("Full Report Export", test_export_full_report),
        ("Filename Generation", test_filename_generation)
    ]

    results = []

    for test_name, test_func in tests:
        result = test_func()
        results.append((test_name, result))

        if not result and test_name == "Health Check":
            print_error("\nCannot continue without backend server")
            sys.exit(1)

    # Summary
    print_section("Test Summary")

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        status = f"{GREEN}PASSED{RESET}" if result else f"{RED}FAILED{RESET}"
        print(f"  {test_name}: {status}")

    print(f"\n{BLUE}Total: {passed}/{total} tests passed{RESET}")

    if passed == total:
        print_success("\nAll tests PASSED! ✓")
        print_info("\nYou can now use the export functionality:")
        print_info("  - Visit http://localhost:5000/api/export/voters?format=csv")
        print_info("  - Visit http://localhost:5000/api/export/votes?format=json")
        print_info("  - Visit http://localhost:5000/api/export/full-report")
        print_info("\nAdd export buttons to the frontend to download data!")
        return 0
    else:
        print_error(f"\n{total - passed} test(s) FAILED")
        return 1

if __name__ == '__main__':
    sys.exit(main())
