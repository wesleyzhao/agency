#!/usr/bin/env python3
"""
Test script for the voter detail page endpoint - Feature #12
Tests the enhanced /api/voters/<id> endpoint
"""

import requests
import json
import sys

API_URL = "http://localhost:5000"

def test_voter_detail_endpoint():
    """Test the voter detail endpoint"""
    print("\n" + "="*60)
    print("Testing Voter Detail Page Endpoint - Feature #12")
    print("="*60 + "\n")

    # First, check if server is running
    try:
        response = requests.get(f"{API_URL}/api/health", timeout=5)
        if response.status_code == 200:
            print("✓ Backend server is running\n")
        else:
            print("✗ Backend server returned unexpected status\n")
            return False
    except requests.exceptions.RequestException as e:
        print(f"✗ Cannot connect to backend server at {API_URL}")
        print(f"  Error: {e}")
        print(f"  Make sure to run: cd backend && python3 app.py\n")
        return False

    # Get list of voters first
    print("Fetching voters list...")
    response = requests.get(f"{API_URL}/api/voters")

    if response.status_code != 200:
        print(f"✗ Failed to get voters list: {response.status_code}")
        return False

    voters = response.json()

    if not voters:
        print("✗ No voters found in database")
        print("  Note: You may need to add some test data first")
        return False

    print(f"✓ Found {len(voters)} voters in database\n")

    # Test voter detail for first voter
    test_voter = voters[0]
    voter_id = test_voter['id']
    voter_name = test_voter['name']

    print(f"Testing voter detail endpoint for: {voter_name} (ID: {voter_id})")
    print("-" * 60)

    response = requests.get(f"{API_URL}/api/voters/{voter_id}?season=2024-25")

    if response.status_code != 200:
        print(f"✗ Failed to get voter details: {response.status_code}")
        return False

    voter_data = response.json()

    # Validate response structure
    required_fields = ['id', 'name', 'ballot', 'statistics', 'season']
    missing_fields = [field for field in required_fields if field not in voter_data]

    if missing_fields:
        print(f"✗ Response missing required fields: {missing_fields}")
        return False

    print("✓ Response contains all required fields\n")

    # Display voter information
    print(f"\033[96mVoter Details:\033[0m")
    print(f"  Name: {voter_data.get('name')}")
    print(f"  Outlet: {voter_data.get('outlet', 'N/A')}")
    print(f"  Twitter: {voter_data.get('twitter_handle', 'N/A')}")
    print(f"  Location: {voter_data.get('location', 'N/A')}")
    print(f"  Season: {voter_data.get('season')}")

    # Display statistics
    stats = voter_data.get('statistics', {})
    print(f"\n\033[96mStatistics:\033[0m")
    print(f"  Total Votes: {stats.get('total_votes', 0)}")
    print(f"  Verified Votes: {stats.get('verified_votes', 0)}")
    print(f"  High Confidence Votes: {stats.get('high_confidence_votes', 0)}")
    print(f"  Has Full Ballot: {stats.get('has_full_ballot', False)}")
    print(f"  First Place Pick: {stats.get('first_place_pick', 'N/A')}")

    # Display ballot
    ballot = voter_data.get('ballot', [])
    if ballot:
        print(f"\n\033[96mBallot ({len(ballot)} votes):\033[0m")
        for vote in ballot:
            print(f"  #{vote.get('ranking')}: {vote.get('candidate')} ({vote.get('team', 'N/A')})")
            print(f"     Confidence: {vote.get('confidence')} (Score: {vote.get('confidence_score', 'N/A')})")
            print(f"     Source: {vote.get('source_type', 'N/A')}")
            print(f"     Verified: {'✓' if vote.get('verified') else '✗'}")
            if vote.get('source_url'):
                print(f"     URL: {vote.get('source_url')[:60]}...")
            print()
    else:
        print(f"\n\033[93m  No votes disclosed for this season\033[0m\n")

    # Test invalid voter ID
    print("-" * 60)
    print("Testing error handling with invalid voter ID...")
    response = requests.get(f"{API_URL}/api/voters/99999?season=2024-25")

    if response.status_code == 404:
        print("✓ Correctly returns 404 for non-existent voter\n")
    else:
        print(f"✗ Expected 404, got {response.status_code}\n")
        return False

    print("\033[92m" + "="*60)
    print("All tests PASSED! ✓")
    print("="*60 + "\033[0m\n")

    print("\033[96mFrontend Testing Instructions:\033[0m")
    print("1. Start the frontend: cd frontend && npm start")
    print("2. Open browser to http://localhost:3000")
    print("3. Click on any voter name to view their detail page")
    print("4. Verify all information displays correctly")
    print("5. Test navigation back to dashboard")
    print()

    return True


if __name__ == "__main__":
    success = test_voter_detail_endpoint()
    sys.exit(0 if success else 1)
