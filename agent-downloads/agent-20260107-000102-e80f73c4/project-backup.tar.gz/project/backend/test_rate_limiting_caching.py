"""
Comprehensive test suite for rate limiting and caching features (Feature #20)

Tests:
1. RateLimiter functionality
2. ResponseCache functionality
3. EnhancedScraper integration
4. Per-domain rate limiting
5. Exponential backoff on errors
6. Cache hit/miss scenarios
7. Cache expiration
8. Statistics tracking
"""
import os
import sys
import time
import shutil
from pathlib import Path

# Add parent directory to path for backend imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Now import directly from backend.scrapers
from backend.scrapers.rate_limiter import RateLimiter, RequestThrottler
from backend.scrapers.response_cache import ResponseCache
from backend.scrapers.enhanced_scraper import EnhancedScraper


# ANSI color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'


def print_success(message):
    print(f"{GREEN}✓ {message}{RESET}")


def print_error(message):
    print(f"{RED}✗ {message}{RESET}")


def print_info(message):
    print(f"{CYAN}ℹ {message}{RESET}")


def print_warning(message):
    print(f"{YELLOW}⚠ {message}{RESET}")


def print_section(title):
    print(f"\n{CYAN}{'=' * 60}")
    print(f"{title}")
    print(f"{'=' * 60}{RESET}\n")


def test_rate_limiter():
    """Test RateLimiter functionality"""
    print_section("Test 1: RateLimiter Functionality")

    limiter = RateLimiter(
        global_delay=0.5,
        per_domain_delay=1.0,
        max_retries=3,
        backoff_factor=2.0
    )

    # Test 1.1: Basic rate limiting
    print_info("Testing basic rate limiting...")
    url1 = "https://example.com/page1"
    url2 = "https://example.com/page2"

    start_time = time.time()
    limiter.wait(url1)
    limiter.wait(url2)
    elapsed = time.time() - start_time

    if elapsed >= 1.0:  # Should wait at least per_domain_delay
        print_success(f"Per-domain delay enforced ({elapsed:.2f}s >= 1.0s)")
    else:
        print_error(f"Per-domain delay too short ({elapsed:.2f}s < 1.0s)")

    # Test 1.2: Different domains
    print_info("Testing different domains...")
    url3 = "https://different.com/page1"

    start_time = time.time()
    limiter.wait(url3)
    elapsed = time.time() - start_time

    if elapsed >= 0.5 and elapsed < 1.0:  # Should use global_delay
        print_success(f"Global delay used for different domain ({elapsed:.2f}s)")
    else:
        print_warning(f"Delay timing: {elapsed:.2f}s (expected ~0.5s)")

    # Test 1.3: Error recording and adaptive limiting
    print_info("Testing error recording and adaptive limiting...")
    test_url = "https://test.com/page1"

    limiter.record_error(test_url, Exception("Test error"))
    limiter.record_error(test_url, Exception("Test error 2"))

    adaptive_delay = limiter.get_adaptive_delay(limiter.extract_domain(test_url))
    expected_delay = 1.0 * (2.0 ** 2)  # backoff_factor^error_count

    if adaptive_delay == expected_delay:
        print_success(f"Adaptive delay calculated correctly: {adaptive_delay}s")
    else:
        print_warning(f"Adaptive delay: {adaptive_delay}s (expected {expected_delay}s)")

    # Test 1.4: Success resets errors
    print_info("Testing success resets errors...")
    limiter.record_success(test_url)
    adaptive_delay_after = limiter.get_adaptive_delay(limiter.extract_domain(test_url))

    if adaptive_delay_after == limiter.per_domain_delay:
        print_success("Error count reset after success")
    else:
        print_error(f"Error count not reset: delay={adaptive_delay_after}s")

    # Test 1.5: Retry limits
    print_info("Testing retry limits...")
    retry_url = "https://retry.com/page"

    for i in range(3):
        limiter.record_error(retry_url, Exception(f"Error {i+1}"))

    if not limiter.should_retry(retry_url):
        print_success("Max retries enforced correctly")
    else:
        print_error("Max retries not enforced")

    # Test 1.6: Statistics
    print_info("Testing statistics...")
    stats = limiter.get_statistics()

    print(f"  Total requests: {stats['total_requests']}")
    print(f"  Total delays: {stats['total_delays']}")
    print(f"  Avg delay time: {stats['avg_delay_time']}s")
    print(f"  Domains tracked: {stats['domains_tracked']}")
    print(f"  Domains with errors: {stats['domains_with_errors']}")

    if stats['total_requests'] > 0:
        print_success("Statistics tracking working")
    else:
        print_error("Statistics not tracking requests")


def test_request_throttler():
    """Test RequestThrottler functionality"""
    print_section("Test 2: RequestThrottler Functionality")

    throttler = RequestThrottler(max_requests=5, time_window=2)

    # Make 5 requests quickly
    print_info("Making 5 requests (should not throttle)...")
    start_time = time.time()

    for i in range(5):
        wait_time = throttler.wait_if_needed()
        if wait_time > 0:
            print_error(f"Unexpected throttling on request {i+1}")

    elapsed = time.time() - start_time

    if elapsed < 1.0:
        print_success(f"First 5 requests completed quickly ({elapsed:.2f}s)")
    else:
        print_warning(f"Requests took longer than expected: {elapsed:.2f}s")

    # 6th request should be throttled
    print_info("Making 6th request (should throttle)...")
    start_time = time.time()
    wait_time = throttler.wait_if_needed()
    elapsed = time.time() - start_time

    if wait_time > 0:
        print_success(f"Throttling enforced on 6th request (waited {wait_time:.2f}s)")
    else:
        print_warning("No throttling on 6th request (may have waited long enough)")

    # Test current rate
    print_info("Testing current rate calculation...")
    rate = throttler.get_current_rate()
    print(f"  Current rate: {rate:.2f} requests/second")

    if rate > 0:
        print_success("Rate calculation working")
    else:
        print_warning("Rate calculation returned 0")


def test_response_cache():
    """Test ResponseCache functionality"""
    print_section("Test 3: ResponseCache Functionality")

    # Use test cache directory
    cache_dir = "backend/scrapers/test_cache"
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)

    cache = ResponseCache(
        cache_dir=cache_dir,
        ttl_seconds=2,  # Short TTL for testing
        max_cache_size_mb=1
    )

    # Test 3.1: Cache miss
    print_info("Testing cache miss...")
    result = cache.get("https://example.com/page1")

    if result is None:
        print_success("Cache miss handled correctly")
    else:
        print_error("Unexpected cache hit")

    # Test 3.2: Cache set and hit
    print_info("Testing cache set and hit...")
    test_content = "<html><body>Test content</body></html>"
    cache.set("https://example.com/page1", test_content)

    cached = cache.get("https://example.com/page1")

    if cached == test_content:
        print_success("Cache set and retrieval working")
    else:
        print_error(f"Cache content mismatch: {cached}")

    # Test 3.3: Cache expiration
    print_info("Testing cache expiration (waiting 3 seconds)...")
    time.sleep(3)  # Wait for TTL to expire

    expired = cache.get("https://example.com/page1")

    if expired is None:
        print_success("Cache expiration working")
    else:
        print_error("Cache did not expire")

    # Test 3.4: Multiple cache entries
    print_info("Testing multiple cache entries...")
    for i in range(5):
        cache.set(f"https://example.com/page{i}", f"Content {i}")

    stats = cache.get_statistics()
    print(f"  Cached items: {stats['cached_items']}")
    print(f"  Cache size: {stats['size_mb']} MB")
    print(f"  Hit rate: {stats['hit_rate']}%")

    if stats['cached_items'] == 5:
        print_success("Multiple cache entries stored")
    else:
        print_warning(f"Cached items: {stats['cached_items']} (expected 5)")

    # Test 3.5: Cache invalidation
    print_info("Testing cache invalidation...")
    invalidated = cache.invalidate("https://example.com/page0")

    if invalidated:
        print_success("Cache invalidation working")
    else:
        print_error("Cache invalidation failed")

    # Test 3.6: Cache cleanup
    print_info("Testing cache cleanup...")
    cache.clear()
    stats_after = cache.get_statistics()

    if stats_after['cached_items'] == 0:
        print_success("Cache cleared successfully")
    else:
        print_error(f"Cache not cleared: {stats_after['cached_items']} items remaining")

    # Cleanup test cache directory
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)


class TestScraper(EnhancedScraper):
    """Concrete test scraper for testing purposes"""
    def search(self, query: str, **kwargs):
        """Dummy search implementation"""
        return []


def test_enhanced_scraper():
    """Test EnhancedScraper integration"""
    print_section("Test 4: EnhancedScraper Integration")

    # Use test cache directory
    cache_dir = "backend/scrapers/test_cache_enhanced"
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)

    # Create enhanced scraper with caching enabled
    scraper = TestScraper(
        rate_limit_delay=0.5,
        enable_caching=True,
        cache_ttl=60,
        enable_throttling=False
    )

    # Override cache directory
    if scraper.cache:
        scraper.cache.cache_dir = Path(cache_dir)
        scraper.cache.cache_dir.mkdir(parents=True, exist_ok=True)

    # Test 4.1: Fetch with rate limiting
    print_info("Testing fetch with rate limiting...")

    # Use httpbin.org for testing (reliable test endpoint)
    test_url = "https://httpbin.org/html"

    start_time = time.time()
    content1 = scraper.fetch_url(test_url)
    elapsed1 = time.time() - start_time

    if content1:
        print_success(f"First fetch successful ({elapsed1:.2f}s)")
    else:
        print_warning("First fetch failed (httpbin.org may be down)")

    # Test 4.2: Second fetch should use cache
    print_info("Testing cache hit on second fetch...")

    start_time = time.time()
    content2 = scraper.fetch_url(test_url)
    elapsed2 = time.time() - start_time

    if content2 and elapsed2 < 0.1:  # Cache should be instant
        print_success(f"Cache hit (fetch took {elapsed2:.2f}s)")
    elif content2:
        print_warning(f"Fetch successful but slow ({elapsed2:.2f}s) - may not have used cache")
    else:
        print_warning("Second fetch failed")

    # Test 4.3: Statistics
    print_info("Testing statistics...")
    stats = scraper.get_statistics()

    print(f"\nRate Limiting Stats:")
    print(f"  Total requests: {stats['rate_limiting']['total_requests']}")
    print(f"  Total delays: {stats['rate_limiting']['total_delays']}")

    if 'caching' in stats:
        print(f"\nCaching Stats:")
        print(f"  Hits: {stats['caching']['hits']}")
        print(f"  Misses: {stats['caching']['misses']}")
        print(f"  Hit rate: {stats['caching']['hit_rate']}%")
        print(f"  Cached items: {stats['caching']['cached_items']}")

    if stats['rate_limiting']['total_requests'] > 0:
        print_success("Statistics tracking working")
    else:
        print_warning("No requests tracked in statistics")

    # Test 4.4: Cache invalidation
    print_info("Testing cache invalidation...")
    invalidated = scraper.invalidate_cache(test_url)

    if invalidated:
        print_success("Cache invalidation successful")
    else:
        print_warning("Cache invalidation returned False")

    # Cleanup
    if os.path.exists(cache_dir):
        shutil.rmtree(cache_dir)


def test_error_handling():
    """Test error handling and retry logic"""
    print_section("Test 5: Error Handling and Retry Logic")

    scraper = TestScraper(
        rate_limit_delay=0.1,  # Short delay for testing
        enable_caching=False,  # Disable cache for error testing
        enable_throttling=False
    )

    # Test with invalid URL (should trigger retries)
    print_info("Testing retry logic with invalid URL...")

    invalid_url = "https://this-domain-definitely-does-not-exist-12345.com"

    start_time = time.time()
    result = scraper.fetch_url(invalid_url, timeout=2)
    elapsed = time.time() - start_time

    if result is None:
        print_success(f"Failed gracefully after retries ({elapsed:.2f}s)")
    else:
        print_error("Should have failed but didn't")

    # Check statistics
    stats = scraper.get_statistics()
    print(f"  Domains with errors: {stats['rate_limiting']['domains_with_errors']}")
    print(f"  Active retries: {stats['rate_limiting']['active_retries']}")

    if stats['rate_limiting']['domains_with_errors'] > 0:
        print_success("Error tracking working")
    else:
        print_warning("No errors tracked")


def run_all_tests():
    """Run all tests"""
    print_section("Rate Limiting and Caching Test Suite - Feature #20")

    try:
        test_rate_limiter()
        test_request_throttler()
        test_response_cache()
        test_enhanced_scraper()
        test_error_handling()

        print_section("All Tests Complete!")
        print_success("Feature #20 implementation verified")

        print_info("\nNext steps:")
        print("  1. Update existing scrapers to use EnhancedScraper")
        print("  2. Configure cache TTL based on content type")
        print("  3. Monitor cache hit rates in production")
        print("  4. Adjust rate limits based on scraping results")

    except Exception as e:
        print_error(f"Test suite failed with exception: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    run_all_tests()
