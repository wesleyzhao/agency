"""
Test script for Dashboard API endpoint - Feature #11
"""
import requests
import json
from colorama import Fore, Style, init

init(autoreset=True)

API_URL = "http://localhost:5000"

def print_success(message):
    print(f"{Fore.GREEN}✓ {message}{Style.RESET_ALL}")

def print_error(message):
    print(f"{Fore.RED}✗ {message}{Style.RESET_ALL}")

def print_info(message):
    print(f"{Fore.YELLOW}ℹ {message}{Style.RESET_ALL}")

def test_dashboard_endpoint():
    """Test the dashboard endpoint"""
    print("\n" + "="*60)
    print("Testing Dashboard API Endpoint")
    print("="*60)

    try:
        # Test dashboard endpoint
        print("\n1. Testing GET /api/dashboard")
        response = requests.get(f"{API_URL}/api/dashboard?season=2024-25")

        if response.status_code == 200:
            print_success(f"Dashboard endpoint returned 200 OK")

            data = response.json()

            # Verify structure
            required_keys = ['stats', 'voters', 'candidate_stats', 'recent_activity', 'season']
            for key in required_keys:
                if key in data:
                    print_success(f"Response contains '{key}' field")
                else:
                    print_error(f"Response missing '{key}' field")
                    return False

            # Check stats structure
            stats = data['stats']
            print(f"\n{Fore.CYAN}Stats:{Style.RESET_ALL}")
            print(f"  Total Voters: {stats.get('total_voters', 0)}")
            print(f"  Known Voters: {stats.get('known_voters', 0)}")
            print(f"  Voters with Disclosed Votes: {stats.get('voters_with_disclosed_votes', 0)}")
            print(f"  First Place Votes Disclosed: {stats.get('first_place_votes_disclosed', 0)}")
            print(f"  Completion: {stats.get('completion_percentage', 0)}%")

            # Check voters
            voters = data['voters']
            print(f"\n{Fore.CYAN}Voters: {len(voters)} total{Style.RESET_ALL}")

            disclosed_count = len([v for v in voters if v['status'] == 'disclosed'])
            not_disclosed_count = len([v for v in voters if v['status'] == 'not_disclosed'])

            print(f"  Disclosed: {disclosed_count}")
            print(f"  Not Disclosed: {not_disclosed_count}")

            # Show sample voter
            if voters:
                sample_voter = voters[0]
                print(f"\n{Fore.CYAN}Sample Voter:{Style.RESET_ALL}")
                print(f"  Name: {sample_voter.get('name')}")
                print(f"  Outlet: {sample_voter.get('outlet')}")
                print(f"  Status: {sample_voter.get('status')}")
                print(f"  Vote Count: {sample_voter.get('vote_count', 0)}")

                if sample_voter.get('ballot'):
                    print(f"  Ballot: {len(sample_voter['ballot'])} votes")
                    for vote in sample_voter['ballot'][:3]:
                        print(f"    {vote.get('ranking')}. {vote.get('candidate')}")

            # Check candidate stats
            candidate_stats = data['candidate_stats']
            print(f"\n{Fore.CYAN}Candidate Stats: {len(candidate_stats)} candidates{Style.RESET_ALL}")

            if candidate_stats:
                print(f"\n{Fore.CYAN}Top 5 Candidates:{Style.RESET_ALL}")
                for i, candidate in enumerate(candidate_stats[:5], 1):
                    print(f"  {i}. {candidate['name']} ({candidate['team']}) - {candidate['first_place_votes']} first place votes")

            # Check recent activity
            recent_activity = data['recent_activity']
            print(f"\n{Fore.CYAN}Recent Activity: {len(recent_activity)} recent votes{Style.RESET_ALL}")

            if recent_activity:
                for activity in recent_activity[:3]:
                    print(f"  {activity['voter_name']} → {activity['candidate_name']} (Rank {activity['ranking']})")

            print_success("Dashboard endpoint test PASSED")
            return True

        else:
            print_error(f"Dashboard endpoint returned {response.status_code}")
            print(response.text)
            return False

    except requests.exceptions.ConnectionError:
        print_error("Could not connect to API. Make sure the backend server is running:")
        print_info("  cd backend && python3 app.py")
        return False
    except Exception as e:
        print_error(f"Error: {str(e)}")
        return False


def test_health_check():
    """Test the health check endpoint"""
    print("\n2. Testing GET /api/health")
    try:
        response = requests.get(f"{API_URL}/api/health")
        if response.status_code == 200:
            print_success("Health check passed")
            return True
        else:
            print_error(f"Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Health check error: {str(e)}")
        return False


if __name__ == "__main__":
    print(f"\n{Fore.CYAN}NFL MVP Voter Tracker - Dashboard Test Suite{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Testing API at: {API_URL}{Style.RESET_ALL}")

    # Test health first
    if not test_health_check():
        print(f"\n{Fore.RED}Backend server is not running!{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}Start it with: cd backend && python3 app.py{Style.RESET_ALL}")
        exit(1)

    # Test dashboard
    success = test_dashboard_endpoint()

    if success:
        print(f"\n{Fore.GREEN}{'='*60}")
        print(f"All tests PASSED! ✓")
        print(f"{'='*60}{Style.RESET_ALL}")
    else:
        print(f"\n{Fore.RED}{'='*60}")
        print(f"Some tests FAILED! ✗")
        print(f"{'='*60}{Style.RESET_ALL}")
        exit(1)
