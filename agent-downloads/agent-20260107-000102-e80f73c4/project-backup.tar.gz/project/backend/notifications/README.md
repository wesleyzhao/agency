# Notification System - Feature #18

## Overview

The NFL MVP Voter Tracker includes a comprehensive notification system that alerts users when new voter information is discovered. The system supports multiple notification channels (email, webhook, console) and can be configured to notify on various events.

## Features

- **Multiple Notification Channels**: Email, webhook, and console logging
- **Event-based Triggers**: Configurable notifications for 7 different event types
- **Rate Limiting**: Prevent notification spam with configurable minimum intervals
- **Notification History**: Complete audit trail of all sent notifications
- **Database-backed Preferences**: Persistent notification configuration
- **API Management**: Full REST API for managing notification preferences
- **Automatic Integration**: Seamlessly integrated with voter and vote creation

## Event Types

The system can send notifications for the following events:

| Event Type | Description | Default State |
|------------|-------------|---------------|
| `NEW_VOTER_FOUND` | A new AP voter has been discovered | Enabled |
| `NEW_VOTE_DISCLOSED` | A voter has publicly disclosed their MVP pick | Enabled |
| `FULL_BALLOT_COMPLETE` | A voter's complete ballot (5 votes) has been disclosed | Enabled |
| `HIGH_CONFIDENCE_VOTE` | A high-confidence vote has been extracted | Enabled |
| `VERIFIED_VOTE` | A vote has been manually verified | Enabled |
| `SCRAPING_COMPLETE` | Web scraping has completed successfully | Disabled |
| `SCRAPING_ERROR` | An error occurred during web scraping | Enabled |

## Notification Channels

### 1. Console Notifications

Simple console logging - perfect for development and testing.

**Configuration:**
```python
from notifications.notification_config import create_console_preference

pref_id = create_console_preference("My Console Notifications")
```

**Example Output:**
```
============================================================
🔔 NOTIFICATION: New MVP Vote: Mina Kimes → Saquon Barkley
============================================================
A new MVP vote has been publicly disclosed:

Voter: Mina Kimes (ESPN)
Candidate: Saquon Barkley (Philadelphia Eagles)
Ranking: #1
Confidence: high
Source: https://x.com/minakimes/status/...
============================================================
```

### 2. Email Notifications

Send email notifications to specified recipients.

**Configuration:**
```python
from notifications.notification_config import create_email_preference

pref_id = create_email_preference(
    name="Email Alerts",
    email_address="admin@example.com",
    email_from="noreply@mvptracker.com"
)
```

**Environment Variables Required:**
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_USE_TLS=true
```

**Note**: For development/testing without a real SMTP server, emails will be logged to console.

### 3. Webhook Notifications

Send JSON payloads to webhook endpoints (Slack, Discord, custom services).

**Configuration:**
```python
from notifications.notification_config import create_webhook_preference

pref_id = create_webhook_preference(
    name="Slack Webhook",
    webhook_url="https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
    webhook_secret="optional-secret-for-authentication"
)
```

**Webhook Payload Format:**
```json
{
  "event_type": "new_vote_disclosed",
  "title": "New MVP Vote: Mina Kimes → Saquon Barkley",
  "message": "A new MVP vote has been publicly disclosed:\n\nVoter: Mina Kimes...",
  "timestamp": "2025-01-07T10:30:00",
  "metadata": {
    "voter_id": 1,
    "voter_name": "Mina Kimes",
    "candidate_id": 2,
    "candidate_name": "Saquon Barkley",
    "team": "Philadelphia Eagles",
    "ranking": 1,
    "confidence": "high",
    "source_url": "https://x.com/minakimes/status/..."
  }
}
```

**Headers:**
```
Content-Type: application/json
X-Webhook-Secret: your-secret (if configured)
```

## Database Schema

### NotificationPreference Table

Stores user notification preferences.

| Column | Type | Description |
|--------|------|-------------|
| `id` | Integer | Primary key |
| `name` | String | Preference set name |
| `enabled` | Integer | 0=disabled, 1=enabled |
| `channel` | Enum | email, webhook, or console |
| `notify_new_voter` | Integer | Enable new voter notifications |
| `notify_new_vote` | Integer | Enable new vote notifications |
| `notify_full_ballot` | Integer | Enable full ballot notifications |
| `notify_high_confidence` | Integer | Enable high confidence notifications |
| `notify_verified_vote` | Integer | Enable verified vote notifications |
| `notify_scraping_complete` | Integer | Enable scraping complete notifications |
| `notify_scraping_error` | Integer | Enable scraping error notifications |
| `email_address` | String | Email recipient (for email channel) |
| `email_from` | String | Email sender (for email channel) |
| `webhook_url` | String | Webhook endpoint URL (for webhook channel) |
| `webhook_secret` | String | Webhook authentication secret |
| `min_interval_minutes` | Integer | Minimum time between notifications |
| `batch_notifications` | Integer | Enable batching (future feature) |
| `created_at` | DateTime | Creation timestamp |
| `updated_at` | DateTime | Last update timestamp |

### NotificationHistory Table

Records all sent notifications for audit trail.

| Column | Type | Description |
|--------|------|-------------|
| `id` | Integer | Primary key |
| `preference_id` | Integer | FK to notification_preferences |
| `event_type` | Enum | Type of event that triggered notification |
| `title` | String | Notification title |
| `message` | Text | Notification message body |
| `channel` | Enum | Channel used to send notification |
| `recipient` | String | Email address or webhook URL |
| `status` | String | pending, sent, or failed |
| `error_message` | Text | Error details if failed |
| `voter_id` | Integer | FK to voters (if applicable) |
| `vote_id` | Integer | FK to votes (if applicable) |
| `candidate_id` | Integer | FK to candidates (if applicable) |
| `sent_at` | DateTime | When notification was sent |
| `created_at` | DateTime | When notification was created |

## API Endpoints

### GET /api/notifications/preferences

Get all notification preferences.

**Response:**
```json
[
  {
    "id": 1,
    "name": "Console Notifications",
    "enabled": true,
    "channel": "console",
    "notify_new_voter": true,
    "notify_new_vote": true,
    "notify_full_ballot": true,
    "notify_high_confidence": true,
    "notify_verified_vote": true,
    "notify_scraping_complete": false,
    "notify_scraping_error": true,
    "email_address": null,
    "webhook_url": null,
    "min_interval_minutes": 0,
    "batch_notifications": false,
    "created_at": "2025-01-07T10:00:00",
    "updated_at": "2025-01-07T10:00:00"
  }
]
```

### POST /api/notifications/preferences

Create a new notification preference.

**Request Body:**
```json
{
  "name": "My Email Notifications",
  "channel": "email",
  "email_address": "user@example.com",
  "email_from": "noreply@mvptracker.com",
  "notify_new_voter": true,
  "notify_new_vote": true,
  "notify_full_ballot": true,
  "notify_high_confidence": true,
  "notify_verified_vote": true,
  "notify_scraping_complete": false,
  "notify_scraping_error": true,
  "min_interval_minutes": 0
}
```

**Response:** `201 Created`
```json
{
  "id": 2,
  "name": "My Email Notifications",
  "channel": "email",
  "enabled": true
}
```

### PUT /api/notifications/preferences/:id

Update an existing notification preference.

**Request Body:**
```json
{
  "enabled": false,
  "notify_new_vote": false
}
```

**Response:** `200 OK`
```json
{
  "id": 2,
  "name": "My Email Notifications",
  "enabled": false,
  "message": "Preference updated successfully"
}
```

### DELETE /api/notifications/preferences/:id

Delete a notification preference.

**Response:** `200 OK`
```json
{
  "message": "Preference deleted successfully"
}
```

### GET /api/notifications/history

Get notification history.

**Query Parameters:**
- `limit` (int): Maximum number of records (default: 50)
- `status` (string): Filter by status (sent, failed, pending)

**Response:**
```json
[
  {
    "id": 1,
    "event_type": "new_vote_disclosed",
    "title": "New MVP Vote: Mina Kimes → Saquon Barkley",
    "message": "A new MVP vote has been publicly disclosed...",
    "channel": "console",
    "recipient": "console",
    "status": "sent",
    "error_message": null,
    "voter_id": 1,
    "vote_id": 5,
    "candidate_id": 2,
    "sent_at": "2025-01-07T10:30:00",
    "created_at": "2025-01-07T10:30:00"
  }
]
```

### POST /api/notifications/test

Send a test notification.

**Request Body (optional):**
```json
{
  "title": "Test Notification",
  "message": "This is a test notification"
}
```

**Response:**
```json
{
  "event_type": "new_vote_disclosed",
  "notifications_sent": 1,
  "notifications_failed": 0,
  "details": [
    {
      "preference": "Console Notifications",
      "channel": "console",
      "status": "sent"
    }
  ]
}
```

## Usage Examples

### Python - Using NotificationService Directly

```python
from notifications import NotificationService
from database.models import NotificationEventType

# Initialize service
service = NotificationService()

# Send notification for new voter
result = service.notify_new_voter(voter_id=1)
print(f"Sent {result['notifications_sent']} notifications")

# Send notification for new vote
result = service.notify_new_vote(vote_id=5)

# Send notification for full ballot
result = service.notify_full_ballot(voter_id=1)

# Send notification for scraping completion
result = service.notify_scraping_complete(
    source="Reddit",
    new_votes=5,
    new_voters=2,
    duration_seconds=45.3
)

# Send custom notification
result = service.notify(
    NotificationEventType.SCRAPING_ERROR,
    "Scraping Error: Twitter",
    "Failed to authenticate with Twitter API",
    metadata={'error_code': 401}
)
```

### JavaScript - Managing Preferences via API

```javascript
// Get all preferences
const response = await fetch('http://localhost:5000/api/notifications/preferences');
const preferences = await response.json();
console.log(preferences);

// Create new preference
const newPref = {
  name: "Webhook to Slack",
  channel: "webhook",
  webhook_url: "https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
  notify_new_voter: true,
  notify_new_vote: true
};

const createResponse = await fetch('http://localhost:5000/api/notifications/preferences', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(newPref)
});

const created = await createResponse.json();
console.log('Created preference:', created);

// Update preference
const updateResponse = await fetch(`http://localhost:5000/api/notifications/preferences/${created.id}`, {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ enabled: false })
});

// Delete preference
await fetch(`http://localhost:5000/api/notifications/preferences/${created.id}`, {
  method: 'DELETE'
});
```

### Command Line - Using notification_config.py

```bash
# List all preferences
python3 backend/notifications/notification_config.py list

# Create console preference
python3 backend/notifications/notification_config.py create-console "Dev Notifications"

# Create email preference
python3 backend/notifications/notification_config.py create-email \
  "Email Alerts" \
  "admin@example.com" \
  "noreply@mvptracker.com"

# Create webhook preference
python3 backend/notifications/notification_config.py create-webhook \
  "Slack Webhook" \
  "https://hooks.slack.com/services/YOUR/WEBHOOK/URL" \
  "optional-secret"

# Enable preference
python3 backend/notifications/notification_config.py enable 1

# Disable preference
python3 backend/notifications/notification_config.py disable 1

# Delete preference
python3 backend/notifications/notification_config.py delete 1
```

## Integration with Application

The notification system is automatically integrated with:

1. **Vote Creation** (`POST /api/votes`):
   - Triggers `NEW_VOTE_DISCLOSED` notification
   - Checks if full ballot is complete → triggers `FULL_BALLOT_COMPLETE`
   - Checks if vote is high confidence → triggers `HIGH_CONFIDENCE_VOTE`

2. **Voter Creation** (`POST /api/voters`):
   - Triggers `NEW_VOTER_FOUND` notification

3. **Web Scraping** (future integration):
   - Can trigger `SCRAPING_COMPLETE` on successful scraping
   - Can trigger `SCRAPING_ERROR` on scraping failures

## Setup & Installation

### 1. Run Database Migration

```bash
cd backend
python3 database/migrate_add_notifications.py
```

### 2. Create Initial Preference

```bash
# Create console preference for testing
python3 notifications/notification_config.py create-console "Development Notifications"
```

### 3. Configure Email (Optional)

Set environment variables for email notifications:

```bash
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USER=your-email@gmail.com
export SMTP_PASSWORD=your-app-password
export SMTP_USE_TLS=true
```

For Gmail, you'll need to:
1. Enable 2-factor authentication
2. Generate an "App Password"
3. Use the app password as `SMTP_PASSWORD`

### 4. Test the System

```bash
# Run comprehensive test suite
cd backend
python3 test_notifications.py
```

## Rate Limiting

To prevent notification spam, you can set a minimum interval between notifications:

```python
from notifications.notification_config import create_email_preference

pref_id = create_email_preference(
    name="Rate Limited Emails",
    email_address="user@example.com",
    min_interval_minutes=60  # Only send once per hour
)
```

Or via API:
```json
{
  "min_interval_minutes": 60
}
```

## Troubleshooting

### Notifications Not Sending

1. **Check if preferences are enabled:**
   ```bash
   python3 notifications/notification_config.py list
   ```

2. **Check notification history for errors:**
   ```bash
   curl http://localhost:5000/api/notifications/history?status=failed
   ```

3. **Test notifications manually:**
   ```bash
   curl -X POST http://localhost:5000/api/notifications/test \
     -H "Content-Type: application/json" \
     -d '{"title": "Test", "message": "Testing"}'
   ```

### Email Notifications Failing

1. Verify SMTP environment variables are set
2. Check that email address is valid
3. For Gmail, ensure app password is used (not regular password)
4. Check firewall allows outbound connections on SMTP port

### Webhook Notifications Failing

1. Verify webhook URL is correct and accessible
2. Check that endpoint accepts POST requests with JSON
3. Verify endpoint returns 2xx status code
4. Check notification history for error details

## Best Practices

1. **Use Console for Development**: Enable console notifications during development for immediate feedback

2. **Disable Verbose Events in Production**: Disable `SCRAPING_COMPLETE` events in production unless needed

3. **Use Rate Limiting for Email**: Set `min_interval_minutes` for email to avoid spam

4. **Monitor Notification History**: Regularly check notification history to ensure notifications are being delivered

5. **Secure Webhook Secrets**: Always use webhook secrets for production webhooks

6. **Test Before Enabling**: Use the test endpoint to verify configuration before enabling notifications

## Future Enhancements

- **Batch/Digest Notifications**: Aggregate multiple events into a single notification
- **Mobile Push Notifications**: Support for iOS and Android push notifications
- **SMS Notifications**: Support for text message alerts
- **Custom Templates**: User-defined notification templates
- **Notification Preferences UI**: Frontend interface for managing preferences
- **Advanced Filtering**: More granular control over which events trigger notifications

## Support

For issues or questions about the notification system:

1. Check the test suite output: `python3 backend/test_notifications.py`
2. Review notification history via API: `GET /api/notifications/history`
3. Check console logs for error messages
4. Verify database schema with migration script

---

**Feature #18 - Notification System**
Implemented: January 7, 2026
Version: 1.0
