"""
Notification Configuration Helper - Feature #18
Utility functions to manage notification preferences
"""
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import NotificationPreference, NotificationChannel


DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///../data/mvp_tracker.db')


def create_console_preference(name: str = "Console Notifications") -> int:
    """
    Create a console notification preference (for development/testing)

    Args:
        name: Name for this preference set

    Returns:
        ID of created preference
    """
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        pref = NotificationPreference(
            name=name,
            enabled=1,
            channel=NotificationChannel.CONSOLE,
            notify_new_voter=1,
            notify_new_vote=1,
            notify_full_ballot=1,
            notify_high_confidence=1,
            notify_verified_vote=1,
            notify_scraping_complete=1,
            notify_scraping_error=1
        )
        session.add(pref)
        session.commit()
        pref_id = pref.id
        print(f"✓ Console notification preference created (ID: {pref_id})")
        return pref_id
    finally:
        session.close()


def create_email_preference(
    name: str,
    email_address: str,
    email_from: str = None,
    events: dict = None
) -> int:
    """
    Create an email notification preference

    Args:
        name: Name for this preference set
        email_address: Recipient email address
        email_from: Sender email address (optional)
        events: Dict of event types to enable (default: all enabled)

    Returns:
        ID of created preference
    """
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    if events is None:
        events = {
            'notify_new_voter': 1,
            'notify_new_vote': 1,
            'notify_full_ballot': 1,
            'notify_high_confidence': 1,
            'notify_verified_vote': 1,
            'notify_scraping_complete': 0,
            'notify_scraping_error': 1
        }

    try:
        pref = NotificationPreference(
            name=name,
            enabled=1,
            channel=NotificationChannel.EMAIL,
            email_address=email_address,
            email_from=email_from,
            **events
        )
        session.add(pref)
        session.commit()
        pref_id = pref.id
        print(f"✓ Email notification preference created (ID: {pref_id})")
        print(f"  Recipient: {email_address}")
        return pref_id
    finally:
        session.close()


def create_webhook_preference(
    name: str,
    webhook_url: str,
    webhook_secret: str = None,
    events: dict = None
) -> int:
    """
    Create a webhook notification preference

    Args:
        name: Name for this preference set
        webhook_url: Webhook endpoint URL
        webhook_secret: Secret for webhook authentication (optional)
        events: Dict of event types to enable (default: all enabled)

    Returns:
        ID of created preference
    """
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    if events is None:
        events = {
            'notify_new_voter': 1,
            'notify_new_vote': 1,
            'notify_full_ballot': 1,
            'notify_high_confidence': 1,
            'notify_verified_vote': 1,
            'notify_scraping_complete': 1,
            'notify_scraping_error': 1
        }

    try:
        pref = NotificationPreference(
            name=name,
            enabled=1,
            channel=NotificationChannel.WEBHOOK,
            webhook_url=webhook_url,
            webhook_secret=webhook_secret,
            **events
        )
        session.add(pref)
        session.commit()
        pref_id = pref.id
        print(f"✓ Webhook notification preference created (ID: {pref_id})")
        print(f"  URL: {webhook_url}")
        return pref_id
    finally:
        session.close()


def list_preferences():
    """List all notification preferences"""
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        prefs = session.query(NotificationPreference).all()

        if not prefs:
            print("No notification preferences found.")
            return

        print("\n" + "=" * 60)
        print("Notification Preferences")
        print("=" * 60)

        for pref in prefs:
            status = "✓ ENABLED" if pref.enabled else "✗ DISABLED"
            print(f"\n[{pref.id}] {pref.name} ({status})")
            print(f"    Channel: {pref.channel.value if pref.channel else 'unknown'}")

            if pref.channel == NotificationChannel.EMAIL:
                print(f"    Email: {pref.email_address}")
            elif pref.channel == NotificationChannel.WEBHOOK:
                print(f"    Webhook: {pref.webhook_url}")

            # Show enabled events
            events = []
            if pref.notify_new_voter:
                events.append("new_voter")
            if pref.notify_new_vote:
                events.append("new_vote")
            if pref.notify_full_ballot:
                events.append("full_ballot")
            if pref.notify_high_confidence:
                events.append("high_confidence")
            if pref.notify_verified_vote:
                events.append("verified_vote")
            if pref.notify_scraping_complete:
                events.append("scraping_complete")
            if pref.notify_scraping_error:
                events.append("scraping_error")

            print(f"    Events: {', '.join(events)}")

        print("\n" + "=" * 60)

    finally:
        session.close()


def enable_preference(preference_id: int):
    """Enable a notification preference"""
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        pref = session.query(NotificationPreference).get(preference_id)
        if not pref:
            print(f"✗ Preference {preference_id} not found")
            return

        pref.enabled = 1
        session.commit()
        print(f"✓ Preference '{pref.name}' enabled")
    finally:
        session.close()


def disable_preference(preference_id: int):
    """Disable a notification preference"""
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        pref = session.query(NotificationPreference).get(preference_id)
        if not pref:
            print(f"✗ Preference {preference_id} not found")
            return

        pref.enabled = 0
        session.commit()
        print(f"✓ Preference '{pref.name}' disabled")
    finally:
        session.close()


def delete_preference(preference_id: int):
    """Delete a notification preference"""
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        pref = session.query(NotificationPreference).get(preference_id)
        if not pref:
            print(f"✗ Preference {preference_id} not found")
            return

        name = pref.name
        session.delete(pref)
        session.commit()
        print(f"✓ Preference '{name}' deleted")
    finally:
        session.close()


if __name__ == '__main__':
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python notification_config.py list")
        print("  python notification_config.py create-console [name]")
        print("  python notification_config.py create-email <name> <email> [from_email]")
        print("  python notification_config.py create-webhook <name> <url> [secret]")
        print("  python notification_config.py enable <id>")
        print("  python notification_config.py disable <id>")
        print("  python notification_config.py delete <id>")
        sys.exit(1)

    command = sys.argv[1]

    if command == 'list':
        list_preferences()
    elif command == 'create-console':
        name = sys.argv[2] if len(sys.argv) > 2 else "Console Notifications"
        create_console_preference(name)
    elif command == 'create-email':
        if len(sys.argv) < 4:
            print("Usage: python notification_config.py create-email <name> <email> [from_email]")
            sys.exit(1)
        name = sys.argv[2]
        email = sys.argv[3]
        from_email = sys.argv[4] if len(sys.argv) > 4 else None
        create_email_preference(name, email, from_email)
    elif command == 'create-webhook':
        if len(sys.argv) < 4:
            print("Usage: python notification_config.py create-webhook <name> <url> [secret]")
            sys.exit(1)
        name = sys.argv[2]
        url = sys.argv[3]
        secret = sys.argv[4] if len(sys.argv) > 4 else None
        create_webhook_preference(name, url, secret)
    elif command == 'enable':
        if len(sys.argv) < 3:
            print("Usage: python notification_config.py enable <id>")
            sys.exit(1)
        enable_preference(int(sys.argv[2]))
    elif command == 'disable':
        if len(sys.argv) < 3:
            print("Usage: python notification_config.py disable <id>")
            sys.exit(1)
        disable_preference(int(sys.argv[2]))
    elif command == 'delete':
        if len(sys.argv) < 3:
            print("Usage: python notification_config.py delete <id>")
            sys.exit(1)
        delete_preference(int(sys.argv[2]))
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
