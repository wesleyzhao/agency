"""
Notification module for NFL MVP Voter Tracker - Feature #18
"""
from .notification_service import NotificationService

__all__ = ['NotificationService']
