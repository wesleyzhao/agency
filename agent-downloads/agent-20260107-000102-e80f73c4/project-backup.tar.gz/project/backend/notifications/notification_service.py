"""
Notification Service for NFL MVP Voter Tracker - Feature #18
Sends notifications when new voter information is found
"""
import os
import sys
import json
import smtplib
import requests
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional, Any

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import (
    NotificationPreference, NotificationHistory, NotificationChannel,
    NotificationEventType, Voter, Vote, Candidate
)


class NotificationService:
    """
    Central notification service that handles sending notifications
    through multiple channels (email, webhook, console).
    """

    def __init__(self, database_url: Optional[str] = None):
        """
        Initialize notification service

        Args:
            database_url: Database connection string. If None, uses environment variable.
        """
        self.database_url = database_url or os.getenv(
            'DATABASE_URL',
            'sqlite:///../data/mvp_tracker.db'
        )
        self.engine = create_engine(self.database_url)
        self.Session = sessionmaker(bind=self.engine)

    def notify(
        self,
        event_type: NotificationEventType,
        title: str,
        message: str,
        voter_id: Optional[int] = None,
        vote_id: Optional[int] = None,
        candidate_id: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Send notifications based on event type and user preferences

        Args:
            event_type: Type of event triggering the notification
            title: Notification title
            message: Notification message body
            voter_id: Related voter ID (optional)
            vote_id: Related vote ID (optional)
            candidate_id: Related candidate ID (optional)
            metadata: Additional metadata to include in notification

        Returns:
            Dict with notification results
        """
        session = self.Session()
        results = {
            'event_type': event_type.value,
            'notifications_sent': 0,
            'notifications_failed': 0,
            'details': []
        }

        try:
            # Get all enabled preferences
            preferences = session.query(NotificationPreference).filter(
                NotificationPreference.enabled == 1
            ).all()

            # Filter preferences based on event type
            relevant_prefs = self._filter_preferences_by_event(preferences, event_type)

            for pref in relevant_prefs:
                # Check rate limiting
                if not self._check_rate_limit(session, pref):
                    results['details'].append({
                        'preference': pref.name,
                        'status': 'skipped',
                        'reason': 'rate_limited'
                    })
                    continue

                # Send notification through appropriate channel
                try:
                    if pref.channel == NotificationChannel.EMAIL:
                        success = self._send_email(pref, title, message, metadata)
                    elif pref.channel == NotificationChannel.WEBHOOK:
                        success = self._send_webhook(pref, event_type, title, message, metadata)
                    elif pref.channel == NotificationChannel.CONSOLE:
                        success = self._send_console(title, message, metadata)
                    else:
                        success = False

                    # Record in history
                    history = NotificationHistory(
                        preference_id=pref.id,
                        event_type=event_type,
                        title=title,
                        message=message,
                        voter_id=voter_id,
                        vote_id=vote_id,
                        candidate_id=candidate_id,
                        channel=pref.channel,
                        recipient=self._get_recipient(pref),
                        status='sent' if success else 'failed',
                        sent_at=datetime.utcnow() if success else None
                    )
                    session.add(history)

                    if success:
                        results['notifications_sent'] += 1
                        results['details'].append({
                            'preference': pref.name,
                            'channel': pref.channel.value,
                            'status': 'sent'
                        })
                    else:
                        results['notifications_failed'] += 1
                        results['details'].append({
                            'preference': pref.name,
                            'channel': pref.channel.value,
                            'status': 'failed'
                        })

                except Exception as e:
                    results['notifications_failed'] += 1
                    results['details'].append({
                        'preference': pref.name,
                        'channel': pref.channel.value if pref.channel else 'unknown',
                        'status': 'error',
                        'error': str(e)
                    })

                    # Record error in history
                    history = NotificationHistory(
                        preference_id=pref.id,
                        event_type=event_type,
                        title=title,
                        message=message,
                        voter_id=voter_id,
                        vote_id=vote_id,
                        candidate_id=candidate_id,
                        channel=pref.channel,
                        recipient=self._get_recipient(pref),
                        status='failed',
                        error_message=str(e)
                    )
                    session.add(history)

            session.commit()

        except Exception as e:
            session.rollback()
            results['error'] = str(e)
        finally:
            session.close()

        return results

    def notify_new_voter(self, voter_id: int) -> Dict[str, Any]:
        """
        Send notification when a new voter is discovered

        Args:
            voter_id: ID of the newly discovered voter

        Returns:
            Notification results
        """
        session = self.Session()
        try:
            voter = session.query(Voter).get(voter_id)
            if not voter:
                return {'error': 'Voter not found'}

            title = f"New AP Voter Discovered: {voter.name}"
            message = f"A new AP NFL MVP voter has been found:\n\n"
            message += f"Name: {voter.name}\n"
            if voter.outlet:
                message += f"Outlet: {voter.outlet}\n"
            if voter.twitter_handle:
                message += f"Twitter: {voter.twitter_handle}\n"

            metadata = {
                'voter_id': voter.id,
                'voter_name': voter.name,
                'outlet': voter.outlet,
                'twitter_handle': voter.twitter_handle
            }

            return self.notify(
                NotificationEventType.NEW_VOTER_FOUND,
                title,
                message,
                voter_id=voter_id,
                metadata=metadata
            )
        finally:
            session.close()

    def notify_new_vote(self, vote_id: int) -> Dict[str, Any]:
        """
        Send notification when a new vote is disclosed

        Args:
            vote_id: ID of the newly disclosed vote

        Returns:
            Notification results
        """
        session = self.Session()
        try:
            vote = session.query(Vote).get(vote_id)
            if not vote:
                return {'error': 'Vote not found'}

            voter = vote.voter
            candidate = vote.candidate

            title = f"New MVP Vote: {voter.name} → {candidate.name}"
            message = f"A new MVP vote has been publicly disclosed:\n\n"
            message += f"Voter: {voter.name}"
            if voter.outlet:
                message += f" ({voter.outlet})"
            message += f"\n"
            message += f"Candidate: {candidate.name} ({candidate.team})\n"
            message += f"Ranking: #{vote.ranking}\n"
            message += f"Confidence: {vote.confidence.value if vote.confidence else 'unknown'}\n"
            if vote.source_url:
                message += f"Source: {vote.source_url}\n"

            metadata = {
                'vote_id': vote.id,
                'voter_id': voter.id,
                'voter_name': voter.name,
                'candidate_id': candidate.id,
                'candidate_name': candidate.name,
                'team': candidate.team,
                'ranking': vote.ranking,
                'confidence': vote.confidence.value if vote.confidence else 'unknown',
                'source_url': vote.source_url
            }

            return self.notify(
                NotificationEventType.NEW_VOTE_DISCLOSED,
                title,
                message,
                voter_id=voter.id,
                vote_id=vote_id,
                candidate_id=candidate.id,
                metadata=metadata
            )
        finally:
            session.close()

    def notify_full_ballot(self, voter_id: int) -> Dict[str, Any]:
        """
        Send notification when a voter's full ballot (5 votes) is complete

        Args:
            voter_id: ID of the voter with complete ballot

        Returns:
            Notification results
        """
        session = self.Session()
        try:
            voter = session.query(Voter).get(voter_id)
            if not voter:
                return {'error': 'Voter not found'}

            # Get votes for current season (2024-25)
            votes = [v for v in voter.votes if v.season == '2024-25']
            votes.sort(key=lambda x: x.ranking if x.ranking else 999)

            if len(votes) < 5:
                return {'error': 'Ballot not complete'}

            title = f"Full Ballot Complete: {voter.name}"
            message = f"{voter.name} has disclosed their complete MVP ballot:\n\n"
            for vote in votes[:5]:
                message += f"#{vote.ranking}: {vote.candidate.name} ({vote.candidate.team})\n"

            metadata = {
                'voter_id': voter.id,
                'voter_name': voter.name,
                'ballot': [{
                    'ranking': v.ranking,
                    'candidate': v.candidate.name,
                    'team': v.candidate.team
                } for v in votes[:5]]
            }

            return self.notify(
                NotificationEventType.FULL_BALLOT_COMPLETE,
                title,
                message,
                voter_id=voter_id,
                metadata=metadata
            )
        finally:
            session.close()

    def notify_high_confidence_vote(self, vote_id: int) -> Dict[str, Any]:
        """
        Send notification for high-confidence vote discovery

        Args:
            vote_id: ID of the high-confidence vote

        Returns:
            Notification results
        """
        session = self.Session()
        try:
            vote = session.query(Vote).get(vote_id)
            if not vote or not vote.confidence or vote.confidence.value != 'high':
                return {'error': 'Vote not found or not high confidence'}

            voter = vote.voter
            candidate = vote.candidate

            title = f"High-Confidence Vote: {voter.name} → {candidate.name}"
            message = f"A high-confidence MVP vote has been found:\n\n"
            message += f"Voter: {voter.name}\n"
            message += f"Candidate: {candidate.name} (#{vote.ranking})\n"
            if vote.source_url:
                message += f"Source: {vote.source_url}\n"

            metadata = {
                'vote_id': vote.id,
                'voter_name': voter.name,
                'candidate_name': candidate.name,
                'ranking': vote.ranking,
                'confidence_score': vote.confidence_score,
                'source_url': vote.source_url
            }

            return self.notify(
                NotificationEventType.HIGH_CONFIDENCE_VOTE,
                title,
                message,
                voter_id=voter.id,
                vote_id=vote_id,
                candidate_id=candidate.id,
                metadata=metadata
            )
        finally:
            session.close()

    def notify_scraping_complete(
        self,
        source: str,
        new_votes: int,
        new_voters: int,
        duration_seconds: float
    ) -> Dict[str, Any]:
        """
        Send notification when scraping completes

        Args:
            source: Name of the scraping source
            new_votes: Number of new votes found
            new_voters: Number of new voters found
            duration_seconds: Scraping duration

        Returns:
            Notification results
        """
        title = f"Scraping Complete: {source}"
        message = f"Web scraping has completed for {source}:\n\n"
        message += f"New votes found: {new_votes}\n"
        message += f"New voters found: {new_voters}\n"
        message += f"Duration: {duration_seconds:.1f} seconds\n"

        metadata = {
            'source': source,
            'new_votes': new_votes,
            'new_voters': new_voters,
            'duration_seconds': duration_seconds
        }

        return self.notify(
            NotificationEventType.SCRAPING_COMPLETE,
            title,
            message,
            metadata=metadata
        )

    def notify_scraping_error(self, source: str, error: str) -> Dict[str, Any]:
        """
        Send notification when scraping encounters an error

        Args:
            source: Name of the scraping source
            error: Error message

        Returns:
            Notification results
        """
        title = f"Scraping Error: {source}"
        message = f"Web scraping encountered an error for {source}:\n\n"
        message += f"Error: {error}\n"

        metadata = {
            'source': source,
            'error': error
        }

        return self.notify(
            NotificationEventType.SCRAPING_ERROR,
            title,
            message,
            metadata=metadata
        )

    def _filter_preferences_by_event(
        self,
        preferences: List[NotificationPreference],
        event_type: NotificationEventType
    ) -> List[NotificationPreference]:
        """Filter preferences based on which events they want to receive"""
        filtered = []

        event_field_map = {
            NotificationEventType.NEW_VOTER_FOUND: 'notify_new_voter',
            NotificationEventType.NEW_VOTE_DISCLOSED: 'notify_new_vote',
            NotificationEventType.FULL_BALLOT_COMPLETE: 'notify_full_ballot',
            NotificationEventType.HIGH_CONFIDENCE_VOTE: 'notify_high_confidence',
            NotificationEventType.VERIFIED_VOTE: 'notify_verified_vote',
            NotificationEventType.SCRAPING_COMPLETE: 'notify_scraping_complete',
            NotificationEventType.SCRAPING_ERROR: 'notify_scraping_error',
        }

        field_name = event_field_map.get(event_type)
        if not field_name:
            return []

        for pref in preferences:
            if getattr(pref, field_name, 0):
                filtered.append(pref)

        return filtered

    def _check_rate_limit(
        self,
        session,
        preference: NotificationPreference
    ) -> bool:
        """Check if notification is within rate limit"""
        if preference.min_interval_minutes <= 0:
            return True

        # Get last notification for this preference
        last_notification = session.query(NotificationHistory).filter(
            NotificationHistory.preference_id == preference.id,
            NotificationHistory.status == 'sent'
        ).order_by(NotificationHistory.sent_at.desc()).first()

        if not last_notification or not last_notification.sent_at:
            return True

        # Check if enough time has passed
        time_since_last = datetime.utcnow() - last_notification.sent_at
        min_interval = timedelta(minutes=preference.min_interval_minutes)

        return time_since_last >= min_interval

    def _get_recipient(self, preference: NotificationPreference) -> Optional[str]:
        """Get recipient address/URL for preference"""
        if preference.channel == NotificationChannel.EMAIL:
            return preference.email_address
        elif preference.channel == NotificationChannel.WEBHOOK:
            return preference.webhook_url
        elif preference.channel == NotificationChannel.CONSOLE:
            return "console"
        return None

    def _send_email(
        self,
        preference: NotificationPreference,
        title: str,
        message: str,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Send email notification

        Args:
            preference: Notification preference with email settings
            title: Email subject
            message: Email body
            metadata: Additional metadata

        Returns:
            True if sent successfully, False otherwise
        """
        if not preference.email_address:
            return False

        try:
            # Get SMTP settings from environment
            smtp_host = os.getenv('SMTP_HOST', 'localhost')
            smtp_port = int(os.getenv('SMTP_PORT', '587'))
            smtp_user = os.getenv('SMTP_USER', '')
            smtp_password = os.getenv('SMTP_PASSWORD', '')
            smtp_use_tls = os.getenv('SMTP_USE_TLS', 'true').lower() == 'true'

            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = title
            msg['From'] = preference.email_from or smtp_user or 'noreply@mvptracker.com'
            msg['To'] = preference.email_address

            # Plain text version
            text_body = message
            if metadata:
                text_body += f"\n\n---\nMetadata: {json.dumps(metadata, indent=2)}"

            msg.attach(MIMEText(text_body, 'plain'))

            # Send via SMTP
            if smtp_host != 'localhost' and smtp_user:
                # Real SMTP server
                server = smtplib.SMTP(smtp_host, smtp_port)
                if smtp_use_tls:
                    server.starttls()
                server.login(smtp_user, smtp_password)
                server.send_message(msg)
                server.quit()
                return True
            else:
                # Development mode - just log
                print(f"[EMAIL] Would send to {preference.email_address}: {title}")
                return True

        except Exception as e:
            print(f"Email send error: {e}")
            return False

    def _send_webhook(
        self,
        preference: NotificationPreference,
        event_type: NotificationEventType,
        title: str,
        message: str,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Send webhook notification

        Args:
            preference: Notification preference with webhook settings
            event_type: Type of event
            title: Notification title
            message: Notification message
            metadata: Additional metadata

        Returns:
            True if sent successfully, False otherwise
        """
        if not preference.webhook_url:
            return False

        try:
            payload = {
                'event_type': event_type.value,
                'title': title,
                'message': message,
                'timestamp': datetime.utcnow().isoformat(),
                'metadata': metadata or {}
            }

            headers = {'Content-Type': 'application/json'}
            if preference.webhook_secret:
                headers['X-Webhook-Secret'] = preference.webhook_secret

            response = requests.post(
                preference.webhook_url,
                json=payload,
                headers=headers,
                timeout=10
            )

            return response.status_code in [200, 201, 202, 204]

        except Exception as e:
            print(f"Webhook send error: {e}")
            return False

    def _send_console(
        self,
        title: str,
        message: str,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Send console notification (print to stdout)

        Args:
            title: Notification title
            message: Notification message
            metadata: Additional metadata

        Returns:
            Always True (console logging always succeeds)
        """
        print("\n" + "=" * 60)
        print(f"🔔 NOTIFICATION: {title}")
        print("=" * 60)
        print(message)
        if metadata:
            print("\nMetadata:")
            print(json.dumps(metadata, indent=2))
        print("=" * 60 + "\n")
        return True

    def get_notification_history(
        self,
        limit: int = 50,
        event_type: Optional[NotificationEventType] = None,
        status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get notification history

        Args:
            limit: Maximum number of records to return
            event_type: Filter by event type
            status: Filter by status (sent, failed, pending)

        Returns:
            List of notification history records
        """
        session = self.Session()
        try:
            query = session.query(NotificationHistory)

            if event_type:
                query = query.filter(NotificationHistory.event_type == event_type)
            if status:
                query = query.filter(NotificationHistory.status == status)

            history = query.order_by(
                NotificationHistory.created_at.desc()
            ).limit(limit).all()

            return [{
                'id': h.id,
                'event_type': h.event_type.value if h.event_type else None,
                'title': h.title,
                'message': h.message,
                'channel': h.channel.value if h.channel else None,
                'recipient': h.recipient,
                'status': h.status,
                'error_message': h.error_message,
                'sent_at': h.sent_at.isoformat() if h.sent_at else None,
                'created_at': h.created_at.isoformat() if h.created_at else None,
            } for h in history]

        finally:
            session.close()
