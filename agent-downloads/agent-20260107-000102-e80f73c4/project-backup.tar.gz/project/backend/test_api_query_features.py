"""
Test suite for Feature #19: API Endpoints to Query Voter Data Programmatically

This test suite verifies the enhanced API query capabilities including:
- Pagination on list endpoints
- Sorting functionality
- Advanced filtering
- Comprehensive query parameter support
"""

import requests
import json
from typing import Dict, Any

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

BASE_URL = "http://localhost:5000/api"


def print_success(message: str):
    """Print success message in green"""
    print(f"{GREEN}✓{RESET} {message}")


def print_error(message: str):
    """Print error message in red"""
    print(f"{RED}✗{RESET} {message}")


def print_info(message: str):
    """Print info message in cyan"""
    print(f"{CYAN}ℹ{RESET} {message}")


def print_section(title: str):
    """Print section header"""
    print(f"\n{YELLOW}{'=' * 70}{RESET}")
    print(f"{YELLOW}{title}{RESET}")
    print(f"{YELLOW}{'=' * 70}{RESET}")


def test_health_check() -> bool:
    """Test API health check endpoint"""
    print_section("Test 1: Health Check")
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            print_success("API is running and healthy")
            return True
        else:
            print_error(f"Health check failed with status {response.status_code}")
            return False
    except requests.ConnectionError:
        print_error("Cannot connect to API. Make sure the backend server is running:")
        print_info("  cd backend && python3 app.py")
        return False


def test_voters_pagination() -> bool:
    """Test voters endpoint pagination - Feature #19"""
    print_section("Test 2: Voters Pagination")
    tests_passed = 0
    total_tests = 3

    # Test 2a: Basic pagination
    try:
        response = requests.get(f"{BASE_URL}/voters", params={
            'page': 1,
            'per_page': 5
        })

        if response.status_code == 200:
            data = response.json()

            # Check response structure
            if 'voters' in data and 'pagination' in data:
                print_success("Response has correct structure (voters + pagination)")
                tests_passed += 1

                # Check pagination metadata
                pagination = data['pagination']
                if all(key in pagination for key in ['page', 'per_page', 'total_count', 'total_pages', 'has_next', 'has_prev']):
                    print_success(f"Pagination metadata complete: page {pagination['page']}, {pagination['total_count']} total")
                    tests_passed += 1
                else:
                    print_error("Missing pagination metadata fields")

                # Check per_page limit is respected
                if len(data['voters']) <= 5:
                    print_success(f"per_page limit respected: {len(data['voters'])} items returned")
                    tests_passed += 1
                else:
                    print_error(f"per_page limit not respected: {len(data['voters'])} > 5")
            else:
                print_error("Response missing 'voters' or 'pagination' field")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Pagination tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_voters_sorting() -> bool:
    """Test voters endpoint sorting - Feature #19"""
    print_section("Test 3: Voters Sorting")
    tests_passed = 0
    total_tests = 2

    # Test 3a: Sort by name ascending
    try:
        response = requests.get(f"{BASE_URL}/voters", params={
            'sort_by': 'name',
            'order': 'asc',
            'per_page': 10
        })

        if response.status_code == 200:
            data = response.json()

            if 'sorting' in data:
                if data['sorting']['sort_by'] == 'name' and data['sorting']['order'] == 'asc':
                    print_success("Sorting parameters correctly reflected in response")
                    tests_passed += 1
                else:
                    print_error("Sorting parameters not reflected correctly")
            else:
                print_error("Response missing 'sorting' field")

            # Check if names are actually sorted
            voters = data.get('voters', [])
            if voters and len(voters) > 1:
                names = [v['name'] for v in voters]
                if names == sorted(names):
                    print_success(f"Voters correctly sorted by name (first: {names[0]})")
                    tests_passed += 1
                else:
                    print_error("Voters not sorted correctly by name")
            else:
                print_info("Not enough voters to verify sort order")
                tests_passed += 1  # Pass if not enough data
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Sorting tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_voters_filtering() -> bool:
    """Test voters endpoint filtering - Feature #19"""
    print_section("Test 4: Voters Filtering")
    tests_passed = 0
    total_tests = 2

    # Test 4a: Filter by has_voted
    try:
        response = requests.get(f"{BASE_URL}/voters", params={
            'has_voted': 'true',
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()

            if 'filters' in data:
                print_success("Response includes filters metadata")
                tests_passed += 1

                # All returned voters should have has_voted=true
                voters = data.get('voters', [])
                if voters:
                    all_voted = all(v.get('has_voted', False) for v in voters)
                    if all_voted:
                        print_success(f"Filter working: all {len(voters)} voters have disclosed votes")
                        tests_passed += 1
                    else:
                        print_error("Filter not working: some voters haven't disclosed votes")
                else:
                    print_info("No voters found (might be empty database)")
                    tests_passed += 1
            else:
                print_error("Response missing 'filters' field")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Filtering tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_votes_pagination() -> bool:
    """Test votes endpoint pagination - Feature #19"""
    print_section("Test 5: Votes Pagination")
    tests_passed = 0
    total_tests = 2

    try:
        response = requests.get(f"{BASE_URL}/votes", params={
            'page': 1,
            'per_page': 10,
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()

            # Check structure
            if 'votes' in data and 'pagination' in data:
                print_success("Response has correct structure (votes + pagination)")
                tests_passed += 1

                # Check pagination metadata
                pagination = data['pagination']
                if 'page' in pagination and 'per_page' in pagination:
                    print_success(f"Pagination working: page {pagination['page']}, {pagination['total_count']} total votes")
                    tests_passed += 1
                else:
                    print_error("Missing pagination metadata")
            else:
                print_error("Response missing 'votes' or 'pagination' field")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Votes pagination tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_votes_filtering() -> bool:
    """Test votes endpoint advanced filtering - Feature #19"""
    print_section("Test 6: Votes Advanced Filtering")
    tests_passed = 0
    total_tests = 3

    # Test 6a: Filter by confidence
    try:
        response = requests.get(f"{BASE_URL}/votes", params={
            'confidence': 'high',
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()
            if 'filters' in data and data['filters'].get('confidence') == 'high':
                print_success("Confidence filter applied")
                tests_passed += 1
            else:
                print_error("Confidence filter not reflected in response")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    # Test 6b: Filter by verified status
    try:
        response = requests.get(f"{BASE_URL}/votes", params={
            'verified': 'true',
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()
            if 'filters' in data and data['filters'].get('verified') == 'true':
                print_success("Verified filter applied")
                tests_passed += 1
            else:
                print_error("Verified filter not reflected in response")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    # Test 6c: Filter by ranking
    try:
        response = requests.get(f"{BASE_URL}/votes", params={
            'ranking': 1,
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()
            if 'filters' in data and data['filters'].get('ranking') == 1:
                print_success("Ranking filter applied (first place votes only)")
                tests_passed += 1
            else:
                print_error("Ranking filter not reflected in response")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Votes filtering tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_votes_sorting() -> bool:
    """Test votes endpoint sorting - Feature #19"""
    print_section("Test 7: Votes Sorting")
    tests_passed = 0
    total_tests = 1

    try:
        response = requests.get(f"{BASE_URL}/votes", params={
            'sort_by': 'ranking',
            'order': 'asc',
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()

            if 'sorting' in data:
                if data['sorting']['sort_by'] == 'ranking' and data['sorting']['order'] == 'asc':
                    print_success("Sorting parameters correctly applied to votes")
                    tests_passed += 1
                else:
                    print_error("Sorting parameters not reflected correctly")
            else:
                print_error("Response missing 'sorting' field")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Votes sorting tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_combined_query_parameters() -> bool:
    """Test combining pagination, sorting, and filtering - Feature #19"""
    print_section("Test 8: Combined Query Parameters")
    tests_passed = 0
    total_tests = 1

    try:
        # Complex query: paginated, sorted, and filtered
        response = requests.get(f"{BASE_URL}/votes", params={
            'page': 1,
            'per_page': 5,
            'sort_by': 'created_at',
            'order': 'desc',
            'confidence': 'high',
            'verified': 'true',
            'season': '2024-25'
        })

        if response.status_code == 200:
            data = response.json()

            # Check all components are present
            has_pagination = 'pagination' in data
            has_filters = 'filters' in data
            has_sorting = 'sorting' in data

            if has_pagination and has_filters and has_sorting:
                print_success("Complex query successful: pagination + filtering + sorting combined")
                print_info(f"  Filters: {json.dumps(data['filters'], indent=2)}")
                print_info(f"  Sorting: {data['sorting']}")
                print_info(f"  Pagination: page {data['pagination']['page']}, {data['pagination']['total_count']} total")
                tests_passed += 1
            else:
                print_error(f"Missing components: pagination={has_pagination}, filters={has_filters}, sorting={has_sorting}")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Combined query tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_max_per_page_limit() -> bool:
    """Test that per_page is capped at maximum (100) - Feature #19"""
    print_section("Test 9: Per Page Maximum Limit")
    tests_passed = 0
    total_tests = 1

    try:
        response = requests.get(f"{BASE_URL}/voters", params={
            'page': 1,
            'per_page': 999  # Try to request way more than max
        })

        if response.status_code == 200:
            data = response.json()

            if data['pagination']['per_page'] == 100:
                print_success(f"per_page correctly capped at 100 (requested 999)")
                tests_passed += 1
            else:
                print_error(f"per_page not capped correctly: {data['pagination']['per_page']}")
        else:
            print_error(f"Request failed with status {response.status_code}")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Max limit tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_openapi_spec_exists() -> bool:
    """Test that OpenAPI specification file exists - Feature #19"""
    print_section("Test 10: OpenAPI Specification")
    tests_passed = 0
    total_tests = 1

    try:
        import os
        # Check current directory first, then parent/backend
        openapi_path = 'openapi.yaml' if os.path.exists('openapi.yaml') else os.path.join('backend', 'openapi.yaml')

        if os.path.exists(openapi_path):
            print_success("OpenAPI specification file exists (openapi.yaml)")

            # Check file has content
            with open(openapi_path, 'r') as f:
                content = f.read()
                if len(content) > 1000:  # Should be substantial
                    print_success(f"OpenAPI spec has substantial content ({len(content)} bytes)")
                    print_info("  Can be used with Swagger UI or other OpenAPI tools")
                    tests_passed += 1
                else:
                    print_error("OpenAPI spec file is too small")
        else:
            print_error("OpenAPI specification file not found")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"OpenAPI tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_postman_collection_exists() -> bool:
    """Test that Postman collection file exists - Feature #19"""
    print_section("Test 11: Postman Collection")
    tests_passed = 0
    total_tests = 1

    try:
        import os
        # Check current directory first, then parent/backend
        postman_path = 'postman_collection.json' if os.path.exists('postman_collection.json') else os.path.join('backend', 'postman_collection.json')

        if os.path.exists(postman_path):
            print_success("Postman collection file exists (postman_collection.json)")

            # Check it's valid JSON
            with open(postman_path, 'r') as f:
                collection = json.load(f)
                if 'info' in collection and 'item' in collection:
                    print_success(f"Postman collection is valid JSON with {len(collection['item'])} folders")
                    print_info("  Import this file into Postman for easy API testing")
                    tests_passed += 1
                else:
                    print_error("Postman collection missing required fields")
        else:
            print_error("Postman collection file not found")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Postman collection tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def test_python_sdk_exists() -> bool:
    """Test that Python SDK example exists - Feature #19"""
    print_section("Test 12: Python SDK Example")
    tests_passed = 0
    total_tests = 1

    try:
        import os
        # Check current directory first, then parent/backend
        sdk_path = 'python_sdk_example.py' if os.path.exists('python_sdk_example.py') else os.path.join('backend', 'python_sdk_example.py')

        if os.path.exists(sdk_path):
            print_success("Python SDK example file exists (python_sdk_example.py)")

            # Check it has MVPTrackerClient class
            with open(sdk_path, 'r') as f:
                content = f.read()
                if 'class MVPTrackerClient' in content:
                    print_success("SDK contains MVPTrackerClient class")
                    print_info("  Use: from python_sdk_example import MVPTrackerClient")
                    tests_passed += 1
                else:
                    print_error("SDK file missing MVPTrackerClient class")
        else:
            print_error("Python SDK example file not found")
    except Exception as e:
        print_error(f"Test error: {str(e)}")

    print_info(f"Python SDK tests passed: {tests_passed}/{total_tests}")
    return tests_passed == total_tests


def main():
    """Run all tests for Feature #19"""
    print(f"\n{CYAN}{'=' * 70}{RESET}")
    print(f"{CYAN}NFL MVP Voter Tracker - Feature #19 Test Suite{RESET}")
    print(f"{CYAN}Testing: API Endpoints to Query Voter Data Programmatically{RESET}")
    print(f"{CYAN}{'=' * 70}{RESET}")

    all_tests = [
        ("Health Check", test_health_check),
        ("Voters Pagination", test_voters_pagination),
        ("Voters Sorting", test_voters_sorting),
        ("Voters Filtering", test_voters_filtering),
        ("Votes Pagination", test_votes_pagination),
        ("Votes Advanced Filtering", test_votes_filtering),
        ("Votes Sorting", test_votes_sorting),
        ("Combined Query Parameters", test_combined_query_parameters),
        ("Per Page Maximum Limit", test_max_per_page_limit),
        ("OpenAPI Specification", test_openapi_spec_exists),
        ("Postman Collection", test_postman_collection_exists),
        ("Python SDK Example", test_python_sdk_exists),
    ]

    passed = 0
    failed = 0

    for test_name, test_func in all_tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print_error(f"Test '{test_name}' crashed: {str(e)}")
            failed += 1

    # Summary
    print(f"\n{CYAN}{'=' * 70}{RESET}")
    print(f"{CYAN}Test Summary{RESET}")
    print(f"{CYAN}{'=' * 70}{RESET}")

    total = passed + failed
    if failed == 0:
        print(f"\n{GREEN}✓ All tests PASSED! ({passed}/{total}){RESET}\n")
        print_info("Feature #19 implementation is complete and working correctly!")
        print_info("\nKey Features Implemented:")
        print_info("  ✓ Pagination on GET /api/voters and GET /api/votes")
        print_info("  ✓ Sorting by multiple fields (name, outlet, ranking, created_at, etc.)")
        print_info("  ✓ Advanced filtering (confidence, verified, source_type, has_voted, etc.)")
        print_info("  ✓ Combined query parameters (pagination + sorting + filtering)")
        print_info("  ✓ OpenAPI/Swagger specification (openapi.yaml)")
        print_info("  ✓ Postman collection (postman_collection.json)")
        print_info("  ✓ Python SDK example (python_sdk_example.py)")
        return True
    else:
        print(f"\n{RED}✗ Some tests FAILED: {failed}/{total} failed, {passed}/{total} passed{RESET}\n")
        print_info("Review the errors above to diagnose issues.")
        return False


if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)
