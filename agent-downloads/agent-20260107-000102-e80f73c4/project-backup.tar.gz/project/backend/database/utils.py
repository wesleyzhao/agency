"""
Database utility functions for common operations
"""
from typing import List, Optional, Dict
from sqlalchemy.orm import Session
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from .models import Voter, Candidate, Vote, Source, VoteSource, ScrapingLog, ConfidenceLevel, SourceType
from datetime import datetime
import hashlib


class VoterDB:
    """Utility class for Voter database operations"""

    @staticmethod
    def get_or_create_voter(session: Session, name: str, **kwargs) -> Voter:
        """
        Get existing voter or create new one

        Args:
            session: Database session
            name: Voter name
            **kwargs: Additional voter attributes (outlet, twitter_handle, etc.)

        Returns:
            Voter instance
        """
        voter = session.query(Voter).filter_by(name=name).first()
        if not voter:
            voter = Voter(name=name, **kwargs)
            session.add(voter)
            session.commit()
        return voter

    @staticmethod
    def get_voter_by_twitter(session: Session, twitter_handle: str) -> Optional[Voter]:
        """Get voter by Twitter handle"""
        return session.query(Voter).filter_by(twitter_handle=twitter_handle).first()

    @staticmethod
    def get_all_voters(session: Session) -> List[Voter]:
        """Get all voters"""
        return session.query(Voter).all()

    @staticmethod
    def search_voters(session: Session, search_term: str) -> List[Voter]:
        """
        Search voters by name or outlet

        Args:
            session: Database session
            search_term: Search term

        Returns:
            List of matching voters
        """
        search = f"%{search_term}%"
        return session.query(Voter).filter(
            (Voter.name.like(search)) | (Voter.outlet.like(search))
        ).all()


class CandidateDB:
    """Utility class for Candidate database operations"""

    @staticmethod
    def get_or_create_candidate(session: Session, name: str, season: str, **kwargs) -> Candidate:
        """
        Get existing candidate or create new one

        Args:
            session: Database session
            name: Candidate name
            season: NFL season (e.g., "2024-25")
            **kwargs: Additional candidate attributes (team, position)

        Returns:
            Candidate instance
        """
        candidate = session.query(Candidate).filter_by(name=name, season=season).first()
        if not candidate:
            candidate = Candidate(name=name, season=season, **kwargs)
            session.add(candidate)
            session.commit()
        return candidate

    @staticmethod
    def get_candidates_by_season(session: Session, season: str) -> List[Candidate]:
        """Get all candidates for a season"""
        return session.query(Candidate).filter_by(season=season).all()


class VoteDB:
    """Utility class for Vote database operations"""

    @staticmethod
    def add_vote(
        session: Session,
        voter_name: str,
        candidate_name: str,
        season: str,
        ranking: int = 1,
        source_url: Optional[str] = None,
        source_type: SourceType = SourceType.SPECULATION,
        confidence: ConfidenceLevel = ConfidenceLevel.MEDIUM,
        **kwargs
    ) -> Vote:
        """
        Add a vote to the database

        Args:
            session: Database session
            voter_name: Name of the voter
            candidate_name: Name of the candidate
            season: NFL season
            ranking: Vote ranking (1-5)
            source_url: URL where vote was found
            source_type: Type of source
            confidence: Confidence level
            **kwargs: Additional vote attributes

        Returns:
            Vote instance
        """
        # Get or create voter
        voter = VoterDB.get_or_create_voter(session, voter_name)

        # Get or create candidate
        candidate = CandidateDB.get_or_create_candidate(session, candidate_name, season)

        # Check if vote already exists
        existing_vote = session.query(Vote).filter_by(
            voter_id=voter.id,
            candidate_id=candidate.id,
            season=season
        ).first()

        if existing_vote:
            # Update existing vote
            existing_vote.ranking = ranking
            existing_vote.source_url = source_url
            existing_vote.source_type = source_type
            existing_vote.confidence = confidence
            for key, value in kwargs.items():
                setattr(existing_vote, key, value)
            session.commit()
            return existing_vote
        else:
            # Create new vote
            vote = Vote(
                voter_id=voter.id,
                candidate_id=candidate.id,
                season=season,
                ranking=ranking,
                source_url=source_url,
                source_type=source_type,
                confidence=confidence,
                **kwargs
            )
            session.add(vote)
            session.commit()
            return vote

    @staticmethod
    def get_votes_by_voter(session: Session, voter_name: str, season: Optional[str] = None) -> List[Vote]:
        """Get all votes by a specific voter"""
        query = session.query(Vote).join(Voter).filter(Voter.name == voter_name)
        if season:
            query = query.filter(Vote.season == season)
        return query.all()

    @staticmethod
    def get_votes_by_candidate(session: Session, candidate_name: str, season: Optional[str] = None) -> List[Vote]:
        """Get all votes for a specific candidate"""
        query = session.query(Vote).join(Candidate).filter(Candidate.name == candidate_name)
        if season:
            query = query.filter(Vote.season == season)
        return query.all()

    @staticmethod
    def get_vote_summary(session: Session, season: str) -> Dict:
        """
        Get summary statistics for votes in a season

        Returns:
            Dict with vote counts per candidate
        """
        results = session.query(
            Candidate.name,
            func.count(Vote.id).label('vote_count')
        ).join(Vote).filter(
            Vote.season == season
        ).group_by(
            Candidate.name
        ).order_by(
            func.count(Vote.id).desc()
        ).all()

        return {name: count for name, count in results}


class SourceDB:
    """Utility class for Source tracking (deduplication)"""

    @staticmethod
    def is_url_processed(session: Session, url: str) -> bool:
        """Check if a URL has already been processed"""
        return session.query(Source).filter_by(url=url).first() is not None

    @staticmethod
    def is_duplicate_content(session: Session, content_hash: str) -> Optional[Source]:
        """
        Check if content with this hash already exists

        Args:
            session: Database session
            content_hash: MD5 hash of content

        Returns:
            Source instance if duplicate found, None otherwise
        """
        if not content_hash:
            return None
        return session.query(Source).filter_by(content_hash=content_hash).first()

    @staticmethod
    def generate_content_hash(content: str) -> str:
        """
        Generate MD5 hash of content for deduplication

        Args:
            content: Text content to hash

        Returns:
            MD5 hash string
        """
        if not content:
            return ""
        return hashlib.md5(content.encode('utf-8')).hexdigest()

    @staticmethod
    def add_source(session: Session, url: str, title: str = None,
                   content: str = None, source_type: str = None) -> Source:
        """
        Add a source to the database with deduplication

        Args:
            session: Database session
            url: Source URL
            title: Source title
            content: Content text (will be hashed for deduplication)
            source_type: Type of source (google, reddit, news, etc.)

        Returns:
            Source instance
        """
        # Check if URL already exists
        source = session.query(Source).filter_by(url=url).first()
        if source:
            return source

        # Generate content hash
        content_hash = SourceDB.generate_content_hash(content) if content else None

        # Check for duplicate content
        if content_hash:
            duplicate = session.query(Source).filter_by(content_hash=content_hash).first()
            if duplicate:
                # Content is duplicate, but URL is different
                # Still add the new URL but mark it as processed since content is duplicate
                source = Source(
                    url=url,
                    title=title,
                    content_hash=content_hash,
                    source_type=source_type,
                    processed=1,
                    processed_at=datetime.utcnow()
                )
                session.add(source)
                try:
                    session.commit()
                except IntegrityError:
                    session.rollback()
                    # Race condition - URL was added by another process
                    source = session.query(Source).filter_by(url=url).first()
                return source

        # Add new source
        source = Source(
            url=url,
            title=title,
            content_hash=content_hash,
            source_type=source_type
        )
        session.add(source)
        try:
            session.commit()
        except IntegrityError:
            session.rollback()
            # Race condition - URL was added by another process
            source = session.query(Source).filter_by(url=url).first()
        return source

    @staticmethod
    def mark_processed(session: Session, url: str):
        """Mark a source as processed"""
        source = session.query(Source).filter_by(url=url).first()
        if source:
            source.processed = 1
            source.processed_at = datetime.utcnow()
            session.commit()

    @staticmethod
    def get_unprocessed_sources(session: Session, limit: int = 100,
                               source_type: str = None) -> List[Source]:
        """
        Get unprocessed sources

        Args:
            session: Database session
            limit: Maximum number of sources to return
            source_type: Filter by source type (optional)

        Returns:
            List of unprocessed Source instances
        """
        query = session.query(Source).filter_by(processed=0)
        if source_type:
            query = query.filter_by(source_type=source_type)
        return query.order_by(Source.discovered_at.desc()).limit(limit).all()

    @staticmethod
    def get_source_stats(session: Session) -> Dict:
        """
        Get statistics about sources

        Returns:
            Dictionary with source statistics
        """
        total = session.query(func.count(Source.id)).scalar()
        processed = session.query(func.count(Source.id)).filter_by(processed=1).scalar()
        unprocessed = total - processed

        # Count by source type
        by_type = {}
        type_results = session.query(
            Source.source_type,
            func.count(Source.id).label('count')
        ).group_by(Source.source_type).all()

        for source_type, count in type_results:
            by_type[source_type or 'unknown'] = count

        return {
            'total': total,
            'processed': processed,
            'unprocessed': unprocessed,
            'by_type': by_type
        }


class VoteSourceDB:
    """Utility class for VoteSource junction table operations"""

    @staticmethod
    def link_vote_to_source(session: Session, vote_id: int, source_id: int) -> VoteSource:
        """
        Link a vote to a source

        Args:
            session: Database session
            vote_id: ID of the vote
            source_id: ID of the source

        Returns:
            VoteSource instance
        """
        # Check if link already exists
        existing = session.query(VoteSource).filter_by(
            vote_id=vote_id,
            source_id=source_id
        ).first()

        if existing:
            return existing

        # Create new link
        vote_source = VoteSource(vote_id=vote_id, source_id=source_id)
        session.add(vote_source)
        session.commit()
        return vote_source

    @staticmethod
    def get_sources_for_vote(session: Session, vote_id: int) -> List[Source]:
        """
        Get all sources that contributed to a vote

        Args:
            session: Database session
            vote_id: ID of the vote

        Returns:
            List of Source instances
        """
        return session.query(Source).join(VoteSource).filter(
            VoteSource.vote_id == vote_id
        ).all()

    @staticmethod
    def get_votes_from_source(session: Session, source_id: int) -> List[Vote]:
        """
        Get all votes that came from a source

        Args:
            session: Database session
            source_id: ID of the source

        Returns:
            List of Vote instances
        """
        return session.query(Vote).join(VoteSource).filter(
            VoteSource.source_id == source_id
        ).all()


class ScrapingLogDB:
    """Utility class for Scraping log operations"""

    @staticmethod
    def create_log(session: Session, source: str, search_query: str) -> ScrapingLog:
        """Create a new scraping log entry"""
        log = ScrapingLog(source=source, search_query=search_query)
        session.add(log)
        session.commit()
        return log

    @staticmethod
    def update_log(
        session: Session,
        log_id: int,
        urls_found: int = 0,
        votes_extracted: int = 0,
        errors: str = None
    ):
        """Update a scraping log entry"""
        log = session.query(ScrapingLog).filter_by(id=log_id).first()
        if log:
            log.urls_found = urls_found
            log.votes_extracted = votes_extracted
            log.errors = errors
            log.completed_at = datetime.utcnow()
            session.commit()

    @staticmethod
    def get_recent_logs(session: Session, limit: int = 10) -> List[ScrapingLog]:
        """Get recent scraping logs"""
        return session.query(ScrapingLog).order_by(
            ScrapingLog.started_at.desc()
        ).limit(limit).all()


class HistoricalDB:
    """Utility class for historical voter data operations - Feature #17"""

    @staticmethod
    def get_seasons(session: Session) -> List[str]:
        """
        Get all seasons that have vote data

        Returns:
            List of season strings, sorted by most recent first
        """
        seasons = session.query(Vote.season).distinct().all()
        season_list = [s[0] for s in seasons if s[0]]
        # Sort by year (most recent first)
        season_list.sort(reverse=True)
        return season_list

    @staticmethod
    def get_voter_history(session: Session, voter_name: str) -> Dict:
        """
        Get complete voting history for a voter across all seasons

        Args:
            session: Database session
            voter_name: Name of the voter

        Returns:
            Dictionary with voter info and history by season
        """
        voter = session.query(Voter).filter_by(name=voter_name).first()
        if not voter:
            return None

        # Group votes by season
        votes_by_season = {}
        for vote in voter.votes:
            season = vote.season
            if season not in votes_by_season:
                votes_by_season[season] = []
            votes_by_season[season].append({
                'ranking': vote.ranking,
                'candidate': vote.candidate.name if vote.candidate else 'Unknown',
                'team': vote.candidate.team if vote.candidate else None,
                'position': vote.candidate.position if vote.candidate else None,
                'confidence': vote.confidence.value if vote.confidence else 'unknown',
                'verified': bool(vote.verified)
            })

        # Sort each season's votes by ranking
        for season in votes_by_season:
            votes_by_season[season].sort(key=lambda x: x['ranking'] if x['ranking'] else 999)

        return {
            'voter': {
                'id': voter.id,
                'name': voter.name,
                'outlet': voter.outlet,
                'twitter_handle': voter.twitter_handle
            },
            'seasons': votes_by_season,
            'total_seasons': len(votes_by_season)
        }

    @staticmethod
    def get_candidate_history(session: Session, candidate_name: str) -> Dict:
        """
        Get vote history for a candidate across all seasons

        Args:
            session: Database session
            candidate_name: Name of the candidate

        Returns:
            Dictionary with candidate info and votes received by season
        """
        candidates = session.query(Candidate).filter_by(name=candidate_name).all()
        if not candidates:
            return None

        # Group votes by season
        votes_by_season = {}
        for candidate in candidates:
            season = candidate.season
            votes = candidate.votes

            if season not in votes_by_season:
                votes_by_season[season] = {
                    'team': candidate.team,
                    'position': candidate.position,
                    'votes': []
                }

            for vote in votes:
                votes_by_season[season]['votes'].append({
                    'voter': vote.voter.name if vote.voter else 'Unknown',
                    'ranking': vote.ranking,
                    'confidence': vote.confidence.value if vote.confidence else 'unknown',
                    'verified': bool(vote.verified)
                })

            # Sort votes by ranking
            votes_by_season[season]['votes'].sort(key=lambda x: x['ranking'] if x['ranking'] else 999)

        return {
            'candidate': {
                'name': candidate_name
            },
            'seasons': votes_by_season,
            'total_seasons': len(votes_by_season)
        }

    @staticmethod
    def compare_seasons(session: Session, season1: str, season2: str) -> Dict:
        """
        Compare voting patterns between two seasons

        Args:
            session: Database session
            season1: First season (e.g., "2024-25")
            season2: Second season (e.g., "2023-24")

        Returns:
            Dictionary with comparison statistics
        """
        s1_votes = session.query(Vote).filter_by(season=season1).all()
        s2_votes = session.query(Vote).filter_by(season=season2).all()

        # Get unique voters in each season
        s1_voters = set([v.voter.name for v in s1_votes if v.voter])
        s2_voters = set([v.voter.name for v in s2_votes if v.voter])

        # Get candidates who received votes
        s1_candidates = {}
        s2_candidates = {}

        for vote in s1_votes:
            if vote.candidate:
                name = vote.candidate.name
                if name not in s1_candidates:
                    s1_candidates[name] = {'first_place': 0, 'total': 0}
                s1_candidates[name]['total'] += 1
                if vote.ranking == 1:
                    s1_candidates[name]['first_place'] += 1

        for vote in s2_votes:
            if vote.candidate:
                name = vote.candidate.name
                if name not in s2_candidates:
                    s2_candidates[name] = {'first_place': 0, 'total': 0}
                s2_candidates[name]['total'] += 1
                if vote.ranking == 1:
                    s2_candidates[name]['first_place'] += 1

        return {
            'season1': {
                'season': season1,
                'total_voters': len(s1_voters),
                'total_votes': len(s1_votes),
                'candidates': s1_candidates
            },
            'season2': {
                'season': season2,
                'total_voters': len(s2_voters),
                'total_votes': len(s2_votes),
                'candidates': s2_candidates
            },
            'voter_overlap': {
                'common_voters': len(s1_voters.intersection(s2_voters)),
                'unique_to_season1': len(s1_voters - s2_voters),
                'unique_to_season2': len(s2_voters - s1_voters)
            }
        }

    @staticmethod
    def get_season_winner(session: Session, season: str) -> Dict:
        """
        Get the MVP winner and vote breakdown for a season

        Args:
            session: Database session
            season: Season string (e.g., "2024-25")

        Returns:
            Dictionary with winner and vote breakdown
        """
        # Calculate weighted points (10-7-5-3-1 system)
        candidates = session.query(Candidate).filter_by(season=season).all()

        candidate_points = {}
        for candidate in candidates:
            points = 0
            vote_breakdown = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

            for vote in candidate.votes:
                if vote.season == season and vote.ranking:
                    vote_breakdown[vote.ranking] = vote_breakdown.get(vote.ranking, 0) + 1

                    # Point system: 1st=10, 2nd=7, 3rd=5, 4th=3, 5th=1
                    if vote.ranking == 1:
                        points += 10
                    elif vote.ranking == 2:
                        points += 7
                    elif vote.ranking == 3:
                        points += 5
                    elif vote.ranking == 4:
                        points += 3
                    elif vote.ranking == 5:
                        points += 1

            if points > 0:
                candidate_points[candidate.name] = {
                    'points': points,
                    'team': candidate.team,
                    'position': candidate.position,
                    'vote_breakdown': vote_breakdown
                }

        # Sort by points
        sorted_candidates = sorted(candidate_points.items(), key=lambda x: x[1]['points'], reverse=True)

        return {
            'season': season,
            'winner': sorted_candidates[0][0] if sorted_candidates else None,
            'top_candidates': [
                {
                    'name': name,
                    'points': data['points'],
                    'team': data['team'],
                    'position': data['position'],
                    'vote_breakdown': data['vote_breakdown']
                }
                for name, data in sorted_candidates[:5]
            ] if sorted_candidates else []
        }

    @staticmethod
    def get_voter_trends(session: Session, voter_name: str) -> Dict:
        """
        Analyze voting trends for a specific voter across seasons

        Args:
            session: Database session
            voter_name: Name of the voter

        Returns:
            Dictionary with trend analysis
        """
        voter = session.query(Voter).filter_by(name=voter_name).first()
        if not voter:
            return None

        # Analyze voting patterns
        seasons = {}
        position_preferences = {}
        team_preferences = {}

        for vote in voter.votes:
            season = vote.season
            if season not in seasons:
                seasons[season] = []

            candidate_info = {
                'name': vote.candidate.name if vote.candidate else 'Unknown',
                'team': vote.candidate.team if vote.candidate else 'Unknown',
                'position': vote.candidate.position if vote.candidate else 'Unknown',
                'ranking': vote.ranking
            }
            seasons[season].append(candidate_info)

            # Track position preferences (only first place votes)
            if vote.ranking == 1 and vote.candidate and vote.candidate.position:
                pos = vote.candidate.position
                position_preferences[pos] = position_preferences.get(pos, 0) + 1

            # Track team preferences
            if vote.candidate and vote.candidate.team:
                team = vote.candidate.team
                team_preferences[team] = team_preferences.get(team, 0) + 1

        return {
            'voter': voter.name,
            'total_seasons_voted': len(seasons),
            'seasons': seasons,
            'position_preferences': position_preferences,
            'team_preferences': team_preferences
        }
