"""
Database migration to add confidence_score column to votes table

This migration adds the numeric confidence score (0-100) field to the votes table
to support the comprehensive confidence scoring system (Feature #9).
"""
import sqlite3
import sys
import os

# Add parent directory to path to import models
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_session


def migrate_add_confidence_score():
    """Add confidence_score column to votes table"""
    session = get_session()

    try:
        # SQLite doesn't support adding columns with constraints easily,
        # so we'll add a simple Float column
        connection = session.connection().connection
        cursor = connection.cursor()

        # Check if column already exists
        cursor.execute("PRAGMA table_info(votes)")
        columns = [column[1] for column in cursor.fetchall()]

        if 'confidence_score' in columns:
            print("✓ Column 'confidence_score' already exists in votes table")
            return True

        # Add the new column
        print("Adding confidence_score column to votes table...")
        cursor.execute("""
            ALTER TABLE votes
            ADD COLUMN confidence_score FLOAT
        """)

        connection.commit()
        print("✓ Successfully added confidence_score column")

        # Verify the column was added
        cursor.execute("PRAGMA table_info(votes)")
        columns = [column[1] for column in cursor.fetchall()]

        if 'confidence_score' in columns:
            print("✓ Migration verified successfully")
            return True
        else:
            print("✗ Migration verification failed")
            return False

    except Exception as e:
        print(f"✗ Migration failed: {e}")
        session.rollback()
        return False
    finally:
        session.close()


def rollback_confidence_score():
    """
    Rollback the migration (remove confidence_score column)

    Note: SQLite doesn't support DROP COLUMN directly in older versions.
    This would require recreating the table, which is more complex.
    """
    print("Warning: SQLite doesn't support DROP COLUMN directly.")
    print("To rollback, you would need to recreate the table without this column.")
    print("For now, the column will remain but can be ignored.")
    return False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Migrate votes table to add confidence_score')
    parser.add_argument('--rollback', action='store_true', help='Rollback the migration')
    args = parser.parse_args()

    if args.rollback:
        success = rollback_confidence_score()
    else:
        success = migrate_add_confidence_score()

    sys.exit(0 if success else 1)
