"""
Test script for database functionality
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from database import init_db, get_session
from database.models import Voter, Candidate, Vote, ConfidenceLevel, SourceType
from database.utils import VoterDB, CandidateDB, VoteDB, SourceDB
from database.init_db import seed_known_voters, seed_known_votes


def test_database_creation():
    """Test database table creation"""
    print("Testing database creation...")
    try:
        init_db()
        print("✓ Database tables created successfully")
        return True
    except Exception as e:
        print(f"✗ Failed to create database: {e}")
        return False


def test_seed_data():
    """Test seeding database with known voters and votes"""
    print("\nTesting seed data...")
    try:
        seed_known_voters()
        seed_known_votes()
        print("✓ Seed data added successfully")
        return True
    except Exception as e:
        print(f"✗ Failed to seed data: {e}")
        return False


def test_query_voters():
    """Test querying voters"""
    print("\nTesting voter queries...")
    session = get_session()
    try:
        voters = VoterDB.get_all_voters(session)
        print(f"✓ Found {len(voters)} voters")

        for voter in voters:
            print(f"  - {voter.name} ({voter.outlet})")

        # Test get voter by Twitter
        mina = VoterDB.get_voter_by_twitter(session, "@minakimes")
        if mina:
            print(f"✓ Found voter by Twitter: {mina.name}")

        session.close()
        return True
    except Exception as e:
        print(f"✗ Failed to query voters: {e}")
        session.close()
        return False


def test_query_votes():
    """Test querying votes"""
    print("\nTesting vote queries...")
    session = get_session()
    try:
        # Get votes by voter
        tom_votes = VoteDB.get_votes_by_voter(session, "Tom Brady", season="2024-25")
        print(f"✓ Tom Brady has {len(tom_votes)} votes")

        for vote in tom_votes:
            print(f"  {vote.ranking}. {vote.candidate.name} ({vote.confidence.value})")

        # Get vote summary
        summary = VoteDB.get_vote_summary(session, "2024-25")
        print(f"\n✓ Vote summary for 2024-25 season:")
        for candidate, count in summary.items():
            print(f"  {candidate}: {count} votes")

        session.close()
        return True
    except Exception as e:
        print(f"✗ Failed to query votes: {e}")
        session.close()
        return False


def test_add_vote():
    """Test adding a new vote"""
    print("\nTesting adding new vote...")
    session = get_session()
    try:
        # Add a test vote
        vote = VoteDB.add_vote(
            session=session,
            voter_name="Test Voter",
            candidate_name="Josh Allen",
            season="2024-25",
            ranking=1,
            source_url="https://example.com/test",
            source_type=SourceType.SPECULATION,
            confidence=ConfidenceLevel.LOW
        )
        print(f"✓ Added vote: {vote.voter.name} -> {vote.candidate.name}")

        session.close()
        return True
    except Exception as e:
        print(f"✗ Failed to add vote: {e}")
        session.close()
        return False


def test_source_tracking():
    """Test source deduplication"""
    print("\nTesting source tracking...")
    session = get_session()
    try:
        # Add a source
        url = "https://example.com/test-article"
        SourceDB.add_source(session, url, title="Test Article")

        # Check if URL is processed
        is_processed = SourceDB.is_url_processed(session, url)
        print(f"✓ URL tracking works: {url} processed={is_processed}")

        session.close()
        return True
    except Exception as e:
        print(f"✗ Failed to track source: {e}")
        session.close()
        return False


def run_all_tests():
    """Run all database tests"""
    print("=" * 60)
    print("NFL MVP Voter Tracker - Database Tests")
    print("=" * 60)

    tests = [
        test_database_creation,
        test_seed_data,
        test_query_voters,
        test_query_votes,
        test_add_vote,
        test_source_tracking
    ]

    results = []
    for test in tests:
        result = test()
        results.append(result)

    print("\n" + "=" * 60)
    print(f"Test Results: {sum(results)}/{len(results)} passed")
    print("=" * 60)

    return all(results)


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
