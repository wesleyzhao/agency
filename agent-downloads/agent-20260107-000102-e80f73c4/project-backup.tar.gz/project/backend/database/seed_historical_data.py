"""
Seed historical MVP voting data into the database - Feature #17
"""
import json
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Voter, Candidate, Vote, ConfidenceLevel, SourceType
from datetime import datetime

def seed_historical_data(database_url=None):
    """
    Seed historical MVP voting data from JSON file

    Args:
        database_url: Database URL (defaults to sqlite)
    """
    if database_url is None:
        database_url = os.getenv('DATABASE_URL', 'sqlite:///data/mvp_tracker.db')

    engine = create_engine(database_url)
    Session = sessionmaker(bind=engine)
    session = Session()

    # Load historical data
    script_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(script_dir, 'historical_mvp_data.json')

    with open(json_path, 'r') as f:
        data = json.load(f)

    print("=" * 60)
    print("Seeding Historical MVP Voting Data")
    print("=" * 60)

    total_voters_added = 0
    total_votes_added = 0
    total_candidates_added = 0

    for season_data in data['historical_seasons']:
        season = season_data['season']
        winner = season_data['winner']

        print(f"\n{season} Season (Winner: {winner})")
        print("-" * 60)

        # Process voter ballots
        for voter_data in season_data['voters']:
            voter_name = voter_data['name']

            # Get or create voter
            voter = session.query(Voter).filter_by(name=voter_name).first()
            if not voter:
                voter = Voter(
                    name=voter_name,
                    outlet=voter_data.get('outlet'),
                    twitter_handle=voter_data.get('twitter_handle')
                )
                session.add(voter)
                session.flush()
                total_voters_added += 1
                print(f"  ✓ Added voter: {voter_name}")

            # Process ballot
            for vote_data in voter_data['ballot']:
                # Get or create candidate
                candidate = session.query(Candidate).filter_by(
                    name=vote_data['candidate'],
                    season=season
                ).first()

                if not candidate:
                    candidate = Candidate(
                        name=vote_data['candidate'],
                        team=vote_data['team'],
                        position=vote_data['position'],
                        season=season
                    )
                    session.add(candidate)
                    session.flush()
                    total_candidates_added += 1

                # Check if vote already exists
                existing_vote = session.query(Vote).filter_by(
                    voter_id=voter.id,
                    candidate_id=candidate.id,
                    season=season,
                    ranking=vote_data['ranking']
                ).first()

                if not existing_vote:
                    # Add vote
                    vote = Vote(
                        voter_id=voter.id,
                        candidate_id=candidate.id,
                        season=season,
                        ranking=vote_data['ranking'],
                        source_type=SourceType.OFFICIAL,
                        confidence=ConfidenceLevel.HIGH,
                        confidence_score=None,
                        credibility_tier=None,
                        credibility_score=None,
                        has_direct_quote=0,
                        has_speculation_language=0,
                        verified=1,
                        announcement_date=datetime(int(season.split('-')[0]) + 1, 2, 1)
                    )
                    session.add(vote)
                    total_votes_added += 1

            print(f"    Added {len(voter_data['ballot'])} votes for {voter_name}")

        # Process final results to ensure all candidates are in database
        for candidate_name, results in season_data['final_results'].items():
            candidate = session.query(Candidate).filter_by(
                name=candidate_name,
                season=season
            ).first()

            if not candidate:
                # Create candidate without full details (we only have name from final results)
                candidate = Candidate(
                    name=candidate_name,
                    season=season
                )
                session.add(candidate)
                total_candidates_added += 1
                print(f"  ✓ Added candidate from final results: {candidate_name}")

    # Commit all changes
    session.commit()

    print("\n" + "=" * 60)
    print("Seeding Complete!")
    print("=" * 60)
    print(f"Total voters added: {total_voters_added}")
    print(f"Total candidates added: {total_candidates_added}")
    print(f"Total votes added: {total_votes_added}")
    print("=" * 60)

    session.close()
    return {
        'voters_added': total_voters_added,
        'candidates_added': total_candidates_added,
        'votes_added': total_votes_added
    }


if __name__ == '__main__':
    seed_historical_data()
