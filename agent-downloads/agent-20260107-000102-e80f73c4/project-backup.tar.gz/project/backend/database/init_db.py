"""
Initialize the database with schema and seed data
"""
from .models import Voter, Candidate, Vote, ConfidenceLevel, SourceType
from .connection import SessionLocal, init_db as create_tables
from datetime import datetime


def seed_known_voters():
    """Seed database with known voters from 2024-25 season"""
    session = SessionLocal()
    
    # Known voters
    voters_data = [
        {"name": "Tom Brady", "outlet": "Fox Sports", "twitter_handle": "@TomBrady"},
        {"name": "Mina Kimes", "outlet": "ESPN", "twitter_handle": "@minakimes"},
        {"name": "Tony Dungy", "outlet": "NBC Sports", "twitter_handle": "@TonyDungy"},
        {"name": "Tedy Bruschi", "outlet": "ESPN", "twitter_handle": "@TedyBruschi"},
    ]
    
    for voter_data in voters_data:
        voter = session.query(Voter).filter_by(name=voter_data["name"]).first()
        if not voter:
            voter = Voter(**voter_data)
            session.add(voter)
    
    session.commit()
    print(f"Seeded {len(voters_data)} known voters")
    
    # Known candidates for 2024-25
    candidates_data = [
        {"name": "Josh Allen", "team": "Buffalo Bills", "position": "QB", "season": "2024-25"},
        {"name": "Lamar Jackson", "team": "Baltimore Ravens", "position": "QB", "season": "2024-25"},
        {"name": "Saquon Barkley", "team": "Philadelphia Eagles", "position": "RB", "season": "2024-25"},
        {"name": "Joe Burrow", "team": "Cincinnati Bengals", "position": "QB", "season": "2024-25"},
        {"name": "Jared Goff", "team": "Detroit Lions", "position": "QB", "season": "2024-25"},
        {"name": "Ja'Marr Chase", "team": "Cincinnati Bengals", "position": "WR", "season": "2024-25"},
        {"name": "Jayden Daniels", "team": "Washington Commanders", "position": "QB", "season": "2024-25"},
        {"name": "Patrick Mahomes", "team": "Kansas City Chiefs", "position": "QB", "season": "2024-25"},
    ]
    
    for candidate_data in candidates_data:
        candidate = session.query(Candidate).filter_by(
            name=candidate_data["name"], 
            season=candidate_data["season"]
        ).first()
        if not candidate:
            candidate = Candidate(**candidate_data)
            session.add(candidate)
    
    session.commit()
    print(f"Seeded {len(candidates_data)} candidates")
    
    session.close()


def seed_known_votes():
    """Seed known votes from public announcements"""
    session = SessionLocal()
    
    # Tom Brady's ballot
    tom_brady = session.query(Voter).filter_by(name="Tom Brady").first()
    if tom_brady:
        votes_data = [
            ("Lamar Jackson", 1, "https://www.fox5dc.com/news/nfl-awards-tom-bradys-nfl-mvp-vote-went-baltimore-raven-lamar-jackson"),
            ("Josh Allen", 2, "https://www.fox5dc.com/news/nfl-awards-tom-bradys-nfl-mvp-vote-went-baltimore-raven-lamar-jackson"),
            ("Saquon Barkley", 3, "https://www.fox5dc.com/news/nfl-awards-tom-bradys-nfl-mvp-vote-went-baltimore-raven-lamar-jackson"),
            ("Ja'Marr Chase", 4, "https://www.cbssports.com/nfl/news/behind-the-nfl-mvp-voting-tom-brady-former-patriots-teammate-both-select-jamarr-chase-over-joe-burrow/"),
            ("Joe Burrow", 5, "https://www.fox5dc.com/news/nfl-awards-tom-bradys-nfl-mvp-vote-went-baltimore-raven-lamar-jackson"),
        ]
        
        for candidate_name, ranking, source_url in votes_data:
            candidate = session.query(Candidate).filter_by(name=candidate_name, season="2024-25").first()
            if candidate:
                vote = session.query(Vote).filter_by(
                    voter_id=tom_brady.id,
                    candidate_id=candidate.id,
                    season="2024-25"
                ).first()
                if not vote:
                    vote = Vote(
                        voter_id=tom_brady.id,
                        candidate_id=candidate.id,
                        ranking=ranking,
                        season="2024-25",
                        source_url=source_url,
                        source_type=SourceType.NEWS_ARTICLE,
                        confidence=ConfidenceLevel.HIGH,
                        verified=1,
                        announcement_date=datetime(2025, 2, 7)
                    )
                    session.add(vote)
    
    # Mina Kimes' ballot
    mina_kimes = session.query(Voter).filter_by(name="Mina Kimes").first()
    if mina_kimes:
        votes_data = [
            ("Lamar Jackson", 1),
            ("Josh Allen", 2),
            ("Joe Burrow", 3),
            ("Saquon Barkley", 4),
            ("Jayden Daniels", 5),
        ]
        
        for candidate_name, ranking in votes_data:
            candidate = session.query(Candidate).filter_by(name=candidate_name, season="2024-25").first()
            if candidate:
                vote = session.query(Vote).filter_by(
                    voter_id=mina_kimes.id,
                    candidate_id=candidate.id,
                    season="2024-25"
                ).first()
                if not vote:
                    vote = Vote(
                        voter_id=mina_kimes.id,
                        candidate_id=candidate.id,
                        ranking=ranking,
                        season="2024-25",
                        source_url="https://x.com/minakimes/status/2008283462403584336",
                        source_type=SourceType.SOCIAL_MEDIA,
                        confidence=ConfidenceLevel.HIGH,
                        verified=1,
                        announcement_date=datetime(2025, 2, 7)
                    )
                    session.add(vote)
    
    session.commit()
    print("Seeded known votes")
    session.close()


if __name__ == "__main__":
    create_tables()
    seed_known_voters()
    seed_known_votes()
    print("\nDatabase initialization complete!")
