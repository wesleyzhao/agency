"""
Database migration to add notification tables for Feature #18
"""
import sys
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.models import Base, NotificationPreference, NotificationHistory

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///../data/mvp_tracker.db')


def migrate():
    """Add notification tables to database"""
    print("=" * 60)
    print("Notification System Migration - Feature #18")
    print("=" * 60)

    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Create notification tables
        print("\n[1/3] Creating notification_preferences table...")
        NotificationPreference.__table__.create(engine, checkfirst=True)
        print("✓ notification_preferences table created")

        print("\n[2/3] Creating notification_history table...")
        NotificationHistory.__table__.create(engine, checkfirst=True)
        print("✓ notification_history table created")

        # Verify tables exist
        print("\n[3/3] Verifying tables...")
        inspector = engine.dialect.get_table_names(session.connection())

        if 'notification_preferences' in inspector:
            print("✓ notification_preferences table verified")
        else:
            raise Exception("notification_preferences table not found!")

        if 'notification_history' in inspector:
            print("✓ notification_history table verified")
        else:
            raise Exception("notification_history table not found!")

        print("\n" + "=" * 60)
        print("Migration completed successfully!")
        print("=" * 60)

    except Exception as e:
        print(f"\n✗ Migration failed: {e}")
        session.rollback()
        raise
    finally:
        session.close()


def rollback():
    """Remove notification tables"""
    print("=" * 60)
    print("Rolling back notification tables...")
    print("=" * 60)

    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        print("\nDropping notification_history table...")
        session.execute(text("DROP TABLE IF EXISTS notification_history"))
        print("✓ notification_history table dropped")

        print("\nDropping notification_preferences table...")
        session.execute(text("DROP TABLE IF EXISTS notification_preferences"))
        print("✓ notification_preferences table dropped")

        session.commit()

        print("\n" + "=" * 60)
        print("Rollback completed successfully!")
        print("=" * 60)

    except Exception as e:
        print(f"\n✗ Rollback failed: {e}")
        session.rollback()
        raise
    finally:
        session.close()


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == '--rollback':
        rollback()
    else:
        migrate()
