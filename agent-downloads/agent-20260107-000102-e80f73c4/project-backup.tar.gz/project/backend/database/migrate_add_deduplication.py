"""
Database migration script to add deduplication features

This script adds:
1. source_type column to sources table
2. vote_sources junction table for many-to-many relationship
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from sqlalchemy import text
from backend.database import get_engine, get_session, Base
from backend.database.models import Source, VoteSource
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def check_column_exists(engine, table_name: str, column_name: str) -> bool:
    """Check if a column exists in a table"""
    with engine.connect() as conn:
        # SQLite query to check if column exists
        result = conn.execute(text(f"PRAGMA table_info({table_name})"))
        columns = [row[1] for row in result]
        return column_name in columns


def check_table_exists(engine, table_name: str) -> bool:
    """Check if a table exists"""
    with engine.connect() as conn:
        result = conn.execute(text(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=:table_name"
        ), {"table_name": table_name})
        return result.fetchone() is not None


def migrate():
    """Run migration to add deduplication features"""
    logger.info("=" * 80)
    logger.info("DATABASE MIGRATION: Adding Deduplication Features")
    logger.info("=" * 80)

    engine = get_engine()

    # Check if sources table exists
    if not check_table_exists(engine, 'sources'):
        logger.error("❌ Sources table does not exist. Please run init_db.py first.")
        return False

    # 1. Add source_type column to sources table if it doesn't exist
    if not check_column_exists(engine, 'sources', 'source_type'):
        logger.info("Adding 'source_type' column to 'sources' table...")
        try:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE sources ADD COLUMN source_type VARCHAR(50)"))
                conn.commit()
            logger.info("✓ Added 'source_type' column")
        except Exception as e:
            logger.error(f"❌ Failed to add source_type column: {e}")
            return False
    else:
        logger.info("✓ 'source_type' column already exists")

    # 2. Create vote_sources junction table if it doesn't exist
    if not check_table_exists(engine, 'vote_sources'):
        logger.info("Creating 'vote_sources' junction table...")
        try:
            # Create just the VoteSource table
            VoteSource.__table__.create(engine, checkfirst=True)
            logger.info("✓ Created 'vote_sources' table")
        except Exception as e:
            logger.error(f"❌ Failed to create vote_sources table: {e}")
            return False
    else:
        logger.info("✓ 'vote_sources' table already exists")

    # 3. Verify the migration
    logger.info("\nVerifying migration...")

    session = get_session()
    try:
        # Test query on sources
        source_count = session.query(Source).count()
        logger.info(f"✓ Sources table accessible: {source_count} sources")

        # Test query on vote_sources
        vote_source_count = session.query(VoteSource).count()
        logger.info(f"✓ VoteSources table accessible: {vote_source_count} links")

    except Exception as e:
        logger.error(f"❌ Verification failed: {e}")
        return False
    finally:
        session.close()

    logger.info("\n" + "=" * 80)
    logger.info("✅ Migration completed successfully!")
    logger.info("=" * 80)

    return True


def rollback():
    """Rollback migration (remove added features)"""
    logger.info("=" * 80)
    logger.info("DATABASE ROLLBACK: Removing Deduplication Features")
    logger.info("=" * 80)

    engine = get_engine()

    # Drop vote_sources table
    if check_table_exists(engine, 'vote_sources'):
        logger.info("Dropping 'vote_sources' table...")
        try:
            with engine.connect() as conn:
                conn.execute(text("DROP TABLE vote_sources"))
                conn.commit()
            logger.info("✓ Dropped 'vote_sources' table")
        except Exception as e:
            logger.error(f"❌ Failed to drop vote_sources table: {e}")
            return False
    else:
        logger.info("✓ 'vote_sources' table doesn't exist")

    # Note: SQLite doesn't support DROP COLUMN, so we can't remove source_type
    # without recreating the entire table
    logger.info("\nNote: 'source_type' column cannot be removed in SQLite without recreating the table.")
    logger.info("If you need to remove it, you'll need to backup data and recreate the sources table.")

    logger.info("\n" + "=" * 80)
    logger.info("✅ Rollback completed!")
    logger.info("=" * 80)

    return True


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Database migration for deduplication features')
    parser.add_argument('--rollback', action='store_true',
                       help='Rollback the migration (remove added features)')

    args = parser.parse_args()

    if args.rollback:
        success = rollback()
    else:
        success = migrate()

    sys.exit(0 if success else 1)
