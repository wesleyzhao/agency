"""
Database models for NFL MVP Voter Tracker
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Enum, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class ConfidenceLevel(enum.Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class SourceType(enum.Enum):
    OFFICIAL = "official"
    SOCIAL_MEDIA = "social_media"
    NEWS_ARTICLE = "news_article"
    REDDIT = "reddit"
    SPECULATION = "speculation"


class CredibilityTier(enum.Enum):
    VERIFIED = "verified"      # Direct from verified account or official source
    OFFICIAL = "official"       # Major news outlet with quote
    RELIABLE = "reliable"       # Reputable source or corroborated
    UNVERIFIED = "unverified"   # Single unverified source
    SPECULATION = "speculation" # Rumor or prediction


class Voter(Base):
    """AP NFL MVP voter information"""
    __tablename__ = 'voters'

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False, unique=True)
    outlet = Column(String(200))  # Media outlet they work for
    twitter_handle = Column(String(100))
    location = Column(String(200))
    bio = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    votes = relationship("Vote", back_populates="voter", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Voter {self.name} - {self.outlet}>"


class Candidate(Base):
    """NFL MVP candidate"""
    __tablename__ = 'candidates'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    team = Column(String(100))
    position = Column(String(50))
    season = Column(String(10))  # e.g., "2024-25"
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    votes = relationship("Vote", back_populates="candidate")
    
    def __repr__(self):
        return f"<Candidate {self.name} - {self.team}>"


class Vote(Base):
    """A voter's MVP vote"""
    __tablename__ = 'votes'
    
    id = Column(Integer, primary_key=True)
    voter_id = Column(Integer, ForeignKey('voters.id'), nullable=False)
    candidate_id = Column(Integer, ForeignKey('candidates.id'), nullable=False)
    
    # Vote details
    ranking = Column(Integer)  # 1-5 for ranked voting
    season = Column(String(10), nullable=False)  # e.g., "2024-25"
    
    # Source information
    source_url = Column(String(500))
    source_type = Column(Enum(SourceType), default=SourceType.SPECULATION)
    confidence = Column(Enum(ConfidenceLevel), default=ConfidenceLevel.MEDIUM)
    confidence_score = Column(Float)  # Numeric confidence score (0-100)

    # Credibility tracking (Feature #16)
    credibility_tier = Column(Enum(CredibilityTier), default=CredibilityTier.UNVERIFIED)
    credibility_score = Column(Float)  # Numeric credibility score (0-100)
    has_direct_quote = Column(Integer, default=0)  # Source contains direct quote
    has_speculation_language = Column(Integer, default=0)  # Source contains speculation

    # Extraction details
    announcement_date = Column(DateTime)
    extracted_text = Column(Text)  # Original text where vote was found
    verified = Column(Integer, default=0)  # Manual verification flag
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    voter = relationship("Voter", back_populates="votes")
    candidate = relationship("Candidate", back_populates="votes")
    
    def __repr__(self):
        return f"<Vote {self.voter.name if self.voter else 'Unknown'} -> {self.candidate.name if self.candidate else 'Unknown'} (Rank {self.ranking})>"


class ScrapingLog(Base):
    """Log of scraping activities"""
    __tablename__ = 'scraping_logs'
    
    id = Column(Integer, primary_key=True)
    source = Column(String(100))  # e.g., "reddit", "google_news", "espn"
    search_query = Column(String(500))
    urls_found = Column(Integer, default=0)
    votes_extracted = Column(Integer, default=0)
    errors = Column(Text)
    
    # Metadata
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    def __repr__(self):
        return f"<ScrapingLog {self.source} - {self.started_at}>"


class Source(Base):
    """Unique sources to avoid duplication"""
    __tablename__ = 'sources'

    id = Column(Integer, primary_key=True)
    url = Column(String(500), unique=True, nullable=False)
    title = Column(String(500))
    content_hash = Column(String(64))  # MD5 hash of content
    processed = Column(Integer, default=0)
    source_type = Column(String(50))  # 'google', 'reddit', 'news', etc.

    # Credibility tracking (Feature #16)
    credibility_tier = Column(Enum(CredibilityTier), default=CredibilityTier.UNVERIFIED)
    credibility_score = Column(Float)  # Numeric credibility score (0-100)
    domain_reputation = Column(String(20))  # tier1/tier2/tier3/social/forum/unknown

    # Metadata
    discovered_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime)

    # Relationships
    votes = relationship("VoteSource", back_populates="source")

    def __repr__(self):
        return f"<Source {self.url}>"


class VoteSource(Base):
    """Junction table linking votes to their sources (many-to-many)"""
    __tablename__ = 'vote_sources'

    id = Column(Integer, primary_key=True)
    vote_id = Column(Integer, ForeignKey('votes.id'), nullable=False)
    source_id = Column(Integer, ForeignKey('sources.id'), nullable=False)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    vote = relationship("Vote")
    source = relationship("Source", back_populates="votes")

    def __repr__(self):
        return f"<VoteSource vote_id={self.vote_id} source_id={self.source_id}>"


class NotificationChannel(enum.Enum):
    """Types of notification channels"""
    EMAIL = "email"
    WEBHOOK = "webhook"
    CONSOLE = "console"


class NotificationEventType(enum.Enum):
    """Types of events that trigger notifications"""
    NEW_VOTER_FOUND = "new_voter_found"
    NEW_VOTE_DISCLOSED = "new_vote_disclosed"
    FULL_BALLOT_COMPLETE = "full_ballot_complete"
    HIGH_CONFIDENCE_VOTE = "high_confidence_vote"
    VERIFIED_VOTE = "verified_vote"
    SCRAPING_COMPLETE = "scraping_complete"
    SCRAPING_ERROR = "scraping_error"


class NotificationPreference(Base):
    """User notification preferences - Feature #18"""
    __tablename__ = 'notification_preferences'

    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)  # Preference set name
    enabled = Column(Integer, default=1)  # 0 = disabled, 1 = enabled

    # Event type preferences (which events trigger notifications)
    notify_new_voter = Column(Integer, default=1)
    notify_new_vote = Column(Integer, default=1)
    notify_full_ballot = Column(Integer, default=1)
    notify_high_confidence = Column(Integer, default=1)
    notify_verified_vote = Column(Integer, default=1)
    notify_scraping_complete = Column(Integer, default=0)
    notify_scraping_error = Column(Integer, default=1)

    # Channel configurations
    channel = Column(Enum(NotificationChannel), nullable=False)

    # Email channel settings
    email_address = Column(String(200))
    email_from = Column(String(200))

    # Webhook channel settings
    webhook_url = Column(String(500))
    webhook_secret = Column(String(200))

    # Rate limiting
    min_interval_minutes = Column(Integer, default=0)  # Minimum time between notifications
    batch_notifications = Column(Integer, default=0)  # 0 = instant, 1 = batch/digest

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<NotificationPreference {self.name} - {self.channel.value if self.channel else 'unknown'}>"


class NotificationHistory(Base):
    """History of sent notifications - Feature #18"""
    __tablename__ = 'notification_history'

    id = Column(Integer, primary_key=True)
    preference_id = Column(Integer, ForeignKey('notification_preferences.id'))

    # Event details
    event_type = Column(Enum(NotificationEventType), nullable=False)
    title = Column(String(500), nullable=False)
    message = Column(Text, nullable=False)

    # Related entities
    voter_id = Column(Integer, ForeignKey('voters.id'))
    vote_id = Column(Integer, ForeignKey('votes.id'))
    candidate_id = Column(Integer, ForeignKey('candidates.id'))

    # Delivery details
    channel = Column(Enum(NotificationChannel), nullable=False)
    recipient = Column(String(500))  # Email address or webhook URL
    status = Column(String(50), default='pending')  # pending, sent, failed
    error_message = Column(Text)

    # Metadata
    sent_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    preference = relationship("NotificationPreference")
    voter = relationship("Voter")
    vote = relationship("Vote")
    candidate = relationship("Candidate")

    def __repr__(self):
        return f"<NotificationHistory {self.event_type.value if self.event_type else 'unknown'} - {self.status}>"
