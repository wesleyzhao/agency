#!/usr/bin/env python3
"""
Quick fix for credibility_tier enum values in database
Converts uppercase 'UNVERIFIED' to lowercase 'unverified' to match enum
"""

from sqlalchemy import create_engine, text
import os

# Database path
DB_PATH = os.path.join(os.path.dirname(__file__), '../../data/mvp_tracker.db')
DATABASE_URL = f'sqlite:///{DB_PATH}'

def fix_credibility_values():
    """Fix credibility_tier values to match enum"""
    engine = create_engine(DATABASE_URL)

    print("Fixing credibility_tier enum values...")

    with engine.connect() as conn:
        # Check current values
        result = conn.execute(text("SELECT DISTINCT credibility_tier FROM votes WHERE credibility_tier IS NOT NULL"))
        current_values = [row[0] for row in result]
        print(f"Current values: {current_values}")

        # Fix UNVERIFIED to unverified
        result = conn.execute(text("UPDATE votes SET credibility_tier = 'unverified' WHERE credibility_tier = 'UNVERIFIED'"))
        conn.commit()
        print(f"✓ Updated {result.rowcount} rows from 'UNVERIFIED' to 'unverified'")

        # Check values after fix
        result = conn.execute(text("SELECT DISTINCT credibility_tier FROM votes WHERE credibility_tier IS NOT NULL"))
        fixed_values = [row[0] for row in result]
        print(f"After fix: {fixed_values}")

    print("✓ Database credibility values fixed!")

if __name__ == "__main__":
    fix_credibility_values()
