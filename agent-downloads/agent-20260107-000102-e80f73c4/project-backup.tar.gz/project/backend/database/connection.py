"""
Database connection management
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager
from .models import Base

# Database configuration
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///data/mvp_tracker.db')

# Create engine
engine = create_engine(
    DATABASE_URL,
    echo=os.getenv('DB_ECHO', 'false').lower() == 'true',
    pool_pre_ping=True  # Verify connections before using them
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_engine():
    """Get the database engine"""
    return engine


def get_session() -> Session:
    """
    Get a new database session

    Returns:
        Session: SQLAlchemy session
    """
    return SessionLocal()


@contextmanager
def session_scope():
    """
    Provide a transactional scope around a series of operations.

    Usage:
        with session_scope() as session:
            voter = session.query(Voter).first()
            print(voter.name)
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()


def init_db():
    """
    Initialize database by creating all tables
    """
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully!")


def drop_all_tables():
    """
    Drop all tables (use with caution!)
    """
    Base.metadata.drop_all(bind=engine)
    print("All tables dropped!")


def reset_db():
    """
    Reset the database by dropping and recreating all tables
    """
    drop_all_tables()
    init_db()
    print("Database reset complete!")
