#!/usr/bin/env python3
"""
Database migration script to add credibility tracking fields

Feature #16: Source Credibility Tracking

Adds the following fields to the votes table:
- credibility_tier (ENUM: verified/official/reliable/unverified/speculation)
- credibility_score (FLOAT: 0-100)
- has_direct_quote (INTEGER: 0/1)
- has_speculation_language (INTEGER: 0/1)

Adds the following fields to the sources table:
- credibility_tier (ENUM: verified/official/reliable/unverified/speculation)
- credibility_score (FLOAT: 0-100)
- domain_reputation (VARCHAR: tier1/tier2/tier3/social/forum/unknown)

Usage:
    python3 migrate_add_credibility.py          # Run migration
    python3 migrate_add_credibility.py --check  # Check if migration needed
    python3 migrate_add_credibility.py --rollback  # Rollback migration
"""

import sys
import os
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from sqlalchemy import inspect, text
from database import get_engine, get_session
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def check_column_exists(engine, table_name, column_name):
    """Check if a column exists in a table"""
    inspector = inspect(engine)
    columns = [col['name'] for col in inspector.get_columns(table_name)]
    return column_name in columns


def check_migration_needed(engine):
    """Check if migration has already been applied"""
    inspector = inspect(engine)

    # Check if tables exist
    tables = inspector.get_table_names()
    if 'votes' not in tables or 'sources' not in tables:
        logger.error("Required tables (votes, sources) do not exist!")
        return False

    # Check votes table
    votes_needs_migration = not check_column_exists(engine, 'votes', 'credibility_tier')

    # Check sources table
    sources_needs_migration = not check_column_exists(engine, 'sources', 'credibility_tier')

    return votes_needs_migration or sources_needs_migration


def migrate_up(engine):
    """Apply the migration"""
    logger.info("Starting credibility tracking migration...")

    session = get_session()

    try:
        # Check if votes table needs migration
        if not check_column_exists(engine, 'votes', 'credibility_tier'):
            logger.info("Adding credibility fields to votes table...")

            # Add credibility_tier column
            session.execute(text(
                "ALTER TABLE votes ADD COLUMN credibility_tier VARCHAR(20) DEFAULT 'unverified'"
            ))

            # Add credibility_score column
            session.execute(text(
                "ALTER TABLE votes ADD COLUMN credibility_score FLOAT"
            ))

            # Add has_direct_quote column
            session.execute(text(
                "ALTER TABLE votes ADD COLUMN has_direct_quote INTEGER DEFAULT 0"
            ))

            # Add has_speculation_language column
            session.execute(text(
                "ALTER TABLE votes ADD COLUMN has_speculation_language INTEGER DEFAULT 0"
            ))

            session.commit()
            logger.info("✓ Added credibility fields to votes table")
        else:
            logger.info("✓ Votes table already has credibility fields")

        # Check if sources table needs migration
        if not check_column_exists(engine, 'sources', 'credibility_tier'):
            logger.info("Adding credibility fields to sources table...")

            # Add credibility_tier column
            session.execute(text(
                "ALTER TABLE sources ADD COLUMN credibility_tier VARCHAR(20) DEFAULT 'unverified'"
            ))

            # Add credibility_score column
            session.execute(text(
                "ALTER TABLE sources ADD COLUMN credibility_score FLOAT"
            ))

            # Add domain_reputation column
            session.execute(text(
                "ALTER TABLE sources ADD COLUMN domain_reputation VARCHAR(20)"
            ))

            session.commit()
            logger.info("✓ Added credibility fields to sources table")
        else:
            logger.info("✓ Sources table already has credibility fields")

        # Verify migration
        logger.info("\nVerifying migration...")
        verify_migration(engine)

        logger.info("\n✅ Migration completed successfully!")

    except Exception as e:
        session.rollback()
        logger.error(f"\n❌ Migration failed: {str(e)}")
        raise
    finally:
        session.close()


def migrate_down(engine):
    """Rollback the migration"""
    logger.info("Rolling back credibility tracking migration...")

    session = get_session()

    try:
        # Check if votes table has the columns
        if check_column_exists(engine, 'votes', 'credibility_tier'):
            logger.info("Removing credibility fields from votes table...")

            # SQLite doesn't support DROP COLUMN directly, need to use workaround
            # For now, we'll just note that this is a limitation
            logger.warning(
                "SQLite doesn't support DROP COLUMN. "
                "Manual rollback required or database recreation."
            )

            # For other databases (PostgreSQL, MySQL), you would use:
            # session.execute(text("ALTER TABLE votes DROP COLUMN credibility_tier"))
            # session.execute(text("ALTER TABLE votes DROP COLUMN credibility_score"))
            # session.execute(text("ALTER TABLE votes DROP COLUMN has_direct_quote"))
            # session.execute(text("ALTER TABLE votes DROP COLUMN has_speculation_language"))

        # Same for sources table
        if check_column_exists(engine, 'sources', 'credibility_tier'):
            logger.info("Removing credibility fields from sources table...")
            logger.warning(
                "SQLite doesn't support DROP COLUMN. "
                "Manual rollback required or database recreation."
            )

        logger.info("\n⚠️  Rollback not fully supported with SQLite")
        logger.info("To fully rollback, backup your data and recreate the database")

    except Exception as e:
        session.rollback()
        logger.error(f"\n❌ Rollback failed: {str(e)}")
        raise
    finally:
        session.close()


def verify_migration(engine):
    """Verify that migration was successful"""
    inspector = inspect(engine)

    # Check votes table
    votes_columns = [col['name'] for col in inspector.get_columns('votes')]
    expected_votes_columns = [
        'credibility_tier', 'credibility_score',
        'has_direct_quote', 'has_speculation_language'
    ]

    for col in expected_votes_columns:
        if col in votes_columns:
            logger.info(f"  ✓ votes.{col} exists")
        else:
            logger.error(f"  ✗ votes.{col} missing")
            return False

    # Check sources table
    sources_columns = [col['name'] for col in inspector.get_columns('sources')]
    expected_sources_columns = [
        'credibility_tier', 'credibility_score', 'domain_reputation'
    ]

    for col in expected_sources_columns:
        if col in sources_columns:
            logger.info(f"  ✓ sources.{col} exists")
        else:
            logger.error(f"  ✗ sources.{col} missing")
            return False

    return True


def print_usage():
    """Print usage information"""
    print(__doc__)


def main():
    """Main migration script"""
    import argparse

    parser = argparse.ArgumentParser(
        description='Add credibility tracking to database'
    )
    parser.add_argument(
        '--check',
        action='store_true',
        help='Check if migration is needed'
    )
    parser.add_argument(
        '--rollback',
        action='store_true',
        help='Rollback the migration'
    )

    args = parser.parse_args()

    # Get database engine
    engine = get_engine()

    if args.check:
        # Check if migration is needed
        if check_migration_needed(engine):
            logger.info("✓ Migration is needed")
            sys.exit(1)  # Exit with error code to indicate migration needed
        else:
            logger.info("✓ Migration already applied or not needed")
            sys.exit(0)

    elif args.rollback:
        # Rollback migration
        migrate_down(engine)

    else:
        # Apply migration
        if check_migration_needed(engine):
            migrate_up(engine)
        else:
            logger.info("✓ Migration already applied")
            logger.info("\nVerifying existing migration...")
            verify_migration(engine)


if __name__ == '__main__':
    main()
