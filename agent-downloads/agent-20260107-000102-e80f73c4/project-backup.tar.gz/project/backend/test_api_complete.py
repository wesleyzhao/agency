#!/usr/bin/env python3
"""
Comprehensive API Testing Script - Feature #19
Tests all 40 API endpoints for the NFL MVP Voter Tracker
"""

import requests
import json
import sys
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:5000/api"
COLORS = {
    'green': '\033[92m',
    'red': '\033[91m',
    'yellow': '\033[93m',
    'cyan': '\033[96m',
    'reset': '\033[0m'
}

# Test results tracking
test_results = {
    'passed': 0,
    'failed': 0,
    'skipped': 0,
    'total': 0
}

def print_color(text, color):
    """Print colored text"""
    print(f"{COLORS.get(color, '')}{text}{COLORS['reset']}")

def print_header(title):
    """Print section header"""
    print()
    print_color("=" * 80, 'cyan')
    print_color(f"  {title}", 'cyan')
    print_color("=" * 80, 'cyan')
    print()

def test_endpoint(name, method, endpoint, expected_status=200, data=None, description=""):
    """Test a single API endpoint"""
    global test_results
    test_results['total'] += 1

    url = f"{BASE_URL}{endpoint}"
    print(f"\n{test_results['total']}. {name}")
    if description:
        print_color(f"   {description}", 'cyan')
    print(f"   {method} {endpoint}")

    try:
        if method == 'GET':
            response = requests.get(url, timeout=10)
        elif method == 'POST':
            response = requests.post(url, json=data, timeout=10)
        elif method == 'PUT':
            response = requests.put(url, json=data, timeout=10)
        elif method == 'DELETE':
            response = requests.delete(url, timeout=10)
        else:
            print_color(f"   ✗ Unsupported HTTP method: {method}", 'red')
            test_results['failed'] += 1
            return None

        if response.status_code == expected_status:
            print_color(f"   ✓ Status: {response.status_code} (expected {expected_status})", 'green')
            test_results['passed'] += 1
            return response
        else:
            print_color(f"   ✗ Status: {response.status_code} (expected {expected_status})", 'red')
            print_color(f"   Response: {response.text[:200]}", 'red')
            test_results['failed'] += 1
            return None

    except requests.exceptions.ConnectionError:
        print_color(f"   ✗ Connection failed - is the backend server running?", 'red')
        test_results['failed'] += 1
        return None
    except requests.exceptions.Timeout:
        print_color(f"   ✗ Request timed out", 'red')
        test_results['failed'] += 1
        return None
    except Exception as e:
        print_color(f"   ✗ Error: {str(e)}", 'red')
        test_results['failed'] += 1
        return None

def display_sample_data(response, max_items=2):
    """Display sample response data"""
    if not response:
        return

    try:
        data = response.json()
        if isinstance(data, list):
            print_color(f"   → Returned {len(data)} items", 'cyan')
            if len(data) > 0:
                print_color(f"   → Sample: {json.dumps(data[0], indent=2)[:200]}...", 'cyan')
        elif isinstance(data, dict):
            print_color(f"   → Response keys: {', '.join(data.keys())}", 'cyan')
            if 'results' in data:
                print_color(f"   → Results count: {data.get('count', len(data['results']))}", 'cyan')
    except:
        pass

def run_all_tests():
    """Run comprehensive API tests"""

    print_header("NFL MVP Voter Tracker - Complete API Test Suite")
    print(f"Testing API at: {BASE_URL}")
    print(f"Test started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Track created IDs for cleanup
    created_ids = {
        'voter': None,
        'candidate': None,
        'vote': None,
        'notification_pref': None
    }

    # ========================================================================
    # 1. HEALTH CHECK
    # ========================================================================
    print_header("1. Health Check API (1 endpoint)")

    response = test_endpoint(
        "Health Check",
        "GET", "/health",
        description="Verify API is running"
    )
    display_sample_data(response)

    # ========================================================================
    # 2. VOTERS API
    # ========================================================================
    print_header("2. Voters API (5 endpoints)")

    # GET /api/voters
    response = test_endpoint(
        "List All Voters",
        "GET", "/voters",
        description="Retrieve list of all AP voters"
    )
    display_sample_data(response)

    # POST /api/voters
    voter_data = {
        "name": f"Test Voter {datetime.now().timestamp()}",
        "outlet": "Test Network",
        "twitter_handle": "@testvoter",
        "location": "Test City, ST",
        "bio": "Test voter for API testing"
    }
    response = test_endpoint(
        "Create Voter",
        "POST", "/voters",
        expected_status=201,
        data=voter_data,
        description="Add new voter to database"
    )
    if response:
        try:
            created_ids['voter'] = response.json().get('id')
            print_color(f"   → Created voter ID: {created_ids['voter']}", 'cyan')
        except:
            pass

    # GET /api/voters/:id
    if created_ids['voter']:
        response = test_endpoint(
            "Get Voter Details",
            "GET", f"/voters/{created_ids['voter']}?season=2024-25",
            description="Retrieve comprehensive voter information"
        )
        display_sample_data(response)
    else:
        print_color("   ⚠ Skipping - no voter ID available", 'yellow')
        test_results['skipped'] += 1

    # PUT /api/voters/:id
    if created_ids['voter']:
        update_data = {"bio": "Updated test voter biography"}
        response = test_endpoint(
            "Update Voter",
            "PUT", f"/voters/{created_ids['voter']}",
            data=update_data,
            description="Update voter information"
        )
    else:
        print_color("   ⚠ Skipping - no voter ID available", 'yellow')
        test_results['skipped'] += 1

    # DELETE /api/voters/:id will be done at the end for cleanup

    # ========================================================================
    # 3. CANDIDATES API
    # ========================================================================
    print_header("3. Candidates API (5 endpoints)")

    # GET /api/candidates
    response = test_endpoint(
        "List All Candidates",
        "GET", "/candidates?season=2024-25",
        description="Retrieve all MVP candidates for a season"
    )
    display_sample_data(response)

    # POST /api/candidates
    candidate_data = {
        "name": f"Test Candidate {datetime.now().timestamp()}",
        "team": "Test Team",
        "position": "QB",
        "season": "2024-25"
    }
    response = test_endpoint(
        "Create Candidate",
        "POST", "/candidates",
        expected_status=201,
        data=candidate_data,
        description="Add new MVP candidate"
    )
    if response:
        try:
            created_ids['candidate'] = response.json().get('id')
            print_color(f"   → Created candidate ID: {created_ids['candidate']}", 'cyan')
        except:
            pass

    # GET /api/candidates/:id (using list to verify)
    # PUT /api/candidates/:id
    if created_ids['candidate']:
        update_data = {"team": "Updated Test Team"}
        response = test_endpoint(
            "Update Candidate",
            "PUT", f"/candidates/{created_ids['candidate']}",
            data=update_data,
            description="Update candidate information"
        )
    else:
        print_color("   ⚠ Skipping - no candidate ID available", 'yellow')
        test_results['skipped'] += 1

    # DELETE /api/candidates/:id will be done at the end

    # ========================================================================
    # 4. VOTES API
    # ========================================================================
    print_header("4. Votes API (5 endpoints)")

    # GET /api/votes
    response = test_endpoint(
        "List All Votes",
        "GET", "/votes?season=2024-25",
        description="Retrieve all MVP votes for a season"
    )
    display_sample_data(response)

    # POST /api/votes (name-based)
    if created_ids['voter'] and created_ids['candidate']:
        vote_data = {
            "voter_id": created_ids['voter'],
            "candidate_id": created_ids['candidate'],
            "season": "2024-25",
            "ranking": 1,
            "source_url": "https://example.com/test",
            "source_type": "speculation",
            "confidence": "medium",
            "confidence_score": 60.0,
            "verified": False
        }
        response = test_endpoint(
            "Create Vote",
            "POST", "/votes",
            expected_status=201,
            data=vote_data,
            description="Add new MVP vote"
        )
        if response:
            try:
                created_ids['vote'] = response.json().get('id')
                print_color(f"   → Created vote ID: {created_ids['vote']}", 'cyan')
            except:
                pass
    else:
        print_color("   ⚠ Skipping - voter or candidate not available", 'yellow')
        test_results['skipped'] += 1

    # PUT /api/votes/:id
    if created_ids['vote']:
        update_data = {"confidence": "high", "confidence_score": 85.0}
        response = test_endpoint(
            "Update Vote",
            "PUT", f"/votes/{created_ids['vote']}",
            data=update_data,
            description="Update vote information"
        )
    else:
        print_color("   ⚠ Skipping - no vote ID available", 'yellow')
        test_results['skipped'] += 1

    # DELETE /api/votes/:id will be done at the end

    # ========================================================================
    # 5. DASHBOARD API
    # ========================================================================
    print_header("5. Dashboard API (1 endpoint)")

    response = test_endpoint(
        "Get Dashboard Data",
        "GET", "/dashboard?season=2024-25",
        description="Comprehensive dashboard data in single call"
    )
    if response:
        try:
            data = response.json()
            print_color(f"   → Stats: {data.get('stats', {})}", 'cyan')
            print_color(f"   → Voters: {len(data.get('voters', []))} items", 'cyan')
            print_color(f"   → Candidates: {len(data.get('candidate_stats', []))} items", 'cyan')
        except:
            pass

    # ========================================================================
    # 6. STATISTICS API
    # ========================================================================
    print_header("6. Statistics API (2 endpoints)")

    # GET /api/statistics
    response = test_endpoint(
        "Get Summary Statistics",
        "GET", "/statistics?season=2024-25",
        description="Comprehensive analytics and voting statistics"
    )
    if response:
        try:
            data = response.json()
            print_color(f"   → Overview: {data.get('overview', {})}", 'cyan')
            print_color(f"   → Top candidates: {len(data.get('top_candidates', []))} items", 'cyan')
            print_color(f"   → Timeline: {len(data.get('timeline', []))} data points", 'cyan')
        except:
            pass

    # GET /api/stats (alternative endpoint)
    response = test_endpoint(
        "Get Basic Stats",
        "GET", "/stats",
        description="Basic statistics summary"
    )
    display_sample_data(response)

    # ========================================================================
    # 7. SEARCH & FILTER API
    # ========================================================================
    print_header("7. Search & Filter API (1 endpoint)")

    response = test_endpoint(
        "Search Voters and Votes",
        "GET", "/search?season=2024-25&confidence=high",
        description="Advanced search with multiple filters"
    )
    if response:
        try:
            data = response.json()
            print_color(f"   → Results: {data.get('count', 0)} matches", 'cyan')
            print_color(f"   → Filters applied: {data.get('filters_applied', {})}", 'cyan')
        except:
            pass

    # ========================================================================
    # 8. EXPORT API
    # ========================================================================
    print_header("8. Export API (4 endpoints)")

    # GET /api/export/voters (CSV)
    response = test_endpoint(
        "Export Voters (CSV)",
        "GET", "/export/voters?format=csv&season=2024-25",
        description="Download voters as CSV file"
    )
    if response:
        print_color(f"   → Content-Type: {response.headers.get('Content-Type')}", 'cyan')
        print_color(f"   → Content length: {len(response.content)} bytes", 'cyan')

    # GET /api/export/voters (JSON)
    response = test_endpoint(
        "Export Voters (JSON)",
        "GET", "/export/voters?format=json&season=2024-25",
        description="Download voters as JSON file"
    )
    display_sample_data(response)

    # GET /api/export/votes (CSV)
    response = test_endpoint(
        "Export Votes (CSV)",
        "GET", "/export/votes?format=csv&season=2024-25",
        description="Download votes as CSV file"
    )
    if response:
        print_color(f"   → Content length: {len(response.content)} bytes", 'cyan')

    # GET /api/export/candidates (CSV)
    response = test_endpoint(
        "Export Candidates (CSV)",
        "GET", "/export/candidates?format=csv&season=2024-25",
        description="Download candidates with vote counts"
    )
    if response:
        print_color(f"   → Content length: {len(response.content)} bytes", 'cyan')

    # GET /api/export/full-report
    response = test_endpoint(
        "Export Full Report",
        "GET", "/export/full-report?season=2024-25",
        description="Comprehensive report with all data"
    )
    if response:
        try:
            data = response.json()
            print_color(f"   → Metadata: {data.get('metadata', {})}", 'cyan')
        except:
            pass

    # ========================================================================
    # 9. CREDIBILITY API
    # ========================================================================
    print_header("9. Credibility API (5 endpoints)")

    # POST /api/credibility/assess
    credibility_data = {
        "source_url": "https://www.espn.com/test",
        "source_type": "news_article",
        "extracted_text": "My MVP vote goes to Josh Allen"
    }
    response = test_endpoint(
        "Assess Source Credibility",
        "POST", "/credibility/assess",
        data=credibility_data,
        description="Evaluate credibility of a source"
    )
    display_sample_data(response)

    # GET /api/credibility/domains
    response = test_endpoint(
        "Get Trusted Domains",
        "GET", "/credibility/domains",
        description="List all trusted domains"
    )
    display_sample_data(response)

    # POST /api/credibility/domains
    domain_data = {
        "domain": "example-test.com",
        "tier": "medium",
        "description": "Test domain"
    }
    response = test_endpoint(
        "Add Trusted Domain",
        "POST", "/credibility/domains",
        expected_status=201,
        data=domain_data,
        description="Add new trusted domain"
    )

    # POST /api/credibility/compare
    compare_data = {
        "sources": [
            {"url": "https://twitter.com/test", "type": "social_media"},
            {"url": "https://espn.com/test", "type": "news_article"}
        ]
    }
    response = test_endpoint(
        "Compare Source Credibility",
        "POST", "/credibility/compare",
        data=compare_data,
        description="Compare multiple sources"
    )
    display_sample_data(response)

    # GET /api/credibility/badges
    response = test_endpoint(
        "Get Credibility Badges",
        "GET", "/credibility/badges",
        description="UI badges for credibility display"
    )
    display_sample_data(response)

    # ========================================================================
    # 10. HISTORICAL DATA API
    # ========================================================================
    print_header("10. Historical Data API (6 endpoints)")

    # GET /api/historical
    response = test_endpoint(
        "Get Historical Overview",
        "GET", "/historical?season=2024-25",
        description="Historical voting data overview"
    )
    display_sample_data(response)

    # GET /api/historical/seasons
    response = test_endpoint(
        "Get Available Seasons",
        "GET", "/historical/seasons",
        description="List all seasons with data"
    )
    display_sample_data(response)

    # GET /api/historical/voter/:name
    response = test_endpoint(
        "Get Voter History",
        "GET", "/historical/voter/Peter%20King",
        description="Voter's historical MVP picks"
    )
    display_sample_data(response)

    # GET /api/historical/candidate/:name
    response = test_endpoint(
        "Get Candidate History",
        "GET", "/historical/candidate/Josh%20Allen",
        description="Candidate's vote history"
    )
    display_sample_data(response)

    # GET /api/historical/compare
    response = test_endpoint(
        "Compare Seasons",
        "GET", "/historical/compare?seasons=2023-24,2024-25",
        description="Compare voting patterns across seasons"
    )
    display_sample_data(response)

    # GET /api/historical/winner/:season
    response = test_endpoint(
        "Get Season Winner",
        "GET", "/historical/winner/2023-24",
        description="Official MVP winner for a season"
    )
    display_sample_data(response)

    # GET /api/historical/trends/:name
    response = test_endpoint(
        "Get Voter Trends",
        "GET", "/historical/trends/Peter%20King",
        description="Analyze voter's historical patterns"
    )
    display_sample_data(response)

    # ========================================================================
    # 11. NOTIFICATIONS API
    # ========================================================================
    print_header("11. Notifications API (6 endpoints)")

    # GET /api/notifications/preferences
    response = test_endpoint(
        "List Notification Preferences",
        "GET", "/notifications/preferences",
        description="Get all notification configurations"
    )
    display_sample_data(response)

    # POST /api/notifications/preferences
    notification_data = {
        "name": f"Test Notification {datetime.now().timestamp()}",
        "channel": "console",
        "enabled": True,
        "notify_new_voter": True,
        "notify_new_vote": True
    }
    response = test_endpoint(
        "Create Notification Preference",
        "POST", "/notifications/preferences",
        expected_status=201,
        data=notification_data,
        description="Configure new notification channel"
    )
    if response:
        try:
            created_ids['notification_pref'] = response.json().get('id')
            print_color(f"   → Created notification preference ID: {created_ids['notification_pref']}", 'cyan')
        except:
            pass

    # PUT /api/notifications/preferences/:id
    if created_ids['notification_pref']:
        update_data = {"enabled": False}
        response = test_endpoint(
            "Update Notification Preference",
            "PUT", f"/notifications/preferences/{created_ids['notification_pref']}",
            data=update_data,
            description="Update notification settings"
        )
    else:
        print_color("   ⚠ Skipping - no notification preference ID available", 'yellow')
        test_results['skipped'] += 1

    # GET /api/notifications/history
    response = test_endpoint(
        "Get Notification History",
        "GET", "/notifications/history?limit=10",
        description="View sent notifications"
    )
    display_sample_data(response)

    # POST /api/notifications/test
    test_notification_data = {
        "title": "Test Notification",
        "message": "Testing API notification system"
    }
    response = test_endpoint(
        "Send Test Notification",
        "POST", "/notifications/test",
        data=test_notification_data,
        description="Send test notification to all channels"
    )
    display_sample_data(response)

    # DELETE /api/notifications/preferences/:id will be done at the end

    # ========================================================================
    # CLEANUP: Delete created test data
    # ========================================================================
    print_header("12. Cleanup - Delete Test Data")

    # Delete vote first (foreign key constraint)
    if created_ids['vote']:
        response = test_endpoint(
            "Delete Test Vote",
            "DELETE", f"/votes/{created_ids['vote']}",
            description="Clean up test vote"
        )

    # Delete voter (cascade deletes votes)
    if created_ids['voter']:
        response = test_endpoint(
            "Delete Test Voter",
            "DELETE", f"/voters/{created_ids['voter']}",
            description="Clean up test voter"
        )

    # Delete candidate
    if created_ids['candidate']:
        response = test_endpoint(
            "Delete Test Candidate",
            "DELETE", f"/candidates/{created_ids['candidate']}",
            description="Clean up test candidate"
        )

    # Delete notification preference
    if created_ids['notification_pref']:
        response = test_endpoint(
            "Delete Test Notification Preference",
            "DELETE", f"/notifications/preferences/{created_ids['notification_pref']}",
            description="Clean up test notification"
        )

    # ========================================================================
    # FINAL RESULTS
    # ========================================================================
    print_header("Test Results Summary")

    print(f"\nTotal tests run: {test_results['total']}")
    print_color(f"✓ Passed: {test_results['passed']}", 'green')
    print_color(f"✗ Failed: {test_results['failed']}", 'red')
    print_color(f"⚠ Skipped: {test_results['skipped']}", 'yellow')

    success_rate = (test_results['passed'] / test_results['total'] * 100) if test_results['total'] > 0 else 0
    print(f"\nSuccess Rate: {success_rate:.1f}%")

    if test_results['failed'] == 0:
        print_color("\n✓ All tests PASSED! The API is fully functional.", 'green')
        return 0
    else:
        print_color(f"\n✗ {test_results['failed']} test(s) FAILED. Please review the errors above.", 'red')
        return 1

if __name__ == "__main__":
    print_color("\n╔══════════════════════════════════════════════════════════════════════════════╗", 'cyan')
    print_color("║                   NFL MVP Voter Tracker API Test Suite                      ║", 'cyan')
    print_color("║                          Feature #19 - API Endpoints                         ║", 'cyan')
    print_color("╚══════════════════════════════════════════════════════════════════════════════╝\n", 'cyan')

    print_color("IMPORTANT: Make sure the backend server is running before starting tests!", 'yellow')
    print_color("Run: python3 backend/app.py\n", 'yellow')

    try:
        # Quick connectivity check
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        print_color(f"✓ Backend server is running at {BASE_URL}", 'green')
        print()
    except:
        print_color(f"✗ Cannot connect to backend at {BASE_URL}", 'red')
        print_color("Please start the backend server first: python3 backend/app.py", 'red')
        sys.exit(1)

    # Run all tests
    exit_code = run_all_tests()

    print_color("\n" + "="*80, 'cyan')
    print(f"Test completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_color("="*80 + "\n", 'cyan')

    sys.exit(exit_code)
