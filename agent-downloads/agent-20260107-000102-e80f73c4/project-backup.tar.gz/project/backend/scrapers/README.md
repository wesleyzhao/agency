# NFL MVP Voter Scrapers

Comprehensive web scraping modules for discovering and extracting NFL MVP voter information from multiple sources.

## Overview

This module provides a suite of scrapers that work together to find NFL MVP voters and their publicly announced votes across:

- **Google Search**: Web search results for MVP-related content
- **Reddit**: Posts and comments from NFL-related subreddits
- **News Sites**: ESPN, NFL.com, ProFootballTalk, The Athletic, etc.
- **Article Extraction**: Full text extraction from news URLs

## Components

### 1. BaseScraper (`base_scraper.py`)

Abstract base class providing common functionality:

- Rate limiting to avoid being blocked
- Content hash generation for deduplication
- MVP-relevance detection
- HTML parsing and text extraction
- Logging infrastructure

### 2. GoogleScraper (`google_scraper.py`)

Searches Google for MVP voter announcements:

```python
from scrapers import GoogleScraper

scraper = GoogleScraper()

# Search for voter announcements
results = scraper.search_voter_announcements(season="2024-25")

# Search for specific voter
results = scraper.search_specific_voter("Mina Kimes", season="2024-25")
```

**Features:**
- Automated query generation
- Result filtering for MVP relevance
- Deduplication by URL
- Customizable result limits

### 3. RedditScraper (`reddit_scraper.py`)

Searches Reddit for MVP discussions:

```python
from scrapers import RedditScraper

scraper = RedditScraper()

# Search multiple subreddits
results = scraper.search_voter_discussions(season="2024-25")

# Get posts from specific user
posts = scraper.get_user_posts("username")

# Monitor subreddit in real-time
new_posts = scraper.monitor_subreddit_new("nfl", duration_minutes=10)
```

**Features:**
- Multi-subreddit search
- Post and comment extraction
- User post history retrieval
- Real-time monitoring
- Automatic comment parsing

**Setup:**
Set environment variables for Reddit API:
```bash
export REDDIT_CLIENT_ID="your_client_id"
export REDDIT_CLIENT_SECRET="your_client_secret"
```

### 4. NewsScraper (`news_scraper.py`)

Extracts articles from news sites:

```python
from scrapers import NewsScraper

scraper = NewsScraper()

# Scrape NFL news sites for URLs
urls = scraper.scrape_nfl_news_sites()

# Extract full article content
article = scraper.extract_article(url)

# Batch extraction
articles = scraper.extract_articles_batch(url_list)
```

**Features:**
- ESPN, NFL.com, ProFootballTalk scraping
- Full article text extraction (using newspaper3k)
- Author and publish date extraction
- Content summarization
- Voter name detection

### 5. ScraperOrchestrator (`scraper_orchestrator.py`)

Coordinates all scrapers for comprehensive searches:

```python
from scrapers import ScraperOrchestrator

orchestrator = ScraperOrchestrator(output_dir='./data/results')

# Run comprehensive search across all sources
results = orchestrator.run_comprehensive_search(
    season="2024-25",
    include_google=True,
    include_reddit=True,
    include_news=True
)

# Search for specific voter
voter_info = orchestrator.search_specific_voter("Tom Brady")

# Extract articles from URLs
articles = orchestrator.extract_articles_from_urls(url_list)
```

**Features:**
- Coordinated multi-source searching
- Automatic result aggregation
- Deduplication across sources
- Results saved to JSON
- Summary statistics
- Progress logging

## Usage Examples

### Basic Usage

```python
from scrapers import ScraperOrchestrator

# Create orchestrator
orchestrator = ScraperOrchestrator()

# Run comprehensive search
results = orchestrator.run_comprehensive_search(season="2024-25")

# Results are automatically saved to ./data/scraping_results/
# Access results:
print(f"Google: {len(results['google'])} results")
print(f"Reddit: {len(results['reddit'])} posts")
print(f"News: {len(results['news'])} articles")
```

### Search Specific Voter

```python
# Search for a specific voter's announcements
voter_results = orchestrator.search_specific_voter(
    voter_name="Mina Kimes",
    season="2024-25"
)

print(f"Found {len(voter_results['google'])} Google results")
print(f"Found {len(voter_results['reddit'])} Reddit mentions")
```

### Real-time Monitoring

```python
from scrapers import RedditScraper

scraper = RedditScraper()

# Monitor r/nfl for new MVP posts
new_posts = scraper.monitor_subreddit_new(
    subreddit_name="nfl",
    duration_minutes=30
)

for post in new_posts:
    print(f"New post: {post['title']}")
```

### Custom Search

```python
from scrapers import GoogleScraper

scraper = GoogleScraper()

# Custom search query
results = scraper.search(
    query="Tony Dungy MVP vote 2024",
    num_results=20
)

for result in results:
    print(f"{result['title']}: {result['url']}")
```

## Testing

Run the test suite:

```bash
cd backend/scrapers
python test_scrapers.py
```

This will:
- Test all scraper components
- Verify MVP detection
- Test Google search
- Test Reddit search (if configured)
- Test news extraction
- Test orchestrator coordination
- Save results to `./data/scraping_results/`

## Rate Limiting

All scrapers implement rate limiting to avoid being blocked:

- **GoogleScraper**: 3 seconds between requests
- **RedditScraper**: 2 seconds between requests
- **NewsScraper**: 2 seconds between requests

Adjust in constructor:
```python
scraper = GoogleScraper(rate_limit_delay=5.0)  # 5 second delay
```

## Output Format

Results are saved as JSON with this structure:

```json
{
  "google": [
    {
      "url": "https://...",
      "title": "Article title",
      "snippet": "Preview text",
      "source": "google",
      "query": "Search query used",
      "discovered_at": "2024-01-07T12:00:00"
    }
  ],
  "reddit": [
    {
      "type": "post",
      "url": "https://reddit.com/...",
      "title": "Post title",
      "content": "Post text",
      "author": "username",
      "subreddit": "nfl",
      "score": 150,
      "created_utc": "2024-01-07T12:00:00"
    }
  ],
  "news": [
    {
      "url": "https://...",
      "title": "Article title",
      "authors": ["Author Name"],
      "publish_date": "2024-01-07",
      "text": "Full article text",
      "content_hash": "md5hash"
    }
  ],
  "metadata": {
    "started_at": "2024-01-07T12:00:00",
    "completed_at": "2024-01-07T12:15:00",
    "total_sources_found": 45,
    "total_urls_found": 38
  }
}
```

## MVP Detection

The scrapers automatically filter results for MVP relevance by checking for:

**MVP Keywords:**
- "nfl mvp", "mvp vote", "mvp ballot"
- "most valuable player", "ap mvp"
- "voted for mvp", "my mvp vote"

**Candidate Names (2024-25):**
- Josh Allen, Lamar Jackson
- Saquon Barkley, Joe Burrow
- Jared Goff, Jayden Daniels
- And other contenders

## Error Handling

All scrapers include comprehensive error handling:

- Network errors (timeouts, connection issues)
- Parsing errors (malformed HTML)
- API errors (Reddit rate limits)
- Logging of all errors for debugging

Errors are logged but don't stop execution - scrapers continue with remaining sources.

## Best Practices

1. **Use the Orchestrator** for most tasks - it coordinates everything
2. **Configure Reddit API** for full functionality
3. **Check rate limits** when scraping intensively
4. **Save results regularly** - they're auto-saved by orchestrator
5. **Monitor logs** for errors and warnings
6. **Deduplicate URLs** before extracting articles

## Integration with Database

To save results to database:

```python
from sqlalchemy.orm import sessionmaker
from database.models import Source, Vote, Voter

# After scraping
results = orchestrator.run_comprehensive_search()

# Save to database
session = Session()

for result in results['google']:
    # Check if URL already exists
    existing = session.query(Source).filter_by(url=result['url']).first()

    if not existing:
        source = Source(
            url=result['url'],
            title=result['title'],
            processed=False,
            discovered_at=result['discovered_at']
        )
        session.add(source)

session.commit()
```

## Future Enhancements

Potential improvements:

- Twitter/X scraping (when API access available)
- Selenium for JavaScript-heavy sites
- More sophisticated NLP for voter extraction
- Automatic scheduling with Celery
- Webhook notifications for new findings
- Advanced deduplication algorithms
- Sentiment analysis of voter discussions

## Troubleshooting

**Google returns no results:**
- Google may be blocking automated requests
- Try increasing `rate_limit_delay`
- Consider using a proxy
- Check if results are being filtered for MVP relevance

**Reddit returns empty:**
- Verify environment variables are set
- Check Reddit API credentials
- Ensure account has API access

**Article extraction fails:**
- Some sites block scrapers
- Try with different User-Agent
- Site structure may have changed
- Check logs for specific error

## License

MIT License - See main project LICENSE file
