"""
Base scraper class with common functionality
"""
import time
import hashlib
import logging
from datetime import datetime
from typing import List, Dict, Optional
from abc import ABC, abstractmethod

import requests
from bs4 import BeautifulSoup


class BaseScraper(ABC):
    """Base class for all scrapers with common functionality"""

    def __init__(self, rate_limit_delay=2.0):
        """
        Initialize base scraper

        Args:
            rate_limit_delay: Seconds to wait between requests
        """
        self.rate_limit_delay = rate_limit_delay
        self.last_request_time = 0
        self.logger = logging.getLogger(self.__class__.__name__)

        # Common headers to avoid being blocked
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }

        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def rate_limit(self):
        """Enforce rate limiting between requests"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - elapsed)
        self.last_request_time = time.time()

    def fetch_url(self, url: str, timeout: int = 30) -> Optional[str]:
        """
        Fetch content from a URL with error handling

        Args:
            url: URL to fetch
            timeout: Request timeout in seconds

        Returns:
            HTML content or None if failed
        """
        try:
            self.rate_limit()
            self.logger.info(f"Fetching: {url}")

            response = self.session.get(url, timeout=timeout)
            response.raise_for_status()

            return response.text

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error fetching {url}: {e}")
            return None

    def parse_html(self, html: str) -> BeautifulSoup:
        """
        Parse HTML content with BeautifulSoup

        Args:
            html: HTML content

        Returns:
            BeautifulSoup object
        """
        return BeautifulSoup(html, 'html.parser')

    def compute_content_hash(self, content: str) -> str:
        """
        Compute MD5 hash of content for deduplication

        Args:
            content: Text content

        Returns:
            MD5 hash string
        """
        return hashlib.md5(content.encode('utf-8')).hexdigest()

    def extract_text(self, soup: BeautifulSoup) -> str:
        """
        Extract clean text from BeautifulSoup object

        Args:
            soup: BeautifulSoup object

        Returns:
            Cleaned text content
        """
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()

        # Get text
        text = soup.get_text()

        # Break into lines and remove leading/trailing space
        lines = (line.strip() for line in text.splitlines())

        # Break multi-headlines into a line each
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))

        # Remove blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)

        return text

    def is_mvp_related(self, text: str) -> bool:
        """
        Check if text contains NFL MVP related keywords

        Args:
            text: Text to check

        Returns:
            True if MVP related
        """
        text_lower = text.lower()

        mvp_keywords = [
            'nfl mvp', 'mvp vote', 'mvp ballot', 'mvp award',
            'most valuable player', 'mvp voter', 'ap mvp',
            'voted for mvp', 'voting for mvp', 'my mvp vote'
        ]

        # Check for candidates (2024-25 season)
        candidate_names = [
            'josh allen', 'lamar jackson', 'saquon barkley',
            'joe burrow', 'jared goff', 'jayden daniels',
            'derrick henry', 'patrick mahomes'
        ]

        # Must have MVP keyword AND candidate name
        has_mvp_keyword = any(keyword in text_lower for keyword in mvp_keywords)
        has_candidate = any(name in text_lower for name in candidate_names)

        return has_mvp_keyword or (has_candidate and 'vote' in text_lower)

    @abstractmethod
    def search(self, query: str, **kwargs) -> List[Dict]:
        """
        Search for MVP voter information

        Args:
            query: Search query
            **kwargs: Additional search parameters

        Returns:
            List of search results with 'url', 'title', 'content', 'source'
        """
        pass

    def log_scraping_activity(self, source: str, query: str, urls_found: int,
                            votes_extracted: int, errors: Optional[str] = None):
        """
        Log scraping activity (to be saved to database)

        Args:
            source: Source name (e.g., 'google', 'reddit')
            query: Search query used
            urls_found: Number of URLs found
            votes_extracted: Number of votes extracted
            errors: Error messages if any
        """
        log_entry = {
            'source': source,
            'query': query,
            'urls_found': urls_found,
            'votes_extracted': votes_extracted,
            'errors': errors,
            'timestamp': datetime.utcnow()
        }

        self.logger.info(f"Scraping activity: {log_entry}")

        return log_entry
