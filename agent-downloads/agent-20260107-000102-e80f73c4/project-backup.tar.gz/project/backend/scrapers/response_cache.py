"""
HTTP response caching for web scraping with TTL and size limits
"""
import os
import json
import hashlib
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from pathlib import Path


class ResponseCache:
    """
    HTTP response cache with time-to-live (TTL) and size limits

    Features:
    - File-based caching for persistence across runs
    - TTL-based expiration
    - LRU eviction when size limit reached
    - Content hash verification
    - Cache statistics and monitoring
    """

    def __init__(
        self,
        cache_dir: str = "cache",
        ttl_seconds: int = 3600,  # 1 hour default
        max_cache_size_mb: int = 500,  # 500 MB default
        enable_compression: bool = False
    ):
        """
        Initialize response cache

        Args:
            cache_dir: Directory to store cache files
            ttl_seconds: Time-to-live for cached responses (default: 3600 = 1 hour)
            max_cache_size_mb: Maximum cache size in megabytes (default: 500)
            enable_compression: Enable gzip compression for cache files (default: False)
        """
        self.cache_dir = Path(cache_dir)
        self.ttl_seconds = ttl_seconds
        self.max_cache_size_bytes = max_cache_size_mb * 1024 * 1024
        self.enable_compression = enable_compression

        # Create cache directory if it doesn't exist
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Statistics (must be initialized before _load_metadata)
        self.stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'expired': 0,
            'size_bytes': 0
        }

        # Cache metadata (in-memory for fast lookups)
        self.metadata: Dict[str, Dict[str, Any]] = {}
        self._load_metadata()

        self.logger = logging.getLogger(__name__)

    def _generate_cache_key(self, url: str) -> str:
        """
        Generate cache key from URL

        Args:
            url: URL to cache

        Returns:
            Cache key (MD5 hash)
        """
        return hashlib.md5(url.encode('utf-8')).hexdigest()

    def _get_cache_path(self, cache_key: str) -> Path:
        """
        Get file path for cache key

        Args:
            cache_key: Cache key

        Returns:
            Path to cache file
        """
        return self.cache_dir / f"{cache_key}.json"

    def _get_metadata_path(self) -> Path:
        """Get path to metadata file"""
        return self.cache_dir / "metadata.json"

    def _load_metadata(self):
        """Load cache metadata from disk"""
        metadata_path = self._get_metadata_path()

        if metadata_path.exists():
            try:
                with open(metadata_path, 'r') as f:
                    self.metadata = json.load(f)
                self.logger.debug(f"Loaded metadata for {len(self.metadata)} cached items")
            except Exception as e:
                self.logger.warning(f"Failed to load metadata: {e}")
                self.metadata = {}
        else:
            self.metadata = {}

        # Calculate total cache size
        self.stats['size_bytes'] = sum(
            meta.get('size_bytes', 0) for meta in self.metadata.values()
        )

    def _save_metadata(self):
        """Save cache metadata to disk"""
        metadata_path = self._get_metadata_path()

        try:
            with open(metadata_path, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save metadata: {e}")

    def _is_expired(self, cache_key: str) -> bool:
        """
        Check if cache entry is expired

        Args:
            cache_key: Cache key

        Returns:
            True if expired
        """
        if cache_key not in self.metadata:
            return True

        cached_time = datetime.fromisoformat(self.metadata[cache_key]['cached_at'])
        age = datetime.now() - cached_time

        return age > timedelta(seconds=self.ttl_seconds)

    def _evict_lru(self):
        """Evict least recently used cache entries to stay under size limit"""
        if self.stats['size_bytes'] <= self.max_cache_size_bytes:
            return

        # Sort by last access time (LRU)
        sorted_keys = sorted(
            self.metadata.keys(),
            key=lambda k: self.metadata[k].get('last_access', '1970-01-01T00:00:00')
        )

        # Evict oldest entries until under limit
        for cache_key in sorted_keys:
            if self.stats['size_bytes'] <= self.max_cache_size_bytes:
                break

            self._delete_cache_entry(cache_key)
            self.stats['evictions'] += 1
            self.logger.debug(f"Evicted cache entry: {cache_key}")

    def _delete_cache_entry(self, cache_key: str):
        """
        Delete a cache entry

        Args:
            cache_key: Cache key to delete
        """
        cache_path = self._get_cache_path(cache_key)

        if cache_path.exists():
            try:
                cache_path.unlink()
            except Exception as e:
                self.logger.warning(f"Failed to delete cache file {cache_path}: {e}")

        if cache_key in self.metadata:
            self.stats['size_bytes'] -= self.metadata[cache_key].get('size_bytes', 0)
            del self.metadata[cache_key]

    def get(self, url: str) -> Optional[str]:
        """
        Get cached response for URL

        Args:
            url: URL to lookup

        Returns:
            Cached response content or None if not cached/expired
        """
        cache_key = self._generate_cache_key(url)

        # Check if in cache
        if cache_key not in self.metadata:
            self.stats['misses'] += 1
            return None

        # Check if expired
        if self._is_expired(cache_key):
            self.logger.debug(f"Cache expired for {url}")
            self._delete_cache_entry(cache_key)
            self.stats['expired'] += 1
            self.stats['misses'] += 1
            return None

        # Load from disk
        cache_path = self._get_cache_path(cache_key)

        if not cache_path.exists():
            self.logger.warning(f"Cache file missing for {url}")
            del self.metadata[cache_key]
            self.stats['misses'] += 1
            return None

        try:
            with open(cache_path, 'r') as f:
                cached_data = json.load(f)

            # Update last access time
            self.metadata[cache_key]['last_access'] = datetime.now().isoformat()
            self._save_metadata()

            self.stats['hits'] += 1
            self.logger.debug(f"Cache hit for {url}")

            return cached_data.get('content')

        except Exception as e:
            self.logger.error(f"Failed to load cache for {url}: {e}")
            self._delete_cache_entry(cache_key)
            self.stats['misses'] += 1
            return None

    def set(self, url: str, content: str, metadata: Optional[Dict] = None):
        """
        Cache response for URL

        Args:
            url: URL to cache
            content: Response content
            metadata: Optional metadata (status_code, headers, etc.)
        """
        cache_key = self._generate_cache_key(url)
        cache_path = self._get_cache_path(cache_key)

        # Prepare cache data
        cache_data = {
            'url': url,
            'content': content,
            'cached_at': datetime.now().isoformat(),
            'metadata': metadata or {}
        }

        try:
            # Write to disk
            with open(cache_path, 'w') as f:
                json.dump(cache_data, f)

            # Calculate size
            file_size = cache_path.stat().st_size

            # Update metadata
            self.metadata[cache_key] = {
                'url': url,
                'cached_at': cache_data['cached_at'],
                'last_access': cache_data['cached_at'],
                'size_bytes': file_size
            }

            # Update size
            self.stats['size_bytes'] += file_size

            # Save metadata
            self._save_metadata()

            # Evict if over limit
            self._evict_lru()

            self.logger.debug(f"Cached {url} ({file_size} bytes)")

        except Exception as e:
            self.logger.error(f"Failed to cache {url}: {e}")

    def invalidate(self, url: str) -> bool:
        """
        Invalidate (delete) cached entry for URL

        Args:
            url: URL to invalidate

        Returns:
            True if cache entry existed and was deleted
        """
        cache_key = self._generate_cache_key(url)

        if cache_key in self.metadata:
            self._delete_cache_entry(cache_key)
            self._save_metadata()
            self.logger.info(f"Invalidated cache for {url}")
            return True

        return False

    def clear(self):
        """Clear all cache entries"""
        for cache_key in list(self.metadata.keys()):
            self._delete_cache_entry(cache_key)

        self._save_metadata()
        self.logger.info("Cleared all cache entries")

    def cleanup_expired(self) -> int:
        """
        Remove all expired cache entries

        Returns:
            Number of entries cleaned up
        """
        expired_keys = [
            key for key in self.metadata.keys()
            if self._is_expired(key)
        ]

        for cache_key in expired_keys:
            self._delete_cache_entry(cache_key)

        if expired_keys:
            self._save_metadata()
            self.logger.info(f"Cleaned up {len(expired_keys)} expired cache entries")

        return len(expired_keys)

    def get_statistics(self) -> Dict:
        """
        Get cache statistics

        Returns:
            Dictionary with cache statistics
        """
        total_requests = self.stats['hits'] + self.stats['misses']
        hit_rate = (self.stats['hits'] / total_requests * 100) if total_requests > 0 else 0

        return {
            'hits': self.stats['hits'],
            'misses': self.stats['misses'],
            'hit_rate': round(hit_rate, 2),
            'cached_items': len(self.metadata),
            'size_bytes': self.stats['size_bytes'],
            'size_mb': round(self.stats['size_bytes'] / (1024 * 1024), 2),
            'evictions': self.stats['evictions'],
            'expired': self.stats['expired'],
            'ttl_seconds': self.ttl_seconds,
            'max_size_mb': self.max_cache_size_bytes / (1024 * 1024)
        }

    def reset_statistics(self):
        """Reset cache statistics (doesn't clear cache)"""
        self.stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'expired': 0,
            'size_bytes': sum(meta.get('size_bytes', 0) for meta in self.metadata.values())
        }
