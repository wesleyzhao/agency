"""
Source tracking integration for scrapers to avoid duplicate processing
"""
import logging
from typing import List, Dict, Optional, Set
from sqlalchemy.orm import Session

from database import SourceDB, VoteSourceDB


class SourceTracker:
    """
    Manages source tracking and deduplication for web scrapers

    This class provides methods to:
    - Check if URLs have already been processed
    - Detect duplicate content via content hashing
    - Track which sources have been scraped
    - Link sources to extracted votes
    """

    def __init__(self, session: Session, source_type: str):
        """
        Initialize source tracker

        Args:
            session: SQLAlchemy database session
            source_type: Type of scraper (e.g., 'google', 'reddit', 'news')
        """
        self.session = session
        self.source_type = source_type
        self.logger = logging.getLogger(__name__)

        # Cache for this scraping session
        self._processed_urls: Set[str] = set()
        self._content_hashes: Set[str] = set()

    def is_url_new(self, url: str) -> bool:
        """
        Check if a URL is new (not already processed)

        Args:
            url: URL to check

        Returns:
            True if URL is new, False if already processed
        """
        # Check session cache first (fast)
        if url in self._processed_urls:
            return False

        # Check database
        if SourceDB.is_url_processed(self.session, url):
            self._processed_urls.add(url)
            return False

        return True

    def is_content_duplicate(self, content: str) -> Optional[str]:
        """
        Check if content is a duplicate

        Args:
            content: Text content to check

        Returns:
            URL of duplicate source if found, None otherwise
        """
        if not content:
            return None

        # Generate hash
        content_hash = SourceDB.generate_content_hash(content)

        # Check session cache
        if content_hash in self._content_hashes:
            return "duplicate_in_session"

        # Check database
        duplicate_source = SourceDB.is_duplicate_content(self.session, content_hash)
        if duplicate_source:
            self._content_hashes.add(content_hash)
            return duplicate_source.url

        # Add to cache
        self._content_hashes.add(content_hash)
        return None

    def add_source(self, url: str, title: str = None, content: str = None) -> int:
        """
        Add a new source to the database

        Args:
            url: Source URL
            title: Source title/headline
            content: Full content text

        Returns:
            Source ID
        """
        source = SourceDB.add_source(
            self.session,
            url=url,
            title=title,
            content=content,
            source_type=self.source_type
        )
        self._processed_urls.add(url)
        return source.id

    def mark_processed(self, url: str):
        """
        Mark a source as processed

        Args:
            url: URL to mark as processed
        """
        SourceDB.mark_processed(self.session, url)
        self._processed_urls.add(url)

    def filter_new_urls(self, urls: List[str]) -> List[str]:
        """
        Filter a list of URLs to only new ones

        Args:
            urls: List of URLs to filter

        Returns:
            List of URLs that haven't been processed yet
        """
        new_urls = []
        for url in urls:
            if self.is_url_new(url):
                new_urls.append(url)
            else:
                self.logger.debug(f"Skipping already processed URL: {url}")

        self.logger.info(f"Filtered {len(urls)} URLs -> {len(new_urls)} new URLs")
        return new_urls

    def filter_new_items(self, items: List[Dict]) -> List[Dict]:
        """
        Filter a list of items (dicts with 'url' key) to only new ones

        Args:
            items: List of dictionaries containing 'url' keys

        Returns:
            List of items with new URLs
        """
        new_items = []
        for item in items:
            url = item.get('url')
            if url and self.is_url_new(url):
                new_items.append(item)
            else:
                self.logger.debug(f"Skipping already processed item: {url}")

        self.logger.info(f"Filtered {len(items)} items -> {len(new_items)} new items")
        return new_items

    def deduplicate_by_content(self, items: List[Dict], content_key: str = 'content') -> List[Dict]:
        """
        Remove duplicate content from a list of items

        Args:
            items: List of items to deduplicate
            content_key: Key in dict that contains content text

        Returns:
            List of items with unique content
        """
        unique_items = []
        seen_hashes = set()

        for item in items:
            content = item.get(content_key, '')
            if not content:
                unique_items.append(item)
                continue

            content_hash = SourceDB.generate_content_hash(content)

            # Check if we've seen this content hash in this batch
            if content_hash in seen_hashes:
                self.logger.debug(f"Removing duplicate content from batch: {item.get('url', 'unknown')}")
                continue

            # Check against database
            duplicate = SourceDB.is_duplicate_content(self.session, content_hash)
            if duplicate:
                self.logger.debug(f"Content already in database: {item.get('url', 'unknown')} (duplicate of {duplicate.url})")
                # Still add the URL to database but mark as processed
                if item.get('url'):
                    self.add_source(item['url'], item.get('title'), content)
                continue

            seen_hashes.add(content_hash)
            unique_items.append(item)

        self.logger.info(f"Deduplicated {len(items)} items -> {len(unique_items)} unique items")
        return unique_items

    def link_vote_to_source(self, vote_id: int, source_url: str):
        """
        Link a vote to its source

        Args:
            vote_id: ID of the vote
            source_url: URL of the source
        """
        # Get source by URL
        source = self.session.query(SourceDB).filter_by(url=source_url).first()
        if not source:
            self.logger.warning(f"Cannot link vote {vote_id} to source {source_url}: source not found")
            return

        # Create link
        VoteSourceDB.link_vote_to_source(self.session, vote_id, source.id)
        self.logger.debug(f"Linked vote {vote_id} to source {source.id}")

    def get_stats(self) -> Dict:
        """
        Get statistics about sources

        Returns:
            Dictionary with source statistics
        """
        return SourceDB.get_source_stats(self.session)

    def clear_cache(self):
        """Clear the session cache"""
        self._processed_urls.clear()
        self._content_hashes.clear()
        self.logger.debug("Cleared source tracker cache")
