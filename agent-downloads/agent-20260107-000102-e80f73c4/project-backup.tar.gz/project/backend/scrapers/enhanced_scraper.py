"""
Enhanced scraper with integrated rate limiting and response caching
"""
import logging
from typing import Optional
import requests

from .base_scraper import BaseScraper
from .rate_limiter import RateLimiter, RequestThrottler
from .response_cache import ResponseCache


class EnhancedScraper(BaseScraper):
    """
    Enhanced scraper base class with advanced rate limiting and caching

    Features:
    - Per-domain rate limiting with exponential backoff
    - HTTP response caching with TTL
    - Request throttling (sliding window)
    - Automatic retry with exponential backoff
    - Comprehensive statistics and monitoring

    Note: This is still an abstract base class. Subclasses must implement the search() method.
    """

    def __init__(
        self,
        rate_limit_delay: float = 2.0,
        enable_caching: bool = True,
        cache_ttl: int = 3600,
        enable_throttling: bool = False,
        max_requests_per_minute: int = 60
    ):
        """
        Initialize enhanced scraper

        Args:
            rate_limit_delay: Base delay between requests in seconds
            enable_caching: Enable response caching
            cache_ttl: Cache time-to-live in seconds (default: 1 hour)
            enable_throttling: Enable request throttling
            max_requests_per_minute: Max requests per minute if throttling enabled
        """
        super().__init__(rate_limit_delay=rate_limit_delay)

        # Initialize rate limiter
        self.rate_limiter = RateLimiter(
            global_delay=rate_limit_delay,
            per_domain_delay=rate_limit_delay,
            max_retries=3,
            backoff_factor=2.0,
            enable_adaptive=True
        )

        # Initialize cache if enabled
        self.enable_caching = enable_caching
        if enable_caching:
            self.cache = ResponseCache(
                cache_dir="backend/scrapers/cache",
                ttl_seconds=cache_ttl,
                max_cache_size_mb=500
            )
        else:
            self.cache = None

        # Initialize throttler if enabled
        self.enable_throttling = enable_throttling
        if enable_throttling:
            self.throttler = RequestThrottler(
                max_requests=max_requests_per_minute,
                time_window=60
            )
        else:
            self.throttler = None

        self.logger = logging.getLogger(self.__class__.__name__)

    def fetch_url(self, url: str, timeout: int = 30, use_cache: bool = True) -> Optional[str]:
        """
        Fetch content from URL with rate limiting, caching, and retry logic

        Args:
            url: URL to fetch
            timeout: Request timeout in seconds
            use_cache: Whether to use cache for this request (default: True)

        Returns:
            HTML content or None if failed
        """
        # Check cache first
        if self.enable_caching and use_cache and self.cache:
            cached_content = self.cache.get(url)
            if cached_content is not None:
                self.logger.info(f"Cache hit: {url}")
                return cached_content

        # Try to fetch with retries
        attempt = 0
        while True:
            try:
                # Apply throttling if enabled
                if self.throttler:
                    self.throttler.wait_if_needed()

                # Apply rate limiting
                is_retry = attempt > 0
                self.rate_limiter.wait(url, is_retry=is_retry)

                # Make request
                self.logger.info(f"Fetching: {url} (attempt {attempt + 1})")
                response = self.session.get(url, timeout=timeout)
                response.raise_for_status()

                # Record success
                self.rate_limiter.record_success(url)

                # Cache response
                if self.enable_caching and use_cache and self.cache:
                    self.cache.set(url, response.text, metadata={
                        'status_code': response.status_code,
                        'headers': dict(response.headers)
                    })

                return response.text

            except requests.exceptions.RequestException as e:
                # Record error
                self.rate_limiter.record_error(url, e)

                # Check if should retry
                if not self.rate_limiter.should_retry(url):
                    self.logger.error(f"Failed to fetch {url} after {attempt + 1} attempts: {e}")
                    return None

                # Increment attempt and retry
                attempt += 1
                self.logger.warning(f"Request failed (attempt {attempt}): {e}")

    def invalidate_cache(self, url: str) -> bool:
        """
        Invalidate cached entry for URL

        Args:
            url: URL to invalidate

        Returns:
            True if cache entry existed and was invalidated
        """
        if self.cache:
            return self.cache.invalidate(url)
        return False

    def clear_cache(self):
        """Clear all cached entries"""
        if self.cache:
            self.cache.clear()
            self.logger.info("Cache cleared")

    def cleanup_expired_cache(self) -> int:
        """
        Remove expired cache entries

        Returns:
            Number of entries removed
        """
        if self.cache:
            return self.cache.cleanup_expired()
        return 0

    def get_statistics(self) -> dict:
        """
        Get comprehensive scraper statistics

        Returns:
            Dictionary with rate limiting, caching, and throttling stats
        """
        stats = {
            'rate_limiting': self.rate_limiter.get_statistics(),
        }

        if self.cache:
            stats['caching'] = self.cache.get_statistics()

        if self.throttler:
            stats['throttling'] = {
                'current_rate': round(self.throttler.get_current_rate(), 2),
                'max_requests': self.throttler.max_requests,
                'time_window': self.throttler.time_window
            }

        return stats

    def reset_statistics(self):
        """Reset all statistics counters"""
        self.rate_limiter.reset_statistics()

        if self.cache:
            self.cache.reset_statistics()

        if self.throttler:
            self.throttler.reset()

        self.logger.info("Statistics reset")

    def reset_domain_errors(self, domain: Optional[str] = None):
        """
        Reset error counters for a domain (useful after temporary issues resolved)

        Args:
            domain: Domain to reset, or None for all domains
        """
        self.rate_limiter.reset_domain_errors(domain)


class CachedGoogleScraper(EnhancedScraper):
    """
    Google scraper with caching enabled

    This is an example of how to use EnhancedScraper
    """

    def __init__(self):
        super().__init__(
            rate_limit_delay=3.0,  # Google is strict, use longer delay
            enable_caching=True,
            cache_ttl=7200,  # 2 hours for search results
            enable_throttling=True,
            max_requests_per_minute=30  # Conservative limit for Google
        )

    def search(self, query: str, max_results: int = 10):
        """
        Search Google with caching

        Args:
            query: Search query
            max_results: Maximum number of results

        Returns:
            List of search results
        """
        # This is a placeholder - actual implementation would use
        # the fetch_url method which automatically handles caching
        self.logger.info(f"Searching Google for: {query}")
        # Implementation would go here
        return []


class CachedNewsScraper(EnhancedScraper):
    """
    News scraper with caching enabled

    This is an example of how to use EnhancedScraper for news sites
    """

    def __init__(self):
        super().__init__(
            rate_limit_delay=2.0,
            enable_caching=True,
            cache_ttl=3600,  # 1 hour for news articles
            enable_throttling=False  # Most news sites are more permissive
        )

    def search(self, query: str):
        """
        Search news sites with caching

        Args:
            query: Search query

        Returns:
            List of search results
        """
        self.logger.info(f"Searching news for: {query}")
        # Implementation would go here
        return []
