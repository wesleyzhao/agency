"""
News Aggregator for finding recent NFL MVP-related articles
Integrates with multiple news APIs and RSS feeds
"""
import time
import requests
import feedparser
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from urllib.parse import quote_plus
import logging

from .base_scraper import BaseScraper


class NewsAggregator(BaseScraper):
    """
    Aggregates NFL MVP news from multiple sources:
    - RSS feeds (ESPN, NFL.com, ProFootballTalk, etc.)
    - NewsAPI (if API key provided)
    - Direct site scraping as fallback
    """

    def __init__(self, newsapi_key: Optional[str] = None, rate_limit_delay: float = 2.0):
        """
        Initialize news aggregator

        Args:
            newsapi_key: Optional NewsAPI.org API key
            rate_limit_delay: Seconds between requests
        """
        super().__init__(rate_limit_delay)
        self.newsapi_key = newsapi_key
        self.logger = logging.getLogger(__name__)

        # RSS feed URLs for major NFL news sources
        self.rss_feeds = {
            'espn_nfl': 'https://www.espn.com/espn/rss/nfl/news',
            'nfl_com': 'https://www.nfl.com/feeds/news/rss.xml',
            'profootballtalk': 'https://profootballtalk.nbcsports.com/feed/',
            'sports_illustrated': 'https://www.si.com/rss/si_nfl.rss',
            'bleacher_report': 'https://bleacherreport.com/articles/feed?tag_id=18',
            'yahoo_sports': 'https://sports.yahoo.com/nfl/rss.xml',
            'cbs_sports': 'https://www.cbssports.com/rss/headlines/nfl/',
            'the_athletic': 'https://theathletic.com/feeds/rss/news/?league=nfl',
        }

        # MVP-related keywords for filtering
        self.mvp_keywords = [
            'mvp', 'most valuable player', 'mvp race', 'mvp voting',
            'mvp candidate', 'mvp ballot', 'mvp vote', 'mvp award',
            'ap nfl mvp', 'mvp pick', 'mvp favorite', 'mvp odds'
        ]

        # Player names to watch (2024-25 season candidates)
        self.candidate_names = [
            'Josh Allen', 'Lamar Jackson', 'Saquon Barkley', 'Joe Burrow',
            'Jared Goff', 'Patrick Mahomes', 'Jalen Hurts', 'Sam Darnold',
            'Jordan Love', 'Derrick Henry', 'Justin Jefferson', 'Jayden Daniels',
            'Baker Mayfield', 'Brock Purdy', 'C.J. Stroud'
        ]

    def fetch_rss_feed(self, feed_url: str, source_name: str) -> List[Dict]:
        """
        Fetch and parse an RSS feed

        Args:
            feed_url: RSS feed URL
            source_name: Name of the news source

        Returns:
            List of article dictionaries
        """
        articles = []

        try:
            self.rate_limit()
            self.logger.info(f"Fetching RSS feed: {source_name}")

            # Parse RSS feed using feedparser
            feed = feedparser.parse(feed_url)

            # Check for errors
            if hasattr(feed, 'bozo_exception'):
                self.logger.warning(f"RSS feed parse error for {source_name}: {feed.bozo_exception}")

            # Process each entry
            for entry in feed.entries[:50]:  # Limit to 50 most recent
                # Extract article data
                article = {
                    'url': entry.get('link', ''),
                    'title': entry.get('title', ''),
                    'summary': entry.get('summary', entry.get('description', '')),
                    'published': entry.get('published', entry.get('pubDate', '')),
                    'author': entry.get('author', ''),
                    'source': source_name,
                    'source_type': 'rss_feed',
                    'discovered_at': datetime.utcnow().isoformat()
                }

                # Parse publish date if available
                if hasattr(entry, 'published_parsed') and entry.published_parsed:
                    try:
                        article['published_date'] = datetime(*entry.published_parsed[:6]).isoformat()
                    except:
                        article['published_date'] = None
                else:
                    article['published_date'] = None

                # Check if MVP-related
                text_to_check = f"{article['title']} {article['summary']}"
                if self.is_mvp_related(text_to_check):
                    articles.append(article)

            self.logger.info(f"Found {len(articles)} MVP-related articles from {source_name}")

        except Exception as e:
            self.logger.error(f"Error fetching RSS feed {source_name}: {e}")

        return articles

    def fetch_all_rss_feeds(self) -> List[Dict]:
        """
        Fetch all configured RSS feeds

        Returns:
            List of all articles from all feeds
        """
        all_articles = []

        for source_name, feed_url in self.rss_feeds.items():
            articles = self.fetch_rss_feed(feed_url, source_name)
            all_articles.extend(articles)
            time.sleep(self.rate_limit_delay)

        # Deduplicate by URL
        seen_urls = set()
        unique_articles = []

        for article in all_articles:
            url = article['url']
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_articles.append(article)

        self.logger.info(f"Total unique articles from RSS feeds: {len(unique_articles)}")
        return unique_articles

    def search_newsapi(self, query: str = 'NFL MVP', days_back: int = 7) -> List[Dict]:
        """
        Search for articles using NewsAPI.org

        Args:
            query: Search query
            days_back: How many days back to search

        Returns:
            List of article dictionaries
        """
        if not self.newsapi_key:
            self.logger.warning("NewsAPI key not configured, skipping NewsAPI search")
            return []

        articles = []

        try:
            self.rate_limit()

            # Calculate date range
            from_date = (datetime.utcnow() - timedelta(days=days_back)).strftime('%Y-%m-%d')

            # NewsAPI endpoint
            url = 'https://newsapi.org/v2/everything'

            params = {
                'q': query,
                'from': from_date,
                'language': 'en',
                'sortBy': 'publishedAt',
                'apiKey': self.newsapi_key,
                'pageSize': 100
            }

            self.logger.info(f"Searching NewsAPI for: {query}")

            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()

            data = response.json()

            if data.get('status') != 'ok':
                self.logger.error(f"NewsAPI error: {data.get('message', 'Unknown error')}")
                return []

            # Process articles
            for item in data.get('articles', []):
                article = {
                    'url': item.get('url', ''),
                    'title': item.get('title', ''),
                    'summary': item.get('description', ''),
                    'content': item.get('content', ''),
                    'published_date': item.get('publishedAt', ''),
                    'author': item.get('author', ''),
                    'source': item.get('source', {}).get('name', 'NewsAPI'),
                    'source_type': 'newsapi',
                    'discovered_at': datetime.utcnow().isoformat()
                }

                # Check if MVP-related (NewsAPI results might be broader)
                text_to_check = f"{article['title']} {article['summary']}"
                if self.is_mvp_related(text_to_check):
                    articles.append(article)

            self.logger.info(f"Found {len(articles)} MVP-related articles from NewsAPI")

        except requests.exceptions.RequestException as e:
            self.logger.error(f"NewsAPI request error: {e}")
        except Exception as e:
            self.logger.error(f"Error searching NewsAPI: {e}")

        return articles

    def search_google_news(self, query: str = 'NFL MVP 2024') -> List[Dict]:
        """
        Search Google News for MVP articles
        Note: This scrapes the Google News web page, not an official API

        Args:
            query: Search query

        Returns:
            List of article dictionaries
        """
        articles = []

        try:
            self.rate_limit()

            # Google News search URL
            encoded_query = quote_plus(query)
            url = f'https://news.google.com/search?q={encoded_query}&hl=en-US&gl=US&ceid=US:en'

            self.logger.info(f"Searching Google News for: {query}")

            html = self.fetch_url(url)
            if not html:
                return []

            soup = self.parse_html(html)

            # Find article links (Google News uses specific classes)
            # Note: These selectors may need updating if Google changes their HTML
            article_elements = soup.find_all('article')

            for element in article_elements[:50]:  # Limit to 50
                try:
                    # Extract article link
                    link_elem = element.find('a', href=True)
                    if not link_elem:
                        continue

                    href = link_elem.get('href', '')

                    # Google News links are relative with ./articles/ prefix
                    if href.startswith('./articles/'):
                        # Full Google News URL
                        full_url = f"https://news.google.com{href[1:]}"
                    elif href.startswith('/articles/'):
                        full_url = f"https://news.google.com{href}"
                    else:
                        continue

                    # Extract title
                    title = link_elem.get_text(strip=True)

                    # Extract source and time (typically in nearby elements)
                    source_elem = element.find('a', {'data-n-tid': True})
                    source = source_elem.get_text(strip=True) if source_elem else 'Google News'

                    time_elem = element.find('time')
                    published = time_elem.get('datetime', '') if time_elem else ''

                    article = {
                        'url': full_url,
                        'title': title,
                        'source': source,
                        'published_date': published,
                        'source_type': 'google_news',
                        'discovered_at': datetime.utcnow().isoformat()
                    }

                    # Google News results are already filtered by query, but double-check
                    if self.is_mvp_related(title):
                        articles.append(article)

                except Exception as e:
                    self.logger.debug(f"Error parsing Google News article element: {e}")
                    continue

            self.logger.info(f"Found {len(articles)} articles from Google News")

        except Exception as e:
            self.logger.error(f"Error searching Google News: {e}")

        return articles

    def filter_recent_articles(self, articles: List[Dict], days: int = 7) -> List[Dict]:
        """
        Filter articles to only include recent ones

        Args:
            articles: List of article dictionaries
            days: Number of days to consider recent

        Returns:
            Filtered list of recent articles
        """
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        recent_articles = []

        for article in articles:
            # Try to parse published date
            published_str = article.get('published_date', article.get('published', ''))

            if not published_str:
                # If no date, include it (might be very recent)
                recent_articles.append(article)
                continue

            try:
                # Try various date formats
                published_date = None

                # ISO format (YYYY-MM-DDTHH:MM:SSZ)
                if 'T' in published_str:
                    published_date = datetime.fromisoformat(published_str.replace('Z', '+00:00'))
                # RFC 2822 format
                elif ',' in published_str:
                    from email.utils import parsedate_to_datetime
                    published_date = parsedate_to_datetime(published_str)

                if published_date and published_date.replace(tzinfo=None) >= cutoff_date:
                    recent_articles.append(article)

            except Exception as e:
                self.logger.debug(f"Could not parse date '{published_str}': {e}")
                # Include if we can't parse the date
                recent_articles.append(article)

        self.logger.info(f"Filtered to {len(recent_articles)} recent articles (last {days} days)")
        return recent_articles

    def aggregate_all_sources(self, days_back: int = 7, include_newsapi: bool = True,
                              include_google_news: bool = True) -> Dict:
        """
        Aggregate articles from all available sources

        Args:
            days_back: How many days back to search
            include_newsapi: Whether to include NewsAPI (requires API key)
            include_google_news: Whether to include Google News scraping

        Returns:
            Dictionary with articles and metadata
        """
        self.logger.info("Starting news aggregation from all sources...")

        all_articles = []
        sources_used = []

        # 1. Fetch RSS feeds
        self.logger.info("Fetching RSS feeds...")
        rss_articles = self.fetch_all_rss_feeds()
        all_articles.extend(rss_articles)
        sources_used.append('rss_feeds')

        # 2. Search NewsAPI if enabled and key available
        if include_newsapi and self.newsapi_key:
            self.logger.info("Searching NewsAPI...")
            newsapi_articles = self.search_newsapi(days_back=days_back)
            all_articles.extend(newsapi_articles)
            sources_used.append('newsapi')

        # 3. Search Google News if enabled
        if include_google_news:
            self.logger.info("Searching Google News...")
            google_articles = self.search_google_news()
            all_articles.extend(google_articles)
            sources_used.append('google_news')

        # Filter to recent articles
        recent_articles = self.filter_recent_articles(all_articles, days=days_back)

        # Deduplicate by URL
        seen_urls = set()
        unique_articles = []

        for article in recent_articles:
            url = article.get('url', '')
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_articles.append(article)

        # Sort by published date (most recent first)
        def get_sort_date(article):
            date_str = article.get('published_date', article.get('published', ''))
            if not date_str:
                return datetime.min
            try:
                if 'T' in date_str:
                    return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                else:
                    from email.utils import parsedate_to_datetime
                    return parsedate_to_datetime(date_str)
            except:
                return datetime.min

        unique_articles.sort(key=get_sort_date, reverse=True)

        result = {
            'articles': unique_articles,
            'metadata': {
                'total_articles': len(unique_articles),
                'sources_used': sources_used,
                'days_searched': days_back,
                'searched_at': datetime.utcnow().isoformat(),
                'duplicates_removed': len(all_articles) - len(unique_articles)
            }
        }

        self.logger.info(f"✓ Aggregation complete: {len(unique_articles)} unique articles from {len(sources_used)} sources")

        return result

    def search(self, query: str = 'NFL MVP', **kwargs) -> List[Dict]:
        """
        Search for articles (implements BaseScraper abstract method)

        Args:
            query: Search query
            **kwargs: Additional parameters (days_back, include_newsapi, include_google_news)

        Returns:
            List of article dictionaries
        """
        days_back = kwargs.get('days_back', 7)
        include_newsapi = kwargs.get('include_newsapi', True)
        include_google_news = kwargs.get('include_google_news', True)

        result = self.aggregate_all_sources(
            days_back=days_back,
            include_newsapi=include_newsapi,
            include_google_news=include_google_news
        )

        return result.get('articles', [])
