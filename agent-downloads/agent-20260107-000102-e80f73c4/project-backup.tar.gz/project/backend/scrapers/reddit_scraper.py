"""
Reddit scraper for NFL MVP voter information using PRAW
"""
import os
import time
from typing import List, Dict, Optional
from datetime import datetime, timedelta

import praw
from prawcore.exceptions import PrawcoreException

from .base_scraper import BaseScraper


class RedditScraper(BaseScraper):
    """Scraper for Reddit posts and comments about NFL MVP voters"""

    def __init__(self, rate_limit_delay=2.0):
        """
        Initialize Reddit scraper

        Args:
            rate_limit_delay: Seconds between requests
        """
        super().__init__(rate_limit_delay)

        # Initialize PRAW client
        try:
            self.reddit = praw.Reddit(
                client_id=os.getenv('REDDIT_CLIENT_ID', 'your_client_id'),
                client_secret=os.getenv('REDDIT_CLIENT_SECRET', 'your_client_secret'),
                user_agent='NFL_MVP_Tracker/1.0 (by /u/your_username)'
            )
            self.reddit.read_only = True
            self.logger.info("Reddit client initialized successfully")

        except Exception as e:
            self.logger.error(f"Failed to initialize Reddit client: {e}")
            self.reddit = None

    def search(self, query: str, subreddits: Optional[List[str]] = None,
               time_filter: str = 'month', limit: int = 100, **kwargs) -> List[Dict]:
        """
        Search Reddit for NFL MVP voter information

        Args:
            query: Search query
            subreddits: List of subreddit names to search (None = all)
            time_filter: Time filter ('hour', 'day', 'week', 'month', 'year', 'all')
            limit: Maximum number of results
            **kwargs: Additional parameters

        Returns:
            List of Reddit posts and comments
        """
        if not self.reddit:
            self.logger.error("Reddit client not initialized")
            return []

        results = []

        # Default subreddits if not specified
        if subreddits is None:
            subreddits = ['nfl', 'ravens', 'buffalobills', 'eagles', 'bengals',
                         'detroitlions', 'commanders', 'fantasyfootball']

        for subreddit_name in subreddits:
            try:
                self.logger.info(f"Searching r/{subreddit_name} for: {query}")

                subreddit = self.reddit.subreddit(subreddit_name)

                # Search posts
                posts = subreddit.search(query, time_filter=time_filter, limit=limit)

                for post in posts:
                    # Check if post is MVP-related
                    combined_text = f"{post.title} {post.selftext}"

                    if self.is_mvp_related(combined_text):
                        result = {
                            'type': 'post',
                            'url': f"https://reddit.com{post.permalink}",
                            'title': post.title,
                            'content': post.selftext[:1000],  # Truncate long posts
                            'author': str(post.author) if post.author else '[deleted]',
                            'subreddit': subreddit_name,
                            'score': post.score,
                            'num_comments': post.num_comments,
                            'created_utc': datetime.fromtimestamp(post.created_utc).isoformat(),
                            'source': 'reddit',
                            'query': query,
                            'discovered_at': datetime.utcnow().isoformat()
                        }

                        results.append(result)

                        # Also search top comments for voter information
                        post.comments.replace_more(limit=0)  # Don't load all comments
                        for comment in post.comments[:20]:  # Check top 20 comments
                            if self.is_mvp_related(comment.body):
                                comment_result = {
                                    'type': 'comment',
                                    'url': f"https://reddit.com{comment.permalink}",
                                    'title': f"Comment on: {post.title}",
                                    'content': comment.body[:500],
                                    'author': str(comment.author) if comment.author else '[deleted]',
                                    'subreddit': subreddit_name,
                                    'score': comment.score,
                                    'created_utc': datetime.fromtimestamp(comment.created_utc).isoformat(),
                                    'source': 'reddit',
                                    'query': query,
                                    'discovered_at': datetime.utcnow().isoformat()
                                }
                                results.append(comment_result)

                # Rate limiting
                time.sleep(self.rate_limit_delay)

            except PrawcoreException as e:
                self.logger.error(f"Reddit API error in r/{subreddit_name}: {e}")
                continue

            except Exception as e:
                self.logger.error(f"Error searching r/{subreddit_name}: {e}")
                continue

        self.logger.info(f"Found {len(results)} relevant items from Reddit")

        return results

    def search_voter_discussions(self, season: str = "2024-25") -> List[Dict]:
        """
        Search Reddit for NFL MVP voter discussions

        Args:
            season: NFL season

        Returns:
            List of relevant Reddit posts/comments
        """
        queries = [
            "NFL MVP vote voter",
            "AP MVP ballot",
            "Tom Brady MVP vote",
            "Mina Kimes MVP",
            "who voted for MVP",
            "MVP voter reveals",
            "Josh Allen Lamar Jackson MVP",
        ]

        all_results = []
        seen_urls = set()

        for query in queries:
            results = self.search(query, time_filter='month', limit=50)

            # Deduplicate
            for result in results:
                if result['url'] not in seen_urls:
                    seen_urls.add(result['url'])
                    all_results.append(result)

        return all_results

    def get_user_posts(self, username: str, limit: int = 100) -> List[Dict]:
        """
        Get posts from a specific Reddit user (useful for known voters)

        Args:
            username: Reddit username
            limit: Number of posts to retrieve

        Returns:
            List of user's posts
        """
        if not self.reddit:
            return []

        results = []

        try:
            user = self.reddit.redditor(username)

            for submission in user.submissions.new(limit=limit):
                if self.is_mvp_related(f"{submission.title} {submission.selftext}"):
                    results.append({
                        'type': 'user_post',
                        'url': f"https://reddit.com{submission.permalink}",
                        'title': submission.title,
                        'content': submission.selftext[:1000],
                        'author': username,
                        'subreddit': str(submission.subreddit),
                        'score': submission.score,
                        'created_utc': datetime.fromtimestamp(submission.created_utc).isoformat(),
                        'source': 'reddit',
                        'discovered_at': datetime.utcnow().isoformat()
                    })

        except Exception as e:
            self.logger.error(f"Error fetching posts for u/{username}: {e}")

        return results

    def monitor_subreddit_new(self, subreddit_name: str, duration_minutes: int = 10) -> List[Dict]:
        """
        Monitor a subreddit's new posts in real-time

        Args:
            subreddit_name: Subreddit to monitor
            duration_minutes: How long to monitor

        Returns:
            List of new MVP-related posts
        """
        if not self.reddit:
            return []

        results = []
        start_time = time.time()
        end_time = start_time + (duration_minutes * 60)

        try:
            subreddit = self.reddit.subreddit(subreddit_name)

            self.logger.info(f"Monitoring r/{subreddit_name} for {duration_minutes} minutes...")

            for submission in subreddit.stream.submissions(skip_existing=True):
                # Check if time limit reached
                if time.time() > end_time:
                    break

                if self.is_mvp_related(f"{submission.title} {submission.selftext}"):
                    results.append({
                        'type': 'new_post',
                        'url': f"https://reddit.com{submission.permalink}",
                        'title': submission.title,
                        'content': submission.selftext[:1000],
                        'author': str(submission.author) if submission.author else '[deleted]',
                        'subreddit': subreddit_name,
                        'score': submission.score,
                        'created_utc': datetime.fromtimestamp(submission.created_utc).isoformat(),
                        'source': 'reddit',
                        'discovered_at': datetime.utcnow().isoformat()
                    })

                    self.logger.info(f"Found new MVP-related post: {submission.title}")

        except Exception as e:
            self.logger.error(f"Error monitoring r/{subreddit_name}: {e}")

        return results
