"""
Orchestrator to coordinate multiple scrapers and manage scraping workflow
"""
import logging
from typing import List, Dict, Optional
from datetime import datetime
import json
import os

from .google_scraper import GoogleScraper
from .reddit_scraper import RedditScraper
from .news_scraper import NewsScraper
from .source_tracker import SourceTracker
from database import get_session


class ScraperOrchestrator:
    """Coordinates multiple scrapers to gather NFL MVP voter information"""

    def __init__(self, output_dir: str = './data/scraping_results', use_db_deduplication: bool = True):
        """
        Initialize scraper orchestrator

        Args:
            output_dir: Directory to save scraping results
            use_db_deduplication: Whether to use database for deduplication
        """
        self.logger = logging.getLogger(__name__)

        # Initialize scrapers
        self.google_scraper = GoogleScraper(rate_limit_delay=3.0)
        self.reddit_scraper = RedditScraper(rate_limit_delay=2.0)
        self.news_scraper = NewsScraper(rate_limit_delay=2.0)

        # Output directory
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        # Database session and source tracking
        self.use_db_deduplication = use_db_deduplication
        self.db_session = None
        self.source_trackers = {}

        if use_db_deduplication:
            try:
                self.db_session = get_session()
                self.logger.info("✓ Database deduplication enabled")
            except Exception as e:
                self.logger.warning(f"Could not initialize database session: {e}")
                self.logger.warning("Continuing without database deduplication")
                self.use_db_deduplication = False

        # Results storage
        self.all_results = {
            'google': [],
            'reddit': [],
            'news': [],
            'metadata': {
                'started_at': None,
                'completed_at': None,
                'total_sources_found': 0,
                'total_urls_found': 0,
                'duplicates_filtered': 0,
                'new_sources_added': 0
            }
        }

    def _get_source_tracker(self, source_type: str) -> Optional[SourceTracker]:
        """
        Get or create source tracker for a specific source type

        Args:
            source_type: Type of source (google, reddit, news)

        Returns:
            SourceTracker instance or None if DB disabled
        """
        if not self.use_db_deduplication or not self.db_session:
            return None

        if source_type not in self.source_trackers:
            self.source_trackers[source_type] = SourceTracker(self.db_session, source_type)

        return self.source_trackers[source_type]

    def _process_results_with_deduplication(self, results: List[Dict],
                                           source_type: str) -> List[Dict]:
        """
        Process results with deduplication if enabled

        Args:
            results: List of result dictionaries
            source_type: Type of source

        Returns:
            Filtered list of unique results
        """
        if not self.use_db_deduplication:
            return results

        tracker = self._get_source_tracker(source_type)
        if not tracker:
            return results

        original_count = len(results)

        # Filter out already-processed URLs
        results = tracker.filter_new_items(results)

        # Deduplicate by content
        results = tracker.deduplicate_by_content(results, content_key='text')

        # Add new sources to database
        for result in results:
            url = result.get('url')
            title = result.get('title', '')
            content = result.get('text', '') or result.get('content', '')

            if url:
                try:
                    source_id = tracker.add_source(url, title, content)
                    result['source_id'] = source_id
                    self.all_results['metadata']['new_sources_added'] += 1
                except Exception as e:
                    self.logger.error(f"Error adding source {url}: {e}")

        duplicates_removed = original_count - len(results)
        self.all_results['metadata']['duplicates_filtered'] += duplicates_removed

        if duplicates_removed > 0:
            self.logger.info(f"🔍 Filtered {duplicates_removed} duplicate items from {source_type}")

        return results

    def run_comprehensive_search(self, season: str = "2024-25",
                                include_google: bool = True,
                                include_reddit: bool = True,
                                include_news: bool = True) -> Dict:
        """
        Run a comprehensive search across all sources

        Args:
            season: NFL season to search for
            include_google: Whether to include Google search
            include_reddit: Whether to include Reddit search
            include_news: Whether to include news site scraping

        Returns:
            Dictionary with all results
        """
        self.logger.info("=" * 80)
        self.logger.info(f"Starting comprehensive NFL MVP voter search for {season} season")
        if self.use_db_deduplication:
            self.logger.info("🔍 Deduplication: ENABLED")
        else:
            self.logger.info("🔍 Deduplication: DISABLED")
        self.logger.info("=" * 80)

        self.all_results['metadata']['started_at'] = datetime.utcnow().isoformat()

        # 1. Google Search
        if include_google:
            self.logger.info("\n[1/3] Searching Google for MVP voter information...")
            try:
                google_results = self.google_scraper.search_voter_announcements(season)
                self.logger.info(f"Found {len(google_results)} Google results")

                # Apply deduplication
                google_results = self._process_results_with_deduplication(google_results, 'google')

                self.all_results['google'] = google_results
                self.logger.info(f"✓ Google search complete: {len(google_results)} unique results")
            except Exception as e:
                self.logger.error(f"✗ Google search failed: {e}")

        # 2. Reddit Search
        if include_reddit:
            self.logger.info("\n[2/3] Searching Reddit for MVP discussions...")
            try:
                reddit_results = self.reddit_scraper.search_voter_discussions(season)
                self.logger.info(f"Found {len(reddit_results)} Reddit results")

                # Apply deduplication
                reddit_results = self._process_results_with_deduplication(reddit_results, 'reddit')

                self.all_results['reddit'] = reddit_results
                self.logger.info(f"✓ Reddit search complete: {len(reddit_results)} unique results")
            except Exception as e:
                self.logger.error(f"✗ Reddit search failed: {e}")

        # 3. News Sites Scraping
        if include_news:
            self.logger.info("\n[3/3] Scraping news sites for MVP articles...")
            try:
                # First, scrape news sites for URLs
                news_urls = self.news_scraper.scrape_nfl_news_sites()
                self.logger.info(f"Found {len(news_urls)} news article URLs")

                # Filter for new URLs only
                if self.use_db_deduplication:
                    tracker = self._get_source_tracker('news')
                    if tracker:
                        news_urls = tracker.filter_new_items(news_urls)
                        self.logger.info(f"After filtering: {len(news_urls)} new URLs")

                # Then extract full articles from promising URLs
                urls_to_extract = [item['url'] for item in news_urls[:20]]  # Limit to top 20
                news_articles = self.news_scraper.extract_articles_batch(urls_to_extract)

                # Apply deduplication
                news_articles = self._process_results_with_deduplication(news_articles, 'news')

                self.all_results['news'] = news_articles
                self.logger.info(f"✓ News extraction complete: {len(news_articles)} unique articles")
            except Exception as e:
                self.logger.error(f"✗ News scraping failed: {e}")

        # Update metadata
        self.all_results['metadata']['completed_at'] = datetime.utcnow().isoformat()
        self.all_results['metadata']['total_sources_found'] = (
            len(self.all_results['google']) +
            len(self.all_results['reddit']) +
            len(self.all_results['news'])
        )

        # Count unique URLs
        all_urls = set()
        for source in ['google', 'reddit', 'news']:
            for item in self.all_results[source]:
                all_urls.add(item.get('url', ''))

        self.all_results['metadata']['total_urls_found'] = len(all_urls)

        # Save results
        self._save_results()

        # Print summary
        self._print_summary()

        return self.all_results

    def search_specific_voter(self, voter_name: str, season: str = "2024-25") -> Dict:
        """
        Search for information about a specific voter

        Args:
            voter_name: Name of the voter to search for
            season: NFL season

        Returns:
            Dictionary with search results
        """
        self.logger.info(f"Searching for voter: {voter_name}")

        results = {
            'voter_name': voter_name,
            'google': [],
            'reddit': [],
            'news': []
        }

        # Google search
        try:
            results['google'] = self.google_scraper.search_specific_voter(voter_name, season)
        except Exception as e:
            self.logger.error(f"Google search failed for {voter_name}: {e}")

        # Reddit search
        try:
            reddit_results = self.reddit_scraper.search(
                f"{voter_name} MVP",
                time_filter='year',
                limit=50
            )
            results['reddit'] = reddit_results
        except Exception as e:
            self.logger.error(f"Reddit search failed for {voter_name}: {e}")

        return results

    def extract_articles_from_urls(self, urls: List[str]) -> List[Dict]:
        """
        Extract full article content from a list of URLs

        Args:
            urls: List of article URLs

        Returns:
            List of extracted articles
        """
        self.logger.info(f"Extracting {len(urls)} articles...")

        articles = self.news_scraper.extract_articles_batch(urls)

        self.logger.info(f"Successfully extracted {len(articles)} articles")

        return articles

    def monitor_reddit_live(self, duration_minutes: int = 10,
                           subreddits: Optional[List[str]] = None) -> List[Dict]:
        """
        Monitor Reddit for new MVP-related posts in real-time

        Args:
            duration_minutes: How long to monitor
            subreddits: List of subreddits to monitor (default: ['nfl'])

        Returns:
            List of new posts found
        """
        if subreddits is None:
            subreddits = ['nfl']

        all_posts = []

        for subreddit in subreddits:
            posts = self.reddit_scraper.monitor_subreddit_new(subreddit, duration_minutes)
            all_posts.extend(posts)

        return all_posts

    def _save_results(self):
        """Save results to JSON file"""
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        filename = f"scraping_results_{timestamp}.json"
        filepath = os.path.join(self.output_dir, filename)

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(self.all_results, f, indent=2, ensure_ascii=False)

            self.logger.info(f"\n✓ Results saved to: {filepath}")

            # Also save to a 'latest' file for easy access
            latest_filepath = os.path.join(self.output_dir, 'latest_results.json')
            with open(latest_filepath, 'w', encoding='utf-8') as f:
                json.dump(self.all_results, f, indent=2, ensure_ascii=False)

        except Exception as e:
            self.logger.error(f"Error saving results: {e}")

    def _print_summary(self):
        """Print summary of scraping results"""
        self.logger.info("\n" + "=" * 80)
        self.logger.info("SCRAPING SUMMARY")
        self.logger.info("=" * 80)

        self.logger.info(f"Started:  {self.all_results['metadata']['started_at']}")
        self.logger.info(f"Finished: {self.all_results['metadata']['completed_at']}")
        self.logger.info(f"\nResults by Source:")
        self.logger.info(f"  Google:  {len(self.all_results['google'])} results")
        self.logger.info(f"  Reddit:  {len(self.all_results['reddit'])} posts/comments")
        self.logger.info(f"  News:    {len(self.all_results['news'])} articles")
        self.logger.info(f"\nTotal Sources: {self.all_results['metadata']['total_sources_found']}")
        self.logger.info(f"Unique URLs:   {self.all_results['metadata']['total_urls_found']}")

        if self.use_db_deduplication:
            self.logger.info(f"\n🔍 Deduplication Stats:")
            self.logger.info(f"  Duplicates Filtered: {self.all_results['metadata']['duplicates_filtered']}")
            self.logger.info(f"  New Sources Added:   {self.all_results['metadata']['new_sources_added']}")

            # Get overall source stats from database
            try:
                for source_type in ['google', 'reddit', 'news']:
                    tracker = self._get_source_tracker(source_type)
                    if tracker:
                        stats = tracker.get_stats()
                        self.logger.info(f"\n  {source_type.capitalize()} Database Stats:")
                        self.logger.info(f"    Total sources: {stats.get('by_type', {}).get(source_type, 0)}")
                        break  # Only show overall stats once
                else:
                    tracker = self._get_source_tracker('google')
                    if tracker:
                        stats = tracker.get_stats()
                        self.logger.info(f"\n  Overall Database Stats:")
                        self.logger.info(f"    Total sources: {stats['total']}")
                        self.logger.info(f"    Processed:     {stats['processed']}")
                        self.logger.info(f"    Unprocessed:   {stats['unprocessed']}")
            except Exception as e:
                self.logger.debug(f"Could not get source stats: {e}")

        self.logger.info("=" * 80)

    def get_summary_stats(self) -> Dict:
        """
        Get summary statistics of scraping results

        Returns:
            Dictionary with statistics
        """
        return {
            'google_results': len(self.all_results['google']),
            'reddit_results': len(self.all_results['reddit']),
            'news_articles': len(self.all_results['news']),
            'total_sources': self.all_results['metadata']['total_sources_found'],
            'unique_urls': self.all_results['metadata']['total_urls_found'],
            'started_at': self.all_results['metadata']['started_at'],
            'completed_at': self.all_results['metadata']['completed_at']
        }


def main():
    """Main function for testing the orchestrator"""
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Create orchestrator
    orchestrator = ScraperOrchestrator()

    # Run comprehensive search
    results = orchestrator.run_comprehensive_search(
        season="2024-25",
        include_google=True,
        include_reddit=True,
        include_news=True
    )

    # Print summary
    print("\n\nFinal Summary:")
    print(json.dumps(orchestrator.get_summary_stats(), indent=2))


if __name__ == '__main__':
    main()
