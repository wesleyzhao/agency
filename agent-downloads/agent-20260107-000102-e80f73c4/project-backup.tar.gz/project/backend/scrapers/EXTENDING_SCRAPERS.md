# Extending the NFL MVP Voter Tracker Scraping System

**Complete Guide to Adding New Data Sources and Extending Functionality**

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Adding a New Scraper](#adding-a-new-scraper)
4. [Implementing Custom NLP Extractors](#implementing-custom-nlp-extractors)
5. [Integrating with the Database](#integrating-with-the-database)
6. [Adding New API Endpoints](#adding-new-api-endpoints)
7. [Testing Your Extensions](#testing-your-extensions)
8. [Best Practices](#best-practices)
9. [Common Patterns](#common-patterns)
10. [Troubleshooting](#troubleshooting)

---

## Overview

The NFL MVP Voter Tracker is built with extensibility in mind. The system consists of several modular components:

- **Scrapers**: Fetch data from external sources (Reddit, news sites, social media)
- **NLP Extractors**: Parse text to extract voter names, candidates, and rankings
- **Database Layer**: Store and retrieve voter and vote information
- **API Layer**: Expose data through REST endpoints
- **Frontend**: Display data to users

This guide will show you how to add new functionality to each of these components.

---

## Architecture

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (React)                        │
│  Dashboard | VoterDetail | Statistics | Admin | Timeline    │
└─────────────────────────┬───────────────────────────────────┘
                          │ HTTP/REST
┌─────────────────────────▼───────────────────────────────────┐
│                    Flask API (app.py)                        │
│  /api/voters | /api/votes | /api/dashboard | /api/admin    │
└─────────────────────────┬───────────────────────────────────┘
                          │
          ┌───────────────┴───────────────┐
          │                               │
┌─────────▼─────────┐         ┌──────────▼──────────┐
│  Database Layer   │         │   NLP Extractors    │
│  (SQLAlchemy)     │         │   VoteExtractor     │
│  models.py        │         │   ConfidenceScorer  │
│  utils.py         │         │                     │
└─────────┬─────────┘         └──────────┬──────────┘
          │                              │
          │         ┌────────────────────┘
          │         │
┌─────────▼─────────▼──────────────────────────────────────┐
│                    Scrapers                               │
│  EnhancedScraper | RedditScraper | GoogleScraper         │
│  NewsScraper | NewsAggregator | ScraperOrchestrator      │
└───────────────────────────────────────────────────────────┘
          │
          │
┌─────────▼─────────────────────────────────────────────────┐
│                 External Sources                          │
│  Reddit | Twitter/X | ESPN | NFL.com | NewsAPI | RSS     │
└───────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Scraper** fetches raw data from external source
2. **Rate Limiter** ensures requests don't exceed limits
3. **Response Cache** stores responses to avoid duplicate requests
4. **NLP Extractor** parses text to extract structured data
5. **Confidence Scorer** assigns confidence levels to extracted data
6. **Database Layer** stores extracted information
7. **Notification System** alerts users of new discoveries
8. **API Layer** exposes data to frontend
9. **Frontend** displays data to users

---

## Adding a New Scraper

### Step 1: Understand the Base Classes

All scrapers inherit from either `BaseScraper` or `EnhancedScraper`:

- **BaseScraper**: Simple base class with common scraping utilities
- **EnhancedScraper**: Includes rate limiting, caching, and retry logic (recommended)

### Step 2: Create Your Scraper Class

Create a new file: `backend/scrapers/my_new_scraper.py`

```python
from scrapers.enhanced_scraper import EnhancedScraper
from logging_config import scraping_logger, log_scraping_activity
import requests
from bs4 import BeautifulSoup

class MyNewScraper(EnhancedScraper):
    """
    Scraper for [Your Data Source Name].

    This scraper fetches NFL MVP voter information from [source description].
    """

    def __init__(self, rate_limit_delay=2.0, use_cache=True, cache_ttl=3600):
        """
        Initialize the scraper.

        Args:
            rate_limit_delay: Seconds to wait between requests (default 2.0)
            use_cache: Whether to cache responses (default True)
            cache_ttl: Cache time-to-live in seconds (default 3600 = 1 hour)
        """
        super().__init__(
            name="my_new_scraper",
            rate_limit_delay=rate_limit_delay,
            use_cache=use_cache,
            cache_ttl=cache_ttl
        )
        self.base_url = "https://example.com"
        scraping_logger.info(f"Initialized MyNewScraper with {rate_limit_delay}s delay")

    def search_mvp_votes(self, season="2024-25"):
        """
        Search for NFL MVP vote announcements.

        Args:
            season: NFL season (e.g., "2024-25")

        Returns:
            list: List of dictionaries with vote information
        """
        results = []

        try:
            # Build the search URL
            search_url = f"{self.base_url}/search?q=nfl+mvp+{season}"

            # Use fetch_url from EnhancedScraper (includes caching, rate limiting, retry)
            html = self.fetch_url(search_url)

            if not html:
                scraping_logger.warning(f"No HTML returned from {search_url}")
                return results

            # Parse the HTML
            soup = BeautifulSoup(html, 'html.parser')

            # Extract articles/posts (customize based on your source)
            articles = soup.find_all('article', class_='mvp-article')

            for article in articles:
                try:
                    # Extract data (customize based on your HTML structure)
                    title = article.find('h2').get_text(strip=True)
                    url = article.find('a')['href']
                    content = article.find('div', class_='content').get_text(strip=True)
                    date_str = article.find('time')['datetime']

                    # Check if MVP-relevant (inherited from BaseScraper)
                    if not self.is_mvp_relevant(title + " " + content):
                        continue

                    # Build result object
                    result = {
                        'title': title,
                        'url': url,
                        'content': content,
                        'published_date': date_str,
                        'source': 'my_new_scraper',
                        'source_type': 'news_article',  # or 'social_media', 'official', etc.
                        'scraped_at': self._get_current_timestamp()
                    }

                    results.append(result)
                    scraping_logger.info(f"Found MVP article: {title[:50]}...")

                except Exception as e:
                    scraping_logger.error(f"Error parsing article: {str(e)}", exc_info=True)
                    continue

            # Log the activity
            log_scraping_activity(
                scraping_logger,
                source='my_new_scraper',
                url=search_url,
                status='success',
                articles_found=len(results)
            )

            return results

        except Exception as e:
            scraping_logger.error(f"Error in search_mvp_votes: {str(e)}", exc_info=True)
            log_scraping_activity(
                scraping_logger,
                source='my_new_scraper',
                url=search_url,
                status='error',
                error_message=str(e)
            )
            return results

    def search_specific_voter(self, voter_name, season="2024-25"):
        """
        Search for information about a specific voter.

        Args:
            voter_name: Name of the voter (e.g., "Mina Kimes")
            season: NFL season

        Returns:
            list: List of dictionaries with voter information
        """
        results = []

        try:
            # Build voter-specific search URL
            search_url = f"{self.base_url}/search?q={voter_name}+mvp+vote+{season}"

            # Fetch and parse (similar to above)
            html = self.fetch_url(search_url)

            if not html:
                return results

            soup = BeautifulSoup(html, 'html.parser')

            # Extract voter-specific information
            # ... customize based on your source ...

            log_scraping_activity(
                scraping_logger,
                source='my_new_scraper',
                url=search_url,
                status='success',
                voter_name=voter_name,
                results_found=len(results)
            )

            return results

        except Exception as e:
            scraping_logger.error(f"Error searching for voter {voter_name}: {str(e)}")
            return results
```

### Step 3: Add Helper Methods

You can add source-specific helper methods:

```python
    def _parse_author_name(self, article_element):
        """Extract author name from article HTML."""
        author_tag = article_element.find('span', class_='author')
        if author_tag:
            return author_tag.get_text(strip=True).replace('By ', '')
        return None

    def _parse_publication_date(self, date_string):
        """Convert date string to ISO format."""
        from dateutil import parser
        try:
            dt = parser.parse(date_string)
            return dt.isoformat()
        except:
            return None

    def _extract_voter_from_text(self, text):
        """Extract voter name from text using NLP."""
        from nlp import VoteExtractor
        extractor = VoteExtractor()

        votes = extractor.extract_votes_from_text(
            text,
            source_url="",
            source_type="news_article"
        )

        return votes
```

### Step 4: Register Your Scraper

Add your scraper to `backend/scrapers/__init__.py`:

```python
from scrapers.my_new_scraper import MyNewScraper

__all__ = [
    'BaseScraper',
    'EnhancedScraper',
    'RedditScraper',
    'GoogleScraper',
    'NewsScraper',
    'NewsAggregator',
    'ScraperOrchestrator',
    'MyNewScraper',  # Add your scraper here
]
```

### Step 5: Integrate with ScraperOrchestrator

Update `backend/scrapers/scraper_orchestrator.py` to include your scraper:

```python
from scrapers.my_new_scraper import MyNewScraper

class ScraperOrchestrator:
    def __init__(self, use_db_deduplication=True):
        # ... existing code ...

        # Add your scraper
        self.my_new_scraper = MyNewScraper(
            rate_limit_delay=2.0,
            use_cache=True
        )

        self.scrapers['my_new_scraper'] = self.my_new_scraper

    def run_comprehensive_search(self, season="2024-25"):
        """Run search across all scrapers."""
        all_results = []

        # ... existing scrapers ...

        # Add your scraper
        scraping_logger.info("Running MyNewScraper...")
        my_new_results = self.my_new_scraper.search_mvp_votes(season)
        if self.use_db_deduplication:
            my_new_results = self._process_results_with_deduplication(
                my_new_results,
                'my_new_scraper'
            )
        all_results.extend(my_new_results)

        # ... rest of method ...
```

### Step 6: Test Your Scraper

Create a test file: `backend/test_my_new_scraper.py`

```python
import sys
sys.path.insert(0, '.')

from scrapers import MyNewScraper

def test_basic_search():
    """Test basic MVP vote search."""
    print("Test 1: Basic MVP Vote Search")
    print("=" * 60)

    scraper = MyNewScraper()
    results = scraper.search_mvp_votes(season="2024-25")

    print(f"Found {len(results)} results")

    if results:
        print("\nFirst result:")
        print(f"  Title: {results[0].get('title', 'N/A')}")
        print(f"  URL: {results[0].get('url', 'N/A')}")
        print(f"  Source: {results[0].get('source', 'N/A')}")
        print(f"  Date: {results[0].get('published_date', 'N/A')}")

    print("✓ Test passed\n")

def test_specific_voter():
    """Test searching for a specific voter."""
    print("Test 2: Specific Voter Search")
    print("=" * 60)

    scraper = MyNewScraper()
    results = scraper.search_specific_voter("Mina Kimes", season="2024-25")

    print(f"Found {len(results)} results for Mina Kimes")

    print("✓ Test passed\n")

if __name__ == "__main__":
    test_basic_search()
    test_specific_voter()
    print("\nAll tests completed!")
```

Run the test:

```bash
cd backend
python3 test_my_new_scraper.py
```

---

## Implementing Custom NLP Extractors

### Step 1: Understand the Extractor Components

The NLP system has three main components:

- **VoterExtractor**: Extracts voter names from text
- **CandidateExtractor**: Extracts MVP candidate names
- **RankingExtractor**: Extracts vote rankings (1st, 2nd, 3rd, etc.)
- **VoteExtractor**: Orchestrates all extractors

### Step 2: Add Custom Extraction Patterns

If you need to recognize new voter name patterns:

Edit `backend/nlp/voter_extractor.py`:

```python
class VoterExtractor:
    def __init__(self):
        # ... existing code ...

        # Add new voting patterns
        self.voting_patterns.extend([
            r"my\s+mvp\s+ballot\s+goes\s+to\s+(.+?)(?:\.|,|for)",
            r"i\s+have\s+decided\s+to\s+vote\s+for\s+(.+?)(?:\s+as\s+mvp|\s+for\s+mvp)",
            r"(.+?)\s+gets\s+my\s+mvp\s+vote",
        ])
```

If you need to recognize new candidate names:

Edit `backend/nlp/candidate_extractor.py`:

```python
class CandidateExtractor:
    def add_candidate(self, name, team, position, aliases=None):
        """Add a new MVP candidate."""
        candidate = {
            'name': name,
            'team': team,
            'position': position,
            'aliases': aliases or []
        }
        self.candidates.append(candidate)

# Usage:
extractor = CandidateExtractor()
extractor.add_candidate(
    name="New Player",
    team="Team Name",
    position="QB",
    aliases=["N. Player", "Player"]
)
```

### Step 3: Create Custom Extractor

For highly specialized extraction, create a new extractor:

`backend/nlp/custom_extractor.py`:

```python
from nlp.base_extractor import BaseExtractor
from logging_config import nlp_logger
import re

class CustomExtractor:
    """
    Custom extractor for specialized text patterns.

    Example: Extract MVP votes from Twitter/X threads.
    """

    def __init__(self):
        self.thread_pattern = re.compile(
            r"Thread:\s*My\s+MVP\s+Ballot.*?1[\.)]?\s*(.+?)2[\.)]?\s*(.+?)3[\.)]?\s*(.+)",
            re.DOTALL | re.IGNORECASE
        )

    def extract_from_thread(self, text):
        """
        Extract MVP ballot from a Twitter/X thread format.

        Args:
            text: Thread text

        Returns:
            list: Extracted votes with rankings
        """
        votes = []

        match = self.thread_pattern.search(text)
        if match:
            # Extract the three candidates
            candidate1 = match.group(1).strip()
            candidate2 = match.group(2).strip()
            candidate3 = match.group(3).strip()

            votes.append({'candidate': candidate1, 'ranking': 1})
            votes.append({'candidate': candidate2, 'ranking': 2})
            votes.append({'candidate': candidate3, 'ranking': 3})

            nlp_logger.info(f"Extracted {len(votes)} votes from thread")

        return votes
```

Register in `backend/nlp/__init__.py`:

```python
from nlp.custom_extractor import CustomExtractor

__all__ = [
    # ... existing ...
    'CustomExtractor',
]
```

---

## Integrating with the Database

### Step 1: Understand the Database Schema

The database has four main tables:

- **Voter**: Stores voter information (name, outlet, Twitter handle, etc.)
- **Candidate**: Stores MVP candidates (name, team, position)
- **Vote**: Stores disclosed votes (voter_id, candidate_id, ranking, confidence, source)
- **Source**: Stores original source URLs for deduplication

### Step 2: Add Data to Database

Example: Save scraped data to database

```python
from database import VoterDB, CandidateDB, VoteDB, SourceDB
from scrapers import MyNewScraper
from nlp import VoteExtractor

def scrape_and_save():
    """Scrape data and save to database."""

    # Initialize components
    scraper = MyNewScraper()
    extractor = VoteExtractor()

    voter_db = VoterDB()
    candidate_db = CandidateDB()
    vote_db = VoteDB()
    source_db = SourceDB()

    # Scrape data
    results = scraper.search_mvp_votes(season="2024-25")

    for result in results:
        # Check if source already processed
        if source_db.is_duplicate_content(result['content']):
            print(f"Skipping duplicate: {result['url']}")
            continue

        # Add source
        source_id = source_db.add_source(
            url=result['url'],
            source_type=result['source_type'],
            content=result['content'],
            title=result.get('title', '')
        )

        # Extract votes using NLP
        votes = extractor.extract_votes_from_text(
            text=result['content'],
            source_url=result['url'],
            source_type=result['source_type']
        )

        for vote_data in votes:
            # Get or create voter
            voter = voter_db.get_voter_by_name(vote_data['voter_name'])
            if not voter:
                voter_id = voter_db.add_voter(
                    name=vote_data['voter_name'],
                    outlet=vote_data.get('voter_outlet', 'Unknown'),
                    twitter_handle=vote_data.get('twitter_handle')
                )
            else:
                voter_id = voter['id']

            # Get or create candidate
            candidate = candidate_db.get_candidate_by_name(
                vote_data['candidate_name'],
                season="2024-25"
            )
            if not candidate:
                candidate_id = candidate_db.add_candidate(
                    name=vote_data['candidate_name'],
                    team=vote_data.get('candidate_team', 'Unknown'),
                    position=vote_data.get('candidate_position', 'Unknown'),
                    season="2024-25"
                )
            else:
                candidate_id = candidate['id']

            # Add vote
            vote_id = vote_db.add_vote(
                voter_id=voter_id,
                candidate_id=candidate_id,
                season="2024-25",
                ranking=vote_data.get('ranking'),
                confidence=vote_data.get('confidence', 'medium'),
                confidence_score=vote_data.get('confidence_numeric', 50.0),
                source_url=result['url'],
                source_type=result['source_type'],
                announcement_date=result.get('published_date'),
                extracted_text=result['content'][:500]
            )

            print(f"Added vote: {vote_data['voter_name']} → {vote_data['candidate_name']}")
```

### Step 3: Create Database Migration (if schema changes needed)

If you need to add new columns or tables:

`backend/database/migrate_add_my_feature.py`:

```python
import sqlite3
import os

def migrate():
    """Add new column to database."""

    db_path = os.path.join('database', 'nfl_mvp_tracker.db')
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Add new column
        cursor.execute("""
            ALTER TABLE voters
            ADD COLUMN my_new_field TEXT
        """)

        conn.commit()
        print("✓ Migration successful: Added my_new_field column")

    except Exception as e:
        print(f"✗ Migration failed: {str(e)}")
        conn.rollback()

    finally:
        conn.close()

if __name__ == "__main__":
    migrate()
```

Run migration:

```bash
cd backend
python3 database/migrate_add_my_feature.py
```

---

## Adding New API Endpoints

### Step 1: Add Endpoint to Flask App

Edit `backend/app.py`:

```python
@app.route('/api/my-new-endpoint', methods=['GET'])
def my_new_endpoint():
    """
    New API endpoint for custom functionality.

    Query Parameters:
        season: NFL season (default: 2024-25)
        limit: Number of results (default: 50)

    Returns:
        JSON response with data
    """
    try:
        # Get query parameters
        season = request.args.get('season', '2024-25')
        limit = int(request.args.get('limit', 50))

        # Get data from database
        from database import VoterDB
        voter_db = VoterDB()

        # ... your custom logic ...

        # Return JSON response
        return jsonify({
            'success': True,
            'data': [],  # Your data here
            'season': season,
            'count': 0
        }), 200

    except Exception as e:
        app.logger.error(f"Error in my_new_endpoint: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
```

### Step 2: Test the Endpoint

Create test file: `backend/test_my_new_endpoint.py`

```python
import requests

def test_endpoint():
    """Test the new API endpoint."""

    url = "http://localhost:5000/api/my-new-endpoint"
    params = {'season': '2024-25', 'limit': 10}

    response = requests.get(url, params=params)

    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

    assert response.status_code == 200
    assert response.json()['success'] == True

    print("✓ Test passed")

if __name__ == "__main__":
    test_endpoint()
```

### Step 3: Add Frontend Integration

Create React component to use the endpoint:

`frontend/src/MyNewComponent.js`:

```javascript
import React, { useState, useEffect } from 'react';

function MyNewComponent() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      const response = await fetch(
        `${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/my-new-endpoint?season=2024-25`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }

      const result = await response.json();
      setData(result.data);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h1>My New Feature</h1>
      {/* Render your data here */}
    </div>
  );
}

export default MyNewComponent;
```

Add route in `frontend/src/App.js`:

```javascript
import MyNewComponent from './MyNewComponent';

// Inside Router:
<Route path="/my-new-feature" element={<MyNewComponent />} />
```

---

## Testing Your Extensions

### Unit Tests

Create comprehensive unit tests:

`backend/test_my_extension.py`:

```python
import sys
sys.path.insert(0, '.')

import unittest
from scrapers import MyNewScraper

class TestMyNewScraper(unittest.TestCase):
    """Unit tests for MyNewScraper."""

    def setUp(self):
        """Set up test fixtures."""
        self.scraper = MyNewScraper()

    def test_initialization(self):
        """Test scraper initialization."""
        self.assertIsNotNone(self.scraper)
        self.assertEqual(self.scraper.base_url, "https://example.com")

    def test_search_mvp_votes(self):
        """Test MVP vote search."""
        results = self.scraper.search_mvp_votes(season="2024-25")
        self.assertIsInstance(results, list)

    def test_mvp_relevance(self):
        """Test MVP relevance detection."""
        text = "Josh Allen is my MVP pick for 2024"
        self.assertTrue(self.scraper.is_mvp_relevant(text))

        text = "I love pizza"
        self.assertFalse(self.scraper.is_mvp_relevant(text))

    def tearDown(self):
        """Clean up after tests."""
        pass

if __name__ == '__main__':
    unittest.main()
```

Run tests:

```bash
cd backend
python3 -m unittest test_my_extension.py
```

### Integration Tests

Test the full pipeline:

```python
def test_full_pipeline():
    """Test scraping → NLP → database pipeline."""

    # Scrape data
    scraper = MyNewScraper()
    results = scraper.search_mvp_votes()
    assert len(results) > 0

    # Extract votes with NLP
    from nlp import VoteExtractor
    extractor = VoteExtractor()
    votes = extractor.extract_votes_from_text(
        results[0]['content'],
        results[0]['url'],
        results[0]['source_type']
    )
    assert len(votes) > 0

    # Save to database
    from database import VoteDB
    vote_db = VoteDB()
    vote_id = vote_db.add_vote(
        voter_id=1,
        candidate_id=1,
        season="2024-25",
        ranking=1
    )
    assert vote_id > 0

    print("✓ Full pipeline test passed")
```

---

## Best Practices

### 1. Error Handling

Always wrap scraping code in try-except blocks:

```python
try:
    html = self.fetch_url(url)
except requests.RequestException as e:
    scraping_logger.error(f"Network error: {str(e)}")
    return []
except Exception as e:
    scraping_logger.error(f"Unexpected error: {str(e)}", exc_info=True)
    return []
```

### 2. Logging

Use the logging system extensively:

```python
from logging_config import scraping_logger, log_scraping_activity

# Log important events
scraping_logger.info("Starting scrape...")
scraping_logger.warning("No results found")
scraping_logger.error("Failed to fetch URL", exc_info=True)

# Use specialized logging functions
log_scraping_activity(
    scraping_logger,
    source='my_scraper',
    url=url,
    status='success',
    posts_found=10
)
```

### 3. Rate Limiting

Always respect rate limits:

```python
# Use EnhancedScraper which includes rate limiting
class MyScraper(EnhancedScraper):
    def __init__(self):
        super().__init__(
            name="my_scraper",
            rate_limit_delay=2.0  # 2 seconds between requests
        )
```

### 4. Caching

Enable caching to avoid duplicate requests:

```python
# Use EnhancedScraper with caching enabled
scraper = MyScraper(
    use_cache=True,
    cache_ttl=3600  # Cache for 1 hour
)
```

### 5. Deduplication

Use the SourceDB to avoid processing duplicate content:

```python
from database import SourceDB

source_db = SourceDB()

# Check if URL already processed
if source_db.is_duplicate_content(content):
    print("Already processed this content")
    return

# Add source to database
source_id = source_db.add_source(
    url=url,
    source_type='news_article',
    content=content
)
```

### 6. Data Validation

Validate extracted data before saving:

```python
def validate_vote_data(vote_data):
    """Validate vote data before saving."""

    required_fields = ['voter_name', 'candidate_name', 'ranking']

    for field in required_fields:
        if field not in vote_data or not vote_data[field]:
            return False, f"Missing required field: {field}"

    # Validate ranking
    if not (1 <= vote_data['ranking'] <= 5):
        return False, "Ranking must be between 1 and 5"

    return True, "Valid"

# Usage
is_valid, message = validate_vote_data(vote_data)
if not is_valid:
    scraping_logger.warning(f"Invalid vote data: {message}")
    continue
```

### 7. Documentation

Document your code thoroughly:

```python
def my_function(param1, param2):
    """
    Brief description of what the function does.

    Args:
        param1 (str): Description of param1
        param2 (int): Description of param2

    Returns:
        list: Description of return value

    Raises:
        ValueError: When param1 is invalid

    Example:
        >>> my_function("test", 42)
        ['result1', 'result2']
    """
    pass
```

---

## Common Patterns

### Pattern 1: Search and Extract

Common pattern for scraping and extracting votes:

```python
def scrape_and_extract(self, query, season="2024-25"):
    """Scrape data and extract votes in one operation."""

    # Step 1: Search for relevant content
    results = self.search_mvp_votes(query, season)

    # Step 2: Extract votes from each result
    all_votes = []
    extractor = VoteExtractor()

    for result in results:
        votes = extractor.extract_votes_from_text(
            text=result['content'],
            source_url=result['url'],
            source_type=result['source_type']
        )
        all_votes.extend(votes)

    return all_votes
```

### Pattern 2: Batch Processing

Process multiple items efficiently:

```python
def batch_process_urls(self, urls):
    """Process multiple URLs efficiently."""

    results = []

    # Use rate limiter to avoid overwhelming the server
    for url in urls:
        try:
            html = self.fetch_url(url)  # EnhancedScraper handles rate limiting

            if html:
                data = self.parse_html(html)
                results.append(data)

        except Exception as e:
            scraping_logger.error(f"Error processing {url}: {str(e)}")
            continue

    return results
```

### Pattern 3: Incremental Updates

Only fetch new data since last run:

```python
from datetime import datetime, timedelta

def get_recent_updates(self, since_days=1):
    """Get updates from the last N days."""

    cutoff_date = datetime.now() - timedelta(days=since_days)

    # Fetch data
    results = self.search_mvp_votes()

    # Filter by date
    recent_results = [
        r for r in results
        if self.parse_date(r['published_date']) > cutoff_date
    ]

    return recent_results
```

### Pattern 4: Retry with Exponential Backoff

Handle transient failures:

```python
import time

def fetch_with_retry(self, url, max_retries=3):
    """Fetch URL with exponential backoff retry."""

    for attempt in range(max_retries):
        try:
            return self.fetch_url(url)

        except requests.RequestException as e:
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential: 1s, 2s, 4s
                scraping_logger.warning(f"Retry {attempt+1}/{max_retries} after {wait_time}s")
                time.sleep(wait_time)
            else:
                scraping_logger.error(f"Failed after {max_retries} retries")
                raise
```

---

## Troubleshooting

### Common Issues and Solutions

#### Issue: "Rate limited by website"

**Solution**: Increase rate limit delay

```python
scraper = MyScraper(rate_limit_delay=5.0)  # Increase to 5 seconds
```

#### Issue: "No data extracted from HTML"

**Solution**: Inspect HTML structure

```python
# Print HTML to see structure
html = scraper.fetch_url(url)
print(html)

# Use browser dev tools to find correct CSS selectors
soup = BeautifulSoup(html, 'html.parser')
print(soup.prettify())
```

#### Issue: "Duplicate votes in database"

**Solution**: Use deduplication

```python
from database import SourceDB

source_db = SourceDB()

# Check before saving
if not source_db.is_duplicate_content(content):
    source_db.add_source(url, source_type, content)
```

#### Issue: "NLP not extracting votes correctly"

**Solution**: Add more patterns or debug extraction

```python
# Enable debug logging
import logging
logging.getLogger('nlp').setLevel(logging.DEBUG)

# Test extraction manually
from nlp import VoteExtractor
extractor = VoteExtractor()

text = "Your test text here"
votes = extractor.extract_votes_from_text(text, "", "news_article")

print(f"Extracted {len(votes)} votes")
for vote in votes:
    print(vote)
```

#### Issue: "Scraper too slow"

**Solution**: Enable caching and parallel processing

```python
# Enable caching
scraper = MyScraper(use_cache=True, cache_ttl=3600)

# Use concurrent requests (be careful with rate limits!)
from concurrent.futures import ThreadPoolExecutor

def fetch_all_urls(urls):
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(scraper.fetch_url, urls))
    return results
```

### Debugging Tips

1. **Check logs**: All scrapers log to `backend/logs/scraping.log`

```bash
tail -f backend/logs/scraping.log
```

2. **Use print statements**: Add debug prints liberally

```python
print(f"DEBUG: Found {len(results)} results")
print(f"DEBUG: HTML length: {len(html)}")
```

3. **Test in isolation**: Test each component separately

```python
# Test scraper only
scraper = MyScraper()
results = scraper.search_mvp_votes()
print(results)

# Test NLP only
from nlp import VoteExtractor
extractor = VoteExtractor()
votes = extractor.extract_votes_from_text("test text", "", "")
print(votes)
```

4. **Use interactive Python**: Test code interactively

```bash
cd backend
python3
>>> from scrapers import MyScraper
>>> scraper = MyScraper()
>>> results = scraper.search_mvp_votes()
>>> print(results[0])
```

---

## Example: Complete Extension

Here's a complete example of adding Twitter/X scraping:

**File: `backend/scrapers/twitter_scraper.py`**

```python
from scrapers.enhanced_scraper import EnhancedScraper
from logging_config import scraping_logger, log_scraping_activity
import requests
from bs4 import BeautifulSoup
import re

class TwitterScraper(EnhancedScraper):
    """
    Scraper for Twitter/X posts about NFL MVP votes.

    Note: Twitter's API requires authentication. This scraper
    uses nitter.net as a proxy to access public tweets.
    """

    def __init__(self, rate_limit_delay=3.0):
        super().__init__(
            name="twitter_scraper",
            rate_limit_delay=rate_limit_delay,
            use_cache=True,
            cache_ttl=1800  # 30 minutes
        )
        self.nitter_instance = "https://nitter.net"
        scraping_logger.info("Initialized TwitterScraper")

    def search_mvp_tweets(self, query="nfl mvp vote", max_results=50):
        """
        Search for MVP-related tweets.

        Args:
            query: Search query
            max_results: Maximum tweets to return

        Returns:
            list: List of tweet dictionaries
        """
        results = []

        try:
            # Build search URL (using nitter as proxy)
            search_url = f"{self.nitter_instance}/search?f=tweets&q={query}"

            scraping_logger.info(f"Searching Twitter for: {query}")

            html = self.fetch_url(search_url)

            if not html:
                return results

            soup = BeautifulSoup(html, 'html.parser')

            # Parse tweets
            tweets = soup.find_all('div', class_='timeline-item')

            for tweet in tweets[:max_results]:
                try:
                    # Extract tweet data
                    username = tweet.find('a', class_='username').get_text(strip=True)
                    content = tweet.find('div', class_='tweet-content').get_text(strip=True)
                    timestamp = tweet.find('span', class_='tweet-date').get('title', '')
                    tweet_link = tweet.find('a', class_='tweet-link')

                    # Build tweet URL
                    tweet_url = f"https://twitter.com{tweet_link['href']}" if tweet_link else ""

                    # Check relevance
                    if not self.is_mvp_relevant(content):
                        continue

                    result = {
                        'username': username,
                        'content': content,
                        'timestamp': timestamp,
                        'url': tweet_url,
                        'source': 'twitter',
                        'source_type': 'social_media',
                        'scraped_at': self._get_current_timestamp()
                    }

                    results.append(result)
                    scraping_logger.info(f"Found MVP tweet from @{username}")

                except Exception as e:
                    scraping_logger.error(f"Error parsing tweet: {str(e)}")
                    continue

            log_scraping_activity(
                scraping_logger,
                source='twitter',
                url=search_url,
                status='success',
                tweets_found=len(results)
            )

            return results

        except Exception as e:
            scraping_logger.error(f"Error in search_mvp_tweets: {str(e)}", exc_info=True)
            return results

    def get_user_tweets(self, username, max_tweets=20):
        """
        Get recent tweets from a specific user.

        Args:
            username: Twitter username (without @)
            max_tweets: Maximum tweets to fetch

        Returns:
            list: User's tweets
        """
        results = []

        try:
            profile_url = f"{self.nitter_instance}/{username}"

            html = self.fetch_url(profile_url)

            if not html:
                return results

            soup = BeautifulSoup(html, 'html.parser')
            tweets = soup.find_all('div', class_='timeline-item')

            for tweet in tweets[:max_tweets]:
                # Similar parsing as above
                # ... implementation ...
                pass

            return results

        except Exception as e:
            scraping_logger.error(f"Error getting user tweets: {str(e)}")
            return results
```

**Integration:**

```python
# In scraper_orchestrator.py
from scrapers.twitter_scraper import TwitterScraper

class ScraperOrchestrator:
    def __init__(self):
        # ... existing code ...
        self.twitter_scraper = TwitterScraper(rate_limit_delay=3.0)
        self.scrapers['twitter'] = self.twitter_scraper

    def run_comprehensive_search(self, season="2024-25"):
        # ... existing code ...

        # Add Twitter search
        twitter_results = self.twitter_scraper.search_mvp_tweets(
            query=f"nfl mvp vote {season}"
        )
        all_results.extend(twitter_results)
```

---

## Next Steps

After extending the scraper system:

1. **Test thoroughly**: Write comprehensive unit and integration tests
2. **Document your changes**: Update this guide with new patterns
3. **Monitor performance**: Check logs for errors and performance issues
4. **Optimize**: Use caching and rate limiting appropriately
5. **Share**: If your extension is useful, consider contributing it back

---

## Additional Resources

- **SQLAlchemy Documentation**: https://docs.sqlalchemy.org/
- **BeautifulSoup Documentation**: https://www.crummy.com/software/BeautifulSoup/bs4/doc/
- **Requests Documentation**: https://requests.readthedocs.io/
- **Flask Documentation**: https://flask.palletsprojects.com/
- **React Documentation**: https://react.dev/

---

## Support

If you encounter issues or have questions:

1. Check the logs in `backend/logs/`
2. Review existing scrapers for examples
3. Run the test suite to identify issues
4. Check the troubleshooting section above

---

**Last Updated**: January 7, 2026
**Version**: 1.0.0
