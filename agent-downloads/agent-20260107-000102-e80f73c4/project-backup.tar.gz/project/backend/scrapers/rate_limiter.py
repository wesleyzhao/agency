"""
Advanced rate limiting for web scraping with per-domain tracking and exponential backoff
"""
import time
import logging
from collections import defaultdict
from typing import Dict, Optional
from urllib.parse import urlparse
from datetime import datetime, timedelta


class RateLimiter:
    """
    Advanced rate limiter with multiple strategies:
    - Global rate limiting (max requests per second across all domains)
    - Per-domain rate limiting (avoid overwhelming specific sites)
    - Exponential backoff on errors
    - Request throttling with queue management
    """

    def __init__(
        self,
        global_delay: float = 1.0,
        per_domain_delay: float = 2.0,
        max_retries: int = 3,
        backoff_factor: float = 2.0,
        enable_adaptive: bool = True
    ):
        """
        Initialize rate limiter

        Args:
            global_delay: Minimum seconds between ANY requests (default: 1.0)
            per_domain_delay: Minimum seconds between requests to SAME domain (default: 2.0)
            max_retries: Maximum retry attempts on errors (default: 3)
            backoff_factor: Multiplier for exponential backoff (default: 2.0)
            enable_adaptive: Enable adaptive rate limiting based on errors (default: True)
        """
        self.global_delay = global_delay
        self.per_domain_delay = per_domain_delay
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.enable_adaptive = enable_adaptive

        # Track last request time globally
        self.last_global_request = 0.0

        # Track last request time per domain
        self.last_domain_request: Dict[str, float] = defaultdict(float)

        # Track error counts per domain for adaptive rate limiting
        self.domain_errors: Dict[str, int] = defaultdict(int)
        self.domain_error_time: Dict[str, datetime] = {}

        # Track retry attempts per URL
        self.retry_counts: Dict[str, int] = defaultdict(int)

        # Statistics
        self.total_requests = 0
        self.total_delays = 0
        self.total_delay_time = 0.0

        self.logger = logging.getLogger(__name__)

    def extract_domain(self, url: str) -> str:
        """
        Extract domain from URL

        Args:
            url: Full URL

        Returns:
            Domain name (e.g., 'espn.com')
        """
        try:
            parsed = urlparse(url)
            domain = parsed.netloc
            # Remove 'www.' prefix if present
            if domain.startswith('www.'):
                domain = domain[4:]
            return domain
        except Exception as e:
            self.logger.warning(f"Failed to parse domain from {url}: {e}")
            return url

    def get_adaptive_delay(self, domain: str) -> float:
        """
        Calculate adaptive delay based on error history

        If a domain has recent errors, increase delay exponentially

        Args:
            domain: Domain name

        Returns:
            Adjusted delay in seconds
        """
        if not self.enable_adaptive:
            return self.per_domain_delay

        error_count = self.domain_errors.get(domain, 0)
        if error_count == 0:
            return self.per_domain_delay

        # Check if errors are recent (within last 5 minutes)
        last_error_time = self.domain_error_time.get(domain)
        if last_error_time:
            time_since_error = datetime.now() - last_error_time
            if time_since_error > timedelta(minutes=5):
                # Reset error count if no errors in 5 minutes
                self.domain_errors[domain] = 0
                return self.per_domain_delay

        # Exponential backoff based on error count
        # error_count=1 -> 2x delay, error_count=2 -> 4x delay, etc.
        adaptive_delay = self.per_domain_delay * (self.backoff_factor ** error_count)

        # Cap at 60 seconds
        return min(adaptive_delay, 60.0)

    def wait(self, url: str, is_retry: bool = False) -> float:
        """
        Wait appropriate amount of time before making request

        Args:
            url: URL to be requested
            is_retry: Whether this is a retry attempt

        Returns:
            Time waited in seconds
        """
        domain = self.extract_domain(url)
        current_time = time.time()

        # Calculate required delays
        global_wait = max(0, self.global_delay - (current_time - self.last_global_request))
        domain_wait = max(0, self.get_adaptive_delay(domain) - (current_time - self.last_domain_request[domain]))

        # Use the longer of the two delays
        wait_time = max(global_wait, domain_wait)

        # Add extra delay for retries (exponential backoff)
        if is_retry:
            retry_count = self.retry_counts[url]
            retry_delay = self.per_domain_delay * (self.backoff_factor ** retry_count)
            wait_time = max(wait_time, retry_delay)
            self.logger.info(f"Retry #{retry_count} for {domain}: waiting {wait_time:.2f}s")

        # Wait if necessary
        if wait_time > 0:
            self.logger.debug(f"Rate limiting {domain}: waiting {wait_time:.2f}s")
            time.sleep(wait_time)
            self.total_delays += 1
            self.total_delay_time += wait_time

        # Update timestamps
        self.last_global_request = time.time()
        self.last_domain_request[domain] = time.time()
        self.total_requests += 1

        return wait_time

    def record_success(self, url: str):
        """
        Record successful request (resets error counters)

        Args:
            url: URL that succeeded
        """
        domain = self.extract_domain(url)

        # Reset error count on success
        if domain in self.domain_errors:
            old_errors = self.domain_errors[domain]
            self.domain_errors[domain] = 0
            if old_errors > 0:
                self.logger.info(f"Success for {domain}: reset error count from {old_errors}")

        # Reset retry count
        if url in self.retry_counts:
            del self.retry_counts[url]

    def record_error(self, url: str, error: Exception):
        """
        Record failed request (increases error counters for adaptive limiting)

        Args:
            url: URL that failed
            error: Exception that occurred
        """
        domain = self.extract_domain(url)

        # Increment error count
        self.domain_errors[domain] += 1
        self.domain_error_time[domain] = datetime.now()

        # Increment retry count
        self.retry_counts[url] += 1

        error_count = self.domain_errors[domain]
        retry_count = self.retry_counts[url]

        self.logger.warning(
            f"Error for {domain} (errors: {error_count}, retries: {retry_count}): {error}"
        )

    def should_retry(self, url: str) -> bool:
        """
        Determine if URL should be retried based on retry count

        Args:
            url: URL to check

        Returns:
            True if should retry, False if max retries exceeded
        """
        retry_count = self.retry_counts.get(url, 0)
        should_retry = retry_count < self.max_retries

        if not should_retry:
            self.logger.error(f"Max retries ({self.max_retries}) exceeded for {url}")

        return should_retry

    def get_statistics(self) -> Dict:
        """
        Get rate limiting statistics

        Returns:
            Dictionary with statistics
        """
        return {
            'total_requests': self.total_requests,
            'total_delays': self.total_delays,
            'total_delay_time': round(self.total_delay_time, 2),
            'avg_delay_time': round(self.total_delay_time / max(self.total_delays, 1), 2),
            'domains_tracked': len(self.last_domain_request),
            'domains_with_errors': len([d for d, e in self.domain_errors.items() if e > 0]),
            'active_retries': len(self.retry_counts),
            'domain_errors': dict(self.domain_errors),
        }

    def reset_statistics(self):
        """Reset statistics counters"""
        self.total_requests = 0
        self.total_delays = 0
        self.total_delay_time = 0.0

    def reset_domain_errors(self, domain: Optional[str] = None):
        """
        Reset error counts for a domain or all domains

        Args:
            domain: Specific domain to reset, or None for all domains
        """
        if domain:
            if domain in self.domain_errors:
                self.domain_errors[domain] = 0
                self.logger.info(f"Reset errors for {domain}")
        else:
            self.domain_errors.clear()
            self.domain_error_time.clear()
            self.logger.info("Reset all domain errors")


class RequestThrottler:
    """
    Request throttler with sliding window rate limiting

    Ensures requests don't exceed a maximum rate over a time window
    (e.g., max 60 requests per minute)
    """

    def __init__(self, max_requests: int = 60, time_window: int = 60):
        """
        Initialize throttler

        Args:
            max_requests: Maximum requests allowed in time window
            time_window: Time window in seconds
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.request_times = []
        self.logger = logging.getLogger(__name__)

    def wait_if_needed(self) -> float:
        """
        Wait if necessary to stay within rate limits

        Returns:
            Time waited in seconds
        """
        current_time = time.time()

        # Remove old requests outside time window
        cutoff_time = current_time - self.time_window
        self.request_times = [t for t in self.request_times if t > cutoff_time]

        # Check if at limit
        if len(self.request_times) >= self.max_requests:
            # Calculate how long to wait
            oldest_request = self.request_times[0]
            wait_time = oldest_request + self.time_window - current_time

            if wait_time > 0:
                self.logger.info(
                    f"Throttling: {len(self.request_times)} requests in last {self.time_window}s, "
                    f"waiting {wait_time:.2f}s"
                )
                time.sleep(wait_time)
                return wait_time

        # Record this request
        self.request_times.append(time.time())
        return 0.0

    def get_current_rate(self) -> float:
        """
        Get current request rate (requests per second)

        Returns:
            Requests per second over the time window
        """
        current_time = time.time()
        cutoff_time = current_time - self.time_window
        recent_requests = [t for t in self.request_times if t > cutoff_time]

        if len(recent_requests) < 2:
            return 0.0

        return len(recent_requests) / self.time_window

    def reset(self):
        """Reset throttler state"""
        self.request_times = []
