"""
Google web search scraper for NFL MVP voter information
"""
import time
from typing import List, Dict, Optional
from urllib.parse import quote_plus, urljoin

from .base_scraper import BaseScraper


class GoogleScraper(BaseScraper):
    """Scraper for Google search results"""

    def __init__(self, rate_limit_delay=3.0):
        """
        Initialize Google scraper

        Args:
            rate_limit_delay: Seconds between requests (higher for Google)
        """
        super().__init__(rate_limit_delay)
        self.base_url = "https://www.google.com/search"

    def search(self, query: str, num_results: int = 20, **kwargs) -> List[Dict]:
        """
        Search Google for NFL MVP voter information

        Args:
            query: Search query
            num_results: Number of results to retrieve
            **kwargs: Additional parameters (e.g., date_range, site)

        Returns:
            List of search results
        """
        results = []

        # Build search URL
        search_url = f"{self.base_url}?q={quote_plus(query)}&num={num_results}"

        # Add date filter if specified
        if 'date_range' in kwargs:
            # tbs=qdr:w (week), qdr:m (month), qdr:y (year)
            search_url += f"&tbs=qdr:{kwargs['date_range']}"

        # Fetch search results page
        html = self.fetch_url(search_url)

        if not html:
            self.logger.warning(f"Failed to fetch Google results for: {query}")
            return results

        # Parse results
        soup = self.parse_html(html)

        # Find all search result divs (Google's structure changes, so we try multiple selectors)
        result_divs = soup.select('div.g') or soup.select('div[data-sokoban-container]')

        for div in result_divs[:num_results]:
            try:
                # Extract title
                title_elem = div.select_one('h3')
                title = title_elem.get_text() if title_elem else ""

                # Extract URL
                link_elem = div.select_one('a')
                url = link_elem.get('href', '') if link_elem else ""

                # Clean URL (Google sometimes uses /url?q=... format)
                if url.startswith('/url?q='):
                    url = url.split('/url?q=')[1].split('&')[0]

                # Extract snippet
                snippet_elem = div.select_one('div[data-sncf]') or div.select_one('.VwiC3b')
                snippet = snippet_elem.get_text() if snippet_elem else ""

                if url and title:
                    # Check if result is MVP-related
                    combined_text = f"{title} {snippet}"

                    if self.is_mvp_related(combined_text):
                        results.append({
                            'url': url,
                            'title': title,
                            'snippet': snippet,
                            'source': 'google',
                            'query': query,
                            'discovered_at': time.strftime('%Y-%m-%d %H:%M:%S')
                        })

            except Exception as e:
                self.logger.error(f"Error parsing Google result: {e}")
                continue

        self.logger.info(f"Found {len(results)} relevant results from Google for: {query}")

        return results

    def search_multiple_queries(self, queries: List[str], num_results: int = 20) -> List[Dict]:
        """
        Search multiple queries and combine results

        Args:
            queries: List of search queries
            num_results: Results per query

        Returns:
            Combined list of unique results
        """
        all_results = []
        seen_urls = set()

        for query in queries:
            self.logger.info(f"Searching Google for: {query}")

            results = self.search(query, num_results=num_results)

            # Deduplicate by URL
            for result in results:
                if result['url'] not in seen_urls:
                    seen_urls.add(result['url'])
                    all_results.append(result)

            # Add extra delay between query searches
            time.sleep(self.rate_limit_delay + 1)

        return all_results

    def search_voter_announcements(self, season: str = "2024-25") -> List[Dict]:
        """
        Search for NFL MVP voter announcements

        Args:
            season: NFL season (e.g., "2024-25")

        Returns:
            List of relevant search results
        """
        # Build comprehensive search queries
        queries = [
            f"NFL MVP vote {season}",
            f"AP NFL MVP voter ballot {season}",
            f"\"my MVP vote\" NFL {season}",
            f"\"I voted for\" NFL MVP {season}",
            f"NFL MVP voter announces {season}",
            "NFL MVP Tom Brady vote",
            "NFL MVP Mina Kimes vote",
            "NFL MVP voter reveals ballot",
            "\"Josh Allen\" \"Lamar Jackson\" MVP vote",
            "NFL MVP voter Twitter announcement",
            "AP NFL MVP 50 voters",
            "who has NFL MVP vote",
        ]

        return self.search_multiple_queries(queries, num_results=15)

    def search_specific_voter(self, voter_name: str, season: str = "2024-25") -> List[Dict]:
        """
        Search for a specific voter's MVP announcement

        Args:
            voter_name: Name of the voter
            season: NFL season

        Returns:
            List of relevant results
        """
        queries = [
            f"{voter_name} NFL MVP vote {season}",
            f"{voter_name} MVP ballot",
            f"\"{voter_name}\" \"my MVP vote\"",
        ]

        return self.search_multiple_queries(queries, num_results=10)
