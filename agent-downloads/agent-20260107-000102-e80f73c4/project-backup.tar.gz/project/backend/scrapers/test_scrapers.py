"""
Test script for web scraping modules
"""
import logging
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scrapers.base_scraper import BaseScraper
from scrapers.google_scraper import GoogleScraper
from scrapers.reddit_scraper import RedditScraper
from scrapers.news_scraper import NewsScraper
from scrapers.scraper_orchestrator import ScraperOrchestrator


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('scraper_test.log')
        ]
    )


def test_base_scraper():
    """Test base scraper functionality"""
    print("\n" + "=" * 80)
    print("Testing BaseScraper")
    print("=" * 80)

    class TestScraper(BaseScraper):
        def search(self, query, **kwargs):
            return []

    scraper = TestScraper()

    # Test MVP detection
    test_texts = [
        "Josh Allen is my NFL MVP vote for 2024",
        "Just a random football article",
        "Lamar Jackson voted MVP by Tom Brady",
    ]

    for text in test_texts:
        is_mvp = scraper.is_mvp_related(text)
        print(f"MVP-related: {is_mvp:5} - {text[:50]}")

    print("\n✓ BaseScraper tests passed")


def test_google_scraper():
    """Test Google scraper"""
    print("\n" + "=" * 80)
    print("Testing GoogleScraper")
    print("=" * 80)

    scraper = GoogleScraper()

    # Test a simple search
    print("\nSearching: 'NFL MVP vote 2024'")
    results = scraper.search("NFL MVP vote 2024", num_results=5)

    print(f"\nFound {len(results)} results:")
    for i, result in enumerate(results[:3], 1):
        print(f"\n{i}. {result['title']}")
        print(f"   URL: {result['url']}")
        print(f"   Snippet: {result['snippet'][:100]}...")

    print(f"\n✓ GoogleScraper test completed ({len(results)} results)")


def test_reddit_scraper():
    """Test Reddit scraper"""
    print("\n" + "=" * 80)
    print("Testing RedditScraper")
    print("=" * 80)

    scraper = RedditScraper()

    if not scraper.reddit:
        print("⚠ Reddit client not configured - skipping test")
        print("  Set REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET environment variables")
        return

    # Test search
    print("\nSearching r/nfl for 'NFL MVP'")
    results = scraper.search("NFL MVP", subreddits=['nfl'], limit=5)

    print(f"\nFound {len(results)} results:")
    for i, result in enumerate(results[:3], 1):
        print(f"\n{i}. [{result['type']}] {result['title']}")
        print(f"   URL: {result['url']}")
        print(f"   Author: {result['author']} | Score: {result['score']}")

    print(f"\n✓ RedditScraper test completed ({len(results)} results)")


def test_news_scraper():
    """Test news scraper"""
    print("\n" + "=" * 80)
    print("Testing NewsScraper")
    print("=" * 80)

    scraper = NewsScraper()

    # Test scraping news sites for URLs
    print("\nScraping NFL news sites for MVP articles...")
    urls = scraper.scrape_nfl_news_sites()

    print(f"\nFound {len(urls)} article URLs:")
    for i, item in enumerate(urls[:5], 1):
        print(f"{i}. {item['title'][:60]}")
        print(f"   Source: {item['source']}")
        print(f"   URL: {item['url'][:70]}...")

    # Test extracting one article
    if urls:
        print("\n\nExtracting first article...")
        article = scraper.extract_article(urls[0]['url'])

        if article:
            print(f"\n✓ Article extracted:")
            print(f"  Title: {article['title']}")
            print(f"  Authors: {', '.join(article['authors']) if article['authors'] else 'Unknown'}")
            print(f"  Text length: {len(article['text'])} characters")
            print(f"  Preview: {article['text'][:200]}...")
        else:
            print("\n⚠ Could not extract article")

    print(f"\n✓ NewsScraper test completed")


def test_orchestrator():
    """Test scraper orchestrator"""
    print("\n" + "=" * 80)
    print("Testing ScraperOrchestrator")
    print("=" * 80)

    orchestrator = ScraperOrchestrator(output_dir='./data/scraping_results')

    # Run a limited search
    print("\nRunning comprehensive search (limited)...")
    results = orchestrator.run_comprehensive_search(
        season="2024-25",
        include_google=True,
        include_reddit=True,
        include_news=False  # Skip news to make test faster
    )

    # Print summary
    stats = orchestrator.get_summary_stats()
    print("\n\nOrchestrator Summary:")
    print(f"  Google results: {stats['google_results']}")
    print(f"  Reddit results: {stats['reddit_results']}")
    print(f"  News articles: {stats['news_articles']}")
    print(f"  Total sources: {stats['total_sources']}")
    print(f"  Unique URLs: {stats['unique_urls']}")

    print("\n✓ ScraperOrchestrator test completed")


def main():
    """Run all tests"""
    setup_logging()

    print("\n" + "=" * 80)
    print("NFL MVP VOTER SCRAPER - TEST SUITE")
    print("=" * 80)

    try:
        # Test individual components
        test_base_scraper()
        test_google_scraper()
        test_reddit_scraper()
        test_news_scraper()

        # Test orchestrator
        test_orchestrator()

        print("\n" + "=" * 80)
        print("ALL TESTS COMPLETED SUCCESSFULLY")
        print("=" * 80)

    except Exception as e:
        print(f"\n✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
