"""
News article scraper for extracting full content from URLs
"""
import time
from typing import List, Dict, Optional
from datetime import datetime

from newspaper import Article
import requests
from bs4 import BeautifulSoup

from .base_scraper import BaseScraper


class NewsScraper(BaseScraper):
    """Scraper for extracting and parsing news articles"""

    def __init__(self, rate_limit_delay=2.0):
        """
        Initialize news scraper

        Args:
            rate_limit_delay: Seconds between requests
        """
        super().__init__(rate_limit_delay)

    def extract_article(self, url: str) -> Optional[Dict]:
        """
        Extract article content from a URL using newspaper3k

        Args:
            url: Article URL

        Returns:
            Dictionary with article data or None if failed
        """
        try:
            self.rate_limit()
            self.logger.info(f"Extracting article: {url}")

            article = Article(url)
            article.download()
            article.parse()

            # Try to extract publish date
            try:
                article.nlp()
            except:
                pass  # NLP is optional

            result = {
                'url': url,
                'title': article.title,
                'authors': article.authors,
                'publish_date': article.publish_date.isoformat() if article.publish_date else None,
                'text': article.text,
                'summary': article.summary if hasattr(article, 'summary') else '',
                'keywords': article.keywords if hasattr(article, 'keywords') else [],
                'top_image': article.top_image,
                'content_hash': self.compute_content_hash(article.text),
                'source': 'news_article',
                'extracted_at': datetime.utcnow().isoformat()
            }

            # Check if MVP-related
            if not self.is_mvp_related(article.text):
                self.logger.info(f"Article not MVP-related: {url}")
                return None

            return result

        except Exception as e:
            self.logger.error(f"Error extracting article {url}: {e}")
            return None

    def extract_articles_batch(self, urls: List[str]) -> List[Dict]:
        """
        Extract multiple articles

        Args:
            urls: List of article URLs

        Returns:
            List of successfully extracted articles
        """
        articles = []

        for url in urls:
            article = self.extract_article(url)

            if article:
                articles.append(article)

            # Rate limiting
            time.sleep(self.rate_limit_delay)

        self.logger.info(f"Extracted {len(articles)} articles out of {len(urls)} URLs")

        return articles

    def search(self, query: str, **kwargs) -> List[Dict]:
        """
        Search news sources (implements abstract method)

        Args:
            query: Search query
            **kwargs: Additional parameters

        Returns:
            List of news results
        """
        # This is a placeholder - actual news search would use Google News or similar
        # For now, we extract from provided URLs
        urls = kwargs.get('urls', [])
        return self.extract_articles_batch(urls)

    def scrape_espn_nfl_section(self) -> List[Dict]:
        """
        Scrape ESPN NFL section for MVP-related articles

        Returns:
            List of article URLs
        """
        results = []

        espn_urls = [
            'https://www.espn.com/nfl/',
            'https://www.espn.com/nfl/insider/',
        ]

        for base_url in espn_urls:
            try:
                html = self.fetch_url(base_url)

                if not html:
                    continue

                soup = self.parse_html(html)

                # Find article links
                links = soup.find_all('a', href=True)

                for link in links:
                    href = link.get('href', '')
                    text = link.get_text().strip()

                    # Check if link looks like an article and is MVP-related
                    if '/story/' in href or '/nfl/' in href:
                        # Make absolute URL
                        if href.startswith('/'):
                            href = f"https://www.espn.com{href}"

                        if self.is_mvp_related(text) and href not in [r['url'] for r in results]:
                            results.append({
                                'url': href,
                                'title': text,
                                'source': 'espn',
                                'discovered_at': datetime.utcnow().isoformat()
                            })

            except Exception as e:
                self.logger.error(f"Error scraping ESPN: {e}")

        return results

    def scrape_nfl_news_sites(self) -> List[Dict]:
        """
        Scrape major NFL news sites for MVP-related content

        Returns:
            List of discovered URLs
        """
        results = []

        # Major NFL news sites
        sites = [
            {
                'name': 'nfl.com',
                'url': 'https://www.nfl.com/news/',
                'selectors': ['a.d3-o-media-object__link']
            },
            {
                'name': 'profootballtalk',
                'url': 'https://profootballtalk.nbcsports.com/',
                'selectors': ['h3.headline a', 'article a']
            },
            {
                'name': 'the_athletic',
                'url': 'https://theathletic.com/nfl/',
                'selectors': ['a[href*="/article/"]']
            },
        ]

        for site in sites:
            try:
                self.logger.info(f"Scraping {site['name']}...")

                html = self.fetch_url(site['url'])

                if not html:
                    continue

                soup = self.parse_html(html)

                # Try each selector
                for selector in site['selectors']:
                    links = soup.select(selector)

                    for link in links:
                        href = link.get('href', '')
                        text = link.get_text().strip()

                        if not href:
                            continue

                        # Make absolute URL
                        if href.startswith('/'):
                            href = f"https://{site['name']}{href}"
                        elif not href.startswith('http'):
                            continue

                        # Check if MVP-related
                        if self.is_mvp_related(text):
                            results.append({
                                'url': href,
                                'title': text,
                                'source': site['name'],
                                'discovered_at': datetime.utcnow().isoformat()
                            })

            except Exception as e:
                self.logger.error(f"Error scraping {site['name']}: {e}")

        # Deduplicate by URL
        seen = set()
        unique_results = []

        for result in results:
            if result['url'] not in seen:
                seen.add(result['url'])
                unique_results.append(result)

        self.logger.info(f"Found {len(unique_results)} unique articles from news sites")

        return unique_results

    def extract_voter_mentions(self, article: Dict) -> List[str]:
        """
        Extract potential voter names from article text

        Args:
            article: Article dictionary with 'text' field

        Returns:
            List of potential voter names
        """
        # Common NFL media personalities who might be voters
        known_voters = [
            'Tom Brady', 'Mina Kimes', 'Tony Dungy', 'Tedy Bruschi',
            'Peter King', 'Adam Schefter', 'Ian Rapoport', 'Jay Glazer',
            'Mike Florio', 'Albert Breer', 'Mike Garafolo', 'Dianna Russini',
            'Chris Mortensen', 'Jeff Darlington', 'Dan Graziano', 'Jeremy Fowler',
            'Mike Silver', 'Jason La Canfora', 'Josina Anderson', 'Diana Russini',
        ]

        text = article.get('text', '')
        found_voters = []

        for voter in known_voters:
            if voter.lower() in text.lower():
                found_voters.append(voter)

        return found_voters
