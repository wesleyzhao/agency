#!/usr/bin/env python3
"""
Comprehensive API Endpoint Test Suite - Feature #19
Tests all programmatic query endpoints for the NFL MVP Voter Tracker API
"""

import requests
import json
import sys
from datetime import datetime

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

BASE_URL = "http://localhost:5000/api"
TEST_SEASON = "2024-25"

def print_success(msg):
    print(f"{GREEN}✓{RESET} {msg}")

def print_error(msg):
    print(f"{RED}✗{RESET} {msg}")

def print_info(msg):
    print(f"{CYAN}ℹ{RESET} {msg}")

def print_warning(msg):
    print(f"{YELLOW}⚠{RESET} {msg}")

def print_section(title):
    print(f"\n{'='*60}")
    print(f"{CYAN}{title}{RESET}")
    print('='*60)


def test_health_check():
    """Test 1: Health Check Endpoint"""
    print_section("Test 1: Health Check Endpoint")

    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)

        if response.status_code == 200:
            data = response.json()
            print_success(f"Health check passed: {data.get('status', 'ok')}")
            return True
        else:
            print_error(f"Health check failed with status {response.status_code}")
            return False

    except requests.exceptions.ConnectionError:
        print_error("Cannot connect to backend server")
        print_info("Please start the backend server: cd backend && python3 app.py")
        return False

    except Exception as e:
        print_error(f"Health check error: {str(e)}")
        return False


def test_voters_endpoints():
    """Test 2: Voters API Endpoints"""
    print_section("Test 2: Voters API Endpoints (GET)")

    try:
        # GET /api/voters
        response = requests.get(f"{BASE_URL}/voters")

        if response.status_code == 200:
            voters = response.json()
            print_success(f"GET /api/voters: Retrieved {len(voters)} voters")

            # Test individual voter details if voters exist
            if len(voters) > 0:
                voter_id = voters[0]['id']
                response = requests.get(f"{BASE_URL}/voters/{voter_id}?season={TEST_SEASON}")

                if response.status_code == 200:
                    voter_details = response.json()
                    print_success(f"GET /api/voters/{voter_id}: Retrieved details for {voter_details['name']}")
                    print_info(f"  - Outlet: {voter_details.get('outlet', 'N/A')}")
                    print_info(f"  - Vote count: {voter_details['statistics']['total_votes']}")
                    return True
                else:
                    print_error(f"Failed to get voter details: {response.status_code}")
                    return False
            else:
                print_warning("No voters in database yet")
                return True
        else:
            print_error(f"Failed to get voters: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Voters endpoint error: {str(e)}")
        return False


def test_candidates_endpoints():
    """Test 3: Candidates API Endpoints"""
    print_section("Test 3: Candidates API Endpoints (GET)")

    try:
        response = requests.get(f"{BASE_URL}/candidates?season={TEST_SEASON}")

        if response.status_code == 200:
            candidates = response.json()
            print_success(f"GET /api/candidates: Retrieved {len(candidates)} candidates")

            if len(candidates) > 0:
                for i, candidate in enumerate(candidates[:3], 1):
                    print_info(f"  {i}. {candidate['name']} ({candidate['team']}) - {candidate.get('vote_count', 0)} votes")
            else:
                print_warning("No candidates in database yet")

            return True
        else:
            print_error(f"Failed to get candidates: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Candidates endpoint error: {str(e)}")
        return False


def test_votes_endpoints():
    """Test 4: Votes API Endpoints"""
    print_section("Test 4: Votes API Endpoints (GET)")

    try:
        response = requests.get(f"{BASE_URL}/votes?season={TEST_SEASON}")

        if response.status_code == 200:
            votes = response.json()
            print_success(f"GET /api/votes: Retrieved {len(votes)} votes")

            if len(votes) > 0:
                for i, vote in enumerate(votes[:3], 1):
                    print_info(f"  {i}. {vote['voter']} → {vote['candidate']} (Rank #{vote['ranking']})")
            else:
                print_warning("No votes in database yet")

            return True
        else:
            print_error(f"Failed to get votes: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Votes endpoint error: {str(e)}")
        return False


def test_dashboard_endpoint():
    """Test 5: Dashboard API Endpoint"""
    print_section("Test 5: Dashboard API Endpoint")

    try:
        response = requests.get(f"{BASE_URL}/dashboard?season={TEST_SEASON}")

        if response.status_code == 200:
            dashboard = response.json()

            # Validate structure
            required_keys = ['stats', 'voters', 'candidate_stats', 'recent_activity', 'season']
            missing_keys = [key for key in required_keys if key not in dashboard]

            if missing_keys:
                print_error(f"Dashboard missing keys: {', '.join(missing_keys)}")
                return False

            print_success("GET /api/dashboard: Retrieved dashboard data")
            print_info(f"  - Total voters: {dashboard['stats']['total_voters']}")
            print_info(f"  - Known voters: {dashboard['stats']['known_voters']}")
            print_info(f"  - Disclosed votes: {dashboard['stats']['voters_with_disclosed_votes']}")
            print_info(f"  - Completion: {dashboard['stats']['completion_percentage']}%")

            return True
        else:
            print_error(f"Failed to get dashboard: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Dashboard endpoint error: {str(e)}")
        return False


def test_statistics_endpoint():
    """Test 6: Statistics API Endpoint"""
    print_section("Test 6: Statistics API Endpoint")

    try:
        response = requests.get(f"{BASE_URL}/statistics?season={TEST_SEASON}")

        if response.status_code == 200:
            stats = response.json()

            # Validate structure
            required_keys = ['overview', 'candidate_breakdown', 'top_candidates',
                           'source_distribution', 'confidence_distribution',
                           'disclosure_breakdown', 'timeline', 'recent_activity']
            missing_keys = [key for key in required_keys if key not in stats]

            if missing_keys:
                print_error(f"Statistics missing keys: {', '.join(missing_keys)}")
                return False

            print_success("GET /api/statistics: Retrieved comprehensive statistics")
            print_info(f"  - Total votes: {stats['overview']['total_votes_disclosed']}")
            print_info(f"  - Verified votes: {stats['overview']['verified_votes']}")
            print_info(f"  - Top candidates: {len(stats['top_candidates'])}")

            # Show top 3 candidates
            for i, candidate in enumerate(stats['top_candidates'][:3], 1):
                print_info(f"    {i}. {candidate['name']} - {candidate['first_place_votes']} 1st place votes, {candidate['weighted_points']} points")

            return True
        else:
            print_error(f"Failed to get statistics: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Statistics endpoint error: {str(e)}")
        return False


def test_search_endpoint():
    """Test 7: Search & Filter API Endpoint"""
    print_section("Test 7: Search & Filter API Endpoint")

    try:
        # Test general search
        response = requests.get(f"{BASE_URL}/search?season={TEST_SEASON}")

        if response.status_code == 200:
            results = response.json()

            # Validate structure
            if 'results' not in results or 'count' not in results:
                print_error("Search response missing required keys")
                return False

            print_success(f"GET /api/search: Retrieved {results['count']} results")

            # Test with filters
            response = requests.get(f"{BASE_URL}/search?confidence=high&season={TEST_SEASON}")
            if response.status_code == 200:
                filtered = response.json()
                print_success(f"Search with filters: {filtered['count']} high-confidence results")
                return True
            else:
                print_error("Failed to search with filters")
                return False
        else:
            print_error(f"Failed to search: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Search endpoint error: {str(e)}")
        return False


def test_export_endpoints():
    """Test 8: Export API Endpoints"""
    print_section("Test 8: Export API Endpoints")

    try:
        endpoints = [
            ('voters', 'csv'),
            ('voters', 'json'),
            ('votes', 'csv'),
            ('candidates', 'json'),
            ('full-report', 'json')
        ]

        all_passed = True

        for endpoint, format_type in endpoints:
            if endpoint == 'full-report':
                url = f"{BASE_URL}/export/{endpoint}?season={TEST_SEASON}"
            else:
                url = f"{BASE_URL}/export/{endpoint}?format={format_type}&season={TEST_SEASON}"

            response = requests.get(url)

            if response.status_code == 200:
                # Check Content-Disposition header for download
                content_disp = response.headers.get('Content-Disposition', '')

                if 'attachment' in content_disp:
                    print_success(f"GET /api/export/{endpoint} ({format_type}): Download ready")
                else:
                    print_warning(f"Export {endpoint} missing download header")
                    all_passed = False
            else:
                print_error(f"Failed to export {endpoint} as {format_type}: {response.status_code}")
                all_passed = False

        return all_passed

    except Exception as e:
        print_error(f"Export endpoints error: {str(e)}")
        return False


def test_historical_endpoints():
    """Test 9: Historical Data API Endpoints"""
    print_section("Test 9: Historical Data API Endpoints")

    try:
        # Test get seasons
        response = requests.get(f"{BASE_URL}/historical/seasons")

        if response.status_code == 200:
            seasons_data = response.json()
            print_success(f"GET /api/historical/seasons: Retrieved seasons list")

            if 'historical_data' in seasons_data:
                print_info(f"  - Available seasons: {len(seasons_data.get('all_seasons', []))}")

            # Test historical endpoint with current season
            response = requests.get(f"{BASE_URL}/historical?season={TEST_SEASON}")
            if response.status_code == 200:
                historical = response.json()
                print_success(f"GET /api/historical: Retrieved historical data")
                return True
            else:
                print_warning("Historical data endpoint returned non-200")
                return True  # Not critical if no historical data yet
        else:
            print_error(f"Failed to get historical seasons: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Historical endpoints error: {str(e)}")
        return False


def test_credibility_endpoints():
    """Test 10: Credibility API Endpoints"""
    print_section("Test 10: Credibility API Endpoints")

    try:
        # Test get domains
        response = requests.get(f"{BASE_URL}/credibility/domains")

        if response.status_code == 200:
            domains = response.json()
            print_success("GET /api/credibility/domains: Retrieved trusted domains")

            # Test get badges
            response = requests.get(f"{BASE_URL}/credibility/badges")
            if response.status_code == 200:
                badges = response.json()
                print_success("GET /api/credibility/badges: Retrieved credibility badges")
                return True
            else:
                print_error("Failed to get credibility badges")
                return False
        else:
            print_error(f"Failed to get domains: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Credibility endpoints error: {str(e)}")
        return False


def test_notifications_endpoints():
    """Test 11: Notifications API Endpoints"""
    print_section("Test 11: Notifications API Endpoints")

    try:
        # Test get preferences
        response = requests.get(f"{BASE_URL}/notifications/preferences")

        if response.status_code == 200:
            preferences = response.json()
            print_success(f"GET /api/notifications/preferences: Retrieved {len(preferences)} preferences")

            # Test get history
            response = requests.get(f"{BASE_URL}/notifications/history?limit=10")
            if response.status_code == 200:
                history = response.json()
                print_success(f"GET /api/notifications/history: Retrieved {len(history)} notifications")
                return True
            else:
                print_error("Failed to get notification history")
                return False
        else:
            print_error(f"Failed to get notification preferences: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Notifications endpoints error: {str(e)}")
        return False


def run_all_tests():
    """Run all API endpoint tests"""
    print_section("NFL MVP Voter Tracker - API Endpoint Test Suite")
    print_info(f"Testing against: {BASE_URL}")
    print_info(f"Test season: {TEST_SEASON}")
    print_info(f"Timestamp: {datetime.now().isoformat()}")

    tests = [
        ("Health Check", test_health_check),
        ("Voters Endpoints", test_voters_endpoints),
        ("Candidates Endpoints", test_candidates_endpoints),
        ("Votes Endpoints", test_votes_endpoints),
        ("Dashboard Endpoint", test_dashboard_endpoint),
        ("Statistics Endpoint", test_statistics_endpoint),
        ("Search Endpoint", test_search_endpoint),
        ("Export Endpoints", test_export_endpoints),
        ("Historical Endpoints", test_historical_endpoints),
        ("Credibility Endpoints", test_credibility_endpoints),
        ("Notifications Endpoints", test_notifications_endpoints),
    ]

    results = []

    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print_error(f"Test '{test_name}' crashed: {str(e)}")
            results.append((test_name, False))

    # Print summary
    print_section("Test Summary")

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print(f"\n{'='*60}")
    if passed == total:
        print(f"{GREEN}✓ ALL TESTS PASSED ({passed}/{total}){RESET}")
        print(f"{GREEN}Feature #19: API endpoints to query voter data programmatically - COMPLETE ✓{RESET}")
    else:
        print(f"{YELLOW}⚠ {passed}/{total} tests passed{RESET}")
        print(f"{RED}✗ {total - passed} tests failed{RESET}")

    print('='*60)

    return passed == total


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
