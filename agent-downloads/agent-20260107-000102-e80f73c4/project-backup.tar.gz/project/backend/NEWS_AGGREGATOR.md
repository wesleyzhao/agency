# News Aggregator Integration - Feature #24

## Overview

The News Aggregator provides comprehensive integration with multiple news APIs and RSS feeds to automatically discover recent NFL MVP-related articles from major sports news sources.

**Key Capabilities:**
- Aggregates news from 8+ major NFL news sources via RSS feeds
- Optional NewsAPI.org integration for broader coverage
- Google News scraping for current articles
- Automatic MVP relevance detection
- Smart deduplication across sources
- Recent article filtering (configurable time window)
- Rate limiting to avoid being blocked

## Features

### Multi-Source Aggregation

1. **RSS Feeds** (8 sources):
   - ESPN NFL
   - NFL.com
   - ProFootballTalk (NBC Sports)
   - Sports Illustrated
   - Bleacher Report
   - Yahoo Sports
   - CBS Sports
   - The Athletic

2. **NewsAPI** (optional, requires API key):
   - Access to 70,000+ news sources worldwide
   - Advanced search capabilities
   - Published date filtering
   - Language filtering

3. **Google News** (web scraping):
   - Real-time news search
   - Article discovery from Google News index
   - Automatic URL extraction

### Intelligent Filtering

- **MVP Relevance Detection**: Uses keyword matching to filter for MVP-related content
- **Recent Article Filtering**: Configurable time window (default: 7 days)
- **Deduplication**: Removes duplicate articles across sources
- **Candidate Tracking**: Monitors mentions of 15+ MVP candidates

## Installation

### Required Dependencies

```bash
pip install feedparser requests beautifulsoup4
```

### Optional Dependencies

For NewsAPI integration:
```bash
pip install requests
# Get API key from: https://newsapi.org/
export NEWSAPI_KEY=your_api_key_here
```

## Usage

### Basic Usage

```python
from backend.scrapers import NewsAggregator

# Initialize aggregator
aggregator = NewsAggregator()

# Fetch articles from all RSS feeds
articles = aggregator.fetch_all_rss_feeds()

print(f"Found {len(articles)} MVP-related articles")
for article in articles[:5]:
    print(f"- {article['title']}")
    print(f"  Source: {article['source']}")
    print(f"  URL: {article['url']}")
```

### Full Aggregation (All Sources)

```python
from backend.scrapers import NewsAggregator

# Initialize with NewsAPI key (optional)
aggregator = NewsAggregator(newsapi_key='your_key_here')

# Aggregate from all sources
result = aggregator.aggregate_all_sources(
    days_back=7,
    include_newsapi=True,
    include_google_news=True
)

# Access articles
articles = result['articles']
metadata = result['metadata']

print(f"Total articles: {metadata['total_articles']}")
print(f"Sources used: {', '.join(metadata['sources_used'])}")
print(f"Duplicates removed: {metadata['duplicates_removed']}")

# Articles are sorted by published date (most recent first)
for article in articles[:10]:
    print(f"\n{article['title']}")
    print(f"  Source: {article['source']}")
    print(f"  Published: {article.get('published_date', 'N/A')}")
    print(f"  URL: {article['url']}")
```

### Individual Source Fetching

```python
aggregator = NewsAggregator()

# Fetch specific RSS feed
espn_articles = aggregator.fetch_rss_feed(
    'https://www.espn.com/espn/rss/nfl/news',
    'espn_nfl'
)

# Search NewsAPI
newsapi_articles = aggregator.search_newsapi(
    query='NFL MVP 2024',
    days_back=7
)

# Search Google News
google_articles = aggregator.search_google_news(
    query='NFL MVP 2024'
)
```

### Custom Filtering

```python
aggregator = NewsAggregator()

# Get all articles
all_articles = aggregator.fetch_all_rss_feeds()

# Filter to last 3 days only
recent_articles = aggregator.filter_recent_articles(
    all_articles,
    days=3
)

print(f"Articles from last 3 days: {len(recent_articles)}")
```

## Article Data Structure

Each article returned has the following structure:

```python
{
    'url': 'https://example.com/article',
    'title': 'Article headline',
    'summary': 'Article description or excerpt',
    'published': 'Mon, 06 Jan 2025 10:30:00 GMT',  # RSS format
    'published_date': '2025-01-06T10:30:00',        # ISO format
    'author': 'Author Name',
    'source': 'espn_nfl',                           # Source identifier
    'source_type': 'rss_feed',                      # rss_feed, newsapi, google_news
    'discovered_at': '2025-01-07T12:00:00.000000',  # When we found it
    'content': 'Full article text (NewsAPI only)',
}
```

## Aggregation Result Structure

```python
{
    'articles': [
        # List of article dictionaries (sorted by date)
    ],
    'metadata': {
        'total_articles': 42,
        'sources_used': ['rss_feeds', 'newsapi', 'google_news'],
        'days_searched': 7,
        'searched_at': '2025-01-07T12:00:00.000000',
        'duplicates_removed': 8
    }
}
```

## Configuration

### RSS Feeds

Add or remove RSS feeds in the `NewsAggregator.__init__()`:

```python
self.rss_feeds = {
    'custom_source': 'https://example.com/rss',
    # Add more feeds...
}
```

### MVP Keywords

Customize MVP detection keywords:

```python
self.mvp_keywords = [
    'mvp', 'most valuable player', 'mvp race',
    # Add more keywords...
]
```

### Candidate Names

Update candidate list for current season:

```python
self.candidate_names = [
    'Josh Allen', 'Lamar Jackson',
    # Add more candidates...
]
```

### Rate Limiting

Adjust rate limiting delay:

```python
aggregator = NewsAggregator(rate_limit_delay=3.0)  # 3 seconds between requests
```

## NewsAPI Integration

### Getting an API Key

1. Sign up at https://newsapi.org/
2. Free tier: 100 requests/day, articles from last 30 days
3. Paid tiers: More requests, more historical data

### Usage

```python
import os

# Set API key via environment variable
os.environ['NEWSAPI_KEY'] = 'your_key_here'

# Or pass directly
aggregator = NewsAggregator(newsapi_key='your_key_here')

# Search
articles = aggregator.search_newsapi('NFL MVP', days_back=7)
```

### NewsAPI Parameters

```python
articles = aggregator.search_newsapi(
    query='NFL MVP',        # Search query
    days_back=7             # How many days back to search
)
```

## Error Handling

The aggregator gracefully handles errors:

```python
aggregator = NewsAggregator()

# RSS feed errors are logged but don't crash
articles = aggregator.fetch_all_rss_feeds()
# Returns available articles even if some feeds fail

# NewsAPI errors
if not aggregator.newsapi_key:
    # Skips NewsAPI automatically if no key provided
    pass

# Network errors are caught and logged
result = aggregator.aggregate_all_sources()
# Returns what's available even if some sources fail
```

## Performance

### Timing

- Single RSS feed: ~1-2 seconds
- All RSS feeds: ~20-30 seconds (with rate limiting)
- NewsAPI search: ~1-2 seconds
- Google News search: ~2-3 seconds
- Full aggregation: ~30-60 seconds

### Rate Limiting

Default delays:
- RSS feeds: 1 second between requests
- NewsAPI: 1 second (API limits apply)
- Google News: 2 seconds (to avoid blocking)

Customize:
```python
aggregator = NewsAggregator(rate_limit_delay=2.0)
```

## Integration with Other Features

### With ScraperOrchestrator

```python
from backend.scrapers import ScraperOrchestrator, NewsAggregator

orchestrator = ScraperOrchestrator()
aggregator = NewsAggregator()

# Get recent articles
articles = aggregator.aggregate_all_sources(days_back=7)

# Process with orchestrator (NLP extraction, database storage)
for article in articles['articles']:
    # Extract article content using NewsScraper
    # Run NLP extraction on content
    # Store in database with source tracking
    pass
```

### With Database Storage

```python
from backend.scrapers import NewsAggregator
from backend.database import get_session, SourceDB

aggregator = NewsAggregator()
session = get_session()
source_db = SourceDB(session)

# Fetch articles
result = aggregator.aggregate_all_sources()

# Store in database
for article in result['articles']:
    # Check if URL already exists
    if source_db.is_duplicate_url(article['url']):
        continue

    # Add to database
    source_db.add_source(
        url=article['url'],
        title=article['title'],
        content=article.get('summary', ''),
        source_type=article['source_type']
    )

session.commit()
```

### With NLP Extraction

```python
from backend.scrapers import NewsAggregator, NewsScraper
from backend.nlp import VoteExtractor

aggregator = NewsAggregator()
news_scraper = NewsScraper()
vote_extractor = VoteExtractor()

# Get recent articles
articles = aggregator.fetch_all_rss_feeds()

# Extract full content and votes
for article in articles:
    # Get full article text
    full_article = news_scraper.extract_article(article['url'])

    if full_article:
        # Extract votes from article text
        votes = vote_extractor.extract_votes_from_text(
            text=full_article['text'],
            source_url=article['url'],
            source_type='news_article'
        )

        # Store votes in database
        for vote in votes:
            print(f"Found vote: {vote['voter_name']} → {vote['candidate_name']}")
```

## Best Practices

### 1. Regular Scheduled Runs

```python
import schedule
import time

def fetch_news():
    aggregator = NewsAggregator()
    result = aggregator.aggregate_all_sources(days_back=1)
    # Process new articles...
    print(f"Found {result['metadata']['total_articles']} new articles")

# Run every 6 hours
schedule.every(6).hours.do(fetch_news)

while True:
    schedule.run_pending()
    time.sleep(60)
```

### 2. Incremental Updates

```python
# Only fetch articles newer than last run
from datetime import datetime, timedelta

last_run = datetime.utcnow() - timedelta(hours=6)
aggregator = NewsAggregator()

# Fetch recent articles
result = aggregator.aggregate_all_sources(days_back=1)

# Filter to truly new articles
new_articles = [
    a for a in result['articles']
    if parse_date(a.get('published_date', '')) > last_run
]
```

### 3. Error Monitoring

```python
import logging

logging.basicConfig(level=logging.INFO)
aggregator = NewsAggregator()

result = aggregator.aggregate_all_sources()

# Check for issues
if result['metadata']['total_articles'] == 0:
    logging.warning("No articles found - possible RSS feed issues")

if len(result['metadata']['sources_used']) < 2:
    logging.warning("Only 1 source returned data - check connectivity")
```

## Troubleshooting

### No Articles Found

**Problem**: `aggregate_all_sources()` returns 0 articles

**Solutions**:
1. Check internet connectivity
2. Verify RSS feed URLs are still valid
3. Check if MVP keywords need updating
4. Temporarily disable MVP filtering to see raw results
5. Check rate limiting isn't too aggressive

### RSS Feed Parse Errors

**Problem**: "RSS feed parse error" in logs

**Solutions**:
1. Some feeds may return HTML instead of XML (normal)
2. Update feed URL if source changed format
3. Remove problematic feeds from `self.rss_feeds`
4. Most errors are non-critical and logged as warnings

### Google News Returns No Results

**Problem**: Google News scraping returns empty list

**Solutions**:
1. Google News HTML structure may have changed
2. Update CSS selectors in `search_google_news()`
3. Check if Google is blocking requests (use rate limiting)
4. Try different search queries

### NewsAPI Errors

**Problem**: NewsAPI requests fail

**Solutions**:
1. Verify API key is correct: `echo $NEWSAPI_KEY`
2. Check request quota (free tier: 100/day)
3. Verify query parameters are valid
4. Check internet connectivity

## Testing

Run the comprehensive test suite:

```bash
cd backend
python3 test_news_aggregator.py
```

**Test Coverage:**
- ✓ Initialization
- ✓ RSS Feed Fetching
- ✓ All RSS Feeds
- ✓ Google News Search
- ✓ NewsAPI Integration
- ✓ Article Filtering
- ✓ Full Aggregation
- ✓ MVP Relevance Detection

## Future Enhancements

### Planned

1. **Article Content Extraction**: Automatically extract full article text
2. **Sentiment Analysis**: Analyze article sentiment toward candidates
3. **Voter Mention Detection**: Identify AP voters mentioned in articles
4. **Social Media Integration**: Twitter/X API for real-time updates
5. **Email Digests**: Daily summary emails of new MVP news
6. **Webhook Notifications**: Real-time alerts for important articles

### Possible Additions

- More RSS feeds (regional sports sites, team blogs)
- Reddit post monitoring
- YouTube video tracking
- Podcast transcription monitoring
- Advanced NLP for context extraction

## Related Features

- **Feature #1**: Web scraping module (NewsScraper for full article extraction)
- **Feature #6**: Automated crawler (can schedule news aggregation)
- **Feature #7**: URL deduplication (prevents processing same article twice)
- **Feature #8**: NLP extraction (extracts votes from articles)
- **Feature #18**: Notification system (alerts on new high-value articles)
- **Feature #20**: Rate limiting (prevents being blocked by news sites)

## API Reference

### NewsAggregator Class

```python
class NewsAggregator(BaseScraper):
    def __init__(self, newsapi_key=None, rate_limit_delay=2.0)

    def fetch_rss_feed(self, feed_url: str, source_name: str) -> List[Dict]
    def fetch_all_rss_feeds(self) -> List[Dict]

    def search_newsapi(self, query: str = 'NFL MVP', days_back: int = 7) -> List[Dict]
    def search_google_news(self, query: str = 'NFL MVP 2024') -> List[Dict]

    def filter_recent_articles(self, articles: List[Dict], days: int = 7) -> List[Dict]

    def aggregate_all_sources(self, days_back: int = 7,
                             include_newsapi: bool = True,
                             include_google_news: bool = True) -> Dict

    def search(self, query: str = 'NFL MVP', **kwargs) -> List[Dict]
```

### Method Details

#### `fetch_rss_feed(feed_url, source_name)`
Fetches and parses a single RSS feed.

**Returns**: List of MVP-related article dictionaries

#### `fetch_all_rss_feeds()`
Fetches all configured RSS feeds and deduplicates.

**Returns**: List of unique articles from all feeds

#### `search_newsapi(query, days_back)`
Searches NewsAPI.org for articles (requires API key).

**Returns**: List of articles from NewsAPI

#### `search_google_news(query)`
Scrapes Google News for articles.

**Returns**: List of articles from Google News

#### `filter_recent_articles(articles, days)`
Filters articles to only include recent ones.

**Returns**: Filtered list of articles

#### `aggregate_all_sources(days_back, include_newsapi, include_google_news)`
Aggregates articles from all available sources.

**Returns**: Dictionary with articles and metadata

---

## Summary

Feature #24 provides a production-ready news aggregation system that:

✓ Aggregates from 8+ major NFL news sources
✓ Optional NewsAPI integration for broader coverage
✓ Intelligent MVP relevance filtering
✓ Smart deduplication across sources
✓ Configurable time windows
✓ Rate limiting to avoid blocks
✓ Comprehensive error handling
✓ Fully tested and documented

**Next Steps:**
- Integrate with automated scheduler (Feature #6)
- Connect to NLP extraction pipeline (Feature #8)
- Add to notification system (Feature #18)
- Include in admin interface for review (Feature #21)
