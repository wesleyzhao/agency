"""
Test NLP extraction with real scraped data
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from nlp import VoteExtractor
from scrapers import GoogleScraper


def test_nlp_with_google_search():
    """Test NLP extraction with real Google search results"""
    print("="*60)
    print("TESTING NLP WITH GOOGLE SEARCH RESULTS")
    print("="*60)

    # Initialize extractors
    nlp_extractor = VoteExtractor()
    google_scraper = GoogleScraper(rate_limit_delay=2.0)

    # Search for MVP voter announcements
    print("\n1. Searching for 'Mina Kimes MVP vote 2024'...")
    results = google_scraper.search("Mina Kimes MVP vote 2024", num_results=5)

    print(f"   Found {len(results)} results from Google")

    # Process each result with NLP
    all_votes = []

    for i, result in enumerate(results[:3], 1):  # Test first 3 results
        print(f"\n2. Processing result {i}:")
        print(f"   URL: {result['url'][:80]}...")
        print(f"   Title: {result['title'][:80]}...")

        # Extract votes from the snippet
        votes = nlp_extractor.extract_votes_from_text(
            text=result.get('snippet', ''),
            source_url=result['url'],
            source_type='google'
        )

        print(f"   Votes extracted: {len(votes)}")

        for vote in votes:
            print(f"     - {vote['voter_name']} -> {vote['candidate_name']} (rank {vote['ranking']})")
            print(f"       Confidence: {vote['overall_confidence']}")
            all_votes.append(vote)

    print(f"\n3. Total votes extracted from all sources: {len(all_votes)}")

    # Summary
    if all_votes:
        print("\n4. Summary of extracted votes:")
        voters = set(v['voter_name'] for v in all_votes)
        candidates = set(v['candidate_name'] for v in all_votes)

        print(f"   Unique voters: {len(voters)}")
        for voter in voters:
            print(f"     - {voter}")

        print(f"\n   Unique candidates: {len(candidates)}")
        for candidate in candidates:
            print(f"     - {candidate}")

    return len(all_votes)


def test_sample_texts():
    """Test NLP with various sample texts"""
    print("\n" + "="*60)
    print("TESTING NLP WITH SAMPLE TEXTS")
    print("="*60)

    extractor = VoteExtractor()

    test_cases = [
        {
            'name': 'Twitter-style announcement',
            'text': """
            Just submitted my MVP ballot. Here's how I voted:
            1. Josh Allen - Most complete QB season
            2. Saquon Barkley - Historic RB performance
            3. Lamar Jackson - Dual-threat excellence
            """,
            'url': 'https://twitter.com/voter/status/123'
        },
        {
            'name': 'News article excerpt',
            'text': """
            ESPN's Mina Kimes revealed her MVP pick on Monday, choosing Buffalo Bills
            quarterback Josh Allen as her first-place vote. "Allen has been the most
            valuable player to his team," Kimes said. "Without him, the Bills don't
            make the playoffs."
            """,
            'url': 'https://espn.com/nfl/story/mvp'
        },
        {
            'name': 'Reddit comment',
            'text': """
            My top 5 for MVP this year:
            #1 Josh Allen
            #2 Lamar Jackson
            #3 Saquon Barkley
            #4 Jared Goff
            #5 Joe Burrow

            Allen has just been on another level. The way he's carried that team is remarkable.
            """,
            'url': 'https://reddit.com/r/nfl/comments/abc123'
        },
    ]

    total_votes = 0

    for i, test_case in enumerate(test_cases, 1):
        print(f"\nTest Case {i}: {test_case['name']}")
        print("-" * 60)

        votes = extractor.extract_votes_from_text(
            test_case['text'],
            test_case['url'],
            source_type='test'
        )

        print(f"Votes extracted: {len(votes)}")

        for vote in votes:
            print(f"  {vote['voter_name']} -> Rank {vote['ranking']}: {vote['candidate_name']}")
            print(f"    Team: {vote['candidate_team']}")
            print(f"    Overall confidence: {vote['overall_confidence']}")

        total_votes += len(votes)

    print(f"\nTotal votes from all test cases: {total_votes}")

    return total_votes


def main():
    """Run all integration tests"""
    print("\n" + "="*70)
    print("NLP EXTRACTION - REAL-WORLD INTEGRATION TESTS")
    print("="*70)

    # Test with sample texts (fast, no network)
    sample_votes = test_sample_texts()

    # Test with Google search (slow, requires network)
    print("\n" + "="*60)
    print("OPTIONAL: Test with live Google search?")
    print("This will make real HTTP requests and may take 30+ seconds.")
    print("="*60)

    # For automated testing, we'll skip the live search
    # Uncomment below to test with real Google search:
    # google_votes = test_nlp_with_google_search()

    print("\n" + "="*60)
    print("INTEGRATION TEST SUMMARY")
    print("="*60)
    print(f"✓ Sample text tests: {sample_votes} votes extracted")
    # print(f"✓ Google search tests: {google_votes} votes extracted")
    print("\n✓ All integration tests completed successfully!")

    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
