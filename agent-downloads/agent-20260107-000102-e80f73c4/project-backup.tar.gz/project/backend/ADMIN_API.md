# Admin Interface API Documentation - Feature #21

Complete API documentation for the admin interface that allows administrators to verify, edit, and manage automatically extracted voter and vote information.

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Endpoints](#endpoints)
4. [Data Models](#data-models)
5. [Usage Examples](#usage-examples)
6. [Frontend Integration](#frontend-integration)
7. [Best Practices](#best-practices)

---

## Overview

The Admin Interface provides comprehensive tools for:
- **Reviewing unverified votes** extracted by NLP from various sources
- **Verifying and approving** accurate vote information
- **Editing vote details** to correct errors in extracted data
- **Deleting false positives** that were incorrectly extracted
- **Updating voter information** to fix mistakes or add missing details
- **Tracking data quality** with statistics and breakdowns

### Key Features

- **Quality Control Dashboard**: View statistics on verification rates, confidence levels, and source types
- **Unverified Queue**: Prioritized list of votes needing admin review (sorted by confidence score)
- **Batch Filtering**: Filter unverified votes by confidence level, source type, or season
- **One-Click Verification**: Quick approve/verify workflow with credibility tier assignment
- **Detailed Editing**: Comprehensive edit forms for all vote and voter fields
- **Notification Integration**: Triggers notifications when votes are verified (Feature #18)

---

## Authentication

**Current Status**: No authentication (development only)

**Production Recommendations**:
- Add JWT-based authentication for admin endpoints
- Require admin role/permission for all `/api/admin/*` endpoints
- Implement rate limiting to prevent abuse
- Add audit logging for all admin actions

**Example Production Middleware**:
```python
from functools import wraps
from flask import request, jsonify

def require_admin(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token or not verify_admin_token(token):
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated_function

@app.route('/api/admin/stats')
@require_admin
def get_admin_stats():
    # ... admin logic
```

---

## Endpoints

### 1. Get Admin Statistics

Get comprehensive statistics about data quality and verification status.

**Endpoint**: `GET /api/admin/stats`

**Query Parameters**:
- `season` (string, optional): Filter by season (default: "2024-25")

**Response**:
```json
{
  "season": "2024-25",
  "total_votes": 150,
  "verified_votes": 120,
  "unverified_votes": 30,
  "verification_rate": 80.0,
  "confidence_breakdown": {
    "high": 50,
    "medium": 70,
    "low": 30
  },
  "source_breakdown": {
    "official": 10,
    "social_media": 60,
    "news_article": 40,
    "reddit": 20,
    "speculation": 20
  },
  "credibility_breakdown": {
    "verified": 120,
    "official": 15,
    "reliable": 10,
    "unverified": 3,
    "speculation": 2
  },
  "recent_unverified": [
    {
      "id": 42,
      "voter_name": "John Smith",
      "candidate_name": "Josh Allen",
      "ranking": 1,
      "confidence": "low",
      "confidence_score": 35.5,
      "source_type": "speculation",
      "created_at": "2025-01-07T10:30:00"
    }
  ]
}
```

**Use Cases**:
- Dashboard overview of data quality
- Monitoring verification progress
- Identifying areas needing review (high % of low-confidence or speculation)

---

### 2. Get Unverified Votes

Retrieve all unverified votes that need admin review, with filtering options.

**Endpoint**: `GET /api/admin/unverified`

**Query Parameters**:
- `season` (string, optional): Filter by season (default: "2024-25")
- `confidence` (string, optional): Filter by confidence level ("high", "medium", "low")
- `source_type` (string, optional): Filter by source type
- `limit` (int, optional): Maximum results (default: 50)

**Response**:
```json
{
  "unverified_votes": [
    {
      "id": 42,
      "voter": {
        "id": 15,
        "name": "John Smith",
        "outlet": "ESPN",
        "twitter_handle": "@johnsmith"
      },
      "candidate": {
        "id": 3,
        "name": "Josh Allen",
        "team": "Buffalo Bills",
        "position": "QB"
      },
      "ranking": 1,
      "season": "2024-25",
      "source_url": "https://twitter.com/johnsmith/status/123",
      "source_type": "social_media",
      "confidence": "medium",
      "confidence_score": 65.5,
      "credibility_tier": "unverified",
      "credibility_score": 50.0,
      "announcement_date": "2025-01-05T14:30:00",
      "extracted_text": "My MVP vote goes to Josh Allen...",
      "created_at": "2025-01-07T10:30:00"
    }
  ],
  "count": 1,
  "season": "2024-25"
}
```

**Sorting**: Results are ordered by confidence_score ascending (lowest confidence first), prioritizing votes that most need review.

**Use Cases**:
- Admin review queue
- Focus on low-confidence votes first
- Filter by source type to review specific extraction sources

---

### 3. Verify Vote

Approve/verify a vote and optionally update its credibility tier.

**Endpoint**: `POST /api/admin/votes/<vote_id>/verify`

**Request Body**:
```json
{
  "verified": true,
  "credibility_tier": "verified"
}
```

**Parameters**:
- `verified` (boolean, required): Set verification status (true/false)
- `credibility_tier` (string, optional): Update credibility tier
  - Values: "verified", "official", "reliable", "unverified", "speculation"
  - Auto-updates credibility_score based on tier

**Response**:
```json
{
  "message": "Vote verification status updated",
  "vote_id": 42,
  "verified": true,
  "credibility_tier": "verified"
}
```

**Side Effects**:
- If `verified=true`, triggers a `VERIFIED_VOTE` notification (Feature #18)
- Updates `updated_at` timestamp

**Use Cases**:
- Quick approval workflow ("Approve & Verify" button)
- Mark false positives as unverified (verified=false)
- Upgrade credibility tier after manual verification

---

### 4. Update Vote

Comprehensive update of all vote details.

**Endpoint**: `PUT /api/admin/votes/<vote_id>`

**Request Body** (all fields optional):
```json
{
  "ranking": 1,
  "candidate_id": 5,
  "source_url": "https://example.com/article",
  "source_type": "news_article",
  "confidence": "high",
  "confidence_score": 85.0,
  "credibility_tier": "official",
  "announcement_date": "2025-01-05T10:00:00",
  "extracted_text": "Updated extracted text...",
  "verified": true
}
```

**Parameters**:
- `ranking` (int): Ballot ranking (1-5)
- `candidate_id` (int): Change which candidate the vote is for
- `source_url` (string): Update source URL
- `source_type` (string): official, social_media, news_article, reddit, speculation
- `confidence` (string): high, medium, low
- `confidence_score` (float): Numeric confidence (0-100)
- `credibility_tier` (string): verified, official, reliable, unverified, speculation
- `announcement_date` (string): ISO 8601 format
- `extracted_text` (string): Original text where vote was found
- `verified` (boolean): Verification status

**Response**:
```json
{
  "message": "Vote updated successfully",
  "vote_id": 42,
  "voter": "John Smith",
  "candidate": "Josh Allen",
  "ranking": 1,
  "verified": true
}
```

**Validation**:
- `ranking` must be 1-5
- `candidate_id` must exist in database
- `confidence_score` must be 0-100
- `announcement_date` must be valid ISO 8601

**Use Cases**:
- Correct NLP extraction errors (wrong ranking, wrong candidate)
- Update source information after finding original announcement
- Adjust confidence levels based on manual review

---

### 5. Delete Vote

Delete a vote (for false positives or duplicates).

**Endpoint**: `DELETE /api/admin/votes/<vote_id>`

**Response**:
```json
{
  "message": "Vote deleted successfully",
  "vote_id": 42,
  "voter": "John Smith",
  "candidate": "Josh Allen"
}
```

**Use Cases**:
- Remove false positives from NLP extraction
- Delete duplicate votes
- Clean up test data

**⚠️ Warning**: This action is permanent and cannot be undone.

---

### 6. Update Voter

Update voter details (outlet, Twitter handle, bio, etc.).

**Endpoint**: `PUT /api/admin/voters/<voter_id>`

**Request Body** (all fields optional):
```json
{
  "name": "John Smith",
  "outlet": "ESPN",
  "twitter_handle": "@johnsmith",
  "location": "New York, NY",
  "bio": "Senior NFL writer for ESPN..."
}
```

**Parameters**:
- `name` (string): Voter full name (must be unique)
- `outlet` (string): Media outlet
- `twitter_handle` (string): Twitter/X handle (with or without @)
- `location` (string): Geographic location
- `bio` (text): Biography or description

**Response**:
```json
{
  "message": "Voter updated successfully",
  "voter_id": 15,
  "name": "John Smith",
  "outlet": "ESPN"
}
```

**Validation**:
- `name` must be unique (409 Conflict if duplicate)

**Use Cases**:
- Fix typos in voter names
- Add missing outlet information
- Update Twitter handles
- Add biographical details

---

## Data Models

### Vote Object (Detailed)

```json
{
  "id": 42,
  "voter_id": 15,
  "candidate_id": 3,
  "ranking": 1,
  "season": "2024-25",
  "source_url": "https://...",
  "source_type": "social_media",
  "confidence": "medium",
  "confidence_score": 65.5,
  "credibility_tier": "unverified",
  "credibility_score": 50.0,
  "has_direct_quote": 0,
  "has_speculation_language": 1,
  "announcement_date": "2025-01-05T14:30:00",
  "extracted_text": "My MVP vote goes to...",
  "verified": 0,
  "created_at": "2025-01-07T10:30:00",
  "updated_at": "2025-01-07T11:00:00"
}
```

### Confidence Levels

- **high**: High confidence extraction (85-100 score)
  - Known voter + verified account + explicit vote statement
- **medium**: Medium confidence (50-84 score)
  - Recognized pattern + reasonable context
- **low**: Low confidence (0-49 score)
  - Uncertain extraction + speculation indicators

### Credibility Tiers

- **verified**: Direct from verified account or official source (95 score)
- **official**: Major news outlet with quote (85 score)
- **reliable**: Reputable source or corroborated (70 score)
- **unverified**: Single unverified source (50 score)
- **speculation**: Rumor or prediction (25 score)

### Source Types

- **official**: Official league/team announcements
- **social_media**: Twitter/X posts
- **news_article**: News website articles
- **reddit**: Reddit posts/comments
- **speculation**: Predictions or rumors

---

## Usage Examples

### Example 1: Admin Dashboard Workflow

```javascript
// 1. Fetch admin stats for overview
const statsResponse = await fetch('/api/admin/stats?season=2024-25');
const stats = await statsResponse.json();

console.log(`Verification Rate: ${stats.verification_rate}%`);
console.log(`Unverified: ${stats.unverified_votes}`);

// 2. Get unverified votes (low confidence first)
const unverifiedResponse = await fetch('/api/admin/unverified?season=2024-25&confidence=low');
const { unverified_votes } = await unverifiedResponse.json();

// 3. Review and verify each vote
for (const vote of unverified_votes) {
  // Admin reviews vote.extracted_text and vote.source_url
  // If accurate, verify it:
  await fetch(`/api/admin/votes/${vote.id}/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      verified: true,
      credibility_tier: 'verified'
    })
  });
}
```

### Example 2: Correcting NLP Extraction Error

```python
import requests

# NLP extracted "Josh Allen" but it was actually "Jalen Hurts"
vote_id = 42

# Get correct candidate ID
candidates_response = requests.get('http://localhost:5000/api/candidates?season=2024-25')
candidates = candidates_response.json()['candidates']
jalen_hurts = next(c for c in candidates if c['name'] == 'Jalen Hurts')

# Update the vote
update_data = {
    'candidate_id': jalen_hurts['id'],
    'confidence': 'high',  # After manual review, we're confident
    'confidence_score': 90.0,
    'verified': True
}

response = requests.put(
    f'http://localhost:5000/api/admin/votes/{vote_id}',
    json=update_data
)

print(response.json())
# {"message": "Vote updated successfully", ...}
```

### Example 3: Filtering and Batch Processing

```bash
# Get all low-confidence speculation votes
curl "http://localhost:5000/api/admin/unverified?confidence=low&source_type=speculation"

# Review and delete false positives
for id in 45 46 47; do
  curl -X DELETE "http://localhost:5000/api/admin/votes/$id"
done

# Verify legitimate votes
for id in 48 49 50; do
  curl -X POST "http://localhost:5000/api/admin/votes/$id/verify" \
    -H "Content-Type: application/json" \
    -d '{"verified": true, "credibility_tier": "verified"}'
done
```

---

## Frontend Integration

### React Admin Component Structure

The frontend Admin component (`frontend/src/Admin.js`) provides:

1. **Admin Statistics Dashboard**
   - Total votes, verified votes, unverified votes, verification rate
   - Confidence breakdown (high/medium/low)
   - Source type distribution
   - Credibility tier breakdown

2. **Unverified Votes List**
   - Card-based layout for each unverified vote
   - Displays voter, candidate, ranking, source, confidence, credibility
   - Shows extracted text for manual review
   - Link to original source URL

3. **Filter Controls**
   - Filter by confidence level (high/medium/low)
   - Filter by source type (official/social_media/news/reddit/speculation)
   - Clear filters button

4. **Vote Actions**
   - **Approve & Verify**: One-click verification with credibility upgrade
   - **Edit**: Modal form to edit all vote details
   - **Delete**: Remove false positives (with confirmation)

5. **Edit Modal**
   - Form fields for all vote properties
   - Validation before submission
   - Save/Cancel actions

### Navigation

- Dashboard → Admin Panel: Button in header (`/admin`)
- Admin Panel → Dashboard: Back link in header and footer

---

## Best Practices

### 1. Review Priority

Focus admin review effort on:
1. **Low confidence votes** (< 50 score) - highest error rate
2. **Speculation sources** - often predictions, not actual votes
3. **Recent extractions** - catch errors early
4. **High-impact votes** (1st place picks) - most important to verify

### 2. Verification Standards

**Verify as "verified" only if**:
- Direct from voter's verified social media account
- Quoted in reputable news article
- Official announcement

**Keep as "unverified" if**:
- Single unverified source
- No direct quote
- Paraphrased or interpreted

**Delete if**:
- NLP false positive (no actual vote)
- Duplicate of existing vote
- Prediction/speculation presented as fact

### 3. Data Correction

When correcting NLP errors:
- Update `confidence_score` to reflect manual review confidence
- Set `verified=true` after manual verification
- Upgrade `credibility_tier` if source quality is confirmed
- Add missing `source_url` if found

### 4. Audit Trail

The system automatically tracks:
- `created_at`: When vote was originally extracted
- `updated_at`: Last modification timestamp
- Notification history (via Feature #18)

**Recommendation for production**:
- Add `verified_by` field (admin user ID)
- Add `verification_notes` field (reason for changes)
- Add `admin_action_log` table for full audit trail

### 5. Batch Operations

For efficiency:
- Review votes in batches (e.g., all low-confidence speculation votes)
- Use filters to focus on specific problem areas
- Process similar issues together (e.g., all "wrong candidate" errors)

### 6. Quality Metrics

Monitor these metrics:
- **Verification rate**: Target > 90% for public display
- **High confidence rate**: Indicates NLP quality
- **False positive rate**: Deleted votes / total extracted

---

## Testing

### Backend API Tests

```bash
cd backend
python3 test_admin.py
```

**Tests include**:
- Admin statistics endpoint
- Get unverified votes
- Verify vote (with notification trigger)
- Update vote (all fields)
- Delete vote
- Update voter
- Filter functionality

### Frontend Manual Tests

1. Start backend: `cd backend && python3 app.py`
2. Start frontend: `cd frontend && npm start`
3. Navigate to: http://localhost:3000/admin

**Test scenarios**:
- View admin statistics
- Filter unverified votes by confidence/source
- Verify a vote (check notification if configured)
- Edit vote details (change ranking, candidate, confidence)
- Delete a false positive vote
- Clear filters and refresh data

---

## Future Enhancements

### Planned Features

1. **Bulk Actions**
   - Select multiple votes for batch verification/deletion
   - "Verify All High Confidence" button

2. **Admin Notes**
   - Add notes to votes explaining verification decision
   - Track who verified each vote

3. **Review History**
   - View admin action history
   - Undo recent changes

4. **Advanced Filters**
   - Filter by voter name
   - Filter by candidate
   - Date range filters

5. **Machine Learning Feedback**
   - Flag corrections to improve NLP model
   - Training data export for model improvement

---

## Error Handling

### Common Errors

**400 Bad Request**
```json
{
  "error": "verified field is required"
}
```
- Missing required field
- Invalid field value (e.g., ranking > 5)
- Invalid date format

**404 Not Found**
```json
{
  "error": "Vote not found"
}
```
- Vote ID doesn't exist
- Voter ID doesn't exist
- Candidate ID doesn't exist

**409 Conflict**
```json
{
  "error": "Voter with this name already exists"
}
```
- Duplicate voter name when updating

**500 Internal Server Error**
```json
{
  "error": "Database connection error"
}
```
- Server error
- Database error
- Unexpected exception

---

## Support

For issues or questions:
- Check test output: `python3 backend/test_admin.py`
- Review backend logs: `cd backend && python3 app.py`
- Verify database state: `sqlite3 data/mvp_tracker.db`

---

**Feature Status**: ✅ COMPLETED

**Last Updated**: January 7, 2026

**Version**: 1.0.0
