# Comprehensive Logging System - Feature #25

## Overview

The NFL MVP Voter Tracker logging system provides comprehensive, structured logging for all application activities including web scraping, NLP extraction, database operations, API requests, and notifications.

## Features

- **Multiple Log Levels**: DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Module-Specific Loggers**: Separate logs for scraping, NLP, API, database, notifications
- **File Rotation**: Automatic log rotation (10MB per file, 5 backups)
- **Console Output**: Color-coded console logging for development
- **Structured Logging**: Optional JSON structured logs for production analysis
- **Context-Aware**: Log with additional metadata and context
- **Performance Tracking**: Execution time decorators
- **Exception Handling**: Full exception tracebacks in logs
- **Pre-configured Loggers**: Ready-to-use loggers for all modules

## Installation

The logging system is already integrated into the application. No additional installation required.

## Log Files Location

All log files are stored in: `backend/logs/`

### Log Files

- `scraping.log` - All web scraping activities (Reddit, Google, news sites)
- `nlp.log` - NLP extraction activities (voter/candidate extraction)
- `api.log` - API endpoint requests and responses
- `database.log` - Database operations (INSERT, UPDATE, DELETE, SELECT)
- `notifications.log` - Notification system activities
- `general.log` - General application logs

## Log Levels

| Level | Description | Use Case |
|-------|-------------|----------|
| DEBUG | Detailed information | Debugging, development |
| INFO | General information | Normal operations, confirmations |
| WARNING | Warning messages | Non-critical issues, rate limits approaching |
| ERROR | Error messages | Recoverable errors, failed operations |
| CRITICAL | Critical errors | System failures, unrecoverable errors |

## Basic Usage

### 1. Using Pre-configured Loggers

```python
from logging_config import scraping_logger, nlp_logger, api_logger

# Log scraping activity
scraping_logger.info("Starting Reddit scrape for r/nfl")
scraping_logger.warning("Rate limit approaching: 90/100 requests")
scraping_logger.error("Failed to fetch URL: timeout", exc_info=True)

# Log NLP extraction
nlp_logger.info("Extracting votes from tweet")
nlp_logger.debug("Text length: 280 characters")

# Log API requests
api_logger.info("GET /api/voters - 200 OK")
api_logger.error("POST /api/votes - 400 Bad Request: missing candidate_id")
```

### 2. Creating Custom Loggers

```python
from logging_config import LoggerFactory

# Create a custom logger
my_logger = LoggerFactory.get_logger(
    name='custom_module',
    log_to_console=True,
    log_to_file=True,
    structured=False,
    level='INFO'
)

my_logger.info("Custom module initialized")
```

### 3. Structured Logging with Context

```python
from logging_config import LoggerFactory

logger = LoggerFactory.get_logger('my_module')

# Log with additional context
LoggerFactory.log_with_context(
    logger,
    'INFO',
    'User performed action',
    user_id=123,
    action='create_vote',
    timestamp='2025-01-07T10:00:00'
)
```

## Specialized Logging Functions

### Scraping Activity Logging

```python
from logging_config import scraping_logger, log_scraping_activity

log_scraping_activity(
    scraping_logger,
    source='reddit',
    url='https://reddit.com/r/nfl/comments/abc123',
    status='success',
    posts_found=10,
    votes_extracted=3,
    duration_seconds=2.5
)

log_scraping_activity(
    scraping_logger,
    source='google',
    url='https://google.com/search?q=nfl+mvp',
    status='error',
    error='Rate limit exceeded',
    retry_after=60
)

log_scraping_activity(
    scraping_logger,
    source='news',
    url='https://espn.com/article/123',
    status='skipped',
    reason='Already processed',
    cached=True
)
```

### NLP Extraction Activity Logging

```python
from logging_config import nlp_logger, log_extraction_activity

log_extraction_activity(
    nlp_logger,
    text_length=500,
    voters_found=1,
    votes_found=1,
    confidence='high',
    source_url='https://twitter.com/minakimes/status/123',
    source_type='social_media',
    voter_name='Mina Kimes',
    candidate_name='Saquon Barkley'
)

log_extraction_activity(
    nlp_logger,
    text_length=200,
    voters_found=0,
    votes_found=0,
    confidence='low',
    source_url='https://reddit.com/r/nfl/comments/xyz',
    reason='No voting patterns detected'
)
```

### Database Operation Logging

```python
from logging_config import database_logger, log_database_operation

log_database_operation(
    database_logger,
    operation='INSERT',
    table='voters',
    affected_rows=1,
    voter_name='Mina Kimes',
    outlet='ESPN'
)

log_database_operation(
    database_logger,
    operation='UPDATE',
    table='votes',
    affected_rows=3,
    field='verified',
    new_value=True,
    condition='confidence >= 0.8'
)

log_database_operation(
    database_logger,
    operation='DELETE',
    table='sources',
    affected_rows=5,
    reason='Duplicate URLs',
    url_pattern='%twitter.com%'
)
```

### API Request Logging

```python
from logging_config import api_logger, log_api_request

log_api_request(
    api_logger,
    method='GET',
    endpoint='/api/voters',
    status_code=200,
    duration=0.15,
    user_id='admin',
    query_params={'season': '2024-25'}
)

log_api_request(
    api_logger,
    method='POST',
    endpoint='/api/votes',
    status_code=201,
    duration=0.25,
    body_size=500,
    vote_id=42
)

log_api_request(
    api_logger,
    method='DELETE',
    endpoint='/api/votes/123',
    status_code=404,
    duration=0.05,
    error='Vote not found'
)
```

## Performance Tracking with Decorators

### Execution Time Decorator

```python
from logging_config import scraping_logger, log_execution_time

@log_execution_time(scraping_logger)
def scrape_reddit():
    # Your scraping code here
    time.sleep(2)
    return {"posts": 10, "votes": 3}

@log_execution_time(nlp_logger)
def extract_votes(text):
    # Your NLP code here
    return extract_data(text)

# Function calls will automatically log execution time
result = scrape_reddit()
# Logs: "scrape_reddit completed in 2.01s"

votes = extract_votes(text)
# Logs: "extract_votes completed in 0.45s"
```

### Error Handling with Decorator

```python
@log_execution_time(api_logger)
def process_request():
    try:
        # Your code here
        return result
    except Exception as e:
        # Exception will be logged automatically with full traceback
        raise

# If function fails:
# Logs: "process_request failed after 1.23s: ValueError: Invalid input"
# Plus full stack trace
```

## Exception Logging

```python
from logging_config import general_logger

try:
    result = risky_operation()
except ValueError as e:
    general_logger.error(
        f"Invalid value encountered: {str(e)}",
        exc_info=True  # Include full traceback
    )
except Exception as e:
    general_logger.critical(
        f"Unexpected error: {str(e)}",
        exc_info=True
    )
```

## Integration Examples

### Scraper Integration

```python
from logging_config import scraping_logger, log_scraping_activity, log_execution_time

class RedditScraper:
    def __init__(self):
        self.logger = scraping_logger

    @log_execution_time(scraping_logger)
    def scrape_subreddit(self, subreddit):
        self.logger.info(f"Starting scrape: r/{subreddit}")

        try:
            # Fetch posts
            posts = self.fetch_posts(subreddit)

            log_scraping_activity(
                self.logger,
                source='reddit',
                url=f'https://reddit.com/r/{subreddit}',
                status='success',
                posts_found=len(posts)
            )

            return posts

        except Exception as e:
            log_scraping_activity(
                self.logger,
                source='reddit',
                url=f'https://reddit.com/r/{subreddit}',
                status='error',
                error=str(e)
            )
            raise
```

### NLP Integration

```python
from logging_config import nlp_logger, log_extraction_activity, log_execution_time

class VoteExtractor:
    def __init__(self):
        self.logger = nlp_logger

    @log_execution_time(nlp_logger)
    def extract_votes_from_text(self, text, source_url):
        self.logger.info(f"Extracting from {len(text)} characters")

        voters = self.extract_voters(text)
        votes = self.extract_votes(text)

        log_extraction_activity(
            self.logger,
            text_length=len(text),
            voters_found=len(voters),
            votes_found=len(votes),
            confidence='high' if votes else 'low',
            source_url=source_url
        )

        return votes
```

### API Integration

```python
from flask import Flask, request
from logging_config import api_logger, log_api_request
import time

app = Flask(__name__)

@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    duration = time.time() - request.start_time

    log_api_request(
        api_logger,
        method=request.method,
        endpoint=request.path,
        status_code=response.status_code,
        duration=duration,
        user_agent=request.headers.get('User-Agent'),
        ip_address=request.remote_addr
    )

    return response

@app.route('/api/voters')
def get_voters():
    api_logger.info("Fetching all voters")
    # Your code here
    return {"voters": []}
```

### Database Integration

```python
from logging_config import database_logger, log_database_operation

class VoterDB:
    def __init__(self):
        self.logger = database_logger

    def add_voter(self, name, outlet):
        self.logger.info(f"Adding voter: {name}")

        try:
            # Insert into database
            cursor.execute("INSERT INTO voters ...")
            affected = cursor.rowcount

            log_database_operation(
                self.logger,
                operation='INSERT',
                table='voters',
                affected_rows=affected,
                voter_name=name,
                outlet=outlet
            )

            return voter_id

        except Exception as e:
            self.logger.error(f"Failed to add voter: {str(e)}", exc_info=True)
            raise
```

## Configuration

### Environment Variables

```bash
# Set log level (optional)
export LOG_LEVEL=DEBUG  # DEBUG, INFO, WARNING, ERROR, CRITICAL

# Set log directory (optional)
export LOG_DIR=/var/log/mvp-tracker
```

### Custom Configuration

```python
from logging_config import LoggerFactory

# Create logger with custom settings
logger = LoggerFactory.get_logger(
    name='my_module',
    log_to_console=True,      # Console output
    log_to_file=True,         # File output
    structured=False,         # Use structured JSON logs
    level='DEBUG'             # Log level
)
```

### Structured JSON Logging

For production environments where you want to parse logs programmatically:

```python
from logging_config import LoggerFactory

# Enable structured JSON logging
logger = LoggerFactory.get_logger(
    name='production',
    structured=True
)

logger.info("User action", extra={'extra_data': {
    'user_id': 123,
    'action': 'create_vote',
    'ip': '192.168.1.1'
}})
```

This will produce JSON output:
```json
{
  "timestamp": "2025-01-07T10:00:00.123456",
  "level": "INFO",
  "logger": "production",
  "message": "User action",
  "module": "app",
  "function": "create_vote",
  "line": 42,
  "extra": {
    "user_id": 123,
    "action": "create_vote",
    "ip": "192.168.1.1"
  }
}
```

## Log Rotation

Log files automatically rotate when they reach 10MB:
- Maximum file size: 10MB
- Backup count: 5 files
- Naming: `scraping.log`, `scraping.log.1`, `scraping.log.2`, etc.

Oldest logs are automatically deleted when rotation occurs.

## Best Practices

### 1. Use Appropriate Log Levels

```python
# DEBUG: Detailed debugging info
logger.debug(f"Processing item {i} of {total}")

# INFO: Confirmations, normal operations
logger.info("Scraping completed successfully")

# WARNING: Non-critical issues
logger.warning("Rate limit approaching: 90/100")

# ERROR: Errors that can be recovered
logger.error("Failed to fetch URL, will retry", exc_info=True)

# CRITICAL: System failures
logger.critical("Database connection lost, shutting down")
```

### 2. Include Context

```python
# Bad
logger.info("Processing complete")

# Good
logger.info(f"Processing complete: {count} items in {duration}s")

# Better
LoggerFactory.log_with_context(
    logger, 'INFO',
    'Processing complete',
    items_processed=count,
    duration_seconds=duration,
    success_rate=success/total
)
```

### 3. Log Exceptions Properly

```python
# Bad
except Exception as e:
    logger.error(str(e))

# Good
except Exception as e:
    logger.error(f"Operation failed: {str(e)}", exc_info=True)
```

### 4. Use Decorators for Performance Tracking

```python
@log_execution_time(scraping_logger)
def expensive_operation():
    # Automatically logs execution time
    pass
```

### 5. Don't Log Sensitive Data

```python
# Bad
logger.info(f"User login: {username} / {password}")

# Good
logger.info(f"User login: {username} (password redacted)")
```

## Monitoring and Analysis

### Viewing Recent Errors

```bash
# View last 50 errors from scraping log
tail -n 50 logs/scraping.log | grep ERROR

# View all critical errors
grep CRITICAL logs/*.log

# Count errors per log file
grep -c ERROR logs/*.log
```

### Real-time Monitoring

```bash
# Watch scraping log in real-time
tail -f logs/scraping.log

# Watch all ERROR level logs
tail -f logs/*.log | grep ERROR
```

### Log Analysis

```bash
# Find all scraping failures
grep "status='error'" logs/scraping.log

# Count votes extracted
grep "votes_found" logs/nlp.log | wc -l

# Find slow operations (>5 seconds)
grep "completed in [5-9]\." logs/*.log
```

## Troubleshooting

### Issue: Logs not being written

**Solution:**
```python
# Check if log directory exists
import os
from logging_config import LOG_DIR

print(f"Log directory: {LOG_DIR}")
print(f"Exists: {os.path.exists(LOG_DIR)}")
print(f"Writable: {os.access(LOG_DIR, os.W_OK)}")
```

### Issue: Log files too large

**Solution:**
Log rotation is automatic, but you can manually clean old logs:
```bash
# Delete old rotated logs
rm logs/*.log.[2-9]

# Keep only last 2 days of logs
find logs -name "*.log*" -mtime +2 -delete
```

### Issue: Performance impact from logging

**Solution:**
```python
# Use appropriate log levels
# Set production logger to INFO or WARNING
logger = LoggerFactory.get_logger('production', level='WARNING')

# Disable console logging in production
logger = LoggerFactory.get_logger(
    'production',
    log_to_console=False,
    log_to_file=True
)
```

## Testing

Run the comprehensive test suite:

```bash
cd backend
python3 test_logging_system.py
```

This will test:
- Logger creation and configuration
- All log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Scraping activity logging
- NLP extraction activity logging
- Database operation logging
- API request logging
- Execution time decorator
- Exception logging
- Pre-configured loggers

## Summary

The logging system provides:

✓ **6 Pre-configured Loggers**: scraping, nlp, api, database, notifications, general
✓ **Automatic Log Rotation**: 10MB per file, 5 backups
✓ **Color-Coded Console**: Easy to read during development
✓ **Structured Logging**: JSON format for production parsing
✓ **Performance Tracking**: Execution time decorators
✓ **Exception Handling**: Full tracebacks captured
✓ **Context-Aware**: Log with additional metadata
✓ **Specialized Functions**: Scraping, NLP, database, API logging
✓ **Comprehensive Testing**: 9 test categories covering all features

All logs are stored in `backend/logs/` with automatic rotation and cleanup.
