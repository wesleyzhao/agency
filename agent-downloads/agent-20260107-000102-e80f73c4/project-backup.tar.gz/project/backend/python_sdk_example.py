"""
NFL MVP Voter Tracker - Python SDK Example

This module provides a simple Python client for programmatic access to the
NFL MVP Voter Tracker API - Feature #19

Usage:
    from python_sdk_example import MVPTrackerClient

    # Create client
    client = MVPTrackerClient(base_url="http://localhost:5000/api")

    # List voters with pagination
    voters = client.get_voters(page=1, per_page=10, has_voted=True)

    # Get voter details
    voter = client.get_voter(voter_id=1, season="2024-25")

    # Create a vote
    vote = client.create_vote(
        voter_name="Mina Kimes",
        candidate_name="Saquon Barkley",
        candidate_team="Philadelphia Eagles",
        season="2024-25",
        ranking=1,
        confidence="high"
    )

    # Search and filter
    results = client.search(candidate_name="Saquon Barkley", confidence="high")

    # Get statistics
    stats = client.get_statistics(season="2024-25")
"""

import requests
from typing import Optional, List, Dict, Any
from dataclasses import dataclass


@dataclass
class APIResponse:
    """Container for API responses"""
    success: bool
    data: Any
    error: Optional[str] = None
    status_code: Optional[int] = None


class MVPTrackerClient:
    """
    Python client for NFL MVP Voter Tracker API

    This client provides programmatic access to all API endpoints with
    support for pagination, filtering, and sorting (Feature #19).
    """

    def __init__(self, base_url: str = "http://localhost:5000/api"):
        """
        Initialize the API client

        Args:
            base_url: Base URL for the API (default: http://localhost:5000/api)
        """
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'MVPTracker-Python-SDK/1.0'
        })

    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None,
                 json: Optional[Dict] = None) -> APIResponse:
        """
        Make an API request

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (e.g., '/voters')
            params: Query parameters
            json: JSON request body

        Returns:
            APIResponse object
        """
        url = f"{self.base_url}{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json
            )

            if response.ok:
                return APIResponse(
                    success=True,
                    data=response.json(),
                    status_code=response.status_code
                )
            else:
                error_data = response.json() if response.text else {}
                return APIResponse(
                    success=False,
                    data=None,
                    error=error_data.get('error', 'Unknown error'),
                    status_code=response.status_code
                )
        except requests.RequestException as e:
            return APIResponse(
                success=False,
                data=None,
                error=str(e)
            )

    # =========================================================================
    # Health Check
    # =========================================================================

    def health_check(self) -> APIResponse:
        """Check API health status"""
        return self._request('GET', '/health')

    # =========================================================================
    # Voters API - Feature #19 Enhanced
    # =========================================================================

    def get_voters(self, page: int = 1, per_page: int = 50, sort_by: str = 'name',
                   order: str = 'asc', outlet: Optional[str] = None,
                   has_voted: Optional[bool] = None, season: str = '2024-25') -> APIResponse:
        """
        Get paginated list of voters with filtering and sorting

        Args:
            page: Page number (default: 1)
            per_page: Items per page (max 100, default: 50)
            sort_by: Field to sort by (name, outlet, vote_count, created_at)
            order: Sort order (asc, desc)
            outlet: Filter by media outlet (partial match)
            has_voted: Filter by whether voter has disclosed votes
            season: Season for vote count calculation

        Returns:
            APIResponse with voters list and pagination metadata
        """
        params = {
            'page': page,
            'per_page': min(per_page, 100),
            'sort_by': sort_by,
            'order': order,
            'season': season
        }

        if outlet:
            params['outlet'] = outlet
        if has_voted is not None:
            params['has_voted'] = str(has_voted).lower()

        return self._request('GET', '/voters', params=params)

    def get_voter(self, voter_id: int, season: str = '2024-25') -> APIResponse:
        """
        Get detailed voter information

        Args:
            voter_id: Voter ID
            season: Season filter for votes

        Returns:
            APIResponse with voter details, ballot, and statistics
        """
        params = {'season': season}
        return self._request('GET', f'/voters/{voter_id}', params=params)

    def create_voter(self, name: str, outlet: Optional[str] = None,
                    twitter_handle: Optional[str] = None, location: Optional[str] = None,
                    bio: Optional[str] = None) -> APIResponse:
        """
        Create a new voter

        Args:
            name: Voter's full name (required)
            outlet: Media organization
            twitter_handle: Twitter/X handle
            location: City, State
            bio: Brief biography

        Returns:
            APIResponse with created voter ID
        """
        data = {'name': name}
        if outlet:
            data['outlet'] = outlet
        if twitter_handle:
            data['twitter_handle'] = twitter_handle
        if location:
            data['location'] = location
        if bio:
            data['bio'] = bio

        return self._request('POST', '/voters', json=data)

    def update_voter(self, voter_id: int, **kwargs) -> APIResponse:
        """
        Update voter information

        Args:
            voter_id: Voter ID
            **kwargs: Fields to update (name, outlet, twitter_handle, location, bio)

        Returns:
            APIResponse with success message
        """
        return self._request('PUT', f'/voters/{voter_id}', json=kwargs)

    def delete_voter(self, voter_id: int) -> APIResponse:
        """Delete a voter and all their votes"""
        return self._request('DELETE', f'/voters/{voter_id}')

    # =========================================================================
    # Candidates API
    # =========================================================================

    def get_candidates(self, season: str = '2024-25') -> APIResponse:
        """Get all MVP candidates for a season"""
        params = {'season': season}
        return self._request('GET', '/candidates', params=params)

    def create_candidate(self, name: str, season: str, team: Optional[str] = None,
                        position: Optional[str] = None) -> APIResponse:
        """
        Create a new MVP candidate

        Args:
            name: Player's full name (required)
            season: Season (required, format: "YYYY-YY")
            team: Team name
            position: Position (QB, RB, WR, etc.)

        Returns:
            APIResponse with created candidate ID
        """
        data = {'name': name, 'season': season}
        if team:
            data['team'] = team
        if position:
            data['position'] = position

        return self._request('POST', '/candidates', json=data)

    def update_candidate(self, candidate_id: int, **kwargs) -> APIResponse:
        """Update candidate information"""
        return self._request('PUT', f'/candidates/{candidate_id}', json=kwargs)

    def delete_candidate(self, candidate_id: int) -> APIResponse:
        """Delete a candidate"""
        return self._request('DELETE', f'/candidates/{candidate_id}')

    # =========================================================================
    # Votes API - Feature #19 Enhanced
    # =========================================================================

    def get_votes(self, page: int = 1, per_page: int = 50, season: str = '2024-25',
                  voter_id: Optional[int] = None, candidate_id: Optional[int] = None,
                  ranking: Optional[int] = None, confidence: Optional[str] = None,
                  verified: Optional[bool] = None, source_type: Optional[str] = None,
                  sort_by: str = 'ranking', order: str = 'asc') -> APIResponse:
        """
        Get paginated list of votes with advanced filtering

        Args:
            page: Page number
            per_page: Items per page (max 100)
            season: Season filter
            voter_id: Filter by voter ID
            candidate_id: Filter by candidate ID
            ranking: Filter by ranking (1-5)
            confidence: Filter by confidence level (high, medium, low)
            verified: Filter by verification status
            source_type: Filter by source type
            sort_by: Field to sort by (ranking, created_at, announcement_date)
            order: Sort order (asc, desc)

        Returns:
            APIResponse with votes list and pagination metadata
        """
        params = {
            'page': page,
            'per_page': min(per_page, 100),
            'season': season,
            'sort_by': sort_by,
            'order': order
        }

        if voter_id:
            params['voter_id'] = voter_id
        if candidate_id:
            params['candidate_id'] = candidate_id
        if ranking:
            params['ranking'] = ranking
        if confidence:
            params['confidence'] = confidence
        if verified is not None:
            params['verified'] = str(verified).lower()
        if source_type:
            params['source_type'] = source_type

        return self._request('GET', '/votes', params=params)

    def create_vote(self, season: str, voter_id: Optional[int] = None,
                   voter_name: Optional[str] = None, candidate_id: Optional[int] = None,
                   candidate_name: Optional[str] = None, candidate_team: Optional[str] = None,
                   candidate_position: Optional[str] = None, ranking: int = 1,
                   source_url: Optional[str] = None, source_type: Optional[str] = None,
                   confidence: Optional[str] = None, confidence_score: Optional[float] = None,
                   verified: bool = True, announcement_date: Optional[str] = None) -> APIResponse:
        """
        Create a new vote (supports ID-based or name-based creation)

        Args:
            season: Season (required)
            voter_id: Voter ID (use either voter_id or voter_name)
            voter_name: Voter name (auto-creates if doesn't exist)
            candidate_id: Candidate ID (use either candidate_id or candidate_name)
            candidate_name: Candidate name (auto-creates if doesn't exist)
            candidate_team: Candidate's team
            candidate_position: Candidate's position
            ranking: Vote ranking (1-5, default: 1)
            source_url: Link to original announcement
            source_type: Type of source (official, social_media, news_article, etc.)
            confidence: Confidence level (high, medium, low)
            confidence_score: Numeric confidence score (0-100)
            verified: Verification status (default: True for manual entries)
            announcement_date: ISO 8601 date string

        Returns:
            APIResponse with created vote ID
        """
        data = {'season': season, 'ranking': ranking, 'verified': verified}

        if voter_id:
            data['voter_id'] = voter_id
        elif voter_name:
            data['voter_name'] = voter_name
        else:
            raise ValueError("Either voter_id or voter_name must be provided")

        if candidate_id:
            data['candidate_id'] = candidate_id
        elif candidate_name:
            data['candidate_name'] = candidate_name
            if candidate_team:
                data['candidate_team'] = candidate_team
            if candidate_position:
                data['candidate_position'] = candidate_position
        else:
            raise ValueError("Either candidate_id or candidate_name must be provided")

        if source_url:
            data['source_url'] = source_url
        if source_type:
            data['source_type'] = source_type
        if confidence:
            data['confidence'] = confidence
        if confidence_score is not None:
            data['confidence_score'] = confidence_score
        if announcement_date:
            data['announcement_date'] = announcement_date

        return self._request('POST', '/votes', json=data)

    def update_vote(self, vote_id: int, **kwargs) -> APIResponse:
        """Update a vote"""
        return self._request('PUT', f'/votes/{vote_id}', json=kwargs)

    def delete_vote(self, vote_id: int) -> APIResponse:
        """Delete a vote"""
        return self._request('DELETE', f'/votes/{vote_id}')

    # =========================================================================
    # Dashboard & Statistics
    # =========================================================================

    def get_dashboard(self, season: str = '2024-25') -> APIResponse:
        """Get comprehensive dashboard data"""
        params = {'season': season}
        return self._request('GET', '/dashboard', params=params)

    def get_statistics(self, season: str = '2024-25') -> APIResponse:
        """Get comprehensive statistics and analytics"""
        params = {'season': season}
        return self._request('GET', '/statistics', params=params)

    # =========================================================================
    # Search & Filter
    # =========================================================================

    def search(self, q: Optional[str] = None, voter_name: Optional[str] = None,
              outlet: Optional[str] = None, candidate_name: Optional[str] = None,
              confidence: Optional[str] = None, verified_only: bool = False,
              has_ballot: Optional[str] = None, season: str = '2024-25') -> APIResponse:
        """
        Search and filter across voters, candidates, and votes

        Args:
            q: General search query
            voter_name: Filter by voter name (partial match)
            outlet: Filter by media outlet
            candidate_name: Filter by candidate name
            confidence: Filter by confidence level
            verified_only: Show only verified votes
            has_ballot: Filter by ballot status (full, partial, any, none)
            season: Season filter

        Returns:
            APIResponse with search results
        """
        params = {'season': season}

        if q:
            params['q'] = q
        if voter_name:
            params['voter_name'] = voter_name
        if outlet:
            params['outlet'] = outlet
        if candidate_name:
            params['candidate_name'] = candidate_name
        if confidence:
            params['confidence'] = confidence
        if verified_only:
            params['verified_only'] = 'true'
        if has_ballot:
            params['has_ballot'] = has_ballot

        return self._request('GET', '/search', params=params)

    # =========================================================================
    # Export
    # =========================================================================

    def export_voters(self, format: str = 'json', season: str = '2024-25') -> APIResponse:
        """Export voters as CSV or JSON"""
        params = {'format': format, 'season': season}
        return self._request('GET', '/export/voters', params=params)

    def export_votes(self, format: str = 'json', season: str = '2024-25') -> APIResponse:
        """Export votes as CSV or JSON"""
        params = {'format': format, 'season': season}
        return self._request('GET', '/export/votes', params=params)

    def export_candidates(self, format: str = 'json', season: str = '2024-25') -> APIResponse:
        """Export candidates as CSV or JSON"""
        params = {'format': format, 'season': season}
        return self._request('GET', '/export/candidates', params=params)

    def export_full_report(self, season: str = '2024-25') -> APIResponse:
        """Export comprehensive report (JSON only)"""
        params = {'season': season}
        return self._request('GET', '/export/full-report', params=params)

    # =========================================================================
    # Notifications
    # =========================================================================

    def get_notification_preferences(self) -> APIResponse:
        """Get all notification preferences"""
        return self._request('GET', '/notifications/preferences')

    def create_notification_preference(self, name: str, channel: str, **kwargs) -> APIResponse:
        """
        Create a notification preference

        Args:
            name: Preference name
            channel: Notification channel (email, webhook, console)
            **kwargs: Additional preference settings

        Returns:
            APIResponse with created preference ID
        """
        data = {'name': name, 'channel': channel}
        data.update(kwargs)
        return self._request('POST', '/notifications/preferences', json=data)

    def get_notification_history(self, limit: int = 50, status: Optional[str] = None) -> APIResponse:
        """
        Get notification history

        Args:
            limit: Number of records to return
            status: Filter by status (sent, failed, pending)

        Returns:
            APIResponse with notification history
        """
        params = {'limit': limit}
        if status:
            params['status'] = status
        return self._request('GET', '/notifications/history', params=params)

    def send_test_notification(self, title: str = 'Test', message: str = 'Test notification') -> APIResponse:
        """Send a test notification"""
        data = {'title': title, 'message': message}
        return self._request('POST', '/notifications/test', json=data)


# =============================================================================
# Usage Examples
# =============================================================================

if __name__ == '__main__':
    # Initialize client
    client = MVPTrackerClient(base_url="http://localhost:5000/api")

    # Example 1: Check API health
    print("=" * 60)
    print("Example 1: Health Check")
    print("=" * 60)
    response = client.health_check()
    if response.success:
        print(f"✓ API is healthy: {response.data}")
    else:
        print(f"✗ API error: {response.error}")

    # Example 2: List voters with pagination
    print("\n" + "=" * 60)
    print("Example 2: List Voters (Paginated)")
    print("=" * 60)
    response = client.get_voters(page=1, per_page=5, sort_by='name', order='asc')
    if response.success:
        data = response.data
        print(f"✓ Found {data['pagination']['total_count']} voters")
        print(f"  Page {data['pagination']['page']} of {data['pagination']['total_pages']}")
        for voter in data['voters']:
            print(f"  - {voter['name']} ({voter['outlet']}): {voter['vote_count']} votes")
    else:
        print(f"✗ Error: {response.error}")

    # Example 3: Search for voters who voted for a specific candidate
    print("\n" + "=" * 60)
    print("Example 3: Search for Saquon Barkley voters")
    print("=" * 60)
    response = client.search(candidate_name='Saquon Barkley', confidence='high')
    if response.success:
        data = response.data
        print(f"✓ Found {data['count']} results")
        for result in data['results'][:3]:  # Show first 3
            print(f"  - {result['name']} ({result['outlet']})")
            for vote in result.get('ballot', []):
                if 'Barkley' in vote['candidate']:
                    print(f"    Ranked {vote['candidate']} #{vote['ranking']}")
    else:
        print(f"✗ Error: {response.error}")

    # Example 4: Get statistics
    print("\n" + "=" * 60)
    print("Example 4: Get Statistics")
    print("=" * 60)
    response = client.get_statistics(season='2024-25')
    if response.success:
        stats = response.data['overview']
        print(f"✓ Season 2024-25 Statistics:")
        print(f"  Total Voters: {stats['total_voters']}")
        print(f"  Known Voters: {stats['known_voters']}")
        print(f"  Voters with Disclosed Votes: {stats['voters_with_disclosed_votes']}")
        print(f"  Completion: {stats['completion_percentage']}%")
    else:
        print(f"✗ Error: {response.error}")

    # Example 5: Get votes with filtering
    print("\n" + "=" * 60)
    print("Example 5: Get High-Confidence Verified Votes")
    print("=" * 60)
    response = client.get_votes(
        page=1,
        per_page=5,
        confidence='high',
        verified=True,
        sort_by='created_at',
        order='desc'
    )
    if response.success:
        data = response.data
        print(f"✓ Found {data['pagination']['total_count']} high-confidence verified votes")
        for vote in data['votes']:
            print(f"  - {vote['voter_name']} → {vote['candidate_name']} (Rank #{vote['ranking']})")
            print(f"    Confidence: {vote['confidence']} ({vote['confidence_score']})")
    else:
        print(f"✗ Error: {response.error}")

    # Example 6: Create a new vote (name-based)
    print("\n" + "=" * 60)
    print("Example 6: Create a Vote (Example - Commented Out)")
    print("=" * 60)
    print("# Uncomment to actually create a vote:")
    print("""
    response = client.create_vote(
        voter_name="Test Voter",
        candidate_name="Josh Allen",
        candidate_team="Buffalo Bills",
        candidate_position="QB",
        season="2024-25",
        ranking=1,
        confidence="high",
        confidence_score=85.0,
        source_url="https://example.com/vote"
    )
    if response.success:
        print(f"✓ Vote created with ID: {response.data['id']}")
    else:
        print(f"✗ Error: {response.error}")
    """)

    print("\n" + "=" * 60)
    print("SDK Examples Complete")
    print("=" * 60)
