# Export API Documentation - Feature #15

Complete documentation for the NFL MVP Voter Tracker export endpoints. These endpoints allow downloading voter, vote, candidate, and comprehensive report data in CSV or JSON formats.

## Table of Contents
- [Overview](#overview)
- [Export Endpoints](#export-endpoints)
- [Query Parameters](#query-parameters)
- [Response Formats](#response-formats)
- [Usage Examples](#usage-examples)
- [Frontend Integration](#frontend-integration)

---

## Overview

The export API provides four main endpoints for exporting data:
1. **Voters Export** - All voter information with vote counts
2. **Votes Export** - Individual vote records with full details
3. **Candidates Export** - Candidate statistics with vote breakdowns
4. **Full Report Export** - Comprehensive report with all data and metadata

All exports support:
- Season filtering
- CSV and JSON formats
- Automatic file download with proper Content-Disposition headers
- Error handling with descriptive messages

---

## Export Endpoints

### 1. Export Voters

**Endpoint:** `GET /api/export/voters`

**Description:** Export all voters with their vote counts and details.

**Query Parameters:**
- `format` (optional): `csv` or `json` (default: `json`)
- `season` (optional): Season filter (default: `2024-25`)

**Response:** CSV or JSON file download

**CSV Columns:**
- `id` - Voter database ID
- `name` - Voter full name
- `outlet` - Media organization
- `twitter_handle` - Twitter handle
- `location` - City, State
- `bio` - Biography
- `vote_count` - Number of votes for the season
- `has_voted` - Boolean indicating if voter has disclosed any votes
- `created_at` - Timestamp when voter was added

**JSON Structure:**
```json
[
  {
    "id": 1,
    "name": "Peter King",
    "outlet": "NBC Sports",
    "twitter_handle": "@peter_king",
    "location": "Montclair, NJ",
    "bio": "Senior NFL columnist",
    "vote_count": 5,
    "has_voted": true,
    "created_at": "2025-01-07T08:30:00"
  }
]
```

---

### 2. Export Votes

**Endpoint:** `GET /api/export/votes`

**Description:** Export all individual vote records with complete details.

**Query Parameters:**
- `format` (optional): `csv` or `json` (default: `json`)
- `season` (optional): Season filter (default: `2024-25`)

**Response:** CSV or JSON file download

**CSV Columns:**
- `id` - Vote database ID
- `voter_name` - Name of the voter
- `voter_outlet` - Voter's media organization
- `candidate_name` - Candidate name
- `candidate_team` - Candidate's team
- `candidate_position` - Candidate's position
- `ranking` - Vote ranking (1-5)
- `season` - Season (e.g., "2024-25")
- `source_url` - URL to original announcement
- `source_type` - Type of source (official, social_media, news_article, reddit, speculation)
- `confidence` - Confidence level (high, medium, low)
- `confidence_score` - Numeric confidence (0-100)
- `verified` - Boolean verification status
- `announcement_date` - Date vote was announced
- `created_at` - Timestamp when vote was added to database

**JSON Structure:**
```json
[
  {
    "id": 1,
    "voter_name": "Peter King",
    "voter_outlet": "NBC Sports",
    "candidate_name": "Josh Allen",
    "candidate_team": "Buffalo Bills",
    "candidate_position": "QB",
    "ranking": 1,
    "season": "2024-25",
    "source_url": "https://...",
    "source_type": "news_article",
    "confidence": "high",
    "confidence_score": 85.5,
    "verified": true,
    "announcement_date": "2025-01-05T10:00:00",
    "created_at": "2025-01-07T08:35:00"
  }
]
```

---

### 3. Export Candidates

**Endpoint:** `GET /api/export/candidates`

**Description:** Export candidate statistics with vote breakdowns.

**Query Parameters:**
- `format` (optional): `csv` or `json` (default: `json`)
- `season` (optional): Season filter (default: `2024-25`)

**Response:** CSV or JSON file download

**CSV Columns:**
- `id` - Candidate database ID
- `name` - Candidate name
- `team` - Team name
- `position` - Position (QB, RB, WR, etc.)
- `season` - Season
- `first_place_votes` - Number of 1st place votes
- `second_place_votes` - Number of 2nd place votes
- `third_place_votes` - Number of 3rd place votes
- `fourth_place_votes` - Number of 4th place votes
- `fifth_place_votes` - Number of 5th place votes
- `total_mentions` - Total appearances on ballots
- `weighted_points` - Weighted points (10-7-5-3-1 system)

**JSON Structure:**
```json
[
  {
    "id": 1,
    "name": "Josh Allen",
    "team": "Buffalo Bills",
    "position": "QB",
    "season": "2024-25",
    "first_place_votes": 15,
    "second_place_votes": 10,
    "third_place_votes": 5,
    "fourth_place_votes": 2,
    "fifth_place_votes": 1,
    "total_mentions": 33,
    "weighted_points": 224
  }
]
```

**Points System:**
- 1st place = 10 points
- 2nd place = 7 points
- 3rd place = 5 points
- 4th place = 3 points
- 5th place = 1 point

---

### 4. Export Full Report

**Endpoint:** `GET /api/export/full-report`

**Description:** Export comprehensive report with all data, metadata, and statistics.

**Query Parameters:**
- `season` (optional): Season filter (default: `2024-25`)

**Response:** JSON file download (CSV not supported due to nested data)

**JSON Structure:**
```json
{
  "metadata": {
    "season": "2024-25",
    "export_date": "2025-01-07T10:00:00",
    "total_voters": 50,
    "known_voters": 25,
    "total_votes": 45,
    "total_candidates": 15
  },
  "statistics": {
    "voters_with_disclosed_votes": 20,
    "first_place_votes_disclosed": 20,
    "verified_votes": 40,
    "high_confidence_votes": 35,
    "completion_percentage": 40.0
  },
  "voters": [
    {
      "id": 1,
      "name": "Peter King",
      "outlet": "NBC Sports",
      "twitter_handle": "@peter_king",
      "location": "Montclair, NJ",
      "vote_count": 5,
      "ballot": [
        {
          "ranking": 1,
          "candidate": "Josh Allen",
          "team": "Buffalo Bills",
          "confidence": "high",
          "confidence_score": 85.5,
          "verified": true,
          "source_url": "https://..."
        }
      ]
    }
  ],
  "candidates": [
    {
      "id": 1,
      "name": "Josh Allen",
      "team": "Buffalo Bills",
      "position": "QB",
      "first_place_votes": 15,
      "second_place_votes": 10,
      "third_place_votes": 5,
      "fourth_place_votes": 2,
      "fifth_place_votes": 1,
      "total_mentions": 33,
      "weighted_points": 224
    }
  ],
  "votes": [
    {
      "id": 1,
      "voter": "Peter King",
      "candidate": "Josh Allen",
      "ranking": 1,
      "source_url": "https://...",
      "source_type": "news_article",
      "confidence": "high",
      "confidence_score": 85.5,
      "verified": true,
      "announcement_date": "2025-01-05T10:00:00"
    }
  ]
}
```

---

## Query Parameters

### format
- **Type:** String
- **Values:** `csv`, `json`
- **Default:** `json`
- **Description:** Output format for the export

### season
- **Type:** String
- **Format:** `YYYY-YY` (e.g., `2024-25`)
- **Default:** `2024-25`
- **Description:** Filter data by NFL season

---

## Response Formats

### Success Response

**Status Code:** `200 OK`

**Headers:**
```
Content-Type: text/csv or application/json
Content-Disposition: attachment; filename=<filename>
```

**Body:** File content (CSV or JSON)

### Error Response

**Status Code:** `500 Internal Server Error`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "error": "Error message description"
}
```

---

## Usage Examples

### cURL Examples

**Export voters as CSV:**
```bash
curl -O -J "http://localhost:5000/api/export/voters?format=csv&season=2024-25"
```

**Export votes as JSON:**
```bash
curl -O -J "http://localhost:5000/api/export/votes?format=json&season=2024-25"
```

**Export candidates as CSV:**
```bash
curl -O -J "http://localhost:5000/api/export/candidates?format=csv&season=2024-25"
```

**Export full report:**
```bash
curl -O -J "http://localhost:5000/api/export/full-report?season=2024-25"
```

### JavaScript (Fetch API)

```javascript
// Export voters as CSV
const exportVoters = async () => {
  const url = 'http://localhost:5000/api/export/voters?format=csv&season=2024-25';
  window.open(url, '_blank');
};

// Export with fetch and download
const exportData = async (type, format) => {
  const response = await fetch(
    `http://localhost:5000/api/export/${type}?format=${format}&season=2024-25`
  );

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${type}_2024-25.${format}`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

// Usage
exportData('voters', 'csv');
exportData('votes', 'json');
```

### Python (requests)

```python
import requests

# Export voters as CSV
url = 'http://localhost:5000/api/export/voters'
params = {'format': 'csv', 'season': '2024-25'}
response = requests.get(url, params=params)

with open('voters_2024-25.csv', 'w') as f:
    f.write(response.text)

# Export full report as JSON
url = 'http://localhost:5000/api/export/full-report'
params = {'season': '2024-25'}
response = requests.get(url, params=params)

import json
data = response.json()
with open('mvp_full_report_2024-25.json', 'w') as f:
    json.dump(data, f, indent=2)
```

---

## Frontend Integration

### React Component Example

```jsx
import React from 'react';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function ExportButtons() {
  const handleExport = (type, format) => {
    const url = `${API_URL}/api/export/${type}?format=${format}&season=2024-25`;
    window.open(url, '_blank');
  };

  return (
    <div className="export-buttons">
      <button onClick={() => handleExport('voters', 'csv')}>
        Export Voters (CSV)
      </button>
      <button onClick={() => handleExport('votes', 'json')}>
        Export Votes (JSON)
      </button>
      <button onClick={() => handleExport('candidates', 'csv')}>
        Export Candidates (CSV)
      </button>
      <button onClick={() => handleExport('full-report', 'json')}>
        Export Full Report
      </button>
    </div>
  );
}

export default ExportButtons;
```

### Dropdown Menu Example

See `frontend/src/Dashboard.js` and `frontend/src/Statistics.js` for complete dropdown implementation with hover menu.

---

## File Naming Convention

Files are automatically named with the following pattern:

- Voters: `voters_{season}.{format}`
  - Example: `voters_2024-25.csv`

- Votes: `votes_{season}.{format}`
  - Example: `votes_2024-25.json`

- Candidates: `candidates_{season}.{format}`
  - Example: `candidates_2024-25.csv`

- Full Report: `mvp_full_report_{season}.json`
  - Example: `mvp_full_report_2024-25.json`

---

## Use Cases

### 1. Data Backup
Export full report to create a complete backup of all voter tracker data.

```bash
curl -O -J "http://localhost:5000/api/export/full-report?season=2024-25"
```

### 2. Spreadsheet Analysis
Export candidates as CSV to analyze in Excel or Google Sheets.

```bash
curl -O -J "http://localhost:5000/api/export/candidates?format=csv&season=2024-25"
```

### 3. Data Integration
Export votes as JSON to integrate with other systems or analytics tools.

```javascript
const response = await fetch('http://localhost:5000/api/export/votes?format=json');
const votes = await response.json();
// Process votes data
```

### 4. Reporting
Export voters to create reports on voter coverage and disclosure rates.

```bash
curl -O -J "http://localhost:5000/api/export/voters?format=csv&season=2024-25"
```

### 5. Historical Analysis
Export data from multiple seasons for year-over-year comparison.

```bash
for season in 2022-23 2023-24 2024-25; do
  curl -O -J "http://localhost:5000/api/export/candidates?format=csv&season=$season"
done
```

---

## Performance Considerations

- **Response Time:** Typically 50-500ms depending on data size
- **File Size:**
  - Voters CSV: ~5-20 KB for 50 voters
  - Votes CSV: ~10-100 KB for 100-500 votes
  - Candidates CSV: ~3-10 KB for 15-30 candidates
  - Full Report JSON: ~50-500 KB depending on data volume

- **Browser Compatibility:** All modern browsers support file downloads via `window.open()`
- **Rate Limiting:** No rate limiting currently implemented (consider adding for production)

---

## Testing

Run the test suite to verify all export endpoints:

```bash
cd backend
python3 test_export.py
```

Test coverage includes:
- Health check
- JSON and CSV exports for all data types
- Filename generation validation
- Response header verification
- Data structure validation

---

## Future Enhancements

Potential improvements for export functionality:

1. **Excel Format:** Add XLSX export support
2. **Email Export:** Send export files via email
3. **Scheduled Exports:** Automatic daily/weekly exports
4. **Custom Fields:** Allow users to select which fields to export
5. **Compression:** ZIP files for large exports
6. **Historical Exports:** Include multiple seasons in one export
7. **Filtered Exports:** Export only high-confidence or verified votes
8. **API Key Authentication:** Secure exports with API keys

---

## Troubleshooting

### Issue: Export returns 500 error
**Solution:** Check backend logs for database connection issues

### Issue: CSV has incorrect encoding
**Solution:** Ensure UTF-8 encoding is supported by your CSV reader

### Issue: JSON file won't download
**Solution:** Check browser popup blocker settings for `window.open()` calls

### Issue: Empty export file
**Solution:** Verify data exists for the specified season in the database

---

## Related Features

- **Feature #10:** Manual Entry Interface - Add data to export
- **Feature #11:** Dashboard - Export from dashboard view
- **Feature #13:** Summary Statistics - Export statistics data
- **Feature #14:** Search and Filter - Export filtered results (future)

---

## Support

For issues or questions about the export functionality:
1. Check the test suite: `python3 backend/test_export.py`
2. Review backend logs for error messages
3. Verify database contains data for the specified season
4. Ensure backend server is running on http://localhost:5000

---

**Last Updated:** January 7, 2025
**Feature Status:** ✓ Completed
**API Version:** 1.0
