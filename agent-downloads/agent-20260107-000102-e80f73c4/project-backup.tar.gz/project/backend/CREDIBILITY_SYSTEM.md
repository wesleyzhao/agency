# Source Credibility Tracking System - Feature #16

## Overview

The Source Credibility Tracking system provides a sophisticated multi-tier assessment of the trustworthiness and reliability of NFL MVP voter information sources. This goes beyond basic source type classification to evaluate sources based on domain reputation, content quality, verification status, and other factors.

## Credibility Tiers

The system uses five credibility tiers, ranked from highest to lowest:

### 1. VERIFIED (Highest Credibility)
- **Score Range**: 90-100
- **Badge**: ✓ Verified Source (Green)
- **Criteria**:
  - Direct announcement from voter's verified social media account, OR
  - Tier 1 news domain with direct quote from voter, OR
  - Multiple corroborating sources (3+) with direct quote
- **Examples**:
  - Tweet from @minakimes (verified account): "My MVP vote is for Josh Allen"
  - ESPN article: "Mina Kimes told ESPN she voted for Josh Allen"

### 2. OFFICIAL (High Credibility)
- **Score Range**: 80-95
- **Badge**: ★ Official (Blue)
- **Criteria**:
  - Major news outlet (tier 1) article
  - Official AP or NFL.com announcement
  - Tier 2 news domain with direct quote
- **Examples**:
  - NFL.com: "Peter King announces MVP vote"
  - CBSSports: "King stated he voted for Josh Allen"

### 3. RELIABLE (Moderate Credibility)
- **Score Range**: 65-80
- **Badge**: ◆ Reliable (Purple)
- **Criteria**:
  - Reputable news outlet (tier 2/3)
  - Multiple corroborating sources (2+)
  - Established sports media
- **Examples**:
  - Pro Football Talk article about voter's pick
  - Bleacher Report with multiple source confirmation

### 4. UNVERIFIED (Low Credibility)
- **Score Range**: 40-65
- **Badge**: ? Unverified (Orange/Amber)
- **Criteria**:
  - Single unverified social media post
  - Unknown domain source
  - No direct quote or verification
- **Examples**:
  - Unverified Twitter account claiming knowledge
  - Single forum post without confirmation

### 5. SPECULATION (Lowest Credibility)
- **Score Range**: 0-40
- **Badge**: ~ Speculation (Red)
- **Criteria**:
  - Contains speculation language (might, probably, I think)
  - Forum post or discussion thread
  - No credible source attribution
- **Examples**:
  - Reddit: "I think Mina will probably vote for Allen"
  - Forum: "Rumor has it that King might pick Mahomes"

## Domain Reputation System

Domains are classified into reputation tiers that influence credibility scoring:

### Tier 1 Domains (Most Reputable)
- **Associated Press**: ap.org, associatedpress.com
- **Major Networks**: nfl.com, espn.com, cbssports.com, nbcsports.com, foxsports.com
- **Premier Sports Media**: si.com, thescore.com, theathletic.com

### Tier 2 Domains (Reputable)
- **Sports Media**: profootballtalk.com, bleacherreport.com, sbnation.com
- **News Organizations**: usatoday.com, washingtonpost.com, nytimes.com
- **General Media**: yahoo.com, msn.com, cnn.com, abc.com, cbs.com, nbc.com

### Tier 3 Domains (Established)
- **Sports Blogs**: profootballrumors.com, sportingnews.com, fansided.com
- **Sports Media**: deadspin.com, barstoolsports.com

### Social Media Platforms
- twitter.com, x.com, instagram.com, facebook.com, threads.net, bluesky.social
- Credibility depends on account verification status

### Forums and Communities
- reddit.com and other forum domains
- Generally lower credibility unless corroborated

## Scoring Algorithm

The credibility score (0-100) is calculated based on multiple factors:

### Base Score by Tier
- Verified: 95 points
- Official: 85 points
- Reliable: 70 points
- Unverified: 45 points
- Speculation: 25 points

### Modifiers

**Domain Reputation Bonus** (+0 to +5)
- Tier 1 domain: +5 points
- Tier 2 domain: +2 points
- Social media (verified): +5 points

**Direct Quote Bonus** (+8)
- Source contains direct quote with quotation marks or attribution
- Examples: "I'm voting for Allen," Kimes said

**Speculation Penalty** (-15)
- Contains words like: might, may, could, probably, likely, I think, rumored

**Corroboration Bonus** (+2 to +10)
- 3+ sources: +10 points
- 2 sources: +5 points
- 1 source: +2 points

## Content Analysis

### Direct Quote Detection

The system looks for patterns indicating direct quotes:

```
- "voter statement with voting keywords"
- 'voter statement with voting keywords'
- [Voter] said [voting statement]
- [Voter] told [outlet] [voting statement]
- [Voter] stated [voting statement]
- [Voter] announced [voting statement]
```

Keywords: vote, voting, ballot, pick, mvp, choice

### Speculation Language Detection

The system identifies speculation through patterns:

```
- might/may/could/would/should + vote
- rumor/speculation/expected/predicted
- i think/i believe/i heard/sources say/reportedly
- if [condition] vote
- will probably, should vote
```

## Database Schema

### Vote Table Fields

```sql
credibility_tier VARCHAR(20) DEFAULT 'unverified'
  -- verified|official|reliable|unverified|speculation

credibility_score FLOAT
  -- Numeric score 0-100

has_direct_quote INTEGER DEFAULT 0
  -- 1 if source contains direct quote, 0 otherwise

has_speculation_language INTEGER DEFAULT 0
  -- 1 if source contains speculation, 0 otherwise
```

### Source Table Fields

```sql
credibility_tier VARCHAR(20) DEFAULT 'unverified'
  -- Same tier values as votes

credibility_score FLOAT
  -- Numeric score 0-100

domain_reputation VARCHAR(20)
  -- tier1|tier2|tier3|social|forum|unknown
```

## API Endpoints

### 1. Assess Source Credibility

```http
POST /api/credibility/assess
Content-Type: application/json

{
  "url": "https://espn.com/article",
  "title": "Article title",
  "content": "Article text content",
  "source_type": "news_article",
  "voter_name": "Mina Kimes",
  "is_verified_account": false,
  "num_corroborating_sources": 0
}
```

**Response:**
```json
{
  "credibility_tier": "verified",
  "credibility_score": 95.0,
  "domain_reputation": "tier1",
  "has_direct_quote": true,
  "has_speculation_language": false,
  "verification_indicators": ["direct_quote", "tier1_domain"],
  "confidence_boost": 15.0,
  "recommendation": "highly_trustworthy",
  "reasoning": [
    "Domain reputation: tier1",
    "Contains direct quote from voter",
    "Assigned tier: verified"
  ],
  "badge": {
    "color": "#10b981",
    "icon": "✓",
    "label": "Verified Source",
    "description": "Direct announcement from verified account or official source"
  },
  "assessed_at": "2026-01-07T10:30:00.000Z"
}
```

### 2. Get Domain Reputation List

```http
GET /api/credibility/domains
```

**Response:**
```json
{
  "tier1": ["ap.org", "espn.com", "nfl.com", ...],
  "tier2": ["profootballtalk.com", "usatoday.com", ...],
  "tier3": ["sportingnews.com", "fansided.com", ...],
  "social": ["twitter.com", "x.com", "instagram.com", ...],
  "forums": ["reddit.com", ...]
}
```

### 3. Add Trusted Domain

```http
POST /api/credibility/domains
Content-Type: application/json

{
  "domain": "newoutlet.com",
  "tier": "tier2"
}
```

**Response:**
```json
{
  "message": "Domain added successfully",
  "domain": "newoutlet.com",
  "tier": "tier2"
}
```

### 4. Compare Multiple Sources

```http
POST /api/credibility/compare
Content-Type: application/json

{
  "sources": [
    {
      "url": "https://espn.com/article1",
      "credibility_tier": "verified",
      "credibility_score": 95.0
    },
    {
      "url": "https://twitter.com/voter/status/123",
      "credibility_tier": "verified",
      "credibility_score": 90.0
    },
    {
      "url": "https://nfl.com/news",
      "credibility_tier": "official",
      "credibility_score": 85.0
    }
  ]
}
```

**Response:**
```json
{
  "highest_tier": "verified",
  "average_score": 90.0,
  "consensus": false,
  "num_sources": 3,
  "recommendation": "highly_confident"
}
```

### 5. Get Badge Definitions

```http
GET /api/credibility/badges
```

**Response:**
```json
{
  "verified": {
    "color": "#10b981",
    "icon": "✓",
    "label": "Verified Source",
    "description": "Direct announcement from verified account or official source"
  },
  "official": {
    "color": "#3b82f6",
    "icon": "★",
    "label": "Official",
    "description": "Major news outlet or official announcement"
  },
  ...
}
```

## Integration with NLP Pipeline

The credibility scorer is automatically integrated with vote extraction:

```python
from nlp import VoteExtractor

extractor = VoteExtractor()
votes = extractor.extract_votes_from_text(
    text="Mina Kimes said 'I'm voting for Josh Allen'",
    source_url="https://espn.com/article",
    source_type="news_article"
)

# Each vote now includes credibility information
for vote in votes:
    print(f"Credibility: {vote['credibility_tier']}")
    print(f"Score: {vote['credibility_score']}")
    print(f"Direct quote: {vote['has_direct_quote']}")
    print(f"Badge: {vote['credibility_badge']}")
```

## Frontend Display

### VoterDetail Page

Credibility badges are displayed alongside confidence badges:

```jsx
{vote.credibility_tier && (
  <span className={`credibility-badge ${vote.credibility_tier}`}>
    {getCredibilityIcon(vote.credibility_tier)}
    {getCredibilityLabel(vote.credibility_tier)}
  </span>
)}

{vote.has_direct_quote && (
  <span className="badge info-badge">
    💬 Direct Quote
  </span>
)}
```

### CSS Styling

```css
.credibility-badge.verified {
  background: #d1fae5;
  color: #065f46;
  border: 1px solid #10b981;
}

.credibility-badge.official {
  background: #dbeafe;
  color: #1e40af;
  border: 1px solid #3b82f6;
}

.credibility-badge.reliable {
  background: #e9d5ff;
  color: #6b21a8;
  border: 1px solid #8b5cf6;
}

.credibility-badge.unverified {
  background: #fed7aa;
  color: #92400e;
  border: 1px solid #f59e0b;
}

.credibility-badge.speculation {
  background: #fee2e2;
  color: #991b1b;
  border: 1px solid #ef4444;
}
```

## Usage Examples

### Example 1: High Credibility Vote

**Source**: ESPN article with direct quote
**URL**: https://espn.com/nfl/mvp-votes
**Content**: "Mina Kimes told ESPN on Tuesday that she's voting for Josh Allen as her NFL MVP."

**Assessment**:
- Credibility Tier: VERIFIED
- Score: 100/100
- Has Direct Quote: Yes
- Domain Reputation: tier1
- Recommendation: highly_trustworthy

### Example 2: Official Announcement

**Source**: NFL.com article
**URL**: https://nfl.com/news/2024-mvp-voters
**Content**: "Peter King announces his MVP selection"

**Assessment**:
- Credibility Tier: OFFICIAL
- Score: 90/100
- Has Direct Quote: No
- Domain Reputation: tier1
- Recommendation: trustworthy

### Example 3: Speculation

**Source**: Reddit comment
**URL**: https://reddit.com/r/nfl/comments/xyz
**Content**: "I think Mina Kimes will probably vote for Josh Allen based on her recent tweets"

**Assessment**:
- Credibility Tier: SPECULATION
- Score: 15/100
- Has Speculation Language: Yes
- Domain Reputation: forum
- Recommendation: treat_as_speculation

## Testing

Run the comprehensive test suite:

```bash
cd backend
python3 test_credibility.py
```

**Test Coverage**:
- CredibilityScorer initialization
- Domain reputation assessment
- Verified source detection
- Speculation detection
- Direct quote detection
- Credibility tier hierarchy
- Badge generation
- Source comparison
- Adding trusted domains
- Database migration verification
- API endpoints (requires running server)

## Database Migration

To add credibility tracking to an existing database:

```bash
cd backend
python3 database/migrate_add_credibility.py
```

**Migration adds**:
- `credibility_tier`, `credibility_score`, `has_direct_quote`, `has_speculation_language` to votes table
- `credibility_tier`, `credibility_score`, `domain_reputation` to sources table

**Check if migration needed**:
```bash
python3 database/migrate_add_credibility.py --check
```

## Best Practices

### 1. Always Assess Credibility
Call `assess_source_credibility()` for every source before storing votes:

```python
credibility_result = scorer.assess_source_credibility({
    'url': source_url,
    'content': extracted_text,
    'source_type': 'news_article',
    'voter_name': voter_name
})
```

### 2. Display Credibility Prominently
Show credibility badges alongside vote information so users can quickly assess reliability.

### 3. Filter by Credibility
Allow users to filter votes by credibility tier:
- Show only VERIFIED and OFFICIAL sources
- Hide SPECULATION sources by default
- Provide warnings for UNVERIFIED sources

### 4. Use Multiple Sources
When multiple sources report the same vote, use `compare_sources()` to determine overall credibility:

```python
comparison = scorer.compare_sources(all_sources_for_vote)
if comparison['highest_tier'] == 'verified' and comparison['consensus']:
    # High confidence - safe to display
```

### 5. Update Domain Lists
Regularly review and update trusted domain lists as new reputable outlets emerge.

## Troubleshooting

### Issue: All sources scored as "unverified"
**Solution**: Check if domain is in reputation lists. Add with `add_trusted_domain()`.

### Issue: Speculation detected incorrectly
**Solution**: Review speculation patterns and adjust regex if needed.

### Issue: Direct quotes not detected
**Solution**: Ensure quotes use standard quotation marks (" or ') and include voting keywords.

### Issue: API endpoints return 500 error
**Solution**: Check that CredibilityScorer is properly imported in app.py.

## Future Enhancements

Potential improvements for the credibility system:

1. **Machine Learning**: Train ML model on verified vs speculation sources
2. **Real-time Verification**: Check Twitter/X API for account verification status
3. **Voter Reputation**: Track historical accuracy of voters' public statements
4. **Source Age**: Factor in how recent the source is (newer = more relevant)
5. **Social Proof**: Weight sources by engagement (retweets, likes, shares)
6. **Manual Override**: Allow admins to manually adjust credibility tiers
7. **Credibility History**: Track credibility changes over time for sources
8. **External APIs**: Integrate with fact-checking services

## Summary

The Source Credibility Tracking system provides a robust, multi-factor assessment of source trustworthiness that helps users identify reliable NFL MVP voter information. By combining domain reputation, content analysis, verification indicators, and corroboration, the system assigns transparent credibility tiers and scores that inform both the system's automated processes and user decision-making.

Key benefits:
- **Transparency**: Clear tier system with reasoning
- **Automation**: Integrated with vote extraction pipeline
- **Flexibility**: Customizable domain lists and scoring weights
- **User-Friendly**: Visual badges and clear labels
- **Comprehensive**: Covers all major source types and scenarios
