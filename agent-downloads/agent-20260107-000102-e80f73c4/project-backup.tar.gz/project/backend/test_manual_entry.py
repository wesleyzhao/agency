"""
Test script for Manual Entry API endpoints (Feature #10)

Tests all CRUD operations for voters, candidates, and votes through the API.
"""
import requests
import json
from datetime import datetime

# Base URL for the API
BASE_URL = "http://localhost:5000/api"

# ANSI color codes for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def print_test(test_name):
    """Print test section header"""
    print(f"\n{BLUE}{'='*60}")
    print(f"Testing: {test_name}")
    print(f"{'='*60}{RESET}\n")

def print_success(message):
    """Print success message"""
    print(f"{GREEN}✓ {message}{RESET}")

def print_error(message):
    """Print error message"""
    print(f"{RED}✗ {message}{RESET}")

def print_info(message):
    """Print info message"""
    print(f"{YELLOW}ℹ {message}{RESET}")

def test_health_check():
    """Test health check endpoint"""
    print_test("Health Check")

    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            print_success("Health check passed")
            print(f"Response: {response.json()}")
            return True
        else:
            print_error(f"Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Health check failed with exception: {e}")
        return False

def test_voter_crud():
    """Test Voter CRUD operations"""
    print_test("Voter CRUD Operations")

    # Test 1: Create a voter
    print_info("Creating new voter: Peter King")
    voter_data = {
        "name": "Peter King",
        "outlet": "NBC Sports",
        "twitter_handle": "@peter_king",
        "location": "Montclair, NJ",
        "bio": "Senior NFL columnist for NBC Sports"
    }

    response = requests.post(f"{BASE_URL}/voters", json=voter_data)
    if response.status_code == 201:
        print_success("Voter created successfully")
        voter = response.json()
        voter_id = voter['id']
        print(f"  ID: {voter_id}, Name: {voter['name']}, Outlet: {voter['outlet']}")
    else:
        print_error(f"Failed to create voter: {response.status_code}")
        print(f"  {response.json()}")
        return None

    # Test 2: Try to create duplicate voter (should fail)
    print_info("Attempting to create duplicate voter (should fail)")
    response = requests.post(f"{BASE_URL}/voters", json=voter_data)
    if response.status_code == 409:
        print_success("Duplicate voter correctly rejected")
    else:
        print_error(f"Unexpected response for duplicate: {response.status_code}")

    # Test 3: Get voter by ID
    print_info(f"Fetching voter by ID: {voter_id}")
    response = requests.get(f"{BASE_URL}/voters/{voter_id}")
    if response.status_code == 200:
        print_success("Voter retrieved successfully")
        voter = response.json()
        print(f"  Name: {voter['name']}, Votes: {len(voter.get('votes', []))}")
    else:
        print_error(f"Failed to get voter: {response.status_code}")

    # Test 4: Update voter
    print_info("Updating voter bio")
    update_data = {
        "bio": "Senior NFL columnist for NBC Sports. FMIA author."
    }
    response = requests.put(f"{BASE_URL}/voters/{voter_id}", json=update_data)
    if response.status_code == 200:
        print_success("Voter updated successfully")
        voter = response.json()
        print(f"  New bio: {voter['bio']}")
    else:
        print_error(f"Failed to update voter: {response.status_code}")

    # Test 5: Get all voters
    print_info("Fetching all voters")
    response = requests.get(f"{BASE_URL}/voters")
    if response.status_code == 200:
        voters = response.json()
        print_success(f"Retrieved {len(voters)} voter(s)")
        for v in voters:
            print(f"  - {v['name']} ({v.get('outlet', 'N/A')})")
    else:
        print_error(f"Failed to get voters: {response.status_code}")

    return voter_id

def test_candidate_crud():
    """Test Candidate CRUD operations"""
    print_test("Candidate CRUD Operations")

    # Test 1: Create candidates
    candidates_data = [
        {
            "name": "Josh Allen",
            "team": "Buffalo Bills",
            "position": "QB",
            "season": "2024-25"
        },
        {
            "name": "Lamar Jackson",
            "team": "Baltimore Ravens",
            "position": "QB",
            "season": "2024-25"
        },
        {
            "name": "Saquon Barkley",
            "team": "Philadelphia Eagles",
            "position": "RB",
            "season": "2024-25"
        }
    ]

    candidate_ids = []
    for candidate_data in candidates_data:
        print_info(f"Creating candidate: {candidate_data['name']}")
        response = requests.post(f"{BASE_URL}/candidates", json=candidate_data)
        if response.status_code == 201:
            candidate = response.json()
            candidate_ids.append(candidate['id'])
            print_success(f"Created: {candidate['name']} ({candidate['team']})")
        else:
            print_error(f"Failed to create candidate: {response.status_code}")
            print(f"  {response.json()}")

    # Test 2: Get all candidates
    print_info("Fetching all candidates for 2024-25 season")
    response = requests.get(f"{BASE_URL}/candidates?season=2024-25")
    if response.status_code == 200:
        candidates = response.json()
        print_success(f"Retrieved {len(candidates)} candidate(s)")
        for c in candidates:
            print(f"  - {c['name']} ({c['team']}) - {c.get('vote_count', 0)} votes")
    else:
        print_error(f"Failed to get candidates: {response.status_code}")

    # Test 3: Update candidate
    if candidate_ids:
        print_info(f"Updating candidate ID: {candidate_ids[0]}")
        update_data = {"position": "Quarterback"}
        response = requests.put(f"{BASE_URL}/candidates/{candidate_ids[0]}", json=update_data)
        if response.status_code == 200:
            print_success("Candidate updated successfully")
        else:
            print_error(f"Failed to update candidate: {response.status_code}")

    return candidate_ids

def test_vote_crud(voter_id, candidate_ids):
    """Test Vote CRUD operations"""
    print_test("Vote CRUD Operations")

    if not voter_id or not candidate_ids:
        print_error("Missing voter_id or candidate_ids, skipping vote tests")
        return []

    # Test 1: Create vote using IDs
    print_info("Creating vote using voter_id and candidate_id")
    vote_data = {
        "voter_id": voter_id,
        "candidate_id": candidate_ids[0],
        "season": "2024-25",
        "ranking": 1,
        "source_url": "https://twitter.com/peter_king/status/123456789",
        "source_type": "social_media",
        "confidence": "high",
        "confidence_score": 85.5
    }

    response = requests.post(f"{BASE_URL}/votes", json=vote_data)
    vote_ids = []
    if response.status_code == 201:
        vote = response.json()
        vote_ids.append(vote['id'])
        print_success(f"Vote created: {vote['voter']} → {vote['candidate']} (Rank {vote['ranking']})")
        print(f"  Confidence: {vote['confidence']} ({vote['confidence_score']})")
    else:
        print_error(f"Failed to create vote: {response.status_code}")
        print(f"  {response.json()}")

    # Test 2: Create vote using names (auto-create voter/candidate)
    print_info("Creating vote using names (auto-create if needed)")
    vote_data2 = {
        "voter_name": "Mina Kimes",
        "candidate_name": "Saquon Barkley",
        "candidate_team": "Philadelphia Eagles",
        "candidate_position": "RB",
        "season": "2024-25",
        "ranking": 1,
        "source_url": "https://x.com/minakimes/status/2008283462403584336",
        "source_type": "social_media",
        "confidence": "high",
        "confidence_score": 90.0
    }

    response = requests.post(f"{BASE_URL}/votes", json=vote_data2)
    if response.status_code == 201:
        vote = response.json()
        vote_ids.append(vote['id'])
        print_success(f"Vote created: {vote['voter']} → {vote['candidate']} (Rank {vote['ranking']})")
    else:
        print_error(f"Failed to create vote: {response.status_code}")
        print(f"  {response.json()}")

    # Test 3: Try to create duplicate vote (should fail)
    print_info("Attempting to create duplicate vote (should fail)")
    response = requests.post(f"{BASE_URL}/votes", json=vote_data)
    if response.status_code == 409:
        print_success("Duplicate vote correctly rejected")
    else:
        print_error(f"Unexpected response for duplicate: {response.status_code}")

    # Test 4: Update vote
    if vote_ids:
        print_info(f"Updating vote ID: {vote_ids[0]}")
        update_data = {
            "confidence": "medium",
            "confidence_score": 75.0,
            "verified": True
        }
        response = requests.put(f"{BASE_URL}/votes/{vote_ids[0]}", json=update_data)
        if response.status_code == 200:
            vote = response.json()
            print_success(f"Vote updated: Confidence now {vote['confidence']} ({vote['confidence_score']})")
        else:
            print_error(f"Failed to update vote: {response.status_code}")

    # Test 5: Get all votes
    print_info("Fetching all votes for 2024-25 season")
    response = requests.get(f"{BASE_URL}/votes?season=2024-25")
    if response.status_code == 200:
        votes = response.json()
        print_success(f"Retrieved {len(votes)} vote(s)")
        for v in votes:
            print(f"  - {v['voter']} → {v['candidate']} (Rank {v.get('ranking', 'N/A')})")
    else:
        print_error(f"Failed to get votes: {response.status_code}")

    return vote_ids

def test_delete_operations(voter_id, candidate_ids, vote_ids):
    """Test DELETE operations"""
    print_test("Delete Operations")

    # Delete votes first (foreign key constraints)
    if vote_ids:
        print_info(f"Deleting vote ID: {vote_ids[0]}")
        response = requests.delete(f"{BASE_URL}/votes/{vote_ids[0]}")
        if response.status_code == 200:
            print_success(f"Vote deleted: {response.json()['message']}")
        else:
            print_error(f"Failed to delete vote: {response.status_code}")

    # Delete one candidate
    if candidate_ids and len(candidate_ids) > 2:
        print_info(f"Deleting candidate ID: {candidate_ids[2]}")
        response = requests.delete(f"{BASE_URL}/candidates/{candidate_ids[2]}")
        if response.status_code == 200:
            print_success(f"Candidate deleted: {response.json()['message']}")
        else:
            print_error(f"Failed to delete candidate: {response.status_code}")

    # Don't delete voter to preserve test data
    print_info("Keeping voter for future tests")

def test_error_handling():
    """Test error handling"""
    print_test("Error Handling")

    # Test 1: Get non-existent voter
    print_info("Fetching non-existent voter (ID: 99999)")
    response = requests.get(f"{BASE_URL}/voters/99999")
    if response.status_code == 404:
        print_success("Correctly returned 404 for non-existent voter")
    else:
        print_error(f"Unexpected status code: {response.status_code}")

    # Test 2: Create voter without required field
    print_info("Creating voter without name (should fail)")
    response = requests.post(f"{BASE_URL}/voters", json={"outlet": "ESPN"})
    if response.status_code == 400:
        print_success("Correctly returned 400 for missing required field")
    else:
        print_error(f"Unexpected status code: {response.status_code}")

    # Test 3: Create vote with invalid confidence level
    print_info("Creating vote with invalid confidence level")
    vote_data = {
        "voter_name": "Test Voter",
        "candidate_name": "Test Candidate",
        "season": "2024-25",
        "confidence": "invalid_level"
    }
    response = requests.post(f"{BASE_URL}/votes", json=vote_data)
    if response.status_code == 400:
        print_success("Correctly returned 400 for invalid confidence level")
    else:
        print_error(f"Unexpected status code: {response.status_code}")

def run_all_tests():
    """Run all tests"""
    print(f"\n{BLUE}{'='*60}")
    print("NFL MVP Voter Tracker - Manual Entry API Tests")
    print(f"{'='*60}{RESET}\n")

    # Check if server is running
    if not test_health_check():
        print_error("\nServer is not running. Please start the Flask app first:")
        print_error("  cd backend && python app.py")
        return

    # Run tests
    voter_id = test_voter_crud()
    candidate_ids = test_candidate_crud()
    vote_ids = test_vote_crud(voter_id, candidate_ids)
    test_delete_operations(voter_id, candidate_ids, vote_ids)
    test_error_handling()

    # Final summary
    print(f"\n{BLUE}{'='*60}")
    print("Test Summary")
    print(f"{'='*60}{RESET}\n")
    print_success("All manual entry API tests completed!")
    print_info("Check the output above for any errors")
    print_info("\nYou can now use these endpoints in your application:")
    print(f"  - POST   {BASE_URL}/voters")
    print(f"  - GET    {BASE_URL}/voters")
    print(f"  - GET    {BASE_URL}/voters/<id>")
    print(f"  - PUT    {BASE_URL}/voters/<id>")
    print(f"  - DELETE {BASE_URL}/voters/<id>")
    print(f"  - POST   {BASE_URL}/candidates")
    print(f"  - PUT    {BASE_URL}/candidates/<id>")
    print(f"  - DELETE {BASE_URL}/candidates/<id>")
    print(f"  - POST   {BASE_URL}/votes")
    print(f"  - PUT    {BASE_URL}/votes/<id>")
    print(f"  - DELETE {BASE_URL}/votes/<id>")

if __name__ == "__main__":
    run_all_tests()
