"""
Test script for Search and Filter functionality - Feature #14
Tests the /api/search endpoint with various query parameters
"""
import requests
import json

BASE_URL = "http://localhost:5000"

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
CYAN = '\033[96m'
RESET = '\033[0m'

def print_success(message):
    print(f"{GREEN}✓ {message}{RESET}")

def print_error(message):
    print(f"{RED}✗ {message}{RESET}")

def print_info(message):
    print(f"{YELLOW}ℹ {message}{RESET}")

def print_header(message):
    print(f"\n{BLUE}{'=' * 60}")
    print(f"{message}")
    print(f"{'=' * 60}{RESET}\n")

def test_health_check():
    """Test that backend is running"""
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        if response.status_code == 200:
            print_success("Backend server is running")
            return True
        else:
            print_error("Backend returned unexpected status code")
            return False
    except requests.exceptions.ConnectionError:
        print_error("Cannot connect to backend server")
        print_info("Please start the backend server with: cd backend && python3 app.py")
        return False

def test_basic_search():
    """Test basic search functionality"""
    print_info("Testing basic search with general query...")

    # Search for "peter" (should match Peter King)
    response = requests.get(f"{BASE_URL}/api/search?q=peter")

    if response.status_code != 200:
        print_error(f"Search returned status code {response.status_code}")
        return False

    data = response.json()

    # Verify response structure
    if 'results' not in data or 'count' not in data:
        print_error("Response missing required fields")
        return False

    print_success(f"Basic search returned {data['count']} results")

    # Display results
    if data['count'] > 0:
        print(f"\n{CYAN}Results for query 'peter':{RESET}")
        for voter in data['results']:
            print(f"  - {voter['name']} ({voter['outlet'] or 'No outlet'}) - {voter['vote_count']} votes")

    return True

def test_voter_name_filter():
    """Test filtering by voter name"""
    print_info("Testing voter name filter...")

    response = requests.get(f"{BASE_URL}/api/search?voter_name=mina")

    if response.status_code != 200:
        print_error(f"Voter name filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Voter name filter returned {data['count']} results")

    # Verify all results contain "mina" in the name
    for voter in data['results']:
        if 'mina' not in voter['name'].lower():
            print_error(f"Result '{voter['name']}' doesn't match filter")
            return False

    if data['count'] > 0:
        print(f"\n{CYAN}Voters matching 'mina':{RESET}")
        for voter in data['results']:
            print(f"  - {voter['name']} - {voter['vote_count']} votes")

    return True

def test_outlet_filter():
    """Test filtering by outlet"""
    print_info("Testing outlet filter...")

    response = requests.get(f"{BASE_URL}/api/search?outlet=espn")

    if response.status_code != 200:
        print_error(f"Outlet filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Outlet filter returned {data['count']} results")

    if data['count'] > 0:
        print(f"\n{CYAN}Voters from ESPN:{RESET}")
        for voter in data['results']:
            print(f"  - {voter['name']} ({voter['outlet']})")

    return True

def test_candidate_filter():
    """Test filtering by candidate voted for"""
    print_info("Testing candidate filter...")

    response = requests.get(f"{BASE_URL}/api/search?candidate_name=saquon")

    if response.status_code != 200:
        print_error(f"Candidate filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Candidate filter returned {data['count']} results")

    if data['count'] > 0:
        print(f"\n{CYAN}Voters who voted for Saquon Barkley:{RESET}")
        for voter in data['results']:
            print(f"  - {voter['name']}")
            for vote in voter['ballot']:
                if 'saquon' in vote['candidate'].lower():
                    print(f"    #{vote['ranking']}: {vote['candidate']} ({vote['confidence']})")

    return True

def test_confidence_filter():
    """Test filtering by confidence level"""
    print_info("Testing confidence filter...")

    response = requests.get(f"{BASE_URL}/api/search?confidence=high")

    if response.status_code != 200:
        print_error(f"Confidence filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Confidence filter (high) returned {data['count']} results")

    if data['count'] > 0:
        print(f"\n{CYAN}Voters with high-confidence votes:{RESET}")
        for voter in data['results']:
            high_conf_votes = [v for v in voter['ballot'] if v['confidence'] == 'high']
            print(f"  - {voter['name']} ({len(high_conf_votes)} high-confidence votes)")

    return True

def test_verified_filter():
    """Test filtering for verified votes only"""
    print_info("Testing verified votes filter...")

    response = requests.get(f"{BASE_URL}/api/search?verified_only=true")

    if response.status_code != 200:
        print_error(f"Verified filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Verified votes filter returned {data['count']} results")

    if data['count'] > 0:
        print(f"\n{CYAN}Voters with verified votes:{RESET}")
        for voter in data['results']:
            verified_votes = [v for v in voter['ballot'] if v['verified']]
            print(f"  - {voter['name']} ({len(verified_votes)} verified votes)")

    return True

def test_ballot_status_filter():
    """Test filtering by ballot status"""
    print_info("Testing ballot status filters...")

    # Test full ballot
    response = requests.get(f"{BASE_URL}/api/search?has_ballot=full")
    data = response.json()
    print_success(f"Full ballot filter returned {data['count']} results")

    # Test any votes
    response = requests.get(f"{BASE_URL}/api/search?has_ballot=any")
    data = response.json()
    print_success(f"Any votes filter returned {data['count']} results")

    # Test no votes
    response = requests.get(f"{BASE_URL}/api/search?has_ballot=none")
    data = response.json()
    print_success(f"No votes filter returned {data['count']} results")

    return True

def test_combined_filters():
    """Test combining multiple filters"""
    print_info("Testing combined filters...")

    # Search for ESPN voters who voted for a specific candidate
    response = requests.get(f"{BASE_URL}/api/search?outlet=espn&candidate_name=allen")

    if response.status_code != 200:
        print_error(f"Combined filter returned status code {response.status_code}")
        return False

    data = response.json()
    print_success(f"Combined filter (ESPN + Allen) returned {data['count']} results")

    if data['count'] > 0:
        print(f"\n{CYAN}ESPN voters who voted for Josh Allen:{RESET}")
        for voter in data['results']:
            print(f"  - {voter['name']} ({voter['outlet']})")
            for vote in voter['ballot']:
                if 'allen' in vote['candidate'].lower():
                    print(f"    #{vote['ranking']}: {vote['candidate']}")

    return True

def test_filters_applied_metadata():
    """Test that filters_applied metadata is correct"""
    print_info("Testing filters_applied metadata...")

    response = requests.get(f"{BASE_URL}/api/search?q=test&outlet=espn&confidence=high")

    if response.status_code != 200:
        print_error(f"Search returned status code {response.status_code}")
        return False

    data = response.json()

    if 'filters_applied' not in data:
        print_error("Response missing filters_applied field")
        return False

    filters = data['filters_applied']

    # Verify filters are captured
    if filters['query'] != 'test':
        print_error("Query filter not captured correctly")
        return False

    if filters['outlet'] != 'espn':
        print_error("Outlet filter not captured correctly")
        return False

    if filters['confidence'] != 'high':
        print_error("Confidence filter not captured correctly")
        return False

    print_success("Filters metadata is correct")
    print(f"\n{CYAN}Filters applied:{RESET}")
    print(f"  {json.dumps(filters, indent=2)}")

    return True

def main():
    print_header("Testing Search and Filter API - Feature #14")

    # Run all tests
    tests = [
        ("Health Check", test_health_check),
        ("Basic Search", test_basic_search),
        ("Voter Name Filter", test_voter_name_filter),
        ("Outlet Filter", test_outlet_filter),
        ("Candidate Filter", test_candidate_filter),
        ("Confidence Filter", test_confidence_filter),
        ("Verified Filter", test_verified_filter),
        ("Ballot Status Filter", test_ballot_status_filter),
        ("Combined Filters", test_combined_filters),
        ("Filters Metadata", test_filters_applied_metadata)
    ]

    passed = 0
    failed = 0

    for test_name, test_func in tests:
        try:
            print(f"\n{YELLOW}Running: {test_name}{RESET}")
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print_error(f"Test failed with exception: {e}")
            failed += 1

    # Print summary
    print_header("Test Summary")
    print(f"Total tests: {passed + failed}")
    print_success(f"Passed: {passed}")
    if failed > 0:
        print_error(f"Failed: {failed}")
    else:
        print_success("All tests PASSED! ✓")

    print_info("\nTo use the search API:")
    print("  General search:  GET /api/search?q=mina")
    print("  Voter name:      GET /api/search?voter_name=peter")
    print("  Outlet:          GET /api/search?outlet=espn")
    print("  Candidate:       GET /api/search?candidate_name=allen")
    print("  Confidence:      GET /api/search?confidence=high")
    print("  Verified only:   GET /api/search?verified_only=true")
    print("  Ballot status:   GET /api/search?has_ballot=full")
    print("  Combined:        GET /api/search?outlet=espn&confidence=high")

if __name__ == '__main__':
    main()
