"""
Rebuild database with latest schema
"""
import os
import sys

# Add database directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'database'))

from sqlalchemy import create_engine
from models import Base

# Database URL
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///data/mvp_tracker.db')

print("=" * 60)
print("Rebuilding Database with Latest Schema")
print("=" * 60)

# Backup old database
db_path = 'data/mvp_tracker.db'
if os.path.exists(db_path):
    backup_path = db_path + '.backup'
    import shutil
    shutil.copy(db_path, backup_path)
    print(f"✓ Backed up database to {backup_path}")

# Create engine
engine = create_engine(DATABASE_URL)

# Drop all tables
print("Dropping all existing tables...")
Base.metadata.drop_all(bind=engine)
print("✓ Dropped all tables")

# Create all tables with latest schema
print("Creating tables with latest schema...")
Base.metadata.create_all(bind=engine)
print("✓ Created all tables")

print("\n" + "=" * 60)
print("Database rebuilt successfully!")
print("=" * 60)
