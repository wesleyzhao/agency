"""
Test Historical MVP Voting Data Feature (#17)

This test suite verifies:
- Historical data API endpoints
- Season filtering
- Data structure and completeness
- Historical data retrieval
"""
import requests
import json

# ANSI color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

BASE_URL = 'http://localhost:5000'

def print_header(text):
    """Print formatted header"""
    print("\n" + "=" * 60)
    print(text)
    print("=" * 60 + "\n")

def print_success(text):
    """Print success message in green"""
    print(f"{GREEN}✓ {text}{RESET}")

def print_error(text):
    """Print error message in red"""
    print(f"{RED}✗ {text}{RESET}")

def print_info(text):
    """Print info message in yellow"""
    print(f"{YELLOW}ℹ {text}{RESET}")

def print_data(text):
    """Print data in cyan"""
    print(f"{CYAN}{text}{RESET}")


def test_health_check():
    """Test that backend server is running"""
    try:
        response = requests.get(f'{BASE_URL}/api/health', timeout=5)
        if response.status_code == 200:
            print_success("Backend server is running")
            return True
        else:
            print_error(f"Backend returned status code {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print_error("Cannot connect to backend server")
        print_info("Please start the server with: cd backend && python3 app.py")
        return False


def test_get_all_historical_data():
    """Test retrieving all historical data"""
    print_info("Testing: GET /api/historical (all seasons)")

    try:
        response = requests.get(f'{BASE_URL}/api/historical')

        if response.status_code == 200:
            print_success("Historical data endpoint returned 200 OK")

            data = response.json()

            # Check response structure
            if 'historical_data' in data:
                print_success("Response contains 'historical_data' field")
            else:
                print_error("Response missing 'historical_data' field")
                return False

            if 'all_seasons' in data:
                print_success("Response contains 'all_seasons' field")
            else:
                print_error("Response missing 'all_seasons' field")
                return False

            # Display available seasons
            seasons = data['all_seasons']
            print_data(f"\n  Available seasons: {', '.join(seasons) if seasons else 'None'}")
            print_data(f"  Total seasons: {len(seasons)}")

            # Display data for each season
            for season_data in data['historical_data']:
                season = season_data['season']
                winner = season_data['winner']
                total_voters = season_data['total_voters']
                num_candidates = len(season_data['candidates'])

                print_data(f"\n  {season}:")
                print_data(f"    Winner: {winner}")
                print_data(f"    Total voters: {total_voters}")
                print_data(f"    Candidates: {num_candidates}")

                # Show top 3 candidates
                if season_data['candidates']:
                    print_data(f"    Top 3:")
                    for i, candidate in enumerate(season_data['candidates'][:3], 1):
                        print_data(f"      {i}. {candidate['name']} ({candidate['team']}) - {candidate['total_points']} pts")

            return True
        else:
            print_error(f"Endpoint returned status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

    except Exception as e:
        print_error(f"Test failed with exception: {str(e)}")
        return False


def test_get_specific_season():
    """Test retrieving data for a specific season"""
    print_info("Testing: GET /api/historical?season=2023-24")

    try:
        response = requests.get(f'{BASE_URL}/api/historical?season=2023-24')

        if response.status_code == 200:
            print_success("Specific season endpoint returned 200 OK")

            data = response.json()

            # Check that only one season is returned
            if len(data['historical_data']) <= 1:
                print_success(f"Response contains {len(data['historical_data'])} season(s)")
            else:
                print_error(f"Expected 0-1 season, got {len(data['historical_data'])}")
                return False

            if data['historical_data']:
                season_data = data['historical_data'][0]

                # Verify it's the correct season
                if season_data['season'] == '2023-24':
                    print_success("Correct season returned (2023-24)")
                else:
                    print_error(f"Wrong season returned: {season_data['season']}")
                    return False

                # Display season details
                print_data(f"\n  Season: {season_data['season']}")
                print_data(f"  Winner: {season_data['winner']}")
                print_data(f"  Total voters: {season_data['total_voters']}")
                print_data(f"  Candidates: {len(season_data['candidates'])}")

                # Display voter ballots
                if season_data['voter_ballots']:
                    print_data(f"\n  Voter Ballots:")
                    for voter_ballot in season_data['voter_ballots']:
                        print_data(f"    {voter_ballot['voter_name']} ({voter_ballot['outlet']}):")
                        for vote in voter_ballot['ballot']:
                            print_data(f"      #{vote['ranking']}: {vote['candidate']} ({vote['team']})")
            else:
                print_info("No data for 2023-24 season (this is ok if database is empty)")

            return True
        else:
            print_error(f"Endpoint returned status code {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Test failed with exception: {str(e)}")
        return False


def test_historical_seasons_endpoint():
    """Test the /api/historical/seasons endpoint"""
    print_info("Testing: GET /api/historical/seasons")

    try:
        response = requests.get(f'{BASE_URL}/api/historical/seasons')

        if response.status_code == 200:
            print_success("Historical seasons endpoint returned 200 OK")

            data = response.json()

            if 'seasons' in data and 'total_seasons' in data:
                print_success("Response contains required fields")
                print_data(f"\n  Total seasons: {data['total_seasons']}")
                print_data(f"  Seasons: {', '.join(data['seasons']) if data['seasons'] else 'None'}")
                return True
            else:
                print_error("Response missing required fields")
                return False
        else:
            print_error(f"Endpoint returned status code {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Test failed with exception: {str(e)}")
        return False


def run_all_tests():
    """Run all test cases"""
    print_header("Testing Historical MVP Voting Data - Feature #17")

    tests = [
        ("Health Check", test_health_check),
        ("Get All Historical Data", test_get_all_historical_data),
        ("Get Specific Season", test_get_specific_season),
        ("Historical Seasons Endpoint", test_historical_seasons_endpoint),
    ]

    results = []
    for test_name, test_func in tests:
        print(f"\n{YELLOW}Running: {test_name}{RESET}")
        print("-" * 60)
        result = test_func()
        results.append((test_name, result))

    # Print summary
    print_header("Test Summary")
    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print("\n" + "=" * 60)
    if passed == total:
        print(f"{GREEN}All tests PASSED! ✓ ({passed}/{total}){RESET}")
    else:
        print(f"{RED}Some tests FAILED ({passed}/{total} passed){RESET}")
    print("=" * 60 + "\n")

    print_info("Frontend Testing:")
    print_info("1. Start frontend: cd frontend && npm start")
    print_info("2. Visit http://localhost:3000")
    print_info("3. Click '📜 View Historical' button in Dashboard header")
    print_info("4. Verify historical data displays correctly")

    return passed == total


if __name__ == '__main__':
    success = run_all_tests()
    exit(0 if success else 1)
