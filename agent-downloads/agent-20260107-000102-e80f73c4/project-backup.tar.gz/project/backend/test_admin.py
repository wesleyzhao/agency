"""
Test suite for Admin Interface - Feature #21
Tests all admin API endpoints for verifying, editing, and managing voter data
"""
import requests
import json
from datetime import datetime

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

API_URL = 'http://localhost:5000'


def print_success(message):
    print(f"{GREEN}✓{RESET} {message}")


def print_error(message):
    print(f"{RED}✗{RESET} {message}")


def print_info(message):
    print(f"{CYAN}ℹ{RESET} {message}")


def print_warning(message):
    print(f"{YELLOW}⚠{RESET} {message}")


def test_admin_stats():
    """Test 1: Admin Statistics Endpoint"""
    print("\n" + "="*60)
    print("Test 1: Admin Statistics Endpoint")
    print("="*60)

    try:
        response = requests.get(f'{API_URL}/api/admin/stats?season=2024-25')

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            return False

        data = response.json()
        print_success("Admin stats endpoint returned 200 OK")

        # Verify required fields
        required_fields = [
            'season', 'total_votes', 'verified_votes', 'unverified_votes',
            'verification_rate', 'confidence_breakdown', 'source_breakdown',
            'credibility_breakdown', 'recent_unverified'
        ]

        for field in required_fields:
            if field in data:
                print_success(f"Contains '{field}' field")
            else:
                print_error(f"Missing '{field}' field")
                return False

        # Display stats
        print_info(f"\nAdmin Statistics for {data['season']}:")
        print_info(f"  Total Votes: {data['total_votes']}")
        print_info(f"  Verified Votes: {data['verified_votes']}")
        print_info(f"  Unverified Votes: {data['unverified_votes']}")
        print_info(f"  Verification Rate: {data['verification_rate']}%")

        print_info(f"\n  Confidence Breakdown:")
        for level, count in data['confidence_breakdown'].items():
            print_info(f"    {level}: {count}")

        print_info(f"\n  Recent Unverified: {len(data['recent_unverified'])} votes")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_get_unverified_votes():
    """Test 2: Get Unverified Votes Endpoint"""
    print("\n" + "="*60)
    print("Test 2: Get Unverified Votes Endpoint")
    print("="*60)

    try:
        response = requests.get(f'{API_URL}/api/admin/unverified?season=2024-25')

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            return False

        data = response.json()
        print_success("Unverified votes endpoint returned 200 OK")

        # Verify structure
        if 'unverified_votes' in data and 'count' in data and 'season' in data:
            print_success("Response contains required fields")
        else:
            print_error("Missing required fields")
            return False

        print_info(f"\nFound {data['count']} unverified votes")

        if data['count'] > 0:
            # Display first unverified vote
            vote = data['unverified_votes'][0]
            print_info(f"\nFirst Unverified Vote:")
            print_info(f"  ID: {vote['id']}")
            print_info(f"  Voter: {vote['voter']['name']}")
            print_info(f"  Candidate: {vote['candidate']['name']}")
            print_info(f"  Ranking: #{vote['ranking']}")
            print_info(f"  Confidence: {vote['confidence']} ({vote['confidence_score']})")
            print_info(f"  Source Type: {vote['source_type']}")
            print_info(f"  Credibility: {vote['credibility_tier']}")
            return vote['id']  # Return ID for use in next tests
        else:
            print_warning("No unverified votes found (all votes are verified)")
            return None

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_verify_vote(vote_id):
    """Test 3: Verify Vote Endpoint"""
    print("\n" + "="*60)
    print("Test 3: Verify Vote Endpoint")
    print("="*60)

    if vote_id is None:
        print_warning("Skipping test - no unverified votes available")
        return True

    try:
        # First, let's create an unverified vote for testing
        print_info("Creating a test unverified vote...")

        # Create voter
        voter_data = {
            'name': f'Test Admin Voter {datetime.now().timestamp()}',
            'outlet': 'Test Outlet',
            'twitter_handle': '@testadmin'
        }
        voter_response = requests.post(f'{API_URL}/api/voters', json=voter_data)
        voter = voter_response.json()
        voter_id = voter.get('id') or voter.get('voter_id')

        # Create vote (unverified by default from manual entry)
        vote_data = {
            'voter_id': voter_id,
            'voter_name': voter_data['name'],
            'candidate_name': 'Josh Allen',
            'candidate_team': 'Buffalo Bills',
            'season': '2024-25',
            'ranking': 1,
            'confidence': 'medium',
            'source_type': 'speculation',
            'verified': False  # Explicitly unverified
        }
        vote_response = requests.post(f'{API_URL}/api/votes', json=vote_data)

        if vote_response.status_code in [200, 201]:
            vote_result = vote_response.json()
            test_vote_id = vote_result.get('id') or vote_result.get('vote_id')
            print_success(f"Created test vote ID: {test_vote_id}")
        else:
            print_error(f"Failed to create test vote: {vote_response.text}")
            return False

        # Now verify the vote
        verify_data = {
            'verified': True,
            'credibility_tier': 'verified'
        }

        response = requests.post(
            f'{API_URL}/api/admin/votes/{test_vote_id}/verify',
            json=verify_data
        )

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

        result = response.json()
        print_success("Vote verification endpoint returned 200 OK")

        if result.get('verified') == True:
            print_success(f"Vote verified successfully")
            print_info(f"  Vote ID: {result['vote_id']}")
            print_info(f"  Credibility Tier: {result['credibility_tier']}")
        else:
            print_error("Vote was not marked as verified")
            return False

        # Cleanup: delete test vote and voter
        requests.delete(f'{API_URL}/api/admin/votes/{test_vote_id}')
        requests.delete(f'{API_URL}/api/voters/{voter_id}')

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_update_vote(vote_id):
    """Test 4: Update Vote Endpoint"""
    print("\n" + "="*60)
    print("Test 4: Update Vote Endpoint")
    print("="*60)

    try:
        # Create a test vote
        print_info("Creating a test vote for update...")

        voter_data = {
            'name': f'Test Update Voter {datetime.now().timestamp()}',
            'outlet': 'Update Test Outlet'
        }
        voter_response = requests.post(f'{API_URL}/api/voters', json=voter_data)
        voter = voter_response.json()
        voter_id = voter.get('id') or voter.get('voter_id')

        vote_data = {
            'voter_id': voter_id,
            'voter_name': voter_data['name'],
            'candidate_name': 'Lamar Jackson',
            'candidate_team': 'Baltimore Ravens',
            'season': '2024-25',
            'ranking': 2,
            'confidence': 'low',
            'confidence_score': 40.0
        }
        vote_response = requests.post(f'{API_URL}/api/votes', json=vote_data)
        vote_result = vote_response.json()
        test_vote_id = vote_result.get('id') or vote_result.get('vote_id')
        print_success(f"Created test vote ID: {test_vote_id}")

        # Update the vote
        update_data = {
            'ranking': 1,
            'confidence': 'high',
            'confidence_score': 85.0,
            'source_type': 'news_article',
            'credibility_tier': 'official'
        }

        response = requests.put(
            f'{API_URL}/api/admin/votes/{test_vote_id}',
            json=update_data
        )

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

        result = response.json()
        print_success("Vote update endpoint returned 200 OK")
        print_info(f"  Updated Vote ID: {result['vote_id']}")
        print_info(f"  New Ranking: #{result['ranking']}")

        # Cleanup
        requests.delete(f'{API_URL}/api/admin/votes/{test_vote_id}')
        requests.delete(f'{API_URL}/api/voters/{voter_id}')

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_delete_vote():
    """Test 5: Delete Vote Endpoint"""
    print("\n" + "="*60)
    print("Test 5: Delete Vote Endpoint")
    print("="*60)

    try:
        # Create a test vote to delete
        print_info("Creating a test vote for deletion...")

        voter_data = {
            'name': f'Test Delete Voter {datetime.now().timestamp()}',
            'outlet': 'Delete Test Outlet'
        }
        voter_response = requests.post(f'{API_URL}/api/voters', json=voter_data)
        voter = voter_response.json()
        voter_id = voter.get('id') or voter.get('voter_id')

        vote_data = {
            'voter_id': voter_id,
            'voter_name': voter_data['name'],
            'candidate_name': 'Joe Burrow',
            'season': '2024-25',
            'ranking': 3
        }
        vote_response = requests.post(f'{API_URL}/api/votes', json=vote_data)
        vote_result = vote_response.json()
        test_vote_id = vote_result.get('id') or vote_result.get('vote_id')
        print_success(f"Created test vote ID: {test_vote_id}")

        # Delete the vote
        response = requests.delete(f'{API_URL}/api/admin/votes/{test_vote_id}')

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

        result = response.json()
        print_success("Vote deletion endpoint returned 200 OK")
        print_info(f"  Deleted Vote ID: {result['vote_id']}")

        # Cleanup voter
        requests.delete(f'{API_URL}/api/voters/{voter_id}')

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_update_voter():
    """Test 6: Update Voter Endpoint"""
    print("\n" + "="*60)
    print("Test 6: Update Voter Endpoint")
    print("="*60)

    try:
        # Create a test voter
        print_info("Creating a test voter for update...")

        voter_data = {
            'name': f'Test Voter Update {datetime.now().timestamp()}',
            'outlet': 'Original Outlet',
            'twitter_handle': '@original'
        }
        response = requests.post(f'{API_URL}/api/voters', json=voter_data)
        voter = response.json()
        voter_id = voter.get('id') or voter.get('voter_id')
        print_success(f"Created test voter ID: {voter_id}")

        # Update the voter
        update_data = {
            'outlet': 'Updated Outlet',
            'twitter_handle': '@updated',
            'location': 'New York, NY',
            'bio': 'Updated bio for testing'
        }

        response = requests.put(
            f'{API_URL}/api/admin/voters/{voter_id}',
            json=update_data
        )

        if response.status_code != 200:
            print_error(f"Failed with status code {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

        result = response.json()
        print_success("Voter update endpoint returned 200 OK")
        print_info(f"  Updated Voter ID: {result['voter_id']}")
        print_info(f"  New Outlet: {result['outlet']}")

        # Cleanup
        requests.delete(f'{API_URL}/api/voters/{voter_id}')

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def test_filters():
    """Test 7: Unverified Votes with Filters"""
    print("\n" + "="*60)
    print("Test 7: Unverified Votes with Filters")
    print("="*60)

    try:
        # Test confidence filter
        response = requests.get(
            f'{API_URL}/api/admin/unverified?season=2024-25&confidence=low'
        )

        if response.status_code != 200:
            print_error(f"Confidence filter failed with status {response.status_code}")
            return False

        data = response.json()
        print_success(f"Confidence filter returned {data['count']} low-confidence votes")

        # Test source type filter
        response = requests.get(
            f'{API_URL}/api/admin/unverified?season=2024-25&source_type=speculation'
        )

        if response.status_code != 200:
            print_error(f"Source type filter failed with status {response.status_code}")
            return False

        data = response.json()
        print_success(f"Source type filter returned {data['count']} speculation votes")

        return True

    except Exception as e:
        print_error(f"Exception: {e}")
        return False


def main():
    """Run all admin interface tests"""
    print("\n" + "="*60)
    print("Testing Admin Interface - Feature #21")
    print("="*60)
    print("\nThis test suite verifies all admin API endpoints:")
    print("  1. Admin statistics")
    print("  2. Get unverified votes")
    print("  3. Verify vote")
    print("  4. Update vote")
    print("  5. Delete vote")
    print("  6. Update voter")
    print("  7. Filters")

    # Check if backend is running
    try:
        response = requests.get(f'{API_URL}/api/voters')
        if response.status_code != 200:
            print_error("\nBackend server is not responding correctly!")
            print_warning("Please start the backend server:")
            print_warning("  cd backend && python3 app.py")
            return
    except requests.exceptions.ConnectionError:
        print_error("\nCannot connect to backend server!")
        print_warning("Please start the backend server:")
        print_warning("  cd backend && python3 app.py")
        return

    print_success("\nBackend server is running")

    # Run tests
    results = []

    results.append(("Admin Statistics", test_admin_stats()))

    vote_id = test_get_unverified_votes()
    results.append(("Get Unverified Votes", vote_id is not False))

    results.append(("Verify Vote", test_verify_vote(vote_id)))
    results.append(("Update Vote", test_update_vote(vote_id)))
    results.append(("Delete Vote", test_delete_vote()))
    results.append(("Update Voter", test_update_voter()))
    results.append(("Filters", test_filters()))

    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print("\n" + "="*60)
    if passed == total:
        print_success(f"All tests PASSED! ({passed}/{total})")
    else:
        print_warning(f"Some tests failed ({passed}/{total} passed)")
    print("="*60)

    print("\n" + CYAN + "Frontend Testing:" + RESET)
    print("  1. Start backend: cd backend && python3 app.py")
    print("  2. Start frontend: cd frontend && npm start")
    print("  3. Navigate to: http://localhost:3000/admin")
    print("  4. Test the admin interface:")
    print("     - View unverified votes")
    print("     - Filter by confidence/source")
    print("     - Edit vote details")
    print("     - Verify/approve votes")
    print("     - Delete false positives")


if __name__ == '__main__':
    main()
