# Database Seeding Guide

Complete guide to seeding the NFL MVP Voter Tracker database with confirmed voters, candidates, and publicly disclosed votes.

## Table of Contents

- [Overview](#overview)
- [Quick Start](#quick-start)
- [Seed Data](#seed-data)
- [Usage](#usage)
- [Command-Line Options](#command-line-options)
- [Testing](#testing)
- [Adding New Data](#adding-new-data)
- [Troubleshooting](#troubleshooting)
- [Best Practices](#best-practices)

---

## Overview

The database seeding script (`seed_database.py`) populates the database with:

1. **Confirmed AP MVP Voters** (15 pre-configured voters)
   - Name, outlet, Twitter handle, location, bio
   - Historical voting seasons

2. **2024-25 MVP Candidates** (15 candidates)
   - Player name, team, position, season

3. **Publicly Disclosed Votes** (as available)
   - Voter → Candidate mappings with rankings
   - Source URLs, confidence scores, verification status

### Key Features

- ✓ **Idempotent**: Safe to run multiple times (skips duplicates)
- ✓ **Validated**: Comprehensive data validation before insertion
- ✓ **Logged**: All operations logged via logging system
- ✓ **Tested**: Complete test suite verifies correctness
- ✓ **Flexible**: Command-line options for selective seeding

---

## Quick Start

### 1. Basic Seeding (First Time)

```bash
cd backend
python3 seed_database.py
```

This will:
- Add 15 confirmed AP voters
- Add 15 MVP candidates for 2024-25 season
- Add any publicly disclosed votes

### 2. Output Example

```
============================================================
NFL MVP VOTER TRACKER - DATABASE SEEDING
============================================================

ℹ Seeding 15 confirmed AP voters...
✓ Added voter: Tom Brady (Fox Sports)
✓ Added voter: Mina Kimes (ESPN)
✓ Added voter: Peter King (NBC Sports)
...
✓ Voters seeded: 15 added, 0 skipped

ℹ Seeding 15 MVP candidates...
✓ Added candidate: Josh Allen (Buffalo Bills - QB)
✓ Added candidate: Lamar Jackson (Baltimore Ravens - QB)
✓ Added candidate: Saquon Barkley (Philadelphia Eagles - RB)
...
✓ Candidates seeded: 15 added, 0 skipped

ℹ Seeding 1 confirmed votes...
✓ Added vote: Mina Kimes → Saquon Barkley (#1)
✓ Votes seeded: 1 added, 0 skipped

============================================================
DATABASE SUMMARY
============================================================
ℹ Total Voters: 15
ℹ Total Candidates: 15
ℹ Total Votes: 1
ℹ Verified Votes: 1
ℹ Voters with Disclosed Votes: 1
ℹ Candidates with Votes: 1
============================================================
```

---

## Seed Data

### Confirmed AP Voters (15)

The script includes these confirmed AP MVP voters:

1. **Tom Brady** - Fox Sports
2. **Mina Kimes** - ESPN
3. **Peter King** - NBC Sports
4. **Adam Schefter** - ESPN
5. **Albert Breer** - Sports Illustrated
6. **Judy Battista** - NFL Media
7. **Dianna Russini** - The Athletic
8. **Dan Graziano** - ESPN
9. **Jeremy Fowler** - ESPN
10. **Mike Florio** - ProFootballTalk
11. **Mike Sando** - The Athletic
12. **Jeff McLane** - Philadelphia Inquirer
13. **Jason La Canfora** - Washington Post
14. **Michael Silver** - San Francisco Chronicle
15. **Jourdan Rodrigue** - The Athletic

Each voter includes:
- Full name
- Media outlet affiliation
- Twitter handle (for verification)
- Location (optional)
- Biography (optional)
- Historical voting seasons

### MVP Candidates (15)

The script includes these 2024-25 MVP candidates:

**Quarterbacks:**
- Josh Allen (Buffalo Bills)
- Lamar Jackson (Baltimore Ravens)
- Joe Burrow (Cincinnati Bengals)
- Jared Goff (Detroit Lions)
- Patrick Mahomes (Kansas City Chiefs)
- Jalen Hurts (Philadelphia Eagles)
- Sam Darnold (Minnesota Vikings)
- Baker Mayfield (Tampa Bay Buccaneers)
- Jayden Daniels (Washington Commanders)
- Justin Herbert (Los Angeles Chargers)
- Jordan Love (Green Bay Packers)
- Matthew Stafford (Los Angeles Rams)
- Brock Purdy (San Francisco 49ers)

**Running Backs:**
- Saquon Barkley (Philadelphia Eagles)
- Derrick Henry (Baltimore Ravens)

### Publicly Disclosed Votes

Currently includes:
- **Mina Kimes → Saquon Barkley** (#1)
  - Source: https://x.com/minakimes/status/2008283462403584336
  - Verified, high confidence

**Note**: As more votes are publicly disclosed, they can be added to the `CONFIRMED_VOTES` list in `seed_database.py`.

---

## Usage

### Basic Usage

```bash
# Seed all data (voters, candidates, votes)
python3 seed_database.py
```

### Clear and Re-seed

```bash
# WARNING: This deletes ALL existing data
python3 seed_database.py --clear
```

### Selective Seeding

```bash
# Only seed voters
python3 seed_database.py --voters-only

# Only seed candidates
python3 seed_database.py --candidates-only

# Only seed votes (requires voters and candidates to exist)
python3 seed_database.py --votes-only
```

### Combining Options

```bash
# Clear database and re-seed only voters
python3 seed_database.py --clear --voters-only

# Clear and re-seed everything
python3 seed_database.py --clear
```

---

## Command-Line Options

| Option | Description |
|--------|-------------|
| `--clear` | Clear all existing data before seeding (WARNING: Destructive) |
| `--voters-only` | Only seed voters table |
| `--candidates-only` | Only seed candidates table |
| `--votes-only` | Only seed votes table (requires voters & candidates) |

---

## Testing

### Run Test Suite

```bash
cd backend
python3 test_seed_database.py
```

### Test Coverage

The test suite includes 7 comprehensive tests:

1. **Database Connection**: Verifies database is accessible
2. **Seed Script Exists**: Checks if seed_database.py exists
3. **Seed Data Structure**: Validates all seed data has required fields
4. **Database Seeding**: Runs the seeding process
5. **Verify Seeded Data**: Confirms data was inserted correctly
6. **Database Integrity**: Checks for duplicates and valid relationships
7. **Idempotency**: Verifies seeding can run multiple times safely

### Expected Output

```
============================================================
Test 1: Database Connection
============================================================
✓ Database connection successful
ℹ Current voter count: 15

...

============================================================
Test Summary
============================================================
✓ Database Connection
✓ Seed Script Exists
✓ Seed Data Structure
✓ Database Seeding
✓ Verify Seeded Data
✓ Database Integrity
✓ Idempotency

ℹ Total: 7 passed, 0 failed out of 7 tests

✓ All tests PASSED!
```

---

## Adding New Data

### Adding a New Voter

Edit `seed_database.py` and add to the `CONFIRMED_VOTERS` list:

```python
{
    "name": "New Voter Name",
    "outlet": "Media Outlet",
    "twitter_handle": "@twitterhandle",
    "location": "City, State",  # Optional
    "bio": "Brief bio...",       # Optional
    "historical_seasons": ["2024-25"]
}
```

### Adding a New Candidate

Edit `seed_database.py` and add to the `MVP_CANDIDATES` list:

```python
{
    "name": "Player Name",
    "team": "Team Name",
    "position": "QB",  # or RB, WR, etc.
    "season": "2024-25"
}
```

### Adding a Publicly Disclosed Vote

Edit `seed_database.py` and add to the `CONFIRMED_VOTES` list:

```python
{
    "voter_name": "Voter Name",          # Must match name in CONFIRMED_VOTERS
    "candidate_name": "Candidate Name",  # Must match name in MVP_CANDIDATES
    "ranking": 1,                        # 1-5
    "season": "2024-25",
    "source_url": "https://...",         # Twitter, article, etc.
    "source_type": "social_media",       # official, social_media, news_article, reddit, speculation
    "confidence": "high",                # high, medium, low
    "confidence_score": 95.0,            # 0-100
    "verified": True,                    # True/False
    "credibility_tier": "verified",      # verified, official, reliable, unverified, speculation
    "announcement_date": "2025-01-05T00:00:00",  # ISO 8601 format
    "extracted_text": "Description of how the vote was announced"
}
```

### Re-run Seeding

After adding new data:

```bash
python3 seed_database.py
```

The script will:
- Skip existing voters/candidates/votes (no duplicates)
- Add only the new entries

---

## Troubleshooting

### Problem: "Voter already exists" warnings

**Cause**: Seeding script has already been run

**Solution**: This is normal behavior. The script is idempotent and skips duplicates.

```bash
# To verify data was seeded correctly
python3 test_seed_database.py
```

### Problem: "Voter not found" error when seeding votes

**Cause**: The voter specified in `CONFIRMED_VOTES` doesn't exist in `CONFIRMED_VOTERS`

**Solution**:
1. Check spelling of `voter_name` in `CONFIRMED_VOTES`
2. Ensure voter is in `CONFIRMED_VOTERS` list
3. Run `python3 seed_database.py --voters-only` first

### Problem: "Candidate not found" error when seeding votes

**Cause**: The candidate specified in `CONFIRMED_VOTES` doesn't exist in `MVP_CANDIDATES`

**Solution**:
1. Check spelling of `candidate_name` in `CONFIRMED_VOTES`
2. Ensure candidate is in `MVP_CANDIDATES` list
3. Run `python3 seed_database.py --candidates-only` first

### Problem: Database integrity errors

**Cause**: Corrupted or inconsistent data

**Solution**: Clear and re-seed the database

```bash
# WARNING: This deletes ALL data
python3 seed_database.py --clear

# Then verify
python3 test_seed_database.py
```

### Problem: Import errors

**Cause**: Missing dependencies or wrong directory

**Solution**:

```bash
# Make sure you're in the backend directory
cd backend

# Verify database models exist
ls database/models.py

# Verify utils exist
ls database/utils.py

# Check Python path
python3 -c "import sys; print(sys.path)"
```

---

## Best Practices

### 1. Always Test After Adding Data

```bash
# Add new data to seed_database.py
vim seed_database.py

# Run seeding
python3 seed_database.py

# Verify with tests
python3 test_seed_database.py
```

### 2. Backup Before Clearing

```bash
# Export existing data before clearing
python3 -c "
from database.models import Session, Voter, Candidate, Vote
import json
session = Session()
voters = [{'name': v.name, 'outlet': v.outlet} for v in session.query(Voter).all()]
with open('backup_voters.json', 'w') as f:
    json.dump(voters, f, indent=2)
session.close()
"

# Now safe to clear and re-seed
python3 seed_database.py --clear
```

### 3. Use Version Control

```bash
# Commit seed_database.py after adding new data
git add seed_database.py
git commit -m "Add new AP voter: [Name]"
```

### 4. Document Sources

Always include source URLs for votes:
- Makes verification possible
- Builds credibility
- Helps with future research

### 5. Verify Data Quality

```bash
# Check for unverified votes
python3 -c "
from database.models import Session, Vote
session = Session()
unverified = session.query(Vote).filter(Vote.verified == False).count()
print(f'Unverified votes: {unverified}')
session.close()
"
```

### 6. Use Confidence Scores

Set appropriate confidence scores:
- **High (80-100)**: Official announcement from voter
- **Medium (50-79)**: Reliable source, some uncertainty
- **Low (0-49)**: Speculation or rumor

### 7. Update Regularly

As the season progresses:
1. Check Twitter/news for new voter announcements
2. Add to `CONFIRMED_VOTES`
3. Re-run seeding
4. Verify with admin interface

---

## Integration with Other Features

### With Manual Entry (Feature #10)

You can use the manual entry API after seeding:

```bash
# Start backend
python3 app.py

# Add a vote via API
curl -X POST http://localhost:5000/api/votes \
  -H "Content-Type: application/json" \
  -d '{
    "voter_name": "Peter King",
    "candidate_name": "Josh Allen",
    "season": "2024-25",
    "ranking": 1
  }'
```

### With Admin Interface (Feature #21)

After seeding:
1. Start the application
2. Navigate to Admin Panel
3. Review and verify seeded votes
4. Edit any incorrect information

### With Notifications (Feature #18)

Seeding operations are logged and can trigger notifications:

```python
# In seed_database.py
from notifications import NotificationService
service = NotificationService()

# After adding a voter
service.notify_new_voter(voter.id)

# After adding a vote
service.notify_new_vote(vote.id)
```

### With Logging (Feature #25)

All seeding operations are automatically logged:

```bash
# View seeding logs
tail -f logs/database.log

# Search for seeding operations
grep "INSERT" logs/database.log | grep "voters"
```

---

## Example Workflows

### Workflow 1: Fresh Installation

```bash
# 1. Setup database (first time)
cd backend
python3 database/models.py

# 2. Run migrations
python3 database/migrate_add_deduplication.py
python3 database/migrate_add_confidence_score.py
python3 database/migrate_add_notifications.py

# 3. Seed database
python3 seed_database.py

# 4. Verify
python3 test_seed_database.py

# 5. Start application
python3 app.py
```

### Workflow 2: Adding New Vote Announcement

```bash
# 1. Edit seed file
vim seed_database.py

# Add to CONFIRMED_VOTES list:
# {
#   "voter_name": "Tom Brady",
#   "candidate_name": "Josh Allen",
#   ...
# }

# 2. Re-seed (only new data added)
python3 seed_database.py

# 3. Verify in admin panel
# Navigate to http://localhost:3000/admin
```

### Workflow 3: Development/Testing

```bash
# 1. Clear and seed test data
python3 seed_database.py --clear

# 2. Run tests
python3 test_seed_database.py

# 3. If tests pass, proceed with development
```

---

## Data Sources

### Where to Find Voter Information

1. **Twitter/X**: Voters often announce on social media
   - Search: "NFL MVP vote 2024"
   - Monitor: Known voter handles

2. **News Articles**: AP typically publishes voter list
   - ESPN, NFL.com, Sports Illustrated

3. **ProFootballTalk**: Often breaks voter announcements

4. **The Athletic**: Insiders sometimes disclose votes

5. **Official AP**: Associated Press official announcements

### Tracking Votes Throughout Season

- Monitor voter Twitter accounts
- Set up Google Alerts for "NFL MVP vote"
- Use Reddit scraper (Feature #2) for discussions
- News aggregator (Feature #24) for articles
- Notification system (Feature #18) for alerts

---

## Technical Details

### Database Tables

Seeding populates these tables:

1. **voters**
   - id, name, outlet, twitter_handle, location, bio, created_at

2. **candidates**
   - id, name, team, position, season, created_at

3. **votes**
   - id, voter_id, candidate_id, season, ranking
   - source_url, source_type, confidence, confidence_score
   - verified, credibility_tier, announcement_date
   - extracted_text, created_at

### Foreign Key Relationships

```
votes.voter_id → voters.id
votes.candidate_id → candidates.id
```

### Constraints

- Voter names must be unique
- Candidate (name + season) must be unique
- Vote (voter + candidate + season + ranking) must be unique
- Rankings must be 1-5

---

## Future Enhancements

Potential improvements to seeding:

1. **CSV Import**: Load seed data from CSV files
2. **JSON Import**: Import from external JSON sources
3. **API Integration**: Pull voters from AP API (if available)
4. **Historical Data**: Seed previous seasons (2023-24, 2022-23)
5. **Bulk Updates**: Update existing records with new information
6. **Validation Scripts**: Separate validation before seeding
7. **Dry Run Mode**: Preview changes before applying
8. **Rollback**: Undo last seeding operation

---

## Summary

The database seeding script provides:

✓ **15 Confirmed AP Voters** with full details
✓ **15 MVP Candidates** for 2024-25 season
✓ **Publicly Disclosed Votes** (updated as available)
✓ **Idempotent Operation** (safe to run multiple times)
✓ **Comprehensive Testing** (7 test categories)
✓ **Full Logging** (all operations tracked)
✓ **Flexible Options** (selective seeding)
✓ **Easy Extension** (add new data to lists)

For questions or issues, check the troubleshooting section or review the test output for specific errors.
