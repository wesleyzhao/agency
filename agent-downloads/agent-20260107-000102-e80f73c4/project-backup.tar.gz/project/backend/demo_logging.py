#!/usr/bin/env python3
"""
Demo script for the comprehensive logging system

This script demonstrates all the logging capabilities:
- Pre-configured loggers
- Specialized logging functions
- Execution time tracking
- Exception logging
- Structured context logging
"""

import sys
import time

# Import the logging system
from logging_config import (
    scraping_logger,
    nlp_logger,
    api_logger,
    database_logger,
    notification_logger,
    general_logger,
    log_scraping_activity,
    log_extraction_activity,
    log_database_operation,
    log_api_request,
    log_execution_time,
    LoggerFactory
)


def demo_basic_logging():
    """Demo 1: Basic logging with pre-configured loggers"""
    print("\n" + "=" * 60)
    print("DEMO 1: Basic Logging")
    print("=" * 60)

    general_logger.debug("This is a DEBUG message - detailed information")
    general_logger.info("This is an INFO message - general information")
    general_logger.warning("This is a WARNING message - something to be aware of")
    general_logger.error("This is an ERROR message - something went wrong")
    general_logger.critical("This is a CRITICAL message - serious problem")

    print("\n✓ Check logs/general.log for these messages")


def demo_scraping_logging():
    """Demo 2: Scraping activity logging"""
    print("\n" + "=" * 60)
    print("DEMO 2: Scraping Activity Logging")
    print("=" * 60)

    # Successful scrape
    log_scraping_activity(
        scraping_logger,
        source='reddit',
        url='https://reddit.com/r/nfl/comments/abc123',
        status='success',
        posts_found=15,
        votes_extracted=3,
        duration_seconds=2.5
    )

    # Failed scrape
    log_scraping_activity(
        scraping_logger,
        source='google',
        url='https://google.com/search?q=nfl+mvp+votes',
        status='error',
        error='Rate limit exceeded',
        retry_after=60
    )

    # Skipped scrape
    log_scraping_activity(
        scraping_logger,
        source='news',
        url='https://espn.com/nfl/story/_/id/12345/mvp-race',
        status='skipped',
        reason='Already processed',
        cached=True
    )

    print("\n✓ Check logs/scraping.log for detailed scraping activity")


def demo_nlp_logging():
    """Demo 3: NLP extraction logging"""
    print("\n" + "=" * 60)
    print("DEMO 3: NLP Extraction Logging")
    print("=" * 60)

    # Successful extraction
    log_extraction_activity(
        nlp_logger,
        text_length=500,
        voters_found=1,
        votes_found=1,
        confidence='high',
        source_url='https://twitter.com/minakimes/status/12345',
        source_type='social_media',
        voter_name='Mina Kimes',
        candidate_name='Saquon Barkley',
        ranking=1
    )

    # Low confidence extraction
    log_extraction_activity(
        nlp_logger,
        text_length=200,
        voters_found=0,
        votes_found=0,
        confidence='low',
        source_url='https://reddit.com/r/nfl/comments/xyz',
        reason='No voting patterns detected'
    )

    print("\n✓ Check logs/nlp.log for extraction activity")


def demo_database_logging():
    """Demo 4: Database operation logging"""
    print("\n" + "=" * 60)
    print("DEMO 4: Database Operation Logging")
    print("=" * 60)

    # INSERT operation
    log_database_operation(
        database_logger,
        operation='INSERT',
        table='voters',
        affected_rows=1,
        voter_name='Mina Kimes',
        outlet='ESPN',
        twitter_handle='@minakimes'
    )

    # UPDATE operation
    log_database_operation(
        database_logger,
        operation='UPDATE',
        table='votes',
        affected_rows=5,
        field='verified',
        new_value=True,
        condition='confidence_score >= 80'
    )

    # DELETE operation
    log_database_operation(
        database_logger,
        operation='DELETE',
        table='sources',
        affected_rows=10,
        reason='Duplicate URLs',
        url_pattern='%twitter.com%'
    )

    print("\n✓ Check logs/database.log for database operations")


def demo_api_logging():
    """Demo 5: API request logging"""
    print("\n" + "=" * 60)
    print("DEMO 5: API Request Logging")
    print("=" * 60)

    # Successful GET request
    log_api_request(
        api_logger,
        method='GET',
        endpoint='/api/voters',
        status_code=200,
        duration=0.15,
        user_id='admin',
        query_params={'season': '2024-25'}
    )

    # Successful POST request
    log_api_request(
        api_logger,
        method='POST',
        endpoint='/api/votes',
        status_code=201,
        duration=0.25,
        body_size=500,
        vote_id=42,
        voter_name='Mina Kimes'
    )

    # Failed request
    log_api_request(
        api_logger,
        method='DELETE',
        endpoint='/api/votes/999',
        status_code=404,
        duration=0.05,
        error='Vote not found'
    )

    print("\n✓ Check logs/api.log for API requests")


def demo_execution_time():
    """Demo 6: Execution time tracking"""
    print("\n" + "=" * 60)
    print("DEMO 6: Execution Time Tracking")
    print("=" * 60)

    @log_execution_time(general_logger)
    def slow_operation():
        """Simulate a slow operation"""
        time.sleep(1)
        return {"status": "completed", "items": 100}

    @log_execution_time(general_logger)
    def fast_operation():
        """Simulate a fast operation"""
        return {"status": "completed", "items": 10}

    print("Running slow_operation (1 second)...")
    result1 = slow_operation()
    print(f"Result: {result1}")

    print("\nRunning fast_operation (instant)...")
    result2 = fast_operation()
    print(f"Result: {result2}")

    print("\n✓ Check logs/general.log for execution times")


def demo_exception_logging():
    """Demo 7: Exception logging"""
    print("\n" + "=" * 60)
    print("DEMO 7: Exception Logging")
    print("=" * 60)

    # Recoverable error
    try:
        raise ValueError("Invalid voter ID: must be a positive integer")
    except ValueError as e:
        general_logger.error(
            f"Validation error: {str(e)}",
            exc_info=True
        )

    # Critical error
    try:
        # Simulate a critical failure
        raise RuntimeError("Database connection lost")
    except RuntimeError as e:
        general_logger.critical(
            f"Critical system error: {str(e)}",
            exc_info=True
        )

    print("\n✓ Check logs/general.log for exception details and tracebacks")


def demo_structured_logging():
    """Demo 8: Structured logging with context"""
    print("\n" + "=" * 60)
    print("DEMO 8: Structured Context Logging")
    print("=" * 60)

    # Log with rich context
    LoggerFactory.log_with_context(
        general_logger,
        'INFO',
        'User performed action',
        user_id=123,
        action='create_vote',
        voter_name='Mina Kimes',
        candidate_name='Saquon Barkley',
        confidence_score=85.5,
        timestamp='2025-01-07T10:00:00'
    )

    LoggerFactory.log_with_context(
        general_logger,
        'WARNING',
        'Rate limit approaching',
        source='reddit',
        requests_made=90,
        requests_limit=100,
        reset_time='2025-01-07T11:00:00'
    )

    print("\n✓ Check logs/general.log for structured context data")


def demo_notification_logging():
    """Demo 9: Notification logging"""
    print("\n" + "=" * 60)
    print("DEMO 9: Notification System Logging")
    print("=" * 60)

    notification_logger.info("Notification sent: New voter discovered (Mina Kimes)")
    notification_logger.info("Notification sent: New vote disclosed (Saquon Barkley)")
    notification_logger.warning("Notification rate limit: Skipped duplicate notification")
    notification_logger.error("Notification failed: SMTP connection timeout")

    print("\n✓ Check logs/notifications.log for notification events")


def show_log_summary():
    """Show summary of created log files"""
    print("\n" + "=" * 60)
    print("LOG FILES SUMMARY")
    print("=" * 60)

    import os

    log_dir = 'logs'
    if os.path.exists(log_dir):
        print(f"\nLog directory: {os.path.abspath(log_dir)}\n")

        log_files = [f for f in os.listdir(log_dir) if f.endswith('.log')]
        if log_files:
            print(f"Created {len(log_files)} log files:")
            for log_file in sorted(log_files):
                file_path = os.path.join(log_dir, log_file)
                file_size = os.path.getsize(file_path)
                print(f"  • {log_file:<25} ({file_size:,} bytes)")

            print("\n" + "=" * 60)
            print("How to view logs:")
            print("=" * 60)
            print(f"  View all logs:      tail -f {log_dir}/*.log")
            print(f"  View scraping:      tail -f {log_dir}/scraping.log")
            print(f"  View NLP:           tail -f {log_dir}/nlp.log")
            print(f"  View API:           tail -f {log_dir}/api.log")
            print(f"  View errors only:   grep ERROR {log_dir}/*.log")
            print(f"  Search for keyword: grep -i 'mina' {log_dir}/*.log")
        else:
            print("No log files created yet")
    else:
        print(f"\nLog directory will be created at: {os.path.abspath(log_dir)}")


def main():
    """Run all demos"""
    print("\n" + "=" * 60)
    print("NFL MVP VOTER TRACKER - LOGGING SYSTEM DEMO")
    print("=" * 60)

    try:
        demo_basic_logging()
        demo_scraping_logging()
        demo_nlp_logging()
        demo_database_logging()
        demo_api_logging()
        demo_execution_time()
        demo_exception_logging()
        demo_structured_logging()
        demo_notification_logging()

        show_log_summary()

        print("\n" + "=" * 60)
        print("DEMO COMPLETE!")
        print("=" * 60)
        print("\n✓ All logging features demonstrated successfully")
        print("✓ Check the logs directory for output files")
        print("✓ See LOGGING_SYSTEM.md for detailed documentation\n")

    except Exception as e:
        print(f"\n✗ Demo failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
