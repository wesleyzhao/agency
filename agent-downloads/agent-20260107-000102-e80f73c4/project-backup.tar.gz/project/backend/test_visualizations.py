#!/usr/bin/env python3
"""
Test script for Feature #22: Visualization showing vote distribution across candidates

This script tests that:
1. The statistics API endpoint provides the necessary data for visualizations
2. All required fields are present for chart rendering
3. Data is formatted correctly for Chart.js consumption
"""

import requests
import json

# ANSI color codes for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_success(message):
    print(f"{GREEN}✓{RESET} {message}")

def print_error(message):
    print(f"{RED}✗{RESET} {message}")

def print_info(message):
    print(f"{CYAN}ℹ{RESET} {message}")

def print_warning(message):
    print(f"{YELLOW}⚠{RESET} {message}")

def print_header(message):
    print(f"\n{BOLD}{message}{RESET}")
    print("=" * 60)

def test_statistics_endpoint():
    """Test that the statistics endpoint returns data needed for visualizations"""
    print_header("Testing Statistics API Endpoint for Visualization Data")

    try:
        # Test health check first
        response = requests.get('http://localhost:5000/api/dashboard')
        if response.status_code != 200:
            print_error("Backend server is not running. Please start it first:")
            print_info("cd backend && python3 app.py")
            return False
        print_success("Backend server is running")

        # Get statistics data
        response = requests.get('http://localhost:5000/api/statistics?season=2024-25')

        if response.status_code != 200:
            print_error(f"Statistics endpoint returned {response.status_code}")
            return False

        print_success("Statistics endpoint returned 200 OK")

        data = response.json()

        # Check for required fields
        required_fields = [
            'overview',
            'candidate_breakdown',
            'top_candidates',
            'source_distribution',
            'confidence_distribution',
            'disclosure_breakdown'
        ]

        for field in required_fields:
            if field not in data:
                print_error(f"Missing required field: {field}")
                return False
            print_success(f"Response contains '{field}' field")

        # Check candidate_breakdown structure
        if len(data['candidate_breakdown']) > 0:
            candidate = data['candidate_breakdown'][0]
            candidate_fields = [
                'name',
                'team',
                'position',
                'first_place_votes',
                'second_place_votes',
                'third_place_votes',
                'fourth_place_votes',
                'fifth_place_votes',
                'total_mentions',
                'weighted_points'
            ]

            for field in candidate_fields:
                if field not in candidate:
                    print_error(f"Candidate missing field: {field}")
                    return False

            print_success("Candidate breakdown has all required fields for charts")

        # Check confidence distribution structure (may not have all if no data)
        print_success("Confidence distribution exists (may have partial data)")

        # Check source distribution structure (may not have all if no data)
        print_success("Source distribution exists (may have partial data)")

        # Display sample data for visualization
        print_header("Sample Data for Visualizations")

        print_info(f"Total Candidates: {len(data['candidate_breakdown'])}")
        print_info(f"Total Votes: {data['overview'].get('total_votes_disclosed', 0)}")
        print_info(f"First Place Votes: {data['overview']['first_place_votes_disclosed']}")

        # Show top 5 candidates
        print_info("\nTop 5 Candidates by Weighted Points:")
        for i, candidate in enumerate(data['top_candidates'][:5], 1):
            print(f"  {i}. {candidate['name']} ({candidate['team']}) - {candidate['weighted_points']} pts")
            print(f"     1st: {candidate['first_place_votes']}, "
                  f"2nd: {candidate['second_place_votes']}, "
                  f"3rd: {candidate['third_place_votes']}, "
                  f"4th: {candidate['fourth_place_votes']}, "
                  f"5th: {candidate['fifth_place_votes']}")

        # Show confidence distribution
        print_info("\nConfidence Distribution:")
        print(f"  High: {data['confidence_distribution'].get('high', 0)}")
        print(f"  Medium: {data['confidence_distribution'].get('medium', 0)}")
        print(f"  Low: {data['confidence_distribution'].get('low', 0)}")
        print(f"  Unknown: {data['confidence_distribution'].get('unknown', 0)}")

        # Show source distribution
        print_info("\nSource Type Distribution:")
        print(f"  Official: {data['source_distribution'].get('official', 0)}")
        print(f"  Social Media: {data['source_distribution'].get('social_media', 0)}")
        print(f"  News Article: {data['source_distribution'].get('news_article', 0)}")
        print(f"  Reddit: {data['source_distribution'].get('reddit', 0)}")
        print(f"  Speculation: {data['source_distribution'].get('speculation', 0)}")

        return True

    except requests.exceptions.ConnectionError:
        print_error("Could not connect to backend server")
        print_info("Please start the backend server: cd backend && python3 app.py")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def main():
    """Run all visualization tests"""
    print_header("Testing Visualizations Feature #22")
    print_info("This test verifies the API provides data for Chart.js visualizations\n")

    success = test_statistics_endpoint()

    print_header("Test Summary")
    if success:
        print_success("All tests PASSED! ✓")
        print_info("\nVisualization data is ready. To view in browser:")
        print_info("1. Start backend: cd backend && python3 app.py")
        print_info("2. Start frontend: cd frontend && npm start")
        print_info("3. Navigate to: http://localhost:3000/visualizations")
        print_info("\nAvailable Charts:")
        print_info("  • Vote Distribution by Ranking Position (Stacked Bar)")
        print_info("  • Top 10 Candidates by First Place Votes (Bar)")
        print_info("  • Top 10 Candidates by Weighted Points (Bar)")
        print_info("  • Confidence Level Distribution (Pie)")
        print_info("  • Source Type Distribution (Pie)")
        print_info("  • Key Metrics Summary Card")
    else:
        print_error("Some tests FAILED! ✗")
        print_info("\nPlease fix the issues above and try again.")

    return success

if __name__ == '__main__':
    import sys
    success = main()
    sys.exit(0 if success else 1)
