# Search and Filter API Documentation - Feature #14

## Overview

The Search and Filter API allows users to search for NFL MVP voters by name, outlet, Twitter handle, and filter by various criteria including candidate voted for, confidence level, verification status, and ballot completion status.

## Endpoint

```
GET /api/search
```

## Query Parameters

All parameters are optional. If no parameters are provided, all voters will be returned.

### Search Parameters

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| `q` | string | General search query (searches name, outlet, Twitter handle) | `q=mina` |
| `voter_name` | string | Filter by voter name (case-insensitive partial match) | `voter_name=peter` |
| `outlet` | string | Filter by media outlet (case-insensitive partial match) | `outlet=espn` |
| `candidate_name` | string | Filter by candidate voted for (case-insensitive partial match) | `candidate_name=allen` |
| `confidence` | string | Filter by confidence level (`high`, `medium`, `low`) | `confidence=high` |
| `verified_only` | boolean | Show only voters with verified votes | `verified_only=true` |
| `has_ballot` | string | Filter by ballot status (`full`, `partial`, `any`, `none`) | `has_ballot=full` |
| `season` | string | Season to filter by (default: `2024-25`) | `season=2024-25` |

### Ballot Status Values

- `full`: Voters with 5 or more votes (complete ballot)
- `partial`: Voters with 1-4 votes (incomplete ballot)
- `any`: Voters with at least 1 vote
- `none`: Voters with 0 votes

## Response Format

```json
{
  "results": [
    {
      "id": 1,
      "name": "Mina Kimes",
      "outlet": "ESPN",
      "twitter_handle": "@minakimes",
      "location": null,
      "has_voted": true,
      "vote_count": 1,
      "status": "disclosed",
      "ballot": [
        {
          "ranking": 1,
          "candidate": "Saquon Barkley",
          "team": "Philadelphia Eagles",
          "confidence": "high",
          "verified": true,
          "source_url": "https://x.com/minakimes/status/..."
        }
      ]
    }
  ],
  "count": 1,
  "season": "2024-25",
  "filters_applied": {
    "query": null,
    "voter_name": null,
    "outlet": null,
    "candidate_name": null,
    "confidence": null,
    "verified_only": false,
    "has_ballot": null
  }
}
```

## Response Fields

### Root Level

- `results`: Array of voter objects matching the search criteria
- `count`: Number of voters found
- `season`: Season that was searched
- `filters_applied`: Object showing which filters were applied

### Voter Object

- `id`: Unique voter ID
- `name`: Voter's full name
- `outlet`: Media outlet/organization
- `twitter_handle`: Twitter handle (with @ symbol)
- `location`: Geographic location (if available)
- `has_voted`: Boolean indicating if voter has any disclosed votes
- `vote_count`: Number of votes disclosed by this voter
- `status`: Either `"disclosed"` or `"not_disclosed"`
- `ballot`: Array of vote objects (ordered by ranking)

### Vote Object (in ballot)

- `ranking`: Vote ranking (1-5)
- `candidate`: Candidate name
- `team`: Team name
- `confidence`: Confidence level (`"high"`, `"medium"`, `"low"`, `"unknown"`)
- `verified`: Boolean indicating if vote is verified
- `source_url`: URL to the original source (if available)

## Example Requests

### 1. General Search

Search for voters whose name, outlet, or Twitter handle contains "mina":

```bash
curl "http://localhost:5000/api/search?q=mina"
```

```javascript
const response = await fetch('http://localhost:5000/api/search?q=mina');
const data = await response.json();
```

### 2. Filter by Outlet

Find all ESPN voters:

```bash
curl "http://localhost:5000/api/search?outlet=espn"
```

### 3. Filter by Candidate

Find all voters who voted for Josh Allen:

```bash
curl "http://localhost:5000/api/search?candidate_name=allen"
```

### 4. Filter by Confidence Level

Find voters with high-confidence votes:

```bash
curl "http://localhost:5000/api/search?confidence=high"
```

### 5. Filter by Ballot Status

Find voters with full ballots (5 votes):

```bash
curl "http://localhost:5000/api/search?has_ballot=full"
```

Find voters with any disclosed votes:

```bash
curl "http://localhost:5000/api/search?has_ballot=any"
```

Find voters who haven't disclosed votes yet:

```bash
curl "http://localhost:5000/api/search?has_ballot=none"
```

### 6. Verified Votes Only

Show only voters with verified votes:

```bash
curl "http://localhost:5000/api/search?verified_only=true"
```

### 7. Combined Filters

Find ESPN voters who voted for Josh Allen with high confidence:

```bash
curl "http://localhost:5000/api/search?outlet=espn&candidate_name=allen&confidence=high"
```

```javascript
const params = new URLSearchParams({
  outlet: 'espn',
  candidate_name: 'allen',
  confidence: 'high'
});

const response = await fetch(`http://localhost:5000/api/search?${params}`);
const data = await response.json();
```

## Use Cases

### 1. Quick Voter Lookup

Find a specific voter by name:

```
/api/search?voter_name=mina
```

### 2. Outlet Analysis

See all voters from a specific media organization:

```
/api/search?outlet=nbc sports
```

### 3. Candidate Support Tracking

Find who is voting for a specific candidate:

```
/api/search?candidate_name=saquon barkley
```

### 4. Data Quality Review

Find votes that need verification:

```
/api/search?confidence=low&verified_only=false
```

### 5. Progress Tracking

See how many full ballots have been disclosed:

```
/api/search?has_ballot=full
```

See voters who haven't disclosed yet:

```
/api/search?has_ballot=none
```

### 6. High-Quality Data

Get only verified, high-confidence votes:

```
/api/search?confidence=high&verified_only=true
```

## Frontend Integration

The Dashboard component includes a search interface that uses this API:

### Search Bar Features

1. **General Search**: Text input searches name, outlet, and Twitter handle
2. **Advanced Filters**: Expandable section with detailed filter options
3. **Real-time Results**: Displays count of matching voters
4. **Clear Function**: Button to reset all filters and return to full list

### User Workflow

1. User types search query or selects filters
2. Clicks "Search" button or presses Enter
3. API returns filtered results
4. Dashboard displays only matching voters
5. User can apply status filters (All/Disclosed/Not Disclosed) on top of search results
6. "Clear" button resets to full voter list

### Example Frontend Code

```javascript
const performSearch = async () => {
  const params = new URLSearchParams();
  params.append('season', '2024-25');

  if (searchQuery.trim()) {
    params.append('q', searchQuery.trim());
  }
  if (advancedFilters.outlet) {
    params.append('outlet', advancedFilters.outlet);
  }
  if (advancedFilters.candidate) {
    params.append('candidate_name', advancedFilters.candidate);
  }
  if (advancedFilters.confidence) {
    params.append('confidence', advancedFilters.confidence);
  }
  if (advancedFilters.verified_only) {
    params.append('verified_only', 'true');
  }
  if (advancedFilters.has_ballot) {
    params.append('has_ballot', advancedFilters.has_ballot);
  }

  const response = await fetch(`${API_URL}/api/search?${params.toString()}`);
  const data = await response.json();

  // Display results...
};
```

## Performance Considerations

- **Case-Insensitive Search**: All text searches are case-insensitive for better UX
- **Partial Matching**: Text filters use substring matching (e.g., "espn" matches "ESPN")
- **Multi-Filter Support**: All filters can be combined for precise results
- **In-Memory Filtering**: Filters are applied in application memory (fast for <1000 voters)
- **Season Scoping**: Results are automatically scoped to the specified season

## Error Handling

### 500 Internal Server Error

```json
{
  "error": "Error message description"
}
```

Common causes:
- Database connection issues
- Invalid data in database
- Server misconfiguration

## Testing

Run the comprehensive test suite:

```bash
cd backend
python3 test_search.py
```

Tests cover:
- Basic search functionality
- Individual filter parameters
- Combined filters
- Filter metadata
- Response structure validation

## Future Enhancements

Potential improvements for future versions:

1. **Pagination**: Add `limit` and `offset` parameters for large result sets
2. **Sorting**: Add `sort_by` parameter (e.g., `name`, `vote_count`, `outlet`)
3. **Full-Text Search**: Implement database full-text search for better performance
4. **Autocomplete**: Add suggestions for voter names and outlets
5. **Saved Searches**: Allow users to save frequently used search queries
6. **Export Results**: Add ability to export search results to CSV/JSON
7. **Search History**: Track recent searches for quick access

## Related Features

- **Feature #11**: Dashboard (displays search results)
- **Feature #12**: Voter Detail Page (linked from search results)
- **Feature #13**: Summary Statistics (can filter statistics by search criteria)
- **Feature #21**: Admin Interface (can use search to find voters to edit)

## Notes

- Search is case-insensitive for better user experience
- Filters use "AND" logic (all conditions must match)
- Empty search returns all voters (useful with status filters)
- Results maintain same structure as dashboard voter list for consistency
