# NFL MVP Voter Research Script - Feature #26

## Overview

The **Research Script** is a comprehensive automated tool that discovers NFL MVP voters and their publicly disclosed votes for the current season. It orchestrates all the scraping, extraction, and database components to perform real research on the web.

### Key Features

- **Multi-Source Scraping**: Searches Reddit, Google News, and news aggregators
- **Automated Extraction**: Uses NLP to extract voter names and votes from text
- **Database Integration**: Automatically saves discovered voters and votes
- **Deduplication**: Skips duplicate votes and sources
- **Progress Tracking**: Real-time progress display and statistics
- **Comprehensive Logging**: All activities logged for audit trail
- **Notification System**: Sends alerts when voters/votes discovered
- **Flexible Modes**: Quick, full, or news-only research modes
- **Specific Voter Search**: Search for a particular voter
- **Command-line Interface**: Easy to use and automate

---

## Installation

The research script uses all the existing backend components. Ensure you have:

1. **Backend Dependencies Installed**:
   ```bash
   cd backend
   pip install -r requirements.txt
   ```

2. **Database Initialized**:
   ```bash
   python3 database/init_db.py
   ```

3. **Reddit API Configured** (optional but recommended):
   - Create a Reddit app at https://www.reddit.com/prefs/apps
   - Set environment variables:
     ```bash
     export REDDIT_CLIENT_ID="your_client_id"
     export REDDIT_CLIENT_SECRET="your_client_secret"
     export REDDIT_USER_AGENT="NFL MVP Tracker v1.0"
     ```

4. **NewsAPI Key** (optional):
   ```bash
   export NEWSAPI_KEY="your_newsapi_key"
   ```

---

## Usage

### Basic Usage

```bash
cd backend

# Run full research (all sources)
python3 research_script.py

# Run quick research (news + Google only, faster)
python3 research_script.py --mode quick

# Run news-only research (fastest)
python3 research_script.py --mode news_only
```

### Search for Specific Voter

```bash
# Search for a specific voter across all sources
python3 research_script.py --voter "Mina Kimes"
python3 research_script.py --voter "Peter King"
python3 research_script.py --voter "Tom Brady"
```

### Choose Specific Sources

```bash
# Use only Reddit
python3 research_script.py --sources reddit

# Use Reddit and news
python3 research_script.py --sources reddit,news

# Use Google and news
python3 research_script.py --sources google,news
```

### Specify Season

```bash
# Research for a different season
python3 research_script.py --season 2023-24

# Combine with other options
python3 research_script.py --season 2024-25 --mode quick
```

---

## Command-Line Arguments

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `--season` | string | `2024-25` | NFL season to research |
| `--mode` | choice | `full` | Research mode: `full`, `quick`, or `news_only` |
| `--sources` | string | `reddit,google,news` | Comma-separated list of sources |
| `--voter` | string | None | Search for a specific voter |

### Research Modes

- **`full`**: Uses all sources (Reddit, Google, News). Most comprehensive but slowest.
- **`quick`**: Uses Google and News only. Faster, good balance.
- **`news_only`**: Uses news aggregator only. Fastest, recent articles only.

---

## How It Works

### Step 1: Gather Sources

The script searches multiple sources for NFL MVP-related content:

1. **Reddit**: Searches r/nfl, r/buffalobills, r/ravens, etc. for MVP discussions
2. **Google News**: Performs targeted Google searches for voter announcements
3. **News Aggregator**: Fetches recent articles from ESPN, NFL.com, ProFootballTalk, etc.

All sources are:
- Filtered for MVP relevance
- Deduplicated by URL
- Rate-limited to avoid being blocked

### Step 2: Extract and Save Votes

For each article/post found:

1. **NLP Extraction**: VoteExtractor analyzes the text
2. **Voter Detection**: Identifies known voters or first-person declarations
3. **Candidate Extraction**: Finds MVP candidate names and rankings
4. **Confidence Scoring**: Calculates confidence (high/medium/low)
5. **Database Storage**: Saves voters, candidates, and votes
6. **Notification**: Sends alerts for new discoveries

### Step 3: Generate Report

The script generates a comprehensive report showing:
- Number of sources scraped
- Voters discovered
- Votes extracted and saved
- Duplicates skipped
- Errors encountered
- Current database state

---

## Example Output

```
======================================================================
NFL MVP VOTER RESEARCH - Season 2024-25
Mode: FULL
Sources: reddit, google, news
======================================================================

[Step 1/3] Gathering sources...

🔍 Searching Reddit...
   ✓ Found 15 Reddit posts

🔍 Searching Google News...
   ✓ Found 8 Google results

🔍 Aggregating news articles...
   ✓ Found 12 news articles

✓ Total sources gathered: 35

[Step 2/3] Extracting and saving votes...

   [1/35] Found 1 votes in: Mina Kimes announces her MVP pick...
      → New voter discovered: Mina Kimes
      → Vote saved: Mina Kimes → #1 Saquon Barkley

   [5/35] Found 2 votes in: Peter King's MVP ballot revealed...
      → New voter discovered: Peter King
      → Vote saved: Peter King → #1 Josh Allen
      → Vote saved: Peter King → #2 Lamar Jackson

✓ Votes extracted: 15
✓ Votes saved: 15
⊘ Duplicates skipped: 0

[Step 3/3] Generating report...

======================================================================
RESEARCH SESSION REPORT
======================================================================

Session Duration: 45.2 seconds

Sources:
  Sources scraped: 3
  Articles/posts found: 35

Extraction:
  Voters discovered: 5
  Votes extracted: 15
  Votes saved to database: 15
  Duplicates skipped: 0

Errors:
  Errors encountered: 0

Current Database State:
  Total voters in database: 5
  Total votes for 2024-25: 15
  Voters with disclosed votes: 5

======================================================================

Newly Discovered Voters:
  • Mina Kimes (ESPN) - 1 votes
  • Peter King (NBC Sports) - 2 votes
  • Tom Brady (Fox Sports) - 5 votes
  • Adam Schefter (ESPN) - 3 votes
  • Ian Rapoport (NFL Network) - 4 votes
```

---

## Integration with Other Features

### Logging

All research activities are logged:
- Scraping activities → `logs/scraping.log`
- NLP extraction → `logs/nlp.log`
- Database operations → `logs/database.log`
- General events → `logs/general.log`

View logs:
```bash
tail -f logs/*.log
```

### Notifications

The script sends notifications for:
- New voters discovered
- New votes disclosed
- Full ballots completed (5 votes)
- High-confidence votes
- Research session completion

Configure notifications in notification preferences.

### Admin Interface

Discovered votes are marked as unverified and appear in the Admin Panel for review:
```
http://localhost:3000/admin
```

Admins can:
- Verify votes
- Edit extracted information
- Delete false positives
- Adjust confidence levels

### Database

All data is saved to SQLite database:
- Voters table: Name, outlet, Twitter handle
- Votes table: Rankings, confidence, sources
- Candidates table: Name, team, position
- Sources table: URLs, deduplication

---

## Automation

### Cron Job (Daily Research)

Add to crontab to run daily research:

```bash
crontab -e
```

Add line:
```bash
# Run NFL MVP research daily at 9 AM
0 9 * * * cd /path/to/backend && python3 research_script.py --mode quick >> logs/research_cron.log 2>&1
```

### Systemd Timer (Linux)

Create `/etc/systemd/system/nfl-mvp-research.service`:

```ini
[Unit]
Description=NFL MVP Voter Research

[Service]
Type=oneshot
User=youruser
WorkingDirectory=/path/to/backend
ExecStart=/usr/bin/python3 research_script.py --mode quick
StandardOutput=append:/path/to/backend/logs/research.log
StandardError=append:/path/to/backend/logs/research_error.log
```

Create `/etc/systemd/system/nfl-mvp-research.timer`:

```ini
[Unit]
Description=Run NFL MVP research daily

[Timer]
OnCalendar=daily
OnCalendar=09:00
Persistent=true

[Install]
WantedBy=timers.target
```

Enable:
```bash
sudo systemctl enable nfl-mvp-research.timer
sudo systemctl start nfl-mvp-research.timer
```

---

## Testing

### Run Test Suite

```bash
cd backend
python3 test_research_script.py
```

Tests:
1. ✓ Imports
2. ✓ ResearchSession creation
3. ✓ Statistics initialization
4. ✓ Save vote method
5. ✓ NLP extraction
6. ✓ Command-line arguments
7. ✓ Logging integration

### Manual Testing

Test with specific voter:
```bash
python3 research_script.py --voter "Mina Kimes" --sources news
```

Test quick mode:
```bash
python3 research_script.py --mode quick
```

---

## Performance

### Typical Execution Times

| Mode | Sources | Time | Articles | Votes |
|------|---------|------|----------|-------|
| `news_only` | News aggregator | 10-20s | 10-15 | 0-5 |
| `quick` | Google + News | 30-60s | 20-30 | 5-15 |
| `full` | Reddit + Google + News | 60-120s | 30-50 | 10-25 |

Times vary based on:
- Rate limiting delays
- Number of articles found
- Network speed
- API response times

### Rate Limiting

The script respects rate limits:
- Reddit: 2 requests per second (PRAW handles this)
- Google: 2-3 seconds between requests
- News: 2 seconds between RSS feed fetches

This prevents being blocked by websites.

---

## Troubleshooting

### Issue: No votes found

**Possible causes:**
1. No new announcements since last run
2. Sources blocked or rate-limited
3. NLP not detecting votes

**Solutions:**
```bash
# Check logs for errors
tail -f logs/*.log

# Try specific voter
python3 research_script.py --voter "Known Voter Name"

# Try different sources
python3 research_script.py --sources news
```

### Issue: ImportError

**Cause:** Missing dependencies

**Solution:**
```bash
pip install -r requirements.txt
```

### Issue: Database errors

**Cause:** Database not initialized

**Solution:**
```bash
python3 database/init_db.py
```

### Issue: Reddit API errors

**Cause:** Missing credentials

**Solution:**
Set environment variables:
```bash
export REDDIT_CLIENT_ID="your_id"
export REDDIT_CLIENT_SECRET="your_secret"
export REDDIT_USER_AGENT="NFL MVP Tracker v1.0"
```

### Issue: Too many duplicates

**Cause:** Running too frequently on same sources

**Solution:**
```bash
# Wait 24 hours between full runs
# Or use news-only for frequent checks
python3 research_script.py --mode news_only
```

---

## Best Practices

### Development

1. **Start with news-only mode**: Fast and less intrusive
2. **Test with specific voters**: `--voter "Mina Kimes"`
3. **Check logs frequently**: `tail -f logs/*.log`
4. **Review in Admin Panel**: Verify extracted votes

### Production

1. **Run daily or twice-daily**: Don't scrape too often
2. **Use quick mode**: Good balance of speed and coverage
3. **Monitor notifications**: Set up email/webhook alerts
4. **Review and verify**: Use Admin Panel to verify votes
5. **Check error logs**: Watch for scraping failures

### Data Quality

1. **Review low-confidence votes**: Filter by confidence in Admin Panel
2. **Verify sources**: Click source links to confirm
3. **Delete false positives**: Remove incorrect extractions
4. **Update voter info**: Add Twitter handles, outlets manually

---

## Future Enhancements

Planned improvements:
- Twitter/X API integration (when available)
- Machine learning for better voter detection
- Historical data import from previous seasons
- Parallel scraping for faster execution
- Browser automation for JavaScript-heavy sites
- Email digest with daily discoveries
- Slack/Discord integration
- Web UI for running research sessions

---

## Related Documentation

- [Web Scraping Module](scrapers/README.md)
- [NLP Extraction System](nlp/README.md)
- [Notification System](notifications/README.md)
- [Logging System](LOGGING_SYSTEM.md)
- [Admin Interface API](ADMIN_API.md)

---

## Support

For issues or questions:
1. Check logs in `backend/logs/`
2. Run test suite: `python3 test_research_script.py`
3. Review documentation
4. Check database state with Admin Panel

---

**Feature Status**: ✅ Complete and tested

**Last Updated**: January 7, 2026
