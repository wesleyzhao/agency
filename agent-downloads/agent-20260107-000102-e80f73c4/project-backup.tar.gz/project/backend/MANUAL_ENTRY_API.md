# Manual Entry API Documentation

## Overview

The Manual Entry API provides RESTful endpoints for creating, reading, updating, and deleting (CRUD) voter, candidate, and vote data. This allows administrators to manually add known voters and their MVP votes to the system.

## Base URL

```
http://localhost:5000/api
```

## Authentication

Currently, no authentication is required. **Note:** In production, these endpoints should be protected with authentication/authorization.

---

## Voters API

### Create Voter

Create a new voter in the system.

**Endpoint:** `POST /voters`

**Request Body:**
```json
{
  "name": "Peter King",              // Required
  "outlet": "NBC Sports",            // Optional
  "twitter_handle": "@peter_king",   // Optional
  "location": "Montclair, NJ",       // Optional
  "bio": "Senior NFL columnist"      // Optional
}
```

**Success Response:** `201 Created`
```json
{
  "id": 1,
  "name": "Peter King",
  "outlet": "NBC Sports",
  "twitter_handle": "@peter_king",
  "location": "Montclair, NJ",
  "bio": "Senior NFL columnist",
  "message": "Voter created successfully"
}
```

**Error Responses:**
- `400 Bad Request` - Missing required field (name)
- `409 Conflict` - Voter with this name already exists

---

### Get All Voters

Retrieve all voters in the system.

**Endpoint:** `GET /voters`

**Success Response:** `200 OK`
```json
[
  {
    "id": 1,
    "name": "Peter King",
    "outlet": "NBC Sports",
    "twitter_handle": "@peter_king",
    "location": "Montclair, NJ",
    "vote_count": 3
  }
]
```

---

### Get Voter by ID

Retrieve a specific voter with their votes.

**Endpoint:** `GET /voters/{voter_id}`

**Success Response:** `200 OK`
```json
{
  "id": 1,
  "name": "Peter King",
  "outlet": "NBC Sports",
  "twitter_handle": "@peter_king",
  "votes": [
    {
      "candidate": "Josh Allen",
      "team": "Buffalo Bills",
      "ranking": 1,
      "source_url": "https://twitter.com/peter_king/...",
      "confidence": "high",
      "verified": true
    }
  ]
}
```

**Error Response:**
- `404 Not Found` - Voter not found

---

### Update Voter

Update an existing voter's information.

**Endpoint:** `PUT /voters/{voter_id}`

**Request Body:** (all fields optional)
```json
{
  "name": "Peter King",
  "outlet": "NBC Sports",
  "twitter_handle": "@peter_king",
  "location": "Montclair, NJ",
  "bio": "Updated bio"
}
```

**Success Response:** `200 OK`
```json
{
  "id": 1,
  "name": "Peter King",
  "outlet": "NBC Sports",
  "twitter_handle": "@peter_king",
  "location": "Montclair, NJ",
  "bio": "Updated bio",
  "message": "Voter updated successfully"
}
```

**Error Response:**
- `404 Not Found` - Voter not found

---

### Delete Voter

Delete a voter from the system.

**Endpoint:** `DELETE /voters/{voter_id}`

**Success Response:** `200 OK`
```json
{
  "message": "Voter \"Peter King\" deleted successfully"
}
```

**Error Response:**
- `404 Not Found` - Voter not found

---

## Candidates API

### Create Candidate

Create a new MVP candidate.

**Endpoint:** `POST /candidates`

**Request Body:**
```json
{
  "name": "Josh Allen",        // Required
  "team": "Buffalo Bills",     // Optional
  "position": "QB",            // Optional
  "season": "2024-25"          // Required
}
```

**Success Response:** `201 Created`
```json
{
  "id": 1,
  "name": "Josh Allen",
  "team": "Buffalo Bills",
  "position": "QB",
  "season": "2024-25",
  "message": "Candidate created successfully"
}
```

**Error Responses:**
- `400 Bad Request` - Missing required fields
- `409 Conflict` - Candidate already exists for this season

---

### Get All Candidates

Retrieve all candidates for a season.

**Endpoint:** `GET /candidates?season=2024-25`

**Query Parameters:**
- `season` - Filter by season (default: "2024-25")

**Success Response:** `200 OK`
```json
[
  {
    "id": 1,
    "name": "Josh Allen",
    "team": "Buffalo Bills",
    "position": "QB",
    "vote_count": 15
  }
]
```

---

### Update Candidate

Update candidate information.

**Endpoint:** `PUT /candidates/{candidate_id}`

**Request Body:** (all fields optional)
```json
{
  "name": "Josh Allen",
  "team": "Buffalo Bills",
  "position": "Quarterback"
}
```

**Success Response:** `200 OK`

**Error Response:**
- `404 Not Found` - Candidate not found

---

### Delete Candidate

Delete a candidate.

**Endpoint:** `DELETE /candidates/{candidate_id}`

**Success Response:** `200 OK`
```json
{
  "message": "Candidate \"Josh Allen\" deleted successfully"
}
```

**Error Response:**
- `404 Not Found` - Candidate not found

---

## Votes API

### Create Vote

Create a new vote. Can use either IDs or names (will auto-create if needed).

**Endpoint:** `POST /votes`

**Request Body (using IDs):**
```json
{
  "voter_id": 1,              // voter_id OR voter_name required
  "candidate_id": 1,          // candidate_id OR candidate_name required
  "season": "2024-25",        // Required
  "ranking": 1,               // Optional (default: 1)
  "source_url": "https://...", // Optional
  "source_type": "social_media", // Optional: official, social_media, news_article, reddit, speculation
  "confidence": "high",       // Optional: high, medium, low
  "confidence_score": 85.5,   // Optional: 0-100
  "announcement_date": "2025-01-07T12:00:00", // Optional
  "extracted_text": "Full text", // Optional
  "verified": true            // Optional (default: true for manual entries)
}
```

**Request Body (using names - auto-create):**
```json
{
  "voter_name": "Mina Kimes",
  "candidate_name": "Saquon Barkley",
  "candidate_team": "Philadelphia Eagles",    // Optional
  "candidate_position": "RB",                 // Optional
  "season": "2024-25",
  "ranking": 1,
  "source_url": "https://x.com/minakimes/...",
  "source_type": "social_media",
  "confidence": "high",
  "confidence_score": 90.0
}
```

**Success Response:** `201 Created`
```json
{
  "id": 1,
  "voter": "Peter King",
  "candidate": "Josh Allen",
  "ranking": 1,
  "season": "2024-25",
  "source_url": "https://...",
  "confidence": "high",
  "confidence_score": 85.5,
  "verified": true,
  "message": "Vote created successfully"
}
```

**Error Responses:**
- `400 Bad Request` - Missing required fields or invalid values
- `404 Not Found` - Voter or candidate not found (when using IDs)
- `409 Conflict` - Vote already exists

---

### Get All Votes

Retrieve all votes for a season.

**Endpoint:** `GET /votes?season=2024-25`

**Query Parameters:**
- `season` - Filter by season (default: "2024-25")

**Success Response:** `200 OK`
```json
[
  {
    "voter": "Peter King",
    "candidate": "Josh Allen",
    "ranking": 1,
    "source_type": "social_media",
    "confidence": "high",
    "verified": true
  }
]
```

---

### Update Vote

Update an existing vote.

**Endpoint:** `PUT /votes/{vote_id}`

**Request Body:** (all fields optional)
```json
{
  "ranking": 2,
  "source_url": "https://...",
  "confidence": "medium",
  "confidence_score": 75.0,
  "source_type": "official",
  "verified": true,
  "extracted_text": "Updated text",
  "announcement_date": "2025-01-07T12:00:00"
}
```

**Success Response:** `200 OK`
```json
{
  "id": 1,
  "voter": "Peter King",
  "candidate": "Josh Allen",
  "ranking": 2,
  "season": "2024-25",
  "source_url": "https://...",
  "confidence": "medium",
  "confidence_score": 75.0,
  "verified": true,
  "message": "Vote updated successfully"
}
```

**Error Responses:**
- `400 Bad Request` - Invalid values
- `404 Not Found` - Vote not found

---

### Delete Vote

Delete a vote.

**Endpoint:** `DELETE /votes/{vote_id}`

**Success Response:** `200 OK`
```json
{
  "message": "Vote from \"Peter King\" for \"Josh Allen\" deleted successfully"
}
```

**Error Response:**
- `404 Not Found` - Vote not found

---

## Testing

A comprehensive test script is provided:

```bash
cd backend
python3 test_manual_entry.py
```

This will test all CRUD operations and error handling.

---

## Usage Examples

### Example 1: Add a known voter and their vote

```bash
# Create voter
curl -X POST http://localhost:5000/api/voters \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Mina Kimes",
    "outlet": "ESPN",
    "twitter_handle": "@minakimes"
  }'

# Create vote (auto-creates candidate if needed)
curl -X POST http://localhost:5000/api/votes \
  -H "Content-Type: application/json" \
  -d '{
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "candidate_team": "Philadelphia Eagles",
    "season": "2024-25",
    "ranking": 1,
    "source_url": "https://x.com/minakimes/status/...",
    "confidence": "high",
    "confidence_score": 90.0
  }'
```

### Example 2: Update voter information

```bash
curl -X PUT http://localhost:5000/api/voters/1 \
  -H "Content-Type: application/json" \
  -d '{
    "bio": "NFL analyst for ESPN. Co-host of NFL Live."
  }'
```

### Example 3: Get all votes for a voter

```bash
curl http://localhost:5000/api/voters/1
```

---

## Security Considerations

**⚠️ IMPORTANT:** This API currently has no authentication. Before deploying to production:

1. Add authentication middleware (JWT, OAuth, etc.)
2. Implement role-based access control (RBAC)
3. Rate limit the endpoints
4. Add input validation and sanitization
5. Enable HTTPS only
6. Add audit logging for all modifications

---

## Integration with Other Features

This manual entry system integrates with:

- **Confidence Scoring (Feature #9):** Votes include confidence scores
- **Source Tracking (Feature #7):** All sources are tracked via URLs
- **Database Schema (Features #4, #5):** Uses the established data models
- **Future Admin Interface (Feature #21):** Will provide UI for these endpoints

---

## Error Handling

All endpoints return appropriate HTTP status codes:

- `200 OK` - Successful GET, PUT, DELETE
- `201 Created` - Successful POST
- `400 Bad Request` - Invalid input
- `404 Not Found` - Resource not found
- `409 Conflict` - Duplicate resource
- `500 Internal Server Error` - Server error

Error responses include a JSON object with an `error` field:

```json
{
  "error": "Description of the error"
}
```
