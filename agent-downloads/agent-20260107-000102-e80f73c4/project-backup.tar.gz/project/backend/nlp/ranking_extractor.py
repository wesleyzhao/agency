"""
Ranking extraction from text (1st place, 2nd place, etc.)
"""
import re
from typing import List, Dict, Optional, Tuple
import logging


class RankingExtractor:
    """Extract ranking information from text"""

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # Patterns for different ranking formats
        self.ranking_patterns = {
            'numbered_list': r'(?:^|\n)\s*(?:#)?(\d+)[.:\)]\s+([^\n]+)',  # 1. Josh Allen
            'ordinal_words': r'(first|second|third|fourth|fifth)\s+place[:\s]+([^\n]+)',  # First place: Josh Allen
            'ordinal_numbers': r'(1st|2nd|3rd|4th|5th)[:\s]+([^\n]+)',  # 1st: Josh Allen
            'hashtag': r'#(\d+)[:\s]+([^\n]+)',  # #1: Josh Allen
            'place_suffix': r'([^\s]+)\s+(?:is|for)\s+(1st|2nd|3rd|4th|5th|first|second|third|fourth|fifth)',  # Josh Allen is 1st
        }

        # Ordinal to number mapping
        self.ordinal_map = {
            'first': 1, '1st': 1,
            'second': 2, '2nd': 2,
            'third': 3, '3rd': 3,
            'fourth': 4, '4th': 4,
            'fifth': 5, '5th': 5,
        }

    def extract_rankings_from_text(self, text: str) -> List[Dict]:
        """
        Extract ranking information from text

        Args:
            text: Text content to analyze

        Returns:
            List of ranking dictionaries with rank, player name, and context
        """
        results = []

        for pattern_type, pattern in self.ranking_patterns.items():
            matches = re.finditer(pattern, text, re.MULTILINE | re.IGNORECASE)

            for match in matches:
                rank_info = self._process_ranking_match(match, pattern_type)
                if rank_info:
                    results.append(rank_info)

        # Sort by rank
        results.sort(key=lambda x: x.get('rank', 999))

        # Deduplicate - keep first occurrence of each rank
        deduped = self._deduplicate_by_rank(results)

        return deduped

    def _process_ranking_match(self, match: re.Match, pattern_type: str) -> Optional[Dict]:
        """Process a regex match to extract ranking info"""
        groups = match.groups()

        if len(groups) != 2:
            return None

        rank_str, content = groups

        # Convert rank to number
        rank = self._parse_rank(rank_str)
        if rank is None or rank > 5:  # MVP voting is typically top 5
            return None

        # Clean up content
        content = content.strip()

        # Extract player name from content (first capitalized words)
        player_name = self._extract_player_name(content)

        return {
            'rank': rank,
            'raw_content': content,
            'player_name': player_name,
            'pattern_type': pattern_type,
            'context': match.group(0),
            'confidence': 'high' if player_name else 'medium'
        }

    def _parse_rank(self, rank_str: str) -> Optional[int]:
        """Convert rank string to integer"""
        rank_str = rank_str.strip().lower()

        # Check ordinal map
        if rank_str in self.ordinal_map:
            return self.ordinal_map[rank_str]

        # Try direct integer conversion
        try:
            rank = int(rank_str)
            return rank if 1 <= rank <= 5 else None
        except ValueError:
            return None

    def _extract_player_name(self, content: str) -> Optional[str]:
        """Extract player name from content string"""
        # Pattern: Capitalized words (likely a name)
        name_pattern = r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})\b'
        match = re.search(name_pattern, content)

        if match:
            name = match.group(1)
            # Validate it's not a common phrase
            if self._is_valid_player_name(name):
                return name

        return None

    def _is_valid_player_name(self, name: str) -> bool:
        """Check if extracted string looks like a player name"""
        # Must have at least first and last name
        words = name.split()
        if len(words) < 2:
            return False

        # Exclude common false positives
        false_positives = [
            'Most Valuable Player', 'National Football League',
            'First Place', 'Second Place', 'Third Place',
            'Fourth Place', 'Fifth Place', 'Super Bowl',
            'Pro Bowl', 'All Pro', 'Associated Press'
        ]

        return name not in false_positives

    def _deduplicate_by_rank(self, rankings: List[Dict]) -> List[Dict]:
        """Remove duplicate rankings, keeping first occurrence"""
        seen_ranks = {}

        for ranking in rankings:
            rank = ranking['rank']
            if rank not in seen_ranks:
                seen_ranks[rank] = ranking

        return list(seen_ranks.values())

    def extract_full_ballot(self, text: str) -> Dict:
        """
        Extract a complete MVP ballot (top 5 votes)

        Args:
            text: Text content to analyze

        Returns:
            Dictionary with ballot information
        """
        rankings = self.extract_rankings_from_text(text)

        ballot = {
            'complete': False,
            'votes': {},
            'raw_rankings': rankings
        }

        for ranking in rankings:
            rank = ranking['rank']
            if 1 <= rank <= 5:
                ballot['votes'][rank] = {
                    'player_name': ranking.get('player_name'),
                    'raw_content': ranking.get('raw_content'),
                    'confidence': ranking.get('confidence')
                }

        # Check if we have a complete ballot (all 5 votes)
        if len(ballot['votes']) == 5 and all(i in ballot['votes'] for i in range(1, 6)):
            ballot['complete'] = True

        return ballot

    def infer_ranking_from_context(self, text: str, player_name: str) -> Optional[int]:
        """
        Infer a player's ranking from context around their name

        Args:
            text: Full text content
            player_name: Player name to search for

        Returns:
            Inferred rank (1-5) or None
        """
        # Find player mention
        pattern = r'\b' + re.escape(player_name) + r'\b'
        match = re.search(pattern, text, re.IGNORECASE)

        if not match:
            return None

        # Get context around mention
        start = max(0, match.start() - 100)
        end = min(len(text), match.end() + 100)
        context = text[start:end].lower()

        # Check for ranking keywords
        ranking_keywords = {
            1: ['first place', '#1', 'number one', 'top of', 'number 1', '1.', '1st'],
            2: ['second place', '#2', 'number two', 'number 2', '2.', '2nd'],
            3: ['third place', '#3', 'number three', 'number 3', '3.', '3rd'],
            4: ['fourth place', '#4', 'number four', 'number 4', '4.', '4th'],
            5: ['fifth place', '#5', 'number five', 'number 5', '5.', '5th']
        }

        for rank, keywords in ranking_keywords.items():
            if any(keyword in context for keyword in keywords):
                return rank

        # Default to rank 1 if MVP-related words but no specific rank
        if any(word in context for word in ['mvp', 'my vote', 'voting for', 'pick is']):
            return 1

        return None

    def validate_ballot(self, ballot: Dict) -> Tuple[bool, List[str]]:
        """
        Validate a ballot for completeness and correctness

        Args:
            ballot: Ballot dictionary from extract_full_ballot

        Returns:
            Tuple of (is_valid, list of issues)
        """
        issues = []

        # Check for duplicate player names
        player_names = [vote.get('player_name') for vote in ballot.get('votes', {}).values() if vote.get('player_name')]
        if len(player_names) != len(set(player_names)):
            issues.append("Duplicate player names in ballot")

        # Check for missing ranks
        for rank in range(1, 6):
            if rank not in ballot.get('votes', {}):
                issues.append(f"Missing rank {rank}")
            elif not ballot['votes'][rank].get('player_name'):
                issues.append(f"Rank {rank} has no player name")

        # Check confidence levels
        low_confidence_ranks = [
            rank for rank, vote in ballot.get('votes', {}).items()
            if vote.get('confidence') == 'low'
        ]
        if low_confidence_ranks:
            issues.append(f"Low confidence for ranks: {low_confidence_ranks}")

        is_valid = len(issues) == 0

        return is_valid, issues
