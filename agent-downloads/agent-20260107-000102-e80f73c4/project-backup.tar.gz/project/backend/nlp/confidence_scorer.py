"""
Comprehensive confidence scoring system for vote extraction

This module provides a sophisticated confidence scoring system that evaluates
the reliability of extracted voter information based on multiple factors.
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime
import re


class ConfidenceScorer:
    """
    Advanced confidence scoring for vote extraction

    Calculates both numeric scores (0-100) and categorical levels (high/medium/low)
    based on multiple factors including source credibility, extraction quality,
    and verification status.
    """

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # Weight distribution for different factors (must sum to 1.0)
        self.weights = {
            'voter_confidence': 0.25,      # How confident we are about voter identity
            'candidate_confidence': 0.15,  # How confident about candidate mention
            'ranking_confidence': 0.15,    # How confident about ranking/placement
            'source_type': 0.20,           # Type of source (official > social > speculation)
            'context_quality': 0.15,       # Quality of surrounding text context
            'verification': 0.10,          # Has this been manually verified?
        }

        # Source type reliability scores (0-100)
        self.source_type_scores = {
            'official': 100,           # Official AP announcement or voter's verified account
            'social_media': 75,        # Verified social media from known voter
            'news_article': 70,        # News article quoting voter
            'reddit': 50,              # Reddit post or comment
            'speculation': 30,         # Speculation or unverified source
            'unknown': 40,             # Unknown source type
        }

        # Known high-credibility domains
        self.trusted_domains = [
            'espn.com', 'nfl.com', 'ap.org', 'associatedpress.com',
            'thescore.com', 'cbssports.com', 'nbcsports.com',
            'foxsports.com', 'si.com', 'theathletic.com',
            'profootballtalk.com', 'twitter.com', 'x.com'
        ]

    def calculate_vote_confidence(self, vote_data: Dict) -> Dict:
        """
        Calculate comprehensive confidence score for a vote

        Args:
            vote_data: Dictionary containing vote information with fields:
                - voter_name: str
                - voter_confidence: str (high/medium/low)
                - candidate_name: str
                - ranking: int
                - ranking_confidence: str (high/medium/low)
                - source_url: str
                - source_type: str
                - extracted_text: str
                - voter_context: str
                - verified: bool (optional)
                - twitter_handle: str (optional)

        Returns:
            Dictionary with:
                - numeric_score: float (0-100)
                - confidence_level: str (high/medium/low)
                - factor_scores: dict with individual factor scores
                - recommendation: str (what to do with this vote)
        """
        factor_scores = {}

        # Calculate individual factor scores
        factor_scores['voter_confidence'] = self._score_voter_confidence(vote_data)
        factor_scores['candidate_confidence'] = self._score_candidate_confidence(vote_data)
        factor_scores['ranking_confidence'] = self._score_ranking_confidence(vote_data)
        factor_scores['source_type'] = self._score_source_type(vote_data)
        factor_scores['context_quality'] = self._score_context_quality(vote_data)
        factor_scores['verification'] = self._score_verification(vote_data)

        # Calculate weighted average
        numeric_score = sum(
            factor_scores[factor] * self.weights[factor]
            for factor in self.weights.keys()
        )

        # Convert to categorical level
        confidence_level = self._numeric_to_categorical(numeric_score)

        # Generate recommendation
        recommendation = self._generate_recommendation(numeric_score, factor_scores)

        self.logger.debug(
            f"Vote confidence: {numeric_score:.1f} ({confidence_level}) - "
            f"{vote_data.get('voter_name')} -> {vote_data.get('candidate_name')}"
        )

        return {
            'numeric_score': round(numeric_score, 2),
            'confidence_level': confidence_level,
            'factor_scores': factor_scores,
            'recommendation': recommendation,
            'calculated_at': datetime.utcnow().isoformat()
        }

    def _score_voter_confidence(self, vote_data: Dict) -> float:
        """
        Score confidence in voter identification (0-100)

        Factors:
        - Is voter in known voters list?
        - Do we have twitter handle?
        - Quality of voter detection pattern
        """
        voter_conf = vote_data.get('voter_confidence', 'low')

        # Base score from categorical confidence
        base_scores = {
            'high': 85,
            'medium': 60,
            'low': 35
        }
        score = base_scores.get(voter_conf, 40)

        # Bonus if we have verified twitter handle
        if vote_data.get('twitter_handle'):
            score = min(100, score + 10)

        # Bonus if voter name is in our known voters list
        # (This assumes VoterExtractor's known_voters was used)
        voter_source = vote_data.get('voter_source', '')
        if voter_source == 'known_voter_list':
            score = min(100, score + 5)

        return float(score)

    def _score_candidate_confidence(self, vote_data: Dict) -> float:
        """
        Score confidence in candidate identification (0-100)

        Factors:
        - Full name vs. last name only
        - Known MVP candidate vs. unknown player
        """
        # If we have a candidate name, assume it was validated
        # against known candidates list (from CandidateExtractor)
        candidate_name = vote_data.get('candidate_name', '')

        if not candidate_name:
            return 0.0

        # Full name (2+ words) is higher confidence
        name_parts = candidate_name.split()
        if len(name_parts) >= 2:
            score = 80
        else:
            score = 60

        # If we have team and position info, it was validated
        if vote_data.get('candidate_team') and vote_data.get('candidate_position'):
            score = min(100, score + 15)

        return float(score)

    def _score_ranking_confidence(self, vote_data: Dict) -> float:
        """
        Score confidence in ranking/placement (0-100)

        Factors:
        - Explicit ranking vs. inferred
        - Ranking pattern clarity
        """
        ranking_conf = vote_data.get('ranking_confidence', 'medium')
        ranking = vote_data.get('ranking', 0)

        # Base score from categorical confidence
        base_scores = {
            'high': 85,
            'medium': 60,
            'low': 35
        }
        score = base_scores.get(ranking_conf, 50)

        # If ranking is 1 (MVP pick), slightly higher confidence
        # since people are more explicit about their #1 choice
        if ranking == 1:
            score = min(100, score + 10)

        # If no ranking specified, lower confidence
        if ranking == 0:
            score = max(0, score - 20)

        return float(score)

    def _score_source_type(self, vote_data: Dict) -> float:
        """
        Score based on source type and credibility (0-100)

        Factors:
        - Source type (official > social media > news > reddit > speculation)
        - Source domain reputation
        - URL structure
        """
        source_type = vote_data.get('source_type', 'unknown')
        source_url = vote_data.get('source_url', '')

        # Base score from source type
        score = self.source_type_scores.get(source_type, 40)

        # Adjust based on domain reputation
        if source_url:
            domain_bonus = self._get_domain_bonus(source_url)
            score = min(100, score + domain_bonus)

        return float(score)

    def _score_context_quality(self, vote_data: Dict) -> float:
        """
        Score quality of extracted text context (0-100)

        Factors:
        - Length of extracted text
        - Presence of voting keywords
        - Clarity of statement
        """
        extracted_text = vote_data.get('extracted_text', '')
        voter_context = vote_data.get('voter_context', '')

        # Combine both context sources
        full_context = f"{extracted_text} {voter_context}"

        if not full_context.strip():
            return 20.0  # Minimal score if no context

        score = 50.0  # Base score

        # Length bonus (more context is better, up to a point)
        context_length = len(full_context)
        if context_length > 200:
            score += 15
        elif context_length > 100:
            score += 10
        elif context_length > 50:
            score += 5

        # Check for strong voting indicators
        strong_indicators = [
            'my mvp vote', 'i voted for', 'my ballot', 'first place',
            'voting for', 'my choice', 'my pick', 'top of my ballot'
        ]

        context_lower = full_context.lower()
        indicator_count = sum(1 for indicator in strong_indicators if indicator in context_lower)
        score += min(20, indicator_count * 10)

        # Check for numbered list (structured ballot)
        if re.search(r'\b[1-5][\.\):]', full_context):
            score += 10

        return min(100.0, score)

    def _score_verification(self, vote_data: Dict) -> float:
        """
        Score based on verification status (0-100)

        Factors:
        - Manual verification flag
        - Number of corroborating sources
        """
        verified = vote_data.get('verified', False)

        if verified:
            return 100.0

        # Check if we have multiple sources for this vote
        # (This would come from VoteSource junction table in production)
        num_sources = vote_data.get('num_sources', 1)

        if num_sources >= 3:
            return 70.0
        elif num_sources >= 2:
            return 50.0
        else:
            return 30.0

    def _get_domain_bonus(self, url: str) -> float:
        """Get bonus score based on URL domain reputation"""
        url_lower = url.lower()

        # Check if URL is from trusted domain
        for domain in self.trusted_domains:
            if domain in url_lower:
                return 10.0

        # Check for verified twitter/x status indicator
        if ('twitter.com' in url_lower or 'x.com' in url_lower):
            # Could enhance this to check for verified badge
            return 5.0

        return 0.0

    def _numeric_to_categorical(self, numeric_score: float) -> str:
        """Convert numeric score (0-100) to categorical level"""
        if numeric_score >= 75:
            return 'high'
        elif numeric_score >= 50:
            return 'medium'
        else:
            return 'low'

    def _generate_recommendation(self, numeric_score: float, factor_scores: Dict) -> str:
        """
        Generate recommendation for how to handle this vote

        Args:
            numeric_score: Overall confidence score
            factor_scores: Individual factor scores

        Returns:
            Recommendation string
        """
        if numeric_score >= 80:
            return "auto_approve"  # High confidence, can show immediately
        elif numeric_score >= 65:
            return "review_recommended"  # Medium-high, quick review suggested
        elif numeric_score >= 45:
            return "verification_required"  # Medium, needs verification
        else:
            return "hold_for_review"  # Low confidence, manual review required

    def calculate_batch_confidence(self, votes: List[Dict]) -> Dict:
        """
        Calculate confidence scores for multiple votes

        Args:
            votes: List of vote data dictionaries

        Returns:
            Dictionary with:
                - votes: List of votes with added confidence scores
                - summary: Batch statistics
        """
        scored_votes = []

        for vote in votes:
            confidence_result = self.calculate_vote_confidence(vote)

            # Add confidence info to vote
            vote_with_confidence = vote.copy()
            vote_with_confidence.update({
                'confidence_numeric': confidence_result['numeric_score'],
                'confidence_level': confidence_result['confidence_level'],
                'confidence_factors': confidence_result['factor_scores'],
                'recommendation': confidence_result['recommendation']
            })

            scored_votes.append(vote_with_confidence)

        # Calculate summary statistics
        if scored_votes:
            numeric_scores = [v['confidence_numeric'] for v in scored_votes]
            avg_score = sum(numeric_scores) / len(numeric_scores)

            level_counts = {
                'high': sum(1 for v in scored_votes if v['confidence_level'] == 'high'),
                'medium': sum(1 for v in scored_votes if v['confidence_level'] == 'medium'),
                'low': sum(1 for v in scored_votes if v['confidence_level'] == 'low')
            }

            recommendation_counts = {}
            for vote in scored_votes:
                rec = vote['recommendation']
                recommendation_counts[rec] = recommendation_counts.get(rec, 0) + 1
        else:
            avg_score = 0
            level_counts = {'high': 0, 'medium': 0, 'low': 0}
            recommendation_counts = {}

        summary = {
            'total_votes': len(scored_votes),
            'average_confidence': round(avg_score, 2),
            'confidence_distribution': level_counts,
            'recommendation_distribution': recommendation_counts
        }

        return {
            'votes': scored_votes,
            'summary': summary
        }

    def adjust_weights(self, new_weights: Dict):
        """
        Adjust the weight distribution for factors

        Args:
            new_weights: Dictionary of factor weights (must sum to 1.0)

        Raises:
            ValueError: If weights don't sum to 1.0
        """
        weight_sum = sum(new_weights.values())
        if abs(weight_sum - 1.0) > 0.01:
            raise ValueError(f"Weights must sum to 1.0, got {weight_sum}")

        self.weights.update(new_weights)
        self.logger.info(f"Updated confidence weights: {self.weights}")

    def get_factor_importance(self) -> Dict:
        """Get current factor weights and their importance"""
        return {
            'weights': self.weights.copy(),
            'description': {
                'voter_confidence': 'Confidence in voter identity',
                'candidate_confidence': 'Confidence in candidate identification',
                'ranking_confidence': 'Confidence in ranking/placement',
                'source_type': 'Reliability of source type',
                'context_quality': 'Quality of extracted text context',
                'verification': 'Manual verification and corroboration'
            }
        }
