"""
Main vote extraction orchestrator that combines all NLP components
"""
import logging
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import re

from .voter_extractor import VoterExtractor
from .candidate_extractor import CandidateExtractor
from .ranking_extractor import RankingExtractor
from .confidence_scorer import ConfidenceScorer
from .credibility_scorer import CredibilityScorer


class VoteExtractor:
    """
    Main orchestrator for extracting complete vote information from text
    Combines voter detection, candidate detection, and ranking extraction
    """

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # Initialize component extractors
        self.voter_extractor = VoterExtractor()
        self.candidate_extractor = CandidateExtractor()
        self.ranking_extractor = RankingExtractor()
        self.confidence_scorer = ConfidenceScorer()
        self.credibility_scorer = CredibilityScorer()  # Feature #16

    def extract_votes_from_text(self, text: str, source_url: str = "",
                                 source_type: str = "unknown") -> List[Dict]:
        """
        Extract complete vote information from text

        Args:
            text: Text content to analyze
            source_url: URL where text was found
            source_type: Type of source (reddit, twitter, news, etc.)

        Returns:
            List of vote dictionaries with voter, candidate, ranking, and confidence
        """
        results = []

        # Step 1: Extract voters
        voters = self.voter_extractor.extract_voters_from_text(text, source_url)
        self.logger.info(f"Found {len(voters)} potential voters")

        # Step 2: Extract candidates
        candidates = self.candidate_extractor.extract_candidates_from_text(text)
        self.logger.info(f"Found {len(candidates)} candidate mentions")

        # Step 3: Extract rankings
        rankings = self.ranking_extractor.extract_rankings_from_text(text)
        self.logger.info(f"Found {len(rankings)} ranked entries")

        # Step 4: Try to extract complete ballots
        if rankings:
            ballot_votes = self._extract_from_ballot(voters, rankings, text, source_url)
            results.extend(ballot_votes)

        # Step 5: If no ballot, try to match voters to candidates
        if not results and voters and candidates:
            paired_votes = self._pair_voters_with_candidates(voters, candidates, text, source_url)
            results.extend(paired_votes)

        # Step 6: Calculate comprehensive confidence scores for each vote
        for vote in results:
            # Legacy simple confidence (for backwards compatibility)
            vote['overall_confidence'] = self._calculate_overall_confidence(vote)
            vote['extracted_at'] = datetime.utcnow().isoformat()
            vote['source_type'] = source_type

            # New comprehensive confidence scoring
            confidence_result = self.confidence_scorer.calculate_vote_confidence(vote)
            vote['confidence_numeric'] = confidence_result['numeric_score']
            vote['confidence_level'] = confidence_result['confidence_level']
            vote['confidence_factors'] = confidence_result['factor_scores']
            vote['recommendation'] = confidence_result['recommendation']

            # Feature #16: Source credibility assessment
            credibility_data = {
                'url': source_url,
                'title': vote.get('source_title', ''),
                'content': text,
                'source_type': source_type,
                'voter_name': vote.get('voter_name', ''),
                'is_verified_account': vote.get('is_verified_account', False)
            }
            credibility_result = self.credibility_scorer.assess_source_credibility(credibility_data)
            vote['credibility_tier'] = credibility_result['credibility_tier']
            vote['credibility_score'] = credibility_result['credibility_score']
            vote['has_direct_quote'] = credibility_result['has_direct_quote']
            vote['has_speculation_language'] = credibility_result['has_speculation_language']
            vote['domain_reputation'] = credibility_result['domain_reputation']
            vote['credibility_badge'] = self.credibility_scorer.get_credibility_badge(
                credibility_result['credibility_tier']
            )

        self.logger.info(f"Extracted {len(results)} total votes")

        return results

    def _extract_from_ballot(self, voters: List[Dict], rankings: List[Dict],
                            text: str, source_url: str) -> List[Dict]:
        """
        Extract votes from a ranked ballot format

        Args:
            voters: List of detected voters
            rankings: List of detected rankings
            text: Full text content
            source_url: Source URL

        Returns:
            List of vote dictionaries
        """
        votes = []

        # If we have one clear voter and multiple rankings, assume it's their ballot
        if len(voters) == 1:
            voter = voters[0]

            for ranking in rankings:
                # Try to match player name to known candidate
                player_name = ranking.get('player_name')
                if player_name:
                    matched_candidate = self._match_player_to_candidate(player_name)

                    if matched_candidate:
                        votes.append({
                            'voter_name': voter['name'],
                            'voter_confidence': voter['confidence'],
                            'voter_context': voter.get('context', ''),
                            'twitter_handle': voter.get('twitter_handle'),
                            'candidate_name': matched_candidate['name'],
                            'candidate_team': matched_candidate['team'],
                            'candidate_position': matched_candidate['position'],
                            'ranking': ranking['rank'],
                            'ranking_confidence': ranking['confidence'],
                            'source_url': source_url,
                            'extracted_text': ranking.get('context', ''),
                        })

        # Multiple voters or no clear voter - try to infer from context
        elif len(voters) > 1:
            # Look for the voter closest to the ranking mentions
            for ranking in rankings:
                closest_voter = self._find_closest_voter(ranking, voters, text)
                player_name = ranking.get('player_name')

                if closest_voter and player_name:
                    matched_candidate = self._match_player_to_candidate(player_name)

                    if matched_candidate:
                        votes.append({
                            'voter_name': closest_voter['name'],
                            'voter_confidence': 'medium',  # Lower confidence when multiple voters
                            'voter_context': closest_voter.get('context', ''),
                            'candidate_name': matched_candidate['name'],
                            'candidate_team': matched_candidate['team'],
                            'candidate_position': matched_candidate['position'],
                            'ranking': ranking['rank'],
                            'ranking_confidence': ranking['confidence'],
                            'source_url': source_url,
                            'extracted_text': ranking.get('context', ''),
                        })

        return votes

    def _pair_voters_with_candidates(self, voters: List[Dict], candidates: List[Dict],
                                     text: str, source_url: str) -> List[Dict]:
        """
        Pair detected voters with candidates when no clear ballot structure

        Args:
            voters: List of detected voters
            candidates: List of detected candidates
            text: Full text content
            source_url: Source URL

        Returns:
            List of vote dictionaries
        """
        votes = []

        # Simple case: one voter, one or more candidates
        if len(voters) == 1:
            voter = voters[0]

            for candidate in candidates:
                # Try to infer ranking from context
                ranking = self.ranking_extractor.infer_ranking_from_context(
                    text, candidate['name']
                )

                votes.append({
                    'voter_name': voter['name'],
                    'voter_confidence': voter['confidence'],
                    'voter_context': voter.get('context', ''),
                    'twitter_handle': voter.get('twitter_handle'),
                    'candidate_name': candidate['name'],
                    'candidate_team': candidate['team'],
                    'candidate_position': candidate['position'],
                    'ranking': ranking or 1,  # Default to 1st place if not specified
                    'ranking_confidence': 'medium' if ranking else 'low',
                    'source_url': source_url,
                    'extracted_text': candidate.get('context', ''),
                })

        # Multiple voters - try to match based on proximity
        elif len(voters) > 1:
            for candidate in candidates:
                closest_voter = self._find_closest_voter(candidate, voters, text)

                if closest_voter:
                    ranking = self.ranking_extractor.infer_ranking_from_context(
                        text, candidate['name']
                    )

                    votes.append({
                        'voter_name': closest_voter['name'],
                        'voter_confidence': 'low',  # Lower confidence for ambiguous attribution
                        'voter_context': closest_voter.get('context', ''),
                        'candidate_name': candidate['name'],
                        'candidate_team': candidate['team'],
                        'candidate_position': candidate['position'],
                        'ranking': ranking or 1,
                        'ranking_confidence': 'low',
                        'source_url': source_url,
                        'extracted_text': candidate.get('context', ''),
                    })

        return votes

    def _match_player_to_candidate(self, player_name: str) -> Optional[Dict]:
        """Match a player name to a known MVP candidate"""
        candidates = self.candidate_extractor.get_candidates()

        # Direct match
        if player_name in candidates:
            return {
                'name': player_name,
                'team': candidates[player_name]['team'],
                'position': candidates[player_name]['position']
            }

        # Alias match
        for candidate_name, info in candidates.items():
            if player_name in info['aliases']:
                return {
                    'name': candidate_name,
                    'team': info['team'],
                    'position': info['position']
                }

        # Fuzzy match on last name
        player_last = player_name.split()[-1].lower()
        for candidate_name, info in candidates.items():
            candidate_last = candidate_name.split()[-1].lower()
            if player_last == candidate_last:
                return {
                    'name': candidate_name,
                    'team': info['team'],
                    'position': info['position']
                }

        return None

    def _find_closest_voter(self, item: Dict, voters: List[Dict], text: str) -> Optional[Dict]:
        """
        Find the voter closest to an item (candidate or ranking) in the text

        Args:
            item: Dictionary with 'context' field
            voters: List of voter dictionaries
            text: Full text content

        Returns:
            Closest voter or None
        """
        item_context = item.get('context', '')
        if not item_context:
            return voters[0] if voters else None

        # Find position of item in text
        item_pos = text.find(item_context)
        if item_pos == -1:
            return voters[0] if voters else None

        # Find closest voter by text position
        min_distance = float('inf')
        closest_voter = None

        for voter in voters:
            voter_context = voter.get('context', '')
            voter_pos = text.find(voter_context)

            if voter_pos != -1:
                distance = abs(item_pos - voter_pos)
                if distance < min_distance:
                    min_distance = distance
                    closest_voter = voter

        return closest_voter or (voters[0] if voters else None)

    def _calculate_overall_confidence(self, vote: Dict) -> str:
        """
        Calculate overall confidence based on voter and candidate confidence

        Args:
            vote: Vote dictionary

        Returns:
            Overall confidence level (high/medium/low)
        """
        voter_conf = vote.get('voter_confidence', 'low')
        ranking_conf = vote.get('ranking_confidence', 'medium')

        confidence_scores = {
            'high': 3,
            'medium': 2,
            'low': 1
        }

        voter_score = confidence_scores.get(voter_conf, 1)
        ranking_score = confidence_scores.get(ranking_conf, 2)

        # Average the scores
        avg_score = (voter_score + ranking_score) / 2

        if avg_score >= 2.5:
            return 'high'
        elif avg_score >= 1.5:
            return 'medium'
        else:
            return 'low'

    def extract_announcement_date(self, text: str) -> Optional[datetime]:
        """
        Try to extract the date when vote was announced

        Args:
            text: Text content

        Returns:
            Datetime object or None
        """
        # Date patterns to look for
        date_patterns = [
            r'(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}',
            r'\d{1,2}/\d{1,2}/\d{4}',
            r'\d{4}-\d{2}-\d{2}',
        ]

        for pattern in date_patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    date_str = match.group(0)
                    # Try to parse - this is simplified, could use dateutil
                    # For now, just return None and let caller handle
                    return None
                except:
                    continue

        return None

    def add_known_voter(self, name: str):
        """Add a voter to the known voters list"""
        self.voter_extractor.add_known_voter(name)

    def add_candidate(self, name: str, team: str, position: str, aliases: List[str] = None):
        """Add a candidate to the known candidates list"""
        self.candidate_extractor.add_candidate(name, team, position, aliases)

    def get_extraction_stats(self) -> Dict:
        """Get statistics about known voters and candidates"""
        return {
            'known_voters': len(self.voter_extractor.get_known_voters()),
            'known_candidates': len(self.candidate_extractor.get_candidates()),
            'voter_list': self.voter_extractor.get_known_voters(),
            'candidate_list': list(self.candidate_extractor.get_candidates().keys())
        }
