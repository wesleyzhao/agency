"""
Source Credibility Scoring System for NFL MVP Voter Tracker

This module provides a sophisticated credibility assessment system that goes beyond
basic source type classification to evaluate the trustworthiness and reliability
of vote announcements.

Credibility Tiers (from highest to lowest):
1. VERIFIED - Direct announcement from voter's verified account
2. OFFICIAL - Official AP/news outlet article with direct quote
3. RELIABLE - Trusted news source reporting voter's pick
4. UNVERIFIED - Social media or forum post without verification
5. SPECULATION - Rumor, prediction, or third-party speculation
"""

import logging
import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from urllib.parse import urlparse


class CredibilityTier:
    """Credibility tier constants"""
    VERIFIED = "verified"
    OFFICIAL = "official"
    RELIABLE = "reliable"
    UNVERIFIED = "unverified"
    SPECULATION = "speculation"


class CredibilityScorer:
    """
    Comprehensive credibility scoring system for source evaluation

    Evaluates sources based on:
    - Domain reputation and authority
    - Source type and verification status
    - Content indicators (direct quote vs. speculation)
    - Cross-verification with other sources
    """

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # Domain reputation database
        # Tier 1: Official AP and major news organizations
        self.tier1_domains = [
            'ap.org', 'associatedpress.com',
            'nfl.com', 'espn.com', 'cbssports.com', 'nbcsports.com',
            'foxsports.com', 'si.com', 'thescore.com', 'theathletic.com'
        ]

        # Tier 2: Reputable sports media and news outlets
        self.tier2_domains = [
            'profootballtalk.com', 'bleacherreport.com', 'sbnation.com',
            'usatoday.com', 'washingtonpost.com', 'nytimes.com',
            'yahoo.com', 'msn.com', 'cnn.com', 'abc.com', 'cbs.com', 'nbc.com'
        ]

        # Tier 3: Sports blogs and smaller outlets
        self.tier3_domains = [
            'profootballrumors.com', 'sportingnews.com', 'fansided.com',
            'deadspin.com', 'barstoolsports.com'
        ]

        # Social media platforms (credibility depends on account verification)
        self.social_media_domains = [
            'twitter.com', 'x.com', 'instagram.com', 'facebook.com',
            'threads.net', 'bluesky.social'
        ]

        # Forums and community sites
        self.forum_domains = [
            'reddit.com', 'boards.net', 'forum', 'community'
        ]

        # Credibility tier scores (0-100)
        self.tier_scores = {
            CredibilityTier.VERIFIED: 95,
            CredibilityTier.OFFICIAL: 85,
            CredibilityTier.RELIABLE: 70,
            CredibilityTier.UNVERIFIED: 45,
            CredibilityTier.SPECULATION: 25
        }

        # Direct quote patterns (indicate higher credibility)
        self.direct_quote_patterns = [
            r'"[^"]*\b(vote|voting|ballot|pick|mvp|choice)\b[^"]*"',
            r"'[^']*\b(vote|voting|ballot|pick|mvp|choice)\b[^']*'",
            r'\bsaid\b.*\b(vote|voting|ballot|pick|mvp)\b',
            r'\btold\b.*\b(vote|voting|ballot|pick|mvp)\b',
            r'\bstated\b.*\b(vote|voting|ballot|pick|mvp)\b',
            r'\bannounced\b.*\b(vote|voting|ballot|pick|mvp)\b'
        ]

        # Speculation patterns (indicate lower credibility)
        self.speculation_patterns = [
            r'\b(might|may|could|would|should|possibly|probably|likely)\b.*\bvote',
            r'\b(rumor|speculation|expected|predicted|anticipated)\b',
            r'\b(i think|i believe|i heard|sources say|reportedly)\b',
            r'\bif\b.*\bvote',
            r'\bwill probably\b',
            r'\bshould vote\b'
        ]

        # Verified account indicators
        self.verified_account_indicators = [
            'verified', 'official', 'authenticated', 'confirmed account',
            'blue checkmark', 'verified badge'
        ]

    def assess_source_credibility(self, source_data: Dict) -> Dict:
        """
        Comprehensive credibility assessment of a source

        Args:
            source_data: Dictionary containing:
                - url: str (source URL)
                - title: str (page title)
                - content: str (extracted text)
                - source_type: str (official/social_media/news_article/etc.)
                - voter_name: str (name of voter)
                - is_verified_account: bool (optional)
                - has_direct_quote: bool (optional)
                - num_corroborating_sources: int (optional)

        Returns:
            Dictionary with:
                - credibility_tier: str (verified/official/reliable/unverified/speculation)
                - credibility_score: float (0-100)
                - domain_reputation: str (tier1/tier2/tier3/social/forum/unknown)
                - has_direct_quote: bool
                - has_speculation_language: bool
                - verification_indicators: List[str]
                - confidence_boost: float (bonus to overall confidence)
                - recommendation: str
                - reasoning: List[str] (explanation of scoring)
        """
        url = source_data.get('url', '')
        content = source_data.get('content', '')
        title = source_data.get('title', '')
        source_type = source_data.get('source_type', 'unknown')

        reasoning = []
        verification_indicators = []

        # Step 1: Assess domain reputation
        domain_reputation = self._assess_domain_reputation(url)
        reasoning.append(f"Domain reputation: {domain_reputation}")

        # Step 2: Check for direct quotes
        has_direct_quote = self._check_direct_quotes(content, title)
        if has_direct_quote:
            reasoning.append("Contains direct quote from voter")
            verification_indicators.append("direct_quote")

        # Step 3: Check for speculation language
        has_speculation = self._check_speculation_language(content, title)
        if has_speculation:
            reasoning.append("Contains speculation language")
            verification_indicators.append("speculation_detected")

        # Step 4: Check for verified account indicators
        is_verified = source_data.get('is_verified_account', False)
        if is_verified or self._check_verified_indicators(content, title):
            reasoning.append("Verified account/source")
            verification_indicators.append("verified_account")
            is_verified = True

        # Step 5: Check for corroborating sources
        num_corroborating = source_data.get('num_corroborating_sources', 0)
        if num_corroborating > 0:
            reasoning.append(f"{num_corroborating} corroborating sources")
            verification_indicators.append(f"corroborated_{num_corroborating}x")

        # Step 6: Determine credibility tier
        credibility_tier = self._determine_credibility_tier(
            domain_reputation=domain_reputation,
            source_type=source_type,
            has_direct_quote=has_direct_quote,
            has_speculation=has_speculation,
            is_verified=is_verified,
            num_corroborating=num_corroborating
        )
        reasoning.append(f"Assigned tier: {credibility_tier}")

        # Step 7: Calculate numeric credibility score
        base_score = self.tier_scores[credibility_tier]

        # Apply modifiers
        score_modifiers = 0.0

        # Domain reputation bonus
        if domain_reputation == 'tier1':
            score_modifiers += 5
        elif domain_reputation == 'tier2':
            score_modifiers += 2

        # Direct quote bonus
        if has_direct_quote:
            score_modifiers += 8

        # Speculation penalty
        if has_speculation:
            score_modifiers -= 15

        # Corroboration bonus
        if num_corroborating >= 3:
            score_modifiers += 10
        elif num_corroborating >= 2:
            score_modifiers += 5
        elif num_corroborating == 1:
            score_modifiers += 2

        credibility_score = max(0, min(100, base_score + score_modifiers))

        # Step 8: Calculate confidence boost
        # This is a bonus that can be added to overall vote confidence
        confidence_boost = self._calculate_confidence_boost(
            credibility_tier, credibility_score
        )

        # Step 9: Generate recommendation
        recommendation = self._generate_credibility_recommendation(
            credibility_tier, credibility_score, has_speculation
        )

        self.logger.info(
            f"Credibility assessed: {credibility_tier} ({credibility_score:.1f}) - {url[:50]}..."
        )

        return {
            'credibility_tier': credibility_tier,
            'credibility_score': round(credibility_score, 2),
            'domain_reputation': domain_reputation,
            'has_direct_quote': has_direct_quote,
            'has_speculation_language': has_speculation,
            'verification_indicators': verification_indicators,
            'confidence_boost': round(confidence_boost, 2),
            'recommendation': recommendation,
            'reasoning': reasoning,
            'assessed_at': datetime.utcnow().isoformat()
        }

    def _assess_domain_reputation(self, url: str) -> str:
        """
        Assess the reputation tier of a domain

        Returns: tier1/tier2/tier3/social/forum/unknown
        """
        if not url:
            return 'unknown'

        url_lower = url.lower()
        domain = self._extract_domain(url)

        # Check tier 1 domains
        for tier1_domain in self.tier1_domains:
            if tier1_domain in domain:
                return 'tier1'

        # Check tier 2 domains
        for tier2_domain in self.tier2_domains:
            if tier2_domain in domain:
                return 'tier2'

        # Check tier 3 domains
        for tier3_domain in self.tier3_domains:
            if tier3_domain in domain:
                return 'tier3'

        # Check social media
        for social_domain in self.social_media_domains:
            if social_domain in domain:
                return 'social'

        # Check forums
        for forum_domain in self.forum_domains:
            if forum_domain in domain:
                return 'forum'

        return 'unknown'

    def _extract_domain(self, url: str) -> str:
        """Extract domain from URL"""
        try:
            parsed = urlparse(url)
            return parsed.netloc.lower()
        except:
            return url.lower()

    def _check_direct_quotes(self, content: str, title: str) -> bool:
        """Check if content contains direct quotes about voting"""
        full_text = f"{title} {content}".lower()

        for pattern in self.direct_quote_patterns:
            if re.search(pattern, full_text, re.IGNORECASE):
                return True

        return False

    def _check_speculation_language(self, content: str, title: str) -> bool:
        """Check if content contains speculation language"""
        full_text = f"{title} {content}".lower()

        for pattern in self.speculation_patterns:
            if re.search(pattern, full_text, re.IGNORECASE):
                return True

        return False

    def _check_verified_indicators(self, content: str, title: str) -> bool:
        """Check for verified account indicators in content"""
        full_text = f"{title} {content}".lower()

        for indicator in self.verified_account_indicators:
            if indicator in full_text:
                return True

        return False

    def _determine_credibility_tier(
        self,
        domain_reputation: str,
        source_type: str,
        has_direct_quote: bool,
        has_speculation: bool,
        is_verified: bool,
        num_corroborating: int
    ) -> str:
        """
        Determine the credibility tier based on multiple factors

        Logic:
        - VERIFIED: Verified social media account OR tier1 domain with direct quote
        - OFFICIAL: Tier1/tier2 domain with official announcement
        - RELIABLE: Tier2/tier3 domain OR multiple corroborating sources
        - UNVERIFIED: Social media without verification OR single unverified source
        - SPECULATION: Contains speculation language OR forum post
        """
        # Speculation tier (lowest)
        if has_speculation:
            return CredibilityTier.SPECULATION

        if domain_reputation == 'forum':
            return CredibilityTier.SPECULATION

        # Verified tier (highest)
        if is_verified and domain_reputation == 'social':
            return CredibilityTier.VERIFIED

        if domain_reputation == 'tier1' and has_direct_quote:
            return CredibilityTier.VERIFIED

        if num_corroborating >= 2 and has_direct_quote:
            return CredibilityTier.VERIFIED

        # Official tier
        if domain_reputation == 'tier1' and source_type == 'official':
            return CredibilityTier.OFFICIAL

        if domain_reputation == 'tier1':
            return CredibilityTier.OFFICIAL

        if domain_reputation == 'tier2' and has_direct_quote:
            return CredibilityTier.OFFICIAL

        # Reliable tier
        if domain_reputation in ['tier2', 'tier3']:
            return CredibilityTier.RELIABLE

        if num_corroborating >= 2:
            return CredibilityTier.RELIABLE

        # Unverified tier (default)
        return CredibilityTier.UNVERIFIED

    def _calculate_confidence_boost(
        self, credibility_tier: str, credibility_score: float
    ) -> float:
        """
        Calculate confidence boost to add to overall vote confidence

        Returns: Float between -20 and +20
        """
        tier_boosts = {
            CredibilityTier.VERIFIED: 15,
            CredibilityTier.OFFICIAL: 10,
            CredibilityTier.RELIABLE: 5,
            CredibilityTier.UNVERIFIED: 0,
            CredibilityTier.SPECULATION: -10
        }

        base_boost = tier_boosts.get(credibility_tier, 0)

        # Adjust based on score within tier
        if credibility_score >= 90:
            base_boost += 5
        elif credibility_score <= 30:
            base_boost -= 5

        return float(base_boost)

    def _generate_credibility_recommendation(
        self, credibility_tier: str, credibility_score: float, has_speculation: bool
    ) -> str:
        """Generate recommendation based on credibility assessment"""
        if credibility_tier == CredibilityTier.VERIFIED:
            return "highly_trustworthy"

        if credibility_tier == CredibilityTier.OFFICIAL:
            if credibility_score >= 85:
                return "trustworthy"
            else:
                return "likely_accurate"

        if credibility_tier == CredibilityTier.RELIABLE:
            return "verify_recommended"

        if credibility_tier == CredibilityTier.UNVERIFIED:
            return "verification_required"

        if credibility_tier == CredibilityTier.SPECULATION or has_speculation:
            return "treat_as_speculation"

        return "manual_review_required"

    def get_credibility_badge(self, credibility_tier: str) -> Dict:
        """
        Get display badge information for credibility tier

        Returns:
            Dictionary with badge color, icon, and label
        """
        badges = {
            CredibilityTier.VERIFIED: {
                'color': '#10b981',  # Green
                'icon': '✓',
                'label': 'Verified Source',
                'description': 'Direct announcement from verified account or official source'
            },
            CredibilityTier.OFFICIAL: {
                'color': '#3b82f6',  # Blue
                'icon': '★',
                'label': 'Official',
                'description': 'Major news outlet or official announcement'
            },
            CredibilityTier.RELIABLE: {
                'color': '#8b5cf6',  # Purple
                'icon': '◆',
                'label': 'Reliable',
                'description': 'Reputable news source or corroborated report'
            },
            CredibilityTier.UNVERIFIED: {
                'color': '#f59e0b',  # Orange/Amber
                'icon': '?',
                'label': 'Unverified',
                'description': 'Social media or single-source report'
            },
            CredibilityTier.SPECULATION: {
                'color': '#ef4444',  # Red
                'icon': '~',
                'label': 'Speculation',
                'description': 'Rumor or speculative report'
            }
        }

        return badges.get(credibility_tier, badges[CredibilityTier.UNVERIFIED])

    def compare_sources(self, sources: List[Dict]) -> Dict:
        """
        Compare multiple sources for the same vote to determine overall credibility

        Args:
            sources: List of source credibility assessments

        Returns:
            Dictionary with:
                - highest_tier: Best credibility tier found
                - average_score: Average credibility score
                - consensus: Whether sources agree
                - recommendation: Overall recommendation
        """
        if not sources:
            return {
                'highest_tier': CredibilityTier.SPECULATION,
                'average_score': 0.0,
                'consensus': False,
                'recommendation': 'no_sources'
            }

        # Find highest tier
        tier_hierarchy = [
            CredibilityTier.VERIFIED,
            CredibilityTier.OFFICIAL,
            CredibilityTier.RELIABLE,
            CredibilityTier.UNVERIFIED,
            CredibilityTier.SPECULATION
        ]

        highest_tier = CredibilityTier.SPECULATION
        for tier in tier_hierarchy:
            if any(s.get('credibility_tier') == tier for s in sources):
                highest_tier = tier
                break

        # Calculate average score
        scores = [s.get('credibility_score', 0) for s in sources]
        average_score = sum(scores) / len(scores) if scores else 0

        # Check consensus (all sources agree or are within same tier range)
        tiers = [s.get('credibility_tier') for s in sources]
        consensus = len(set(tiers)) == 1 or len(sources) == 1

        # Generate recommendation
        if highest_tier == CredibilityTier.VERIFIED and consensus:
            recommendation = "highly_confident"
        elif highest_tier in [CredibilityTier.VERIFIED, CredibilityTier.OFFICIAL]:
            recommendation = "confident"
        elif len(sources) >= 2 and highest_tier == CredibilityTier.RELIABLE:
            recommendation = "moderately_confident"
        elif highest_tier == CredibilityTier.SPECULATION:
            recommendation = "low_confidence"
        else:
            recommendation = "verify_with_additional_sources"

        return {
            'highest_tier': highest_tier,
            'average_score': round(average_score, 2),
            'consensus': consensus,
            'num_sources': len(sources),
            'recommendation': recommendation
        }

    def add_trusted_domain(self, domain: str, tier: str = 'tier3'):
        """
        Add a new trusted domain to the reputation database

        Args:
            domain: Domain name (e.g., 'example.com')
            tier: Reputation tier (tier1/tier2/tier3)
        """
        domain = domain.lower()

        if tier == 'tier1':
            if domain not in self.tier1_domains:
                self.tier1_domains.append(domain)
                self.logger.info(f"Added {domain} to tier1 domains")
        elif tier == 'tier2':
            if domain not in self.tier2_domains:
                self.tier2_domains.append(domain)
                self.logger.info(f"Added {domain} to tier2 domains")
        elif tier == 'tier3':
            if domain not in self.tier3_domains:
                self.tier3_domains.append(domain)
                self.logger.info(f"Added {domain} to tier3 domains")
        else:
            self.logger.warning(f"Invalid tier: {tier}")

    def get_domain_reputation_list(self) -> Dict:
        """Get all domains organized by reputation tier"""
        return {
            'tier1': self.tier1_domains.copy(),
            'tier2': self.tier2_domains.copy(),
            'tier3': self.tier3_domains.copy(),
            'social': self.social_media_domains.copy(),
            'forums': self.forum_domains.copy()
        }
