"""
MVP candidate extraction from text
"""
import re
from typing import List, Dict, Optional, Tuple
import logging


class CandidateExtractor:
    """Extract MVP candidate names from text content"""

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # 2024-25 NFL MVP candidates with their teams
        self.candidates = {
            'Josh Allen': {'team': 'Buffalo Bills', 'position': 'QB', 'aliases': ['Allen', 'J. Allen']},
            'Lamar Jackson': {'team': 'Baltimore Ravens', 'position': 'QB', 'aliases': ['Jackson', 'L. Jackson', 'Lamar']},
            'Saquon Barkley': {'team': 'Philadelphia Eagles', 'position': 'RB', 'aliases': ['Barkley', 'S. Barkley', 'Saquon']},
            'Joe Burrow': {'team': 'Cincinnati Bengals', 'position': 'QB', 'aliases': ['Burrow', 'J. Burrow']},
            'Jared Goff': {'team': 'Detroit Lions', 'position': 'QB', 'aliases': ['Goff', 'J. Goff']},
            'Patrick Mahomes': {'team': 'Kansas City Chiefs', 'position': 'QB', 'aliases': ['Mahomes', 'P. Mahomes']},
            'Jalen Hurts': {'team': 'Philadelphia Eagles', 'position': 'QB', 'aliases': ['Hurts', 'J. Hurts']},
            'Sam Darnold': {'team': 'Minnesota Vikings', 'position': 'QB', 'aliases': ['Darnold', 'S. Darnold']},
            'Baker Mayfield': {'team': 'Tampa Bay Buccaneers', 'position': 'QB', 'aliases': ['Mayfield', 'B. Mayfield']},
            'Derrick Henry': {'team': 'Baltimore Ravens', 'position': 'RB', 'aliases': ['Henry', 'D. Henry']},
            'Justin Herbert': {'team': 'Los Angeles Chargers', 'position': 'QB', 'aliases': ['Herbert', 'J. Herbert']},
            'Jordan Love': {'team': 'Green Bay Packers', 'position': 'QB', 'aliases': ['Love', 'J. Love']},
            'Jayden Daniels': {'team': 'Washington Commanders', 'position': 'QB', 'aliases': ['Daniels', 'J. Daniels', 'Jayden']},
            'CJ Stroud': {'team': 'Houston Texans', 'position': 'QB', 'aliases': ['Stroud', 'C.J. Stroud', 'CJ', 'C. Stroud']},
            'Brock Purdy': {'team': 'San Francisco 49ers', 'position': 'QB', 'aliases': ['Purdy', 'B. Purdy']},
        }

        # Patterns indicating MVP candidate mention
        self.candidate_patterns = [
            r'(?:vote|voting|voted|pick|picking|chose|chosen|going\s+with)\s+(?:for\s+)?',
            r'(?:MVP|most\s+valuable\s+player)\s+(?:is|should\s+be|goes\s+to)',
            r'(?:first|second|third|fourth|fifth)\s+place:\s*',
            r'(?:my|My)\s+(?:top\s+)?(?:pick|choice|vote|ballot)',
            r'(?:#1|#2|#3|#4|#5|1\.|2\.|3\.|4\.|5\.)\s*',
        ]

    def extract_candidates_from_text(self, text: str) -> List[Dict]:
        """
        Extract MVP candidates mentioned in text

        Args:
            text: Text content to analyze

        Returns:
            List of candidate dictionaries with name, team, and context
        """
        results = []

        # Check for each known candidate
        for candidate_name, info in self.candidates.items():
            # Check full name
            if self._is_candidate_mentioned(text, candidate_name):
                context = self._get_context_around_candidate(text, candidate_name)
                confidence = self._determine_confidence(context, candidate_name)

                results.append({
                    'name': candidate_name,
                    'team': info['team'],
                    'position': info['position'],
                    'confidence': confidence,
                    'context': context[:300]
                })
                continue  # Skip alias checking if full name found

            # Check aliases (last name only, etc.)
            for alias in info['aliases']:
                if self._is_candidate_mentioned(text, alias):
                    context = self._get_context_around_candidate(text, alias)
                    confidence = self._determine_confidence(context, alias)

                    # Lower confidence for alias matches
                    if confidence == 'high':
                        confidence = 'medium'

                    results.append({
                        'name': candidate_name,  # Use full name
                        'team': info['team'],
                        'position': info['position'],
                        'confidence': confidence,
                        'context': context[:300],
                        'matched_as': alias
                    })
                    break  # Only match first alias

        # Deduplicate
        deduped = self._deduplicate_candidates(results)

        return deduped

    def extract_candidates_with_ranking(self, text: str) -> List[Dict]:
        """
        Extract candidates along with their ranking positions

        Args:
            text: Text content to analyze

        Returns:
            List of candidate dictionaries with ranking information
        """
        results = []

        # Pattern for ranked lists (1. Josh Allen, 2. Lamar Jackson, etc.)
        ranked_patterns = [
            r'(?:^|\n)(?:#?(\d+)[.:\)]\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # 1. Josh Allen
            r'(?:first|second|third|fourth|fifth)\s+place[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # First place: Josh Allen
            r'(?:1st|2nd|3rd|4th|5th)[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',  # 1st: Josh Allen
        ]

        for pattern in ranked_patterns:
            matches = re.finditer(pattern, text, re.MULTILINE | re.IGNORECASE)

            for match in matches:
                # Extract ranking and name
                groups = match.groups()
                if len(groups) == 2:
                    rank_str, name = groups
                    try:
                        rank = int(rank_str)
                    except (ValueError, TypeError):
                        rank = self._parse_ordinal_rank(groups[0])
                elif len(groups) == 1:
                    name = groups[0]
                    rank = None
                else:
                    continue

                # Match to known candidate
                matched_candidate = self._match_to_known_candidate(name)

                if matched_candidate:
                    results.append({
                        'name': matched_candidate,
                        'team': self.candidates[matched_candidate]['team'],
                        'position': self.candidates[matched_candidate]['position'],
                        'ranking': rank,
                        'confidence': 'high',
                        'context': match.group(0)
                    })

        # If no ranked matches, fall back to regular extraction
        if not results:
            candidates = self.extract_candidates_from_text(text)
            # Try to infer ranking from context
            for candidate in candidates:
                rank = self._infer_ranking_from_context(candidate['context'])
                candidate['ranking'] = rank
                results.append(candidate)

        return results

    def _is_candidate_mentioned(self, text: str, name: str) -> bool:
        """Check if a candidate name appears in text"""
        # Word boundary matching to avoid false positives
        pattern = r'\b' + re.escape(name) + r'\b'
        return bool(re.search(pattern, text, re.IGNORECASE))

    def _get_context_around_candidate(self, text: str, name: str) -> str:
        """Get text context around a candidate mention"""
        pattern = r'\b' + re.escape(name) + r'\b'
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            start = max(0, match.start() - 150)
            end = min(len(text), match.end() + 150)
            return text[start:end]

        return ""

    def _determine_confidence(self, context: str, candidate_name: str) -> str:
        """
        Determine confidence level based on context

        High: Explicit voting/picking language
        Medium: MVP mentioned with candidate
        Low: Just name mentioned
        """
        context_lower = context.lower()

        # High confidence keywords
        high_keywords = [
            'vote for', 'voting for', 'voted for',
            'pick is', 'picking', 'chose', 'chosen',
            'first place', 'my mvp', 'mvp is',
            'going with', 'ballot'
        ]

        # Medium confidence keywords
        medium_keywords = [
            'mvp', 'most valuable player', 'candidate',
            'deserves', 'should win', 'front runner',
            'favorite'
        ]

        if any(keyword in context_lower for keyword in high_keywords):
            return 'high'
        elif any(keyword in context_lower for keyword in medium_keywords):
            return 'medium'
        else:
            return 'low'

    def _match_to_known_candidate(self, name: str) -> Optional[str]:
        """Match extracted name to known candidate"""
        name_lower = name.lower().strip()

        # Direct match
        for candidate in self.candidates.keys():
            if candidate.lower() == name_lower:
                return candidate

        # Alias match
        for candidate, info in self.candidates.items():
            for alias in info['aliases']:
                if alias.lower() == name_lower:
                    return candidate

        # Partial match (last name only)
        for candidate in self.candidates.keys():
            last_name = candidate.split()[-1].lower()
            if last_name == name_lower:
                return candidate

        return None

    def _parse_ordinal_rank(self, ordinal: str) -> Optional[int]:
        """Convert ordinal string to number (first -> 1, second -> 2, etc.)"""
        ordinals = {
            'first': 1, '1st': 1,
            'second': 2, '2nd': 2,
            'third': 3, '3rd': 3,
            'fourth': 4, '4th': 4,
            'fifth': 5, '5th': 5
        }
        return ordinals.get(ordinal.lower())

    def _infer_ranking_from_context(self, context: str) -> Optional[int]:
        """Try to infer ranking from context"""
        context_lower = context.lower()

        # Check for ranking keywords
        if any(word in context_lower for word in ['first place', '#1', 'number one', 'top of']):
            return 1
        elif any(word in context_lower for word in ['second place', '#2', 'number two']):
            return 2
        elif any(word in context_lower for word in ['third place', '#3', 'number three']):
            return 3
        elif any(word in context_lower for word in ['fourth place', '#4', 'number four']):
            return 4
        elif any(word in context_lower for word in ['fifth place', '#5', 'number five']):
            return 5

        return None

    def _deduplicate_candidates(self, candidates: List[Dict]) -> List[Dict]:
        """Remove duplicate candidate mentions, keeping highest confidence"""
        seen = {}

        confidence_order = {'high': 3, 'medium': 2, 'low': 1}

        for candidate in candidates:
            name = candidate['name']

            if name not in seen:
                seen[name] = candidate
            else:
                # Keep higher confidence entry
                current_conf = confidence_order.get(seen[name]['confidence'], 0)
                new_conf = confidence_order.get(candidate['confidence'], 0)

                if new_conf > current_conf:
                    seen[name] = candidate

        return list(seen.values())

    def add_candidate(self, name: str, team: str, position: str, aliases: List[str] = None):
        """Add a new MVP candidate to the list"""
        if name not in self.candidates:
            self.candidates[name] = {
                'team': team,
                'position': position,
                'aliases': aliases or []
            }
            self.logger.info(f"Added candidate: {name} ({team})")

    def get_candidates(self) -> Dict:
        """Get all known candidates"""
        return self.candidates.copy()
