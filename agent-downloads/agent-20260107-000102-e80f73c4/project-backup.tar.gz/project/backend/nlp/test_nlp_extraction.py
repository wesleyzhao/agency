"""
Comprehensive test suite for NLP extraction modules
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from nlp import VoteExtractor, VoterExtractor, CandidateExtractor, RankingExtractor


def test_voter_extraction():
    """Test voter name extraction"""
    print("\n" + "="*60)
    print("TEST 1: VOTER EXTRACTION")
    print("="*60)

    extractor = VoterExtractor()

    # Test case 1: Known voter with voting declaration
    text1 = """
    Mina Kimes tweeted: "I'm voting for Josh Allen as my MVP. He's been incredible this season."
    """
    voters1 = extractor.extract_voters_from_text(text1, "https://twitter.com/minakimes/status/123")
    print(f"\nTest 1.1 - Known voter with declaration:")
    print(f"  Text: {text1.strip()}")
    print(f"  Voters found: {len(voters1)}")
    for v in voters1:
        print(f"    - {v['name']} (confidence: {v['confidence']}, source: {v['source']})")

    # Test case 2: First-person voting declaration
    text2 = """
    My MVP vote goes to Lamar Jackson. He's been dominant all season long.
    """
    voters2 = extractor.extract_voters_from_text(text2)
    print(f"\nTest 1.2 - First-person declaration (no byline):")
    print(f"  Text: {text2.strip()}")
    print(f"  Voters found: {len(voters2)}")
    for v in voters2:
        print(f"    - {v['name']} (confidence: {v['confidence']})")

    # Test case 3: Twitter URL extraction
    voters3 = extractor.extract_voters_from_text(
        "I voted for Saquon Barkley",
        "https://twitter.com/minakimes/status/456"
    )
    print(f"\nTest 1.3 - Twitter URL extraction:")
    print(f"  URL: https://twitter.com/minakimes/status/456")
    print(f"  Voters found: {len(voters3)}")
    for v in voters3:
        print(f"    - {v['name']} (handle: {v.get('twitter_handle', 'N/A')})")

    assert len(voters1) > 0, "Should find voter in test 1"
    print("\n✓ Voter extraction tests passed!")
    return True


def test_candidate_extraction():
    """Test candidate name extraction"""
    print("\n" + "="*60)
    print("TEST 2: CANDIDATE EXTRACTION")
    print("="*60)

    extractor = CandidateExtractor()

    # Test case 1: Single candidate mention
    text1 = """
    Josh Allen has been the MVP frontrunner all season. His performance against
    the Chiefs was outstanding.
    """
    candidates1 = extractor.extract_candidates_from_text(text1)
    print(f"\nTest 2.1 - Single candidate:")
    print(f"  Candidates found: {len(candidates1)}")
    for c in candidates1:
        print(f"    - {c['name']} ({c['team']}, {c['position']}) - confidence: {c['confidence']}")

    # Test case 2: Multiple candidates
    text2 = """
    The MVP race is between Josh Allen, Lamar Jackson, and Saquon Barkley.
    All three have been exceptional this year.
    """
    candidates2 = extractor.extract_candidates_from_text(text2)
    print(f"\nTest 2.2 - Multiple candidates:")
    print(f"  Candidates found: {len(candidates2)}")
    for c in candidates2:
        print(f"    - {c['name']} ({c['team']})")

    # Test case 3: Candidate with voting context (high confidence)
    text3 = """
    I'm voting for Lamar Jackson as my MVP pick. He's been unstoppable.
    """
    candidates3 = extractor.extract_candidates_from_text(text3)
    print(f"\nTest 2.3 - Candidate with voting context:")
    print(f"  Candidates found: {len(candidates3)}")
    for c in candidates3:
        print(f"    - {c['name']} - confidence: {c['confidence']}")

    assert len(candidates1) > 0, "Should find Josh Allen"
    assert len(candidates2) >= 3, "Should find at least 3 candidates"
    assert candidates3[0]['confidence'] == 'high', "Should be high confidence with voting context"
    print("\n✓ Candidate extraction tests passed!")
    return True


def test_ranking_extraction():
    """Test ranking extraction"""
    print("\n" + "="*60)
    print("TEST 3: RANKING EXTRACTION")
    print("="*60)

    extractor = RankingExtractor()

    # Test case 1: Numbered list
    text1 = """
    My MVP ballot:
    1. Josh Allen
    2. Lamar Jackson
    3. Saquon Barkley
    4. Jared Goff
    5. Joe Burrow
    """
    rankings1 = extractor.extract_rankings_from_text(text1)
    print(f"\nTest 3.1 - Numbered list:")
    print(f"  Rankings found: {len(rankings1)}")
    for r in rankings1:
        print(f"    Rank {r['rank']}: {r['player_name']} (confidence: {r['confidence']})")

    # Test case 2: Ordinal words
    text2 = """
    First place: Josh Allen
    Second place: Lamar Jackson
    Third place: Saquon Barkley
    """
    rankings2 = extractor.extract_rankings_from_text(text2)
    print(f"\nTest 3.2 - Ordinal words:")
    print(f"  Rankings found: {len(rankings2)}")
    for r in rankings2:
        print(f"    Rank {r['rank']}: {r['player_name']}")

    # Test case 3: Extract full ballot
    ballot = extractor.extract_full_ballot(text1)
    print(f"\nTest 3.3 - Full ballot extraction:")
    print(f"  Complete ballot: {ballot['complete']}")
    print(f"  Votes: {len(ballot['votes'])}")
    for rank, vote in sorted(ballot['votes'].items()):
        print(f"    {rank}. {vote['player_name']}")

    # Test case 4: Validate ballot
    is_valid, issues = extractor.validate_ballot(ballot)
    print(f"\nTest 3.4 - Ballot validation:")
    print(f"  Valid: {is_valid}")
    if issues:
        print(f"  Issues: {issues}")

    assert len(rankings1) == 5, "Should find 5 rankings"
    assert rankings1[0]['rank'] == 1, "First ranking should be rank 1"
    assert ballot['complete'], "Should be a complete ballot"
    print("\n✓ Ranking extraction tests passed!")
    return True


def test_vote_extraction_integration():
    """Test complete vote extraction (integration test)"""
    print("\n" + "="*60)
    print("TEST 4: COMPLETE VOTE EXTRACTION (INTEGRATION)")
    print("="*60)

    extractor = VoteExtractor()

    # Test case 1: Complete ballot from single voter
    text1 = """
    By Mina Kimes - January 5, 2025

    Here's my official MVP ballot for the 2024-25 season:

    1. Josh Allen - He's been the best QB all year
    2. Lamar Jackson - Incredible dual-threat performance
    3. Saquon Barkley - Best RB season in years
    4. Jared Goff - Led Lions to historic season
    5. Joe Burrow - Clutch performances all year

    It was a tough decision, but Allen gets my first-place vote.
    """

    votes1 = extractor.extract_votes_from_text(text1, "https://espn.com/nfl/story/mvp-votes")
    print(f"\nTest 4.1 - Complete ballot:")
    print(f"  Votes extracted: {len(votes1)}")
    for vote in votes1:
        print(f"    {vote['voter_name']} -> Rank {vote['ranking']}: {vote['candidate_name']} ({vote['candidate_team']})")
        print(f"      Overall confidence: {vote['overall_confidence']}")

    # Test case 2: Simple single vote
    text2 = """
    Peter King tweets: "My MVP vote is going to Lamar Jackson. What he's done this year is remarkable."
    """
    votes2 = extractor.extract_votes_from_text(text2, "https://twitter.com/peter_king/status/789")
    print(f"\nTest 4.2 - Simple single vote:")
    print(f"  Votes extracted: {len(votes2)}")
    for vote in votes2:
        print(f"    {vote['voter_name']} -> {vote['candidate_name']} (rank {vote['ranking']})")
        print(f"      Voter confidence: {vote['voter_confidence']}")
        print(f"      Overall confidence: {vote['overall_confidence']}")

    # Test case 3: Multiple candidates, single voter
    text3 = """
    Tom Brady on Twitter: "For MVP, I'm going with Josh Allen at #1 and Lamar Jackson at #2."
    """
    votes3 = extractor.extract_votes_from_text(text3, "https://twitter.com/tombrady/status/999")
    print(f"\nTest 4.3 - Multiple candidates with rankings:")
    print(f"  Votes extracted: {len(votes3)}")
    for vote in votes3:
        print(f"    {vote['voter_name']} -> Rank {vote['ranking']}: {vote['candidate_name']}")

    # Test case 4: Get extraction stats
    stats = extractor.get_extraction_stats()
    print(f"\nTest 4.4 - Extraction statistics:")
    print(f"  Known voters: {stats['known_voters']}")
    print(f"  Known candidates: {stats['known_candidates']}")

    assert len(votes1) > 0, "Should extract votes from ballot"
    assert len(votes2) > 0, "Should extract simple vote"
    print("\n✓ Integration tests passed!")
    return True


def test_edge_cases():
    """Test edge cases and error handling"""
    print("\n" + "="*60)
    print("TEST 5: EDGE CASES")
    print("="*60)

    extractor = VoteExtractor()

    # Test case 1: Empty text
    votes1 = extractor.extract_votes_from_text("")
    print(f"\nTest 5.1 - Empty text:")
    print(f"  Votes extracted: {len(votes1)}")
    assert len(votes1) == 0, "Empty text should return no votes"

    # Test case 2: No MVP-related content
    text2 = "This is just a random article about football scores."
    votes2 = extractor.extract_votes_from_text(text2)
    print(f"\nTest 5.2 - No MVP content:")
    print(f"  Votes extracted: {len(votes2)}")

    # Test case 3: Ambiguous text
    text3 = "Josh Allen and Lamar Jackson are great players."
    votes3 = extractor.extract_votes_from_text(text3)
    print(f"\nTest 5.3 - Ambiguous text (candidates but no voter):")
    print(f"  Votes extracted: {len(votes3)}")

    # Test case 4: Unknown candidate
    text4 = "I'm voting for John Doe as MVP."
    votes4 = extractor.extract_votes_from_text(text4)
    print(f"\nTest 5.4 - Unknown candidate:")
    print(f"  Votes extracted: {len(votes4)}")

    print("\n✓ Edge case tests completed!")
    return True


def test_real_world_example():
    """Test with real-world example from Mina Kimes tweet"""
    print("\n" + "="*60)
    print("TEST 6: REAL-WORLD EXAMPLE (Mina Kimes)")
    print("="*60)

    extractor = VoteExtractor()

    # Simulated tweet content
    text = """
    Mina Kimes @minakimes

    OK fine, here's my MVP ballot:

    1. Josh Allen
    2. Saquon Barkley
    3. Lamar Jackson
    4. Jared Goff
    5. Joe Burrow

    Allen has been the most valuable player to his team this season. The Bills don't
    make the playoffs without him.
    """

    votes = extractor.extract_votes_from_text(
        text,
        source_url="https://x.com/minakimes/status/2008283462403584336",
        source_type="twitter"
    )

    print(f"\nVotes extracted: {len(votes)}")
    print(f"\nDetailed results:")
    for i, vote in enumerate(votes, 1):
        print(f"\n  Vote {i}:")
        print(f"    Voter: {vote['voter_name']}")
        print(f"    Candidate: {vote['candidate_name']} ({vote['candidate_team']})")
        print(f"    Ranking: {vote['ranking']}")
        print(f"    Voter confidence: {vote['voter_confidence']}")
        print(f"    Ranking confidence: {vote['ranking_confidence']}")
        print(f"    Overall confidence: {vote['overall_confidence']}")
        print(f"    Source: {vote['source_url'][:50]}...")

    assert len(votes) > 0, "Should extract votes from real example"
    assert any(v['voter_name'] == 'Mina Kimes' for v in votes), "Should identify Mina Kimes as voter"
    print("\n✓ Real-world example test passed!")
    return True


def run_all_tests():
    """Run all test suites"""
    print("\n" + "="*60)
    print("NLP EXTRACTION MODULE - COMPREHENSIVE TEST SUITE")
    print("="*60)

    tests = [
        ("Voter Extraction", test_voter_extraction),
        ("Candidate Extraction", test_candidate_extraction),
        ("Ranking Extraction", test_ranking_extraction),
        ("Integration Tests", test_vote_extraction_integration),
        ("Edge Cases", test_edge_cases),
        ("Real-World Example", test_real_world_example),
    ]

    passed = 0
    failed = 0

    for test_name, test_func in tests:
        try:
            result = test_func()
            if result:
                passed += 1
        except Exception as e:
            print(f"\n✗ {test_name} FAILED: {str(e)}")
            import traceback
            traceback.print_exc()
            failed += 1

    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    print(f"Total tests: {len(tests)}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")

    if failed == 0:
        print("\n🎉 ALL TESTS PASSED! 🎉")
    else:
        print(f"\n⚠️  {failed} test(s) failed")

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
