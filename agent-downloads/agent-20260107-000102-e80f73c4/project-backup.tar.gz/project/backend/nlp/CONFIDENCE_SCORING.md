# Confidence Scoring System

## Overview

The confidence scoring system (Feature #9) provides a comprehensive, multi-factor approach to evaluating the reliability of extracted voter information. Instead of simple high/medium/low categorization, it calculates numeric scores (0-100) based on six weighted factors.

## Confidence Factors

The system evaluates six key factors, each contributing to the overall confidence score:

### 1. Voter Confidence (25% weight)
- **High (85 base)**: Known AP voter with clear voting declaration
- **Medium (60 base)**: Recognized name with voting context
- **Low (35 base)**: Unknown or ambiguous voter identity

**Bonuses**:
- +10: Verified Twitter/social media handle
- +5: Name in known voters database

### 2. Candidate Confidence (15% weight)
- **Full name (80 base)**: "Josh Allen" or "Lamar Jackson"
- **Partial name (60 base)**: "Allen" or "Jackson"

**Bonuses**:
- +15: Team and position information available (validated candidate)

### 3. Ranking Confidence (15% weight)
- **High (85 base)**: Explicit ranking pattern detected (1., 2., etc.)
- **Medium (60 base)**: Implied ranking from context
- **Low (35 base)**: Weak or missing ranking information

**Adjustments**:
- +10: Rank 1 (MVP pick) - people are more explicit about #1
- -20: No ranking specified

### 4. Source Type (20% weight)
- **Official (100)**: AP announcement, verified voter account
- **Social Media (75)**: Twitter/X from known voter
- **News Article (70)**: Media article quoting voter
- **Reddit (50)**: Reddit post or comment
- **Speculation (30)**: Unverified or speculative source
- **Unknown (40)**: Source type not determined

**Bonuses**:
- +10: URL from trusted domain (ESPN, NFL.com, SI, etc.)
- +5: Twitter/X source (potential verification)

### 5. Context Quality (15% weight)
- **Base score**: 50

**Length bonuses**:
- +15: Context > 200 characters
- +10: Context > 100 characters
- +5: Context > 50 characters

**Content bonuses**:
- +10 per indicator: Strong voting phrases ("my MVP vote", "I voted for", "my ballot", etc.)
- +10: Structured numbered list detected

**Minimum**: 20 (if no context available)

### 6. Verification (10% weight)
- **Verified (100)**: Manually verified by admin
- **Multiple sources (70)**: 3+ sources confirm the vote
- **Dual sources (50)**: 2 sources confirm the vote
- **Single source (30)**: Only one source

## Score Interpretation

### Numeric Score (0-100)
The weighted average of all factor scores:

```
score = (voter_conf × 0.25) + (candidate_conf × 0.15) + (ranking_conf × 0.15) +
        (source_type × 0.20) + (context_quality × 0.15) + (verification × 0.10)
```

### Confidence Levels
- **High**: Score ≥ 75
- **Medium**: Score 50-74
- **Low**: Score < 50

### Recommendations
Based on numeric score, the system provides action recommendations:

- **auto_approve** (≥80): High confidence, show immediately in UI
- **review_recommended** (65-79): Medium-high, quick review suggested
- **verification_required** (45-64): Medium, needs manual verification
- **hold_for_review** (<45): Low confidence, thorough review required

## Usage Examples

### Basic Usage

```python
from nlp import ConfidenceScorer

scorer = ConfidenceScorer()

vote_data = {
    'voter_name': 'Mina Kimes',
    'voter_confidence': 'high',
    'voter_source': 'known_voter_list',
    'twitter_handle': '@minakimes',
    'candidate_name': 'Josh Allen',
    'candidate_team': 'Buffalo Bills',
    'candidate_position': 'QB',
    'ranking': 1,
    'ranking_confidence': 'high',
    'source_url': 'https://twitter.com/minakimes/status/123',
    'source_type': 'social_media',
    'extracted_text': '1. Josh Allen - My MVP pick',
    'verified': False,
}

result = scorer.calculate_vote_confidence(vote_data)

print(f"Numeric Score: {result['numeric_score']}")  # e.g., 82.5
print(f"Level: {result['confidence_level']}")        # e.g., "high"
print(f"Recommendation: {result['recommendation']}")  # e.g., "auto_approve"
print(f"Factors: {result['factor_scores']}")
```

### Batch Processing

```python
votes = [vote1, vote2, vote3, ...]

result = scorer.calculate_batch_confidence(votes)

# Access scored votes
for vote in result['votes']:
    print(f"{vote['voter_name']}: {vote['confidence_numeric']}")

# View summary statistics
print(result['summary'])
# {
#     'total_votes': 3,
#     'average_confidence': 67.5,
#     'confidence_distribution': {'high': 1, 'medium': 1, 'low': 1},
#     'recommendation_distribution': {...}
# }
```

### Adjusting Weights

You can customize factor weights based on your priorities:

```python
# Emphasize source type more heavily
new_weights = {
    'voter_confidence': 0.20,
    'candidate_confidence': 0.15,
    'ranking_confidence': 0.10,
    'source_type': 0.35,     # Increased from 0.20
    'context_quality': 0.10,
    'verification': 0.10,
}

scorer.adjust_weights(new_weights)
```

**Note**: Weights must sum to 1.0

### Integration with VoteExtractor

The confidence scorer is automatically integrated into `VoteExtractor`:

```python
from nlp import VoteExtractor

extractor = VoteExtractor()

text = "My MVP vote: 1. Josh Allen 2. Lamar Jackson..."
votes = extractor.extract_votes_from_text(
    text,
    source_url="https://twitter.com/minakimes/...",
    source_type="social_media"
)

# Each vote now includes comprehensive confidence scoring
for vote in votes:
    print(f"Voter: {vote['voter_name']}")
    print(f"Confidence: {vote['confidence_numeric']} ({vote['confidence_level']})")
    print(f"Recommendation: {vote['recommendation']}")
    print(f"Factors: {vote['confidence_factors']}")
```

## Database Integration

The `Vote` model in `database/models.py` includes both fields:

- `confidence`: Enum (HIGH/MEDIUM/LOW) - categorical level
- `confidence_score`: Float (0-100) - numeric score

Example database query:

```python
from database import VoteDB, get_session

session = get_session()
vote_db = VoteDB(session)

# Get all high-confidence votes
high_conf_votes = session.query(Vote).filter(
    Vote.confidence_score >= 75
).all()

# Get votes requiring review
review_votes = session.query(Vote).filter(
    Vote.confidence_score < 65
).all()
```

## Testing

Run the comprehensive test suite:

```bash
python3 backend/test_confidence_scoring.py
```

Tests cover:
1. High confidence vote scenarios
2. Medium confidence vote scenarios
3. Low confidence vote scenarios
4. Source type impact on scores
5. Batch confidence calculation
6. Weight adjustment functionality
7. Context quality impact

## Confidence Score Distribution

Typical score ranges by scenario:

| Scenario | Expected Score | Level |
|----------|---------------|-------|
| Known voter + verified Twitter + full ballot | 85-95 | High |
| Known voter + news article + clear vote | 70-80 | Medium-High |
| Unknown voter + social media + partial info | 45-60 | Medium |
| Reddit speculation + minimal context | 25-40 | Low |

## Future Enhancements

Potential improvements to the scoring system:

1. **Machine Learning**: Train model on manually verified votes to optimize weights
2. **Social Signals**: Incorporate likes, retweets, engagement metrics
3. **Time Decay**: Lower confidence for older announcements without corroboration
4. **Network Analysis**: Cross-reference voter networks and patterns
5. **Verification API**: Auto-verify against official AP announcements when available

## Migration

To add the `confidence_score` field to existing database:

```bash
python3 backend/database/migrate_add_confidence_score.py
```

This adds the new Float column to the votes table while preserving existing data.

## Best Practices

1. **Always calculate confidence**: Don't skip scoring for any extracted vote
2. **Review medium scores**: Scores 45-75 should undergo quick human review
3. **Track patterns**: Monitor which factors most often indicate false positives
4. **Update weights**: Adjust based on real-world accuracy feedback
5. **Use recommendations**: Follow the system's action recommendations
6. **Document overrides**: If manually overriding scores, document why

## Troubleshooting

### Score seems too low
- Check if all available fields are being passed (twitter_handle, team, position, etc.)
- Verify source_type is set correctly (not defaulting to 'unknown')
- Ensure extracted_text and voter_context are populated

### Score seems too high
- Review if source_type might be inflated (verify official sources)
- Check if voter is incorrectly in known_voters list
- Validate that verification flag isn't incorrectly set to True

### Scores are all similar
- Adjust weights to emphasize most important factors for your use case
- Ensure input data has variance (not all high/medium/low)
- Check that factor scoring functions are working correctly
