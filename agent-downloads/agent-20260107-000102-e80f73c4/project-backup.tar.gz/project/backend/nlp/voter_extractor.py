"""
Voter name extraction from text
"""
import re
from typing import List, Dict, Optional, Tuple
import logging


class VoterExtractor:
    """Extract voter names from text content"""

    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

        # Known AP voters (seed list - will expand)
        self.known_voters = [
            "Mina Kimes", "Tom Brady", "Peter King", "Chris Mortensen",
            "Adam Schefter", "Ian Rapoport", "Jay Glazer", "Judy Battista",
            "Diana Russini", "Ari Meirov", "Mike Florio", "Albert Breer",
            "Mike Garafolo", "Kimberley A. Martin", "Lindsay Jones",
            "Dan Graziano", "Jeremy Fowler", "Kevin Seifert", "Jamison Hensley",
            "Jeff Darlington", "Louis Riddick", "Domonique Foxworth",
            "Damien Woody", "Ryan Clark", "Marcus Spears", "Dan Orlovsky",
            "Rex Ryan", "Steve Young", "Charles Davis", "Solomon Wilcots",
            "Rich Eisen", "Andrea Kremer", "Suzy Kolber", "Chris Simms",
            "Peter Schrager", "Michael Silver", "Charean Williams"
        ]

        # Patterns indicating someone is a voter
        self.voter_patterns = [
            r'(?:I|I\'ll|I will|I am|I\'m)\s+(?:voting|vote|voted)\s+(?:for|)',
            r'(?:my|My)\s+(?:vote|ballot|MVP\s+(?:vote|pick|choice|ballot))',
            r'(?:as|As)\s+(?:a|an)\s+(?:AP\s+)?(?:voter|MVP\s+voter)',
            r'(?:I|I\'ve)\s+(?:cast|submitted|turned\s+in)\s+(?:my\s+)?(?:ballot|vote)',
            r'(?:I|I\'m)\s+(?:voting|picking|choosing|going\s+with)',
            r'(?:my|My)\s+(?:first|second|third|fourth|fifth)\s+place\s+vote',
            r'(?:I|I\'ve)\s+(?:decided|chosen)\s+(?:my\s+)?(?:MVP|top\s+(?:5|five))',
        ]

        # Patterns for extracting names
        # Matches capitalized words (2-4 words for names like "John Smith" or "Martin Luther King Jr.")
        self.name_pattern = r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})\b'

        # Common media outlets (helps identify journalists)
        self.media_outlets = [
            'ESPN', 'NFL Network', 'CBS Sports', 'Fox Sports', 'NBC Sports',
            'The Athletic', 'Sports Illustrated', 'Pro Football Talk',
            'NFL.com', 'AP', 'Associated Press', 'Twitter', 'X'
        ]

    def extract_voters_from_text(self, text: str, source_url: str = "") -> List[Dict]:
        """
        Extract potential voters from text

        Args:
            text: Text content to analyze
            source_url: Source URL for context

        Returns:
            List of voter dictionaries with name and confidence
        """
        results = []

        # Check for known voters
        known_matches = self._find_known_voters(text)
        results.extend(known_matches)

        # Check for voting declarations (high confidence)
        declaration_matches = self._find_voting_declarations(text)
        results.extend(declaration_matches)

        # Extract names from twitter/social media handles if present
        if 'twitter.com' in source_url or 'x.com' in source_url:
            handle_match = self._extract_from_twitter_url(source_url)
            if handle_match:
                results.append(handle_match)

        # Deduplicate by name (keep highest confidence)
        deduped = self._deduplicate_voters(results)

        return deduped

    def _find_known_voters(self, text: str) -> List[Dict]:
        """Find known voters mentioned in text"""
        results = []
        text_lower = text.lower()

        for voter in self.known_voters:
            # Check if voter name appears in text
            if voter.lower() in text_lower:
                # Check if they're actually voting (not just mentioned)
                context = self._get_context_around_name(text, voter)
                is_voting = self._check_if_voting(context)

                confidence = 'high' if is_voting else 'medium'

                results.append({
                    'name': voter,
                    'confidence': confidence,
                    'source': 'known_voter_list',
                    'context': context[:200]
                })

        return results

    def _find_voting_declarations(self, text: str) -> List[Dict]:
        """Find statements where someone declares their vote"""
        results = []

        for pattern in self.voter_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)

            for match in matches:
                # Get surrounding context
                start = max(0, match.start() - 100)
                end = min(len(text), match.end() + 100)
                context = text[start:end]

                # Try to extract name from context
                name = self._extract_name_from_declaration(context, text)

                if name:
                    results.append({
                        'name': name,
                        'confidence': 'high',
                        'source': 'voting_declaration',
                        'context': context
                    })

        return results

    def _extract_name_from_declaration(self, context: str, full_text: str) -> Optional[str]:
        """
        Extract the speaker's name from a voting declaration

        First-person declarations (I/my) require looking at author metadata or bylines
        """
        # Look for byline patterns
        byline_patterns = [
            r'By\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})',
            r'Author:\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})',
            r'Posted\s+by\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})',
            r'@([A-Za-z0-9_]+)',  # Twitter handle
        ]

        # Check first 500 chars of full text for byline
        header = full_text[:500]

        for pattern in byline_patterns:
            match = re.search(pattern, header)
            if match:
                name = match.group(1)
                # Clean up twitter handle
                if pattern.startswith(r'@'):
                    return self._convert_handle_to_name(name)
                # Validate it's a real name (not just capitalized words)
                if self._is_valid_name(name):
                    return name

        return None

    def _extract_from_twitter_url(self, url: str) -> Optional[Dict]:
        """Extract voter name from Twitter/X URL"""
        # Pattern: twitter.com/username or x.com/username
        pattern = r'(?:twitter\.com|x\.com)/([A-Za-z0-9_]+)'
        match = re.search(pattern, url)

        if match:
            handle = match.group(1)
            # Convert handle to likely real name if in known voters
            for voter in self.known_voters:
                # Simple match: if handle is similar to name
                name_parts = voter.lower().split()
                handle_lower = handle.lower()

                if any(part in handle_lower for part in name_parts):
                    return {
                        'name': voter,
                        'confidence': 'high',
                        'source': 'twitter_handle',
                        'twitter_handle': f'@{handle}',
                        'context': url
                    }

            # Unknown twitter user
            return {
                'name': self._convert_handle_to_name(handle),
                'confidence': 'low',
                'source': 'twitter_handle',
                'twitter_handle': f'@{handle}',
                'context': url
            }

        return None

    def _convert_handle_to_name(self, handle: str) -> str:
        """Convert Twitter handle to likely real name"""
        # Remove underscores, capitalize words
        parts = handle.replace('_', ' ').split()
        return ' '.join(word.capitalize() for word in parts)

    def _get_context_around_name(self, text: str, name: str) -> str:
        """Get text context around a name mention"""
        pattern = re.escape(name)
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            start = max(0, match.start() - 150)
            end = min(len(text), match.end() + 150)
            return text[start:end]

        return ""

    def _check_if_voting(self, context: str) -> bool:
        """Check if context indicates person is actually voting"""
        voting_keywords = [
            'vote', 'voting', 'voted', 'ballot', 'mvp pick',
            'my choice', 'i pick', 'i choose', 'going with',
            'first place', 'top of my ballot'
        ]

        context_lower = context.lower()
        return any(keyword in context_lower for keyword in voting_keywords)

    def _is_valid_name(self, name: str) -> bool:
        """Check if extracted string looks like a real person name"""
        # Must be 2-4 words
        words = name.split()
        if len(words) < 2 or len(words) > 4:
            return False

        # Each word should start with capital
        if not all(word[0].isupper() for word in words):
            return False

        # Exclude common false positives
        false_positives = [
            'Most Valuable Player', 'National Football League',
            'Associated Press', 'First Place', 'Second Place',
            'This Week', 'Next Week', 'Last Week', 'Super Bowl'
        ]

        if name in false_positives:
            return False

        # Should not be all caps (likely acronym)
        if name.isupper():
            return False

        return True

    def _deduplicate_voters(self, voters: List[Dict]) -> List[Dict]:
        """Remove duplicate voters, keeping highest confidence"""
        seen = {}

        confidence_order = {'high': 3, 'medium': 2, 'low': 1}

        for voter in voters:
            name = voter['name']

            if name not in seen:
                seen[name] = voter
            else:
                # Keep higher confidence entry
                current_conf = confidence_order.get(seen[name]['confidence'], 0)
                new_conf = confidence_order.get(voter['confidence'], 0)

                if new_conf > current_conf:
                    seen[name] = voter

        return list(seen.values())

    def add_known_voter(self, name: str):
        """Add a name to the known voters list"""
        if name not in self.known_voters:
            self.known_voters.append(name)
            self.logger.info(f"Added known voter: {name}")

    def get_known_voters(self) -> List[str]:
        """Get list of all known voters"""
        return self.known_voters.copy()
