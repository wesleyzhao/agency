# NFL MVP Voter Tracker - Complete API Reference

**Version:** 1.0
**Base URL:** `http://localhost:5000/api`
**Format:** JSON
**CORS:** Enabled

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Health Check](#health-check)
4. [Voters API](#voters-api)
5. [Candidates API](#candidates-api)
6. [Votes API](#votes-api)
7. [Dashboard API](#dashboard-api)
8. [Statistics API](#statistics-api)
9. [Search & Filter API](#search--filter-api)
10. [Export API](#export-api)
11. [Credibility API](#credibility-api)
12. [Historical Data API](#historical-data-api)
13. [Notifications API](#notifications-api)
14. [Error Responses](#error-responses)
15. [Rate Limiting](#rate-limiting)
16. [Examples](#examples)

---

## Overview

The NFL MVP Voter Tracker API provides programmatic access to NFL MVP voter data, including:
- **50 AP Voters**: Track all 50 Associated Press voters
- **MVP Votes**: Public declarations of MVP picks with rankings (1st-5th place)
- **Candidates**: NFL players receiving MVP votes
- **Source Attribution**: Links to original announcements (Twitter, news articles, etc.)
- **Confidence Scoring**: Data quality indicators (high/medium/low confidence)
- **Historical Data**: Access to previous seasons' voting patterns
- **Real-time Search**: Find voters, votes, and candidates with advanced filters

### Key Features
- ✅ Full CRUD operations on voters, candidates, and votes
- ✅ Advanced search and filtering
- ✅ Comprehensive statistics and analytics
- ✅ Export to CSV and JSON
- ✅ Source credibility tracking
- ✅ Historical voting patterns
- ✅ Real-time notifications
- ✅ Weighted voting system (10-7-5-3-1 points)

---

## Authentication

**Current Version:** No authentication required (development mode)

**Production Recommendations:**
- Implement API key authentication for write operations
- Use OAuth 2.0 for user-specific actions
- Add rate limiting per API key/IP address
- Require authentication for admin endpoints

---

## Health Check

### Check API Status

**Endpoint:** `GET /api/health`

**Description:** Verify the API is running and responsive.

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2025-01-07T12:00:00Z"
}
```

**Example:**
```bash
curl http://localhost:5000/api/health
```

---

## Voters API

### List All Voters

**Endpoint:** `GET /api/voters`

**Description:** Retrieve a list of all AP MVP voters with basic information.

**Response:**
```json
[
  {
    "id": 1,
    "name": "Mina Kimes",
    "outlet": "ESPN",
    "twitter_handle": "@minakimes",
    "location": "Los Angeles, CA",
    "vote_count": 5
  }
]
```

**Example:**
```bash
curl http://localhost:5000/api/voters
```

---

### Get Voter Details

**Endpoint:** `GET /api/voters/:id`

**Description:** Get comprehensive details about a specific voter, including their full ballot, statistics, and historical votes.

**Query Parameters:**
- `season` (string, optional): Filter votes by season (default: "2024-25")

**Response:**
```json
{
  "id": 1,
  "name": "Mina Kimes",
  "outlet": "ESPN",
  "twitter_handle": "@minakimes",
  "location": "Los Angeles, CA",
  "bio": "Senior NFL analyst for ESPN",
  "created_at": "2025-01-07T08:30:00Z",
  "ballot": [
    {
      "id": 1,
      "ranking": 1,
      "candidate": "Saquon Barkley",
      "team": "Philadelphia Eagles",
      "position": "RB",
      "source_url": "https://x.com/minakimes/status/...",
      "source_type": "social_media",
      "confidence": "high",
      "confidence_score": 90.5,
      "verified": true,
      "announcement_date": "2025-01-05T10:00:00Z",
      "created_at": "2025-01-07T08:35:00Z",
      "extracted_text": "My MVP vote goes to Saquon Barkley...",
      "credibility_tier": "official",
      "credibility_score": 95.0,
      "has_direct_quote": true,
      "has_speculation_language": false
    }
  ],
  "statistics": {
    "total_votes": 5,
    "verified_votes": 5,
    "high_confidence_votes": 4,
    "has_full_ballot": true,
    "first_place_pick": "Saquon Barkley"
  },
  "all_seasons": [
    {
      "season": "2024-25",
      "candidate": "Saquon Barkley",
      "ranking": 1
    }
  ],
  "season": "2024-25"
}
```

**Example:**
```bash
curl "http://localhost:5000/api/voters/1?season=2024-25"
```

**Error Responses:**
- `404 Not Found`: Voter ID does not exist

---

### Create Voter

**Endpoint:** `POST /api/voters`

**Description:** Manually add a new AP voter to the database.

**Request Body:**
```json
{
  "name": "Tom Brady",
  "outlet": "Fox Sports",
  "twitter_handle": "@TomBrady",
  "location": "Tampa, FL",
  "bio": "7-time Super Bowl champion, NFL analyst"
}
```

**Required Fields:**
- `name` (string): Voter's full name

**Optional Fields:**
- `outlet` (string): Media organization
- `twitter_handle` (string): Twitter/X handle (include @)
- `location` (string): City, State
- `bio` (string): Brief biography

**Response:** `201 Created`
```json
{
  "id": 2,
  "message": "Voter created successfully"
}
```

**Error Responses:**
- `400 Bad Request`: Missing required field (name)
- `409 Conflict`: Voter with this name already exists

**Example:**
```bash
curl -X POST http://localhost:5000/api/voters \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tom Brady",
    "outlet": "Fox Sports",
    "twitter_handle": "@TomBrady"
  }'
```

---

### Update Voter

**Endpoint:** `PUT /api/voters/:id`

**Description:** Update information for an existing voter.

**Request Body:** (all fields optional)
```json
{
  "name": "Tom Brady",
  "outlet": "Fox Sports",
  "twitter_handle": "@TomBrady",
  "location": "Tampa, FL",
  "bio": "Updated biography"
}
```

**Response:** `200 OK`
```json
{
  "message": "Voter updated successfully"
}
```

**Error Responses:**
- `404 Not Found`: Voter ID does not exist

**Example:**
```bash
curl -X PUT http://localhost:5000/api/voters/2 \
  -H "Content-Type: application/json" \
  -d '{"bio": "Updated biography"}'
```

---

### Delete Voter

**Endpoint:** `DELETE /api/voters/:id`

**Description:** Delete a voter and all their associated votes (cascade delete).

**Response:** `200 OK`
```json
{
  "message": "Voter deleted successfully"
}
```

**Error Responses:**
- `404 Not Found`: Voter ID does not exist

**Example:**
```bash
curl -X DELETE http://localhost:5000/api/voters/2
```

---

## Candidates API

### List All Candidates

**Endpoint:** `GET /api/candidates`

**Description:** Retrieve all MVP candidates for a given season.

**Query Parameters:**
- `season` (string, optional): Filter by season (default: "2024-25")

**Response:**
```json
[
  {
    "id": 1,
    "name": "Saquon Barkley",
    "team": "Philadelphia Eagles",
    "position": "RB",
    "season": "2024-25",
    "vote_count": 15,
    "first_place_votes": 8
  }
]
```

**Example:**
```bash
curl "http://localhost:5000/api/candidates?season=2024-25"
```

---

### Create Candidate

**Endpoint:** `POST /api/candidates`

**Description:** Add a new MVP candidate.

**Request Body:**
```json
{
  "name": "Josh Allen",
  "team": "Buffalo Bills",
  "position": "QB",
  "season": "2024-25"
}
```

**Required Fields:**
- `name` (string): Player's full name
- `season` (string): Season (format: "YYYY-YY")

**Optional Fields:**
- `team` (string): Team name
- `position` (string): Position (QB, RB, WR, etc.)

**Response:** `201 Created`
```json
{
  "id": 2,
  "message": "Candidate created successfully"
}
```

**Error Responses:**
- `400 Bad Request`: Missing required fields
- `409 Conflict`: Candidate already exists for this season

**Example:**
```bash
curl -X POST http://localhost:5000/api/candidates \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Josh Allen",
    "team": "Buffalo Bills",
    "position": "QB",
    "season": "2024-25"
  }'
```

---

### Update Candidate

**Endpoint:** `PUT /api/candidates/:id`

**Description:** Update candidate information.

**Request Body:** (all fields optional)
```json
{
  "name": "Josh Allen",
  "team": "Buffalo Bills",
  "position": "QB"
}
```

**Response:** `200 OK`
```json
{
  "message": "Candidate updated successfully"
}
```

**Error Responses:**
- `404 Not Found`: Candidate ID does not exist

---

### Delete Candidate

**Endpoint:** `DELETE /api/candidates/:id`

**Description:** Delete a candidate.

**Response:** `200 OK`
```json
{
  "message": "Candidate deleted successfully"
}
```

**Error Responses:**
- `404 Not Found`: Candidate ID does not exist

---

## Votes API

### List All Votes

**Endpoint:** `GET /api/votes`

**Description:** Retrieve all MVP votes.

**Query Parameters:**
- `season` (string, optional): Filter by season (default: "2024-25")

**Response:**
```json
[
  {
    "id": 1,
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "ranking": 1,
    "season": "2024-25",
    "confidence": "high",
    "verified": true,
    "source_url": "https://x.com/minakimes/status/..."
  }
]
```

**Example:**
```bash
curl "http://localhost:5000/api/votes?season=2024-25"
```

---

### Create Vote

**Endpoint:** `POST /api/votes`

**Description:** Add a new MVP vote. Supports two modes: ID-based (for existing entities) and name-based (auto-creates voter/candidate if needed).

**Request Body (ID-based):**
```json
{
  "voter_id": 1,
  "candidate_id": 2,
  "season": "2024-25",
  "ranking": 1,
  "source_url": "https://x.com/minakimes/status/...",
  "confidence": "high",
  "confidence_score": 90.0,
  "verified": true
}
```

**Request Body (Name-based - auto-creates):**
```json
{
  "voter_name": "Peter King",
  "voter_outlet": "NBC Sports",
  "voter_twitter": "@peter_king",
  "candidate_name": "Josh Allen",
  "candidate_team": "Buffalo Bills",
  "candidate_position": "QB",
  "season": "2024-25",
  "ranking": 1,
  "source_url": "https://profootballtalk.nbcsports.com/...",
  "source_type": "news_article",
  "confidence": "high",
  "confidence_score": 85.0,
  "announcement_date": "2025-01-05T14:30:00Z"
}
```

**Required Fields:**
- Either `voter_id` OR `voter_name`
- Either `candidate_id` OR `candidate_name`
- `season` (string)

**Optional Fields:**
- `ranking` (integer): 1-5 for ranked ballot
- `source_url` (string): Link to original announcement
- `source_type` (string): official, social_media, news_article, reddit, speculation
- `confidence` (string): high, medium, low
- `confidence_score` (float): 0-100
- `verified` (boolean): Default false for auto-extracted, true for manual entries
- `announcement_date` (ISO 8601 string)
- `extracted_text` (string): Original text containing the vote

**Response:** `201 Created`
```json
{
  "id": 15,
  "message": "Vote created successfully"
}
```

**Automatic Notifications:**
- Triggers `NEW_VOTE_DISCLOSED` notification
- If vote completes a full ballot (5 votes), triggers `FULL_BALLOT_COMPLETE`
- If vote is high confidence, triggers `HIGH_CONFIDENCE_VOTE`

**Error Responses:**
- `400 Bad Request`: Missing required fields
- `409 Conflict`: Vote already exists (same voter + candidate + season + ranking)

**Example:**
```bash
curl -X POST http://localhost:5000/api/votes \
  -H "Content-Type: application/json" \
  -d '{
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "candidate_team": "Philadelphia Eagles",
    "season": "2024-25",
    "ranking": 1,
    "source_url": "https://x.com/minakimes/status/...",
    "confidence": "high"
  }'
```

---

### Update Vote

**Endpoint:** `PUT /api/votes/:id`

**Description:** Update an existing vote.

**Request Body:** (all fields optional)
```json
{
  "ranking": 2,
  "confidence": "high",
  "confidence_score": 95.0,
  "verified": true,
  "source_url": "https://updated-source.com"
}
```

**Response:** `200 OK`
```json
{
  "message": "Vote updated successfully"
}
```

**Error Responses:**
- `404 Not Found`: Vote ID does not exist

---

### Delete Vote

**Endpoint:** `DELETE /api/votes/:id`

**Description:** Delete a vote.

**Response:** `200 OK`
```json
{
  "message": "Vote deleted successfully"
}
```

**Error Responses:**
- `404 Not Found`: Vote ID does not exist

---

## Dashboard API

### Get Dashboard Data

**Endpoint:** `GET /api/dashboard`

**Description:** Retrieve comprehensive dashboard data in a single API call, optimized for dashboard display.

**Query Parameters:**
- `season` (string, optional): Filter by season (default: "2024-25")

**Response:**
```json
{
  "stats": {
    "total_voters": 50,
    "known_voters": 12,
    "voters_with_disclosed_votes": 8,
    "first_place_votes_disclosed": 8,
    "completion_percentage": 16.0
  },
  "voters": [
    {
      "id": 1,
      "name": "Mina Kimes",
      "outlet": "ESPN",
      "twitter_handle": "@minakimes",
      "has_voted": true,
      "vote_count": 5,
      "ballot": [
        {
          "ranking": 1,
          "candidate": "Saquon Barkley",
          "team": "Philadelphia Eagles",
          "confidence": "high",
          "verified": true,
          "source_url": "https://..."
        }
      ],
      "status": "disclosed"
    }
  ],
  "candidate_stats": [
    {
      "name": "Saquon Barkley",
      "team": "Philadelphia Eagles",
      "position": "RB",
      "first_place_votes": 5,
      "total_mentions": 12
    }
  ],
  "recent_activity": [
    {
      "voter_name": "Mina Kimes",
      "candidate_name": "Saquon Barkley",
      "ranking": 1,
      "date": "2025-01-05T10:30:00Z",
      "created_at": "2025-01-07T08:35:00Z"
    }
  ],
  "season": "2024-25"
}
```

**Use Case:** Single API call to populate entire dashboard UI with statistics, voter list, candidate leaderboard, and recent activity.

**Example:**
```bash
curl "http://localhost:5000/api/dashboard?season=2024-25"
```

---

## Statistics API

### Get Summary Statistics

**Endpoint:** `GET /api/statistics`

**Description:** Comprehensive analytics and statistics about MVP voting patterns.

**Query Parameters:**
- `season` (string, optional): Filter by season (default: "2024-25")

**Response:**
```json
{
  "overview": {
    "total_voters": 50,
    "known_voters": 12,
    "voters_with_disclosed_votes": 8,
    "total_votes": 35,
    "first_place_votes": 8,
    "verified_votes": 30,
    "completion_percentage": 16.0
  },
  "candidate_breakdown": [
    {
      "name": "Saquon Barkley",
      "team": "Philadelphia Eagles",
      "position": "RB",
      "first_place_votes": 5,
      "second_place_votes": 2,
      "third_place_votes": 1,
      "fourth_place_votes": 2,
      "fifth_place_votes": 2,
      "total_mentions": 12,
      "weighted_points": 87
    }
  ],
  "top_candidates": [
    {
      "rank": 1,
      "name": "Saquon Barkley",
      "team": "Philadelphia Eagles",
      "position": "RB",
      "first_place_votes": 5,
      "weighted_points": 87,
      "total_mentions": 12
    }
  ],
  "source_distribution": {
    "official": 5,
    "social_media": 15,
    "news_article": 10,
    "reddit": 3,
    "speculation": 2
  },
  "confidence_distribution": {
    "high": 25,
    "medium": 8,
    "low": 2,
    "unknown": 0
  },
  "disclosure_breakdown": {
    "full_ballot": 2,
    "partial_ballot": 4,
    "first_place_only": 2,
    "no_disclosure": 42
  },
  "timeline": [
    {
      "date": "2025-01-05",
      "count": 5
    }
  ],
  "recent_activity": [
    {
      "voter_name": "Mina Kimes",
      "candidate_name": "Saquon Barkley",
      "ranking": 1,
      "confidence": "high",
      "verified": true,
      "announcement_date": "2025-01-05T10:30:00Z",
      "created_at": "2025-01-07T08:35:00Z"
    }
  ],
  "season": "2024-25"
}
```

**Weighted Points System:**
- 1st place = 10 points
- 2nd place = 7 points
- 3rd place = 5 points
- 4th place = 3 points
- 5th place = 1 point

**Example:**
```bash
curl "http://localhost:5000/api/statistics?season=2024-25"
```

---

## Search & Filter API

### Search Voters and Votes

**Endpoint:** `GET /api/search`

**Description:** Advanced search and filtering across voters, candidates, and votes.

**Query Parameters:**
- `q` (string): General search query (searches voter name, outlet, Twitter handle)
- `voter_name` (string): Filter by specific voter name (partial match)
- `outlet` (string): Filter by media outlet (partial match)
- `candidate` (string): Filter by candidate voted for (partial match)
- `confidence` (string): Filter by confidence level (high, medium, low)
- `verified` (boolean): Filter to only verified votes ("true" or "false")
- `ballot_status` (string): Filter by ballot completion (full, partial, any, none)
- `season` (string): Filter by season (default: "2024-25")

**Response:**
```json
{
  "results": [
    {
      "id": 1,
      "name": "Mina Kimes",
      "outlet": "ESPN",
      "twitter_handle": "@minakimes",
      "has_voted": true,
      "vote_count": 5,
      "ballot": [
        {
          "ranking": 1,
          "candidate": "Saquon Barkley",
          "team": "Philadelphia Eagles",
          "confidence": "high",
          "verified": true
        }
      ],
      "status": "disclosed"
    }
  ],
  "count": 1,
  "filters_applied": {
    "candidate": "Saquon Barkley",
    "confidence": "high",
    "season": "2024-25"
  }
}
```

**Example - Search for voters who voted for Saquon Barkley:**
```bash
curl "http://localhost:5000/api/search?candidate=Saquon%20Barkley"
```

**Example - Find high-confidence verified votes:**
```bash
curl "http://localhost:5000/api/search?confidence=high&verified=true"
```

**Example - Search ESPN voters with disclosed ballots:**
```bash
curl "http://localhost:5000/api/search?outlet=ESPN&ballot_status=full"
```

---

## Export API

### Export Voters (CSV)

**Endpoint:** `GET /api/export/voters?format=csv`

**Description:** Export voter data as CSV file.

**Query Parameters:**
- `format` (string): "csv" or "json" (default: csv)
- `season` (string, optional): Filter by season

**Response:** CSV file download
```csv
id,name,outlet,twitter_handle,location,bio,created_at
1,Mina Kimes,ESPN,@minakimes,"Los Angeles, CA","Senior NFL analyst",2025-01-07T08:30:00Z
```

**Example:**
```bash
curl "http://localhost:5000/api/export/voters?format=csv" -o voters.csv
```

---

### Export Voters (JSON)

**Endpoint:** `GET /api/export/voters?format=json`

**Response:** JSON file download
```json
[
  {
    "id": 1,
    "name": "Mina Kimes",
    "outlet": "ESPN",
    "twitter_handle": "@minakimes",
    "location": "Los Angeles, CA",
    "bio": "Senior NFL analyst",
    "created_at": "2025-01-07T08:30:00Z"
  }
]
```

**Example:**
```bash
curl "http://localhost:5000/api/export/voters?format=json" -o voters.json
```

---

### Export Votes (CSV)

**Endpoint:** `GET /api/export/votes?format=csv`

**Description:** Export vote data as CSV file.

**Query Parameters:**
- `format` (string): "csv" or "json" (default: csv)
- `season` (string, optional): Filter by season

**Response:** CSV file download
```csv
id,voter_name,candidate_name,ranking,season,confidence,confidence_score,verified,source_type,source_url,announcement_date
1,Mina Kimes,Saquon Barkley,1,2024-25,high,90.5,true,social_media,https://...,2025-01-05T10:30:00Z
```

**Example:**
```bash
curl "http://localhost:5000/api/export/votes?format=csv&season=2024-25" -o votes.csv
```

---

### Export Candidates (CSV)

**Endpoint:** `GET /api/export/candidates?format=csv`

**Description:** Export candidate data with vote counts and weighted points.

**Query Parameters:**
- `format` (string): "csv" or "json" (default: csv)
- `season` (string, optional): Filter by season

**Response:** CSV file download
```csv
id,name,team,position,season,first_place_votes,second_place_votes,third_place_votes,fourth_place_votes,fifth_place_votes,total_mentions,weighted_points
1,Saquon Barkley,Philadelphia Eagles,RB,2024-25,5,2,1,2,2,12,87
```

**Example:**
```bash
curl "http://localhost:5000/api/export/candidates?format=csv" -o candidates.csv
```

---

### Export Full Report (JSON)

**Endpoint:** `GET /api/export/full-report`

**Description:** Export comprehensive report with all data (voters, votes, candidates, statistics).

**Query Parameters:**
- `season` (string, optional): Filter by season

**Response:** JSON file download
```json
{
  "metadata": {
    "season": "2024-25",
    "export_date": "2025-01-07T12:00:00Z",
    "total_voters": 12,
    "total_votes": 35,
    "total_candidates": 15
  },
  "voters": [...],
  "votes": [...],
  "candidates": [...],
  "statistics": {
    "overview": {...},
    "candidate_breakdown": [...],
    "source_distribution": {...}
  }
}
```

**Example:**
```bash
curl "http://localhost:5000/api/export/full-report?season=2024-25" -o full-report.json
```

---

## Credibility API

### Assess Source Credibility

**Endpoint:** `POST /api/credibility/assess`

**Description:** Evaluate the credibility of a source URL and assign a credibility tier.

**Request Body:**
```json
{
  "source_url": "https://www.espn.com/nfl/story/...",
  "source_type": "news_article",
  "extracted_text": "Peter King writes: 'My MVP vote goes to Josh Allen...'"
}
```

**Response:**
```json
{
  "credibility_tier": "official",
  "credibility_score": 95.0,
  "domain_trusted": true,
  "has_direct_quote": true,
  "has_speculation_language": false,
  "factors": {
    "trusted_domain": true,
    "source_type": "news_article",
    "direct_quote": true,
    "speculation": false
  }
}
```

**Credibility Tiers:**
- `official`: 90-100 score (verified voter accounts, official announcements)
- `high`: 75-89 score (trusted news outlets, direct quotes)
- `medium`: 50-74 score (general news, social media)
- `low`: 25-49 score (speculation, unverified sources)
- `unverified`: 0-24 score (unreliable sources)

**Example:**
```bash
curl -X POST http://localhost:5000/api/credibility/assess \
  -H "Content-Type: application/json" \
  -d '{
    "source_url": "https://www.espn.com/nfl/story/...",
    "source_type": "news_article",
    "extracted_text": "My MVP vote goes to Josh Allen"
  }'
```

---

### Get Trusted Domains

**Endpoint:** `GET /api/credibility/domains`

**Description:** Retrieve list of all trusted domains for credibility scoring.

**Response:**
```json
{
  "trusted_domains": [
    {
      "domain": "espn.com",
      "tier": "official",
      "description": "ESPN - Major sports network"
    },
    {
      "domain": "nfl.com",
      "tier": "official",
      "description": "NFL.com - Official NFL site"
    }
  ]
}
```

---

### Add Trusted Domain

**Endpoint:** `POST /api/credibility/domains`

**Description:** Add a new trusted domain to the credibility system.

**Request Body:**
```json
{
  "domain": "theathletic.com",
  "tier": "high",
  "description": "The Athletic - Premium sports journalism"
}
```

**Response:** `201 Created`
```json
{
  "message": "Trusted domain added successfully"
}
```

---

### Compare Source Credibility

**Endpoint:** `POST /api/credibility/compare`

**Description:** Compare credibility of multiple sources for the same vote.

**Request Body:**
```json
{
  "sources": [
    {
      "url": "https://twitter.com/voter1/status/...",
      "type": "social_media"
    },
    {
      "url": "https://espn.com/article/...",
      "type": "news_article"
    }
  ]
}
```

**Response:**
```json
{
  "comparison": [
    {
      "url": "https://espn.com/article/...",
      "credibility_tier": "official",
      "credibility_score": 95.0,
      "rank": 1
    },
    {
      "url": "https://twitter.com/voter1/status/...",
      "credibility_tier": "high",
      "credibility_score": 80.0,
      "rank": 2
    }
  ],
  "recommended_source": "https://espn.com/article/..."
}
```

---

### Get Credibility Badges

**Endpoint:** `GET /api/credibility/badges`

**Description:** Get list of available credibility badges for UI display.

**Response:**
```json
{
  "badges": [
    {
      "tier": "official",
      "label": "Official",
      "color": "#10b981",
      "icon": "✓"
    },
    {
      "tier": "high",
      "label": "High Credibility",
      "color": "#3b82f6",
      "icon": "⭐"
    }
  ]
}
```

---

## Historical Data API

### Get Available Seasons

**Endpoint:** `GET /api/historical/seasons`

**Description:** List all seasons with historical MVP voting data.

**Response:**
```json
{
  "seasons": [
    {
      "season": "2024-25",
      "vote_count": 35,
      "voter_count": 12,
      "winner": null
    },
    {
      "season": "2023-24",
      "vote_count": 250,
      "voter_count": 50,
      "winner": "Lamar Jackson"
    }
  ]
}
```

---

### Get Voter History

**Endpoint:** `GET /api/historical/voter/:name`

**Description:** Retrieve a voter's historical MVP picks across all seasons.

**Response:**
```json
{
  "voter_name": "Peter King",
  "voting_history": [
    {
      "season": "2024-25",
      "first_place": "Josh Allen",
      "ballot": [
        {"ranking": 1, "candidate": "Josh Allen"},
        {"ranking": 2, "candidate": "Lamar Jackson"}
      ]
    },
    {
      "season": "2023-24",
      "first_place": "Lamar Jackson",
      "ballot": [...]
    }
  ]
}
```

**Example:**
```bash
curl "http://localhost:5000/api/historical/voter/Peter%20King"
```

---

### Get Candidate History

**Endpoint:** `GET /api/historical/candidate/:name`

**Description:** Retrieve a candidate's vote history across all seasons.

**Response:**
```json
{
  "candidate_name": "Josh Allen",
  "seasons": [
    {
      "season": "2024-25",
      "first_place_votes": 5,
      "total_votes": 12,
      "weighted_points": 87,
      "rank": 1
    },
    {
      "season": "2023-24",
      "first_place_votes": 3,
      "total_votes": 8,
      "weighted_points": 45,
      "rank": 3
    }
  ]
}
```

---

### Compare Seasons

**Endpoint:** `GET /api/historical/compare`

**Description:** Compare MVP voting patterns across multiple seasons.

**Query Parameters:**
- `seasons` (string): Comma-separated list of seasons (e.g., "2023-24,2024-25")

**Response:**
```json
{
  "comparison": [
    {
      "season": "2024-25",
      "winner": null,
      "vote_count": 35,
      "top_candidate": "Saquon Barkley"
    },
    {
      "season": "2023-24",
      "winner": "Lamar Jackson",
      "vote_count": 250,
      "top_candidate": "Lamar Jackson"
    }
  ]
}
```

---

### Get Season Winner

**Endpoint:** `GET /api/historical/winner/:season`

**Description:** Get the official MVP winner for a given season.

**Response:**
```json
{
  "season": "2023-24",
  "winner": "Lamar Jackson",
  "team": "Baltimore Ravens",
  "first_place_votes": 49,
  "total_points": 498
}
```

---

### Get Voter Trends

**Endpoint:** `GET /api/historical/trends/:name`

**Description:** Analyze a voter's historical voting patterns and preferences.

**Response:**
```json
{
  "voter_name": "Peter King",
  "total_votes": 150,
  "seasons_voted": 3,
  "position_preferences": {
    "QB": 65,
    "RB": 25,
    "WR": 10
  },
  "consistency_score": 0.85,
  "favorite_teams": [
    {"team": "Kansas City Chiefs", "votes": 8},
    {"team": "Baltimore Ravens", "votes": 6}
  ]
}
```

---

## Notifications API

### List Notification Preferences

**Endpoint:** `GET /api/notifications/preferences`

**Description:** Get all configured notification preferences.

**Response:**
```json
[
  {
    "id": 1,
    "name": "Email Alerts",
    "enabled": true,
    "channel": "email",
    "notify_new_voter": true,
    "notify_new_vote": true,
    "notify_full_ballot": true,
    "notify_high_confidence": false,
    "email_address": "admin@example.com",
    "min_interval_minutes": 60,
    "created_at": "2025-01-07T08:00:00Z"
  }
]
```

---

### Create Notification Preference

**Endpoint:** `POST /api/notifications/preferences`

**Description:** Configure a new notification channel.

**Request Body (Email):**
```json
{
  "name": "Email Alerts",
  "channel": "email",
  "enabled": true,
  "notify_new_voter": true,
  "notify_new_vote": true,
  "notify_full_ballot": true,
  "email_address": "admin@example.com",
  "email_from": "noreply@mvptracker.com",
  "min_interval_minutes": 60
}
```

**Request Body (Webhook - Slack/Discord):**
```json
{
  "name": "Slack Notifications",
  "channel": "webhook",
  "enabled": true,
  "notify_new_voter": true,
  "notify_new_vote": true,
  "webhook_url": "https://hooks.slack.com/services/...",
  "webhook_secret": "optional-secret-key"
}
```

**Request Body (Console - Development):**
```json
{
  "name": "Console Logs",
  "channel": "console",
  "enabled": true,
  "notify_new_voter": true,
  "notify_new_vote": true
}
```

**Response:** `201 Created`
```json
{
  "id": 2,
  "message": "Notification preference created successfully"
}
```

**Notification Event Types:**
- `notify_new_voter`: New AP voter discovered
- `notify_new_vote`: New MVP vote publicly disclosed
- `notify_full_ballot`: Voter completes full 5-vote ballot
- `notify_high_confidence`: High-confidence vote extracted
- `notify_verified_vote`: Vote manually verified
- `notify_scraping_complete`: Web scraping completed successfully
- `notify_scraping_error`: Web scraping encountered error

---

### Update Notification Preference

**Endpoint:** `PUT /api/notifications/preferences/:id`

**Description:** Update notification settings.

**Request Body:** (all fields optional)
```json
{
  "enabled": false,
  "notify_new_vote": false,
  "min_interval_minutes": 120
}
```

**Response:** `200 OK`
```json
{
  "message": "Notification preference updated successfully"
}
```

---

### Delete Notification Preference

**Endpoint:** `DELETE /api/notifications/preferences/:id`

**Description:** Remove a notification configuration.

**Response:** `200 OK`
```json
{
  "message": "Notification preference deleted successfully"
}
```

---

### Get Notification History

**Endpoint:** `GET /api/notifications/history`

**Description:** View history of sent notifications.

**Query Parameters:**
- `limit` (integer, optional): Number of records to return (default: 50)
- `status` (string, optional): Filter by status (sent, failed, pending)

**Response:**
```json
[
  {
    "id": 1,
    "event_type": "NEW_VOTE_DISCLOSED",
    "title": "New MVP Vote: Mina Kimes → Saquon Barkley",
    "message": "A new MVP vote has been publicly disclosed...",
    "channel": "email",
    "recipient": "admin@example.com",
    "status": "sent",
    "sent_at": "2025-01-07T10:35:00Z"
  }
]
```

---

### Send Test Notification

**Endpoint:** `POST /api/notifications/test`

**Description:** Send a test notification to all enabled channels.

**Request Body:** (all fields optional)
```json
{
  "title": "Test Notification",
  "message": "Testing the notification system"
}
```

**Response:**
```json
{
  "notifications_sent": 2,
  "notifications_failed": 0,
  "details": [
    {
      "channel": "email",
      "status": "sent",
      "recipient": "admin@example.com"
    },
    {
      "channel": "webhook",
      "status": "sent",
      "recipient": "https://hooks.slack.com/..."
    }
  ]
}
```

---

## Error Responses

All endpoints return standard HTTP status codes with JSON error messages.

### 400 Bad Request
```json
{
  "error": "Missing required field: name"
}
```

### 404 Not Found
```json
{
  "error": "Voter not found"
}
```

### 409 Conflict
```json
{
  "error": "Voter with this name already exists"
}
```

### 500 Internal Server Error
```json
{
  "error": "An internal error occurred",
  "details": "Database connection failed"
}
```

---

## Rate Limiting

**Current Status:** No rate limiting implemented (development mode)

**Production Recommendations:**
- Implement rate limiting: 100 requests per minute per IP
- Higher limits for authenticated API keys: 1000 requests per minute
- Burst allowance: 20 requests per second
- Use Redis for distributed rate limiting
- Return `429 Too Many Requests` with `Retry-After` header

**Rate Limit Headers (Planned):**
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1641571200
```

---

## Examples

### Python Example

```python
import requests

BASE_URL = "http://localhost:5000/api"

# Get all voters
response = requests.get(f"{BASE_URL}/voters")
voters = response.json()
print(f"Found {len(voters)} voters")

# Create a new vote
vote_data = {
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "candidate_team": "Philadelphia Eagles",
    "season": "2024-25",
    "ranking": 1,
    "source_url": "https://x.com/minakimes/status/...",
    "confidence": "high"
}
response = requests.post(f"{BASE_URL}/votes", json=vote_data)
if response.status_code == 201:
    print("Vote created successfully!")

# Get dashboard data
response = requests.get(f"{BASE_URL}/dashboard?season=2024-25")
dashboard = response.json()
print(f"Completion: {dashboard['stats']['completion_percentage']}%")

# Search for voters who voted for Saquon Barkley
response = requests.get(f"{BASE_URL}/search?candidate=Saquon Barkley")
results = response.json()
print(f"Found {results['count']} voters who voted for Saquon Barkley")

# Export votes as CSV
response = requests.get(f"{BASE_URL}/export/votes?format=csv")
with open("votes.csv", "wb") as f:
    f.write(response.content)
```

### JavaScript Example

```javascript
const BASE_URL = "http://localhost:5000/api";

// Get all voters
async function getVoters() {
  const response = await fetch(`${BASE_URL}/voters`);
  const voters = await response.json();
  console.log(`Found ${voters.length} voters`);
  return voters;
}

// Create a new vote
async function createVote(voteData) {
  const response = await fetch(`${BASE_URL}/votes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(voteData),
  });

  if (response.ok) {
    const result = await response.json();
    console.log("Vote created:", result.id);
    return result;
  } else {
    const error = await response.json();
    console.error("Error:", error.error);
  }
}

// Get statistics
async function getStatistics() {
  const response = await fetch(`${BASE_URL}/statistics?season=2024-25`);
  const stats = await response.json();
  console.log("Completion:", stats.overview.completion_percentage + "%");
  return stats;
}

// Search voters
async function searchVoters(query) {
  const response = await fetch(`${BASE_URL}/search?q=${encodeURIComponent(query)}`);
  const results = await response.json();
  console.log(`Found ${results.count} results`);
  return results.results;
}

// Export data
async function exportVotes() {
  const response = await fetch(`${BASE_URL}/export/votes?format=csv`);
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "votes.csv";
  a.click();
}
```

### cURL Examples

```bash
# Get all voters
curl http://localhost:5000/api/voters

# Get voter details
curl "http://localhost:5000/api/voters/1?season=2024-25"

# Create a voter
curl -X POST http://localhost:5000/api/voters \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tom Brady",
    "outlet": "Fox Sports",
    "twitter_handle": "@TomBrady"
  }'

# Create a vote
curl -X POST http://localhost:5000/api/votes \
  -H "Content-Type: application/json" \
  -d '{
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "season": "2024-25",
    "ranking": 1,
    "confidence": "high"
  }'

# Get dashboard
curl "http://localhost:5000/api/dashboard?season=2024-25"

# Get statistics
curl "http://localhost:5000/api/statistics?season=2024-25"

# Search voters
curl "http://localhost:5000/api/search?candidate=Saquon%20Barkley&confidence=high"

# Export votes as CSV
curl "http://localhost:5000/api/export/votes?format=csv" -o votes.csv

# Export full report
curl "http://localhost:5000/api/export/full-report?season=2024-25" -o report.json

# Create notification preference
curl -X POST http://localhost:5000/api/notifications/preferences \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Console Logs",
    "channel": "console",
    "enabled": true,
    "notify_new_voter": true,
    "notify_new_vote": true
  }'

# Send test notification
curl -X POST http://localhost:5000/api/notifications/test \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test",
    "message": "Testing notifications"
  }'
```

---

## API Versioning (Future)

**Current Version:** 1.0 (no versioning in URLs)

**Future Versioning Strategy:**
- Version in URL path: `/api/v2/voters`
- Version in Accept header: `Accept: application/vnd.mvptracker.v2+json`
- Backward compatibility for at least 2 versions
- Deprecation warnings in response headers

---

## CORS Configuration

**Current Configuration:**
- CORS enabled for all origins (development mode)
- All HTTP methods allowed
- All headers allowed

**Production Recommendations:**
```python
CORS(app,
     origins=['https://mvptracker.com'],
     methods=['GET', 'POST', 'PUT', 'DELETE'],
     allow_headers=['Content-Type', 'Authorization'])
```

---

## WebSocket Support (Future Feature)

**Planned Features:**
- Real-time vote updates via WebSocket
- Live dashboard updates
- Notification delivery via WebSocket
- Endpoint: `ws://localhost:5000/ws`

---

## API Status & Monitoring

**Recommended Monitoring:**
- Response time tracking
- Error rate monitoring
- Database query performance
- Rate limit violations
- Failed notification tracking

**Health Check Endpoint:**
```bash
curl http://localhost:5000/api/health
```

---

## Security Considerations

**Current Security Status:**
- ⚠️ No authentication (development mode)
- ⚠️ No authorization checks
- ⚠️ No input sanitization
- ⚠️ No SQL injection protection (SQLAlchemy ORM provides some protection)
- ⚠️ No CSRF protection
- ✅ CORS enabled

**Production Security Checklist:**
- [ ] Implement API key authentication
- [ ] Add rate limiting
- [ ] Enable HTTPS only
- [ ] Implement input validation and sanitization
- [ ] Add SQL injection protection
- [ ] Enable CSRF tokens for write operations
- [ ] Implement role-based access control (RBAC)
- [ ] Add request logging and audit trails
- [ ] Enable helmet.js security headers
- [ ] Implement API key rotation
- [ ] Add IP whitelisting for admin endpoints

---

## Support & Feedback

For questions, bug reports, or feature requests:
- GitHub: (repository URL)
- Email: (support email)
- Documentation: (docs URL)

---

**Last Updated:** January 7, 2025
**API Version:** 1.0
**Total Endpoints:** 40
