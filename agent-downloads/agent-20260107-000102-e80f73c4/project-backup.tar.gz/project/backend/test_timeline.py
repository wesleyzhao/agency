#!/usr/bin/env python3
"""
Test suite for Timeline API endpoint - Feature #23
Tests the /api/timeline endpoint that shows chronological vote announcements
"""

import requests
import json
from datetime import datetime

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
RESET = '\033[0m'

API_URL = 'http://localhost:5000'

def print_test_header(message):
    """Print a formatted test header"""
    print(f"\n{CYAN}{'='*60}")
    print(f"{message}")
    print(f"{'='*60}{RESET}\n")

def print_success(message):
    """Print a success message"""
    print(f"{GREEN}✓ {message}{RESET}")

def print_error(message):
    """Print an error message"""
    print(f"{RED}✗ {message}{RESET}")

def print_info(message):
    """Print an info message"""
    print(f"{YELLOW}ℹ {message}{RESET}")

def test_health_check():
    """Test 1: Verify backend server is running"""
    print_test_header("Test 1: Health Check")

    try:
        response = requests.get(f"{API_URL}/api/voters", timeout=5)
        if response.status_code == 200:
            print_success("Backend server is running")
            return True
        else:
            print_error(f"Backend returned status code {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print_error("Cannot connect to backend server")
        print_info("Make sure the backend is running: cd backend && python3 app.py")
        return False
    except Exception as e:
        print_error(f"Health check failed: {str(e)}")
        return False

def test_timeline_endpoint_basic():
    """Test 2: Test timeline endpoint with default parameters"""
    print_test_header("Test 2: Timeline Endpoint - Basic")

    try:
        response = requests.get(f"{API_URL}/api/timeline?season=2024-25")

        if response.status_code != 200:
            print_error(f"Timeline endpoint returned status code {response.status_code}")
            return False

        print_success("Timeline endpoint returned 200 OK")

        data = response.json()

        # Check required fields
        required_fields = ['season', 'group_by', 'timeline', 'summary']
        for field in required_fields:
            if field in data:
                print_success(f"Response contains '{field}' field")
            else:
                print_error(f"Response missing '{field}' field")
                return False

        # Check summary structure
        summary_fields = ['total_timeline_entries', 'total_votes', 'total_first_place_votes',
                         'unique_voters', 'unique_candidates', 'earliest_announcement', 'latest_announcement']
        for field in summary_fields:
            if field in data['summary']:
                print_success(f"Summary contains '{field}' field")
            else:
                print_error(f"Summary missing '{field}' field")
                return False

        print(f"\n{CYAN}Summary Stats:{RESET}")
        print(f"  Timeline Entries: {data['summary']['total_timeline_entries']}")
        print(f"  Total Votes: {data['summary']['total_votes']}")
        print(f"  First Place Votes: {data['summary']['total_first_place_votes']}")
        print(f"  Unique Voters: {data['summary']['unique_voters']}")
        print(f"  Unique Candidates: {data['summary']['unique_candidates']}")

        if data['summary']['earliest_announcement'] and data['summary']['latest_announcement']:
            print(f"  Date Range: {data['summary']['earliest_announcement']} to {data['summary']['latest_announcement']}")

        return True

    except Exception as e:
        print_error(f"Test failed: {str(e)}")
        return False

def test_timeline_entries_structure():
    """Test 3: Validate timeline entries structure"""
    print_test_header("Test 3: Timeline Entries Structure")

    try:
        response = requests.get(f"{API_URL}/api/timeline?season=2024-25")
        data = response.json()

        if not data['timeline'] or len(data['timeline']) == 0:
            print_info("No timeline entries found (no votes with announcement dates)")
            return True

        print_success(f"Found {len(data['timeline'])} timeline entries")

        # Check first entry structure
        entry = data['timeline'][0]
        required_fields = ['date', 'display_date', 'votes', 'stats']

        for field in required_fields:
            if field in entry:
                print_success(f"Timeline entry contains '{field}' field")
            else:
                print_error(f"Timeline entry missing '{field}' field")
                return False

        # Check stats structure
        stats_fields = ['total_votes', 'first_place_votes', 'unique_voters', 'unique_candidates', 'verified_votes']
        for field in stats_fields:
            if field in entry['stats']:
                print_success(f"Entry stats contains '{field}' field")
            else:
                print_error(f"Entry stats missing '{field}' field")
                return False

        print(f"\n{CYAN}First Timeline Entry:{RESET}")
        print(f"  Date: {entry['display_date']}")
        print(f"  Total Votes: {entry['stats']['total_votes']}")
        print(f"  First Place Votes: {entry['stats']['first_place_votes']}")
        print(f"  Unique Voters: {entry['stats']['unique_voters']}")
        print(f"  Unique Candidates: {entry['stats']['unique_candidates']}")
        print(f"  Verified Votes: {entry['stats']['verified_votes']}")

        # Show first vote in entry
        if entry['votes'] and len(entry['votes']) > 0:
            vote = entry['votes'][0]
            print(f"\n{CYAN}Sample Vote:{RESET}")
            print(f"  Voter: {vote['voter_name']} ({vote.get('voter_outlet', 'N/A')})")
            print(f"  Candidate: {vote['candidate_name']} ({vote.get('candidate_team', 'N/A')})")
            print(f"  Ranking: #{vote['ranking']}")
            print(f"  Confidence: {vote.get('confidence', 'N/A')}")
            print(f"  Verified: {'Yes' if vote.get('verified') else 'No'}")

        return True

    except Exception as e:
        print_error(f"Test failed: {str(e)}")
        return False

def test_timeline_grouping():
    """Test 4: Test different grouping options (day, week, month)"""
    print_test_header("Test 4: Timeline Grouping Options")

    try:
        groupings = ['day', 'week', 'month']
        results = {}

        for group_by in groupings:
            response = requests.get(f"{API_URL}/api/timeline?season=2024-25&group_by={group_by}")

            if response.status_code != 200:
                print_error(f"Failed to fetch timeline with group_by={group_by}")
                return False

            data = response.json()

            if data['group_by'] != group_by:
                print_error(f"Expected group_by={group_by}, got {data['group_by']}")
                return False

            print_success(f"Successfully fetched timeline with group_by={group_by}")
            results[group_by] = len(data['timeline'])

        print(f"\n{CYAN}Timeline Entries by Grouping:{RESET}")
        for group_by, count in results.items():
            print(f"  {group_by}: {count} entries")

        return True

    except Exception as e:
        print_error(f"Test failed: {str(e)}")
        return False

def test_timeline_limit():
    """Test 5: Test limit parameter"""
    print_test_header("Test 5: Timeline Limit Parameter")

    try:
        # Test with limit=5
        response = requests.get(f"{API_URL}/api/timeline?season=2024-25&limit=5")

        if response.status_code != 200:
            print_error(f"Failed to fetch timeline with limit parameter")
            return False

        data = response.json()

        if len(data['timeline']) <= 5:
            print_success(f"Limit parameter working (returned {len(data['timeline'])} entries, limit was 5)")
        else:
            print_error(f"Limit parameter not working (returned {len(data['timeline'])} entries, limit was 5)")
            return False

        return True

    except Exception as e:
        print_error(f"Test failed: {str(e)}")
        return False

def test_frontend_instructions():
    """Display instructions for testing the frontend"""
    print_test_header("Frontend Testing Instructions")

    print_info("To test the Timeline page in the frontend:")
    print()
    print("1. Make sure the backend is running:")
    print("   cd backend && python3 app.py")
    print()
    print("2. Start the frontend in another terminal:")
    print("   cd frontend && npm start")
    print()
    print("3. Access the Timeline page:")
    print("   - Click '📅 Timeline' button on Dashboard")
    print("   - Or navigate to: http://localhost:3000/timeline")
    print()
    print("4. Test the features:")
    print("   - View timeline entries grouped by date")
    print("   - Toggle grouping (Day/Week/Month)")
    print("   - Expand/collapse timeline entries")
    print("   - Click on voter names to view details")
    print("   - Click source links to verify announcements")
    print("   - Use Expand All / Collapse All buttons")
    print()

def main():
    """Run all tests"""
    print(f"\n{CYAN}{'='*60}")
    print("Testing Timeline Feature #23")
    print(f"{'='*60}{RESET}")

    # Run tests
    tests = [
        ("Health Check", test_health_check),
        ("Timeline Endpoint Basic", test_timeline_endpoint_basic),
        ("Timeline Entries Structure", test_timeline_entries_structure),
        ("Timeline Grouping", test_timeline_grouping),
        ("Timeline Limit", test_timeline_limit),
    ]

    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print_error(f"{test_name} failed with exception: {str(e)}")
            results.append((test_name, False))

    # Display frontend instructions
    test_frontend_instructions()

    # Print summary
    print(f"\n{CYAN}{'='*60}")
    print("Test Summary")
    print(f"{'='*60}{RESET}\n")

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print(f"\n{CYAN}Total: {passed}/{total} tests passed{RESET}\n")

    if passed == total:
        print(f"{GREEN}All tests PASSED! ✓{RESET}\n")
    else:
        print(f"{RED}Some tests FAILED ✗{RESET}\n")

if __name__ == '__main__':
    main()
