#!/usr/bin/env python3
"""
Comprehensive test suite for Feature #16: Source Credibility Tracking

Tests all aspects of the credibility scoring system including:
- CredibilityScorer functionality
- Database schema and migration
- API endpoints
- Integration with vote extraction
"""

import sys
import os
from pathlib import Path

# Add backend directory to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

import logging
from nlp import CredibilityScorer, CredibilityTier

# Colored output
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_test(name, passed, details=""):
    """Print test result with color coding"""
    status = f"{Colors.GREEN}✓ PASSED{Colors.RESET}" if passed else f"{Colors.RED}✗ FAILED{Colors.RESET}"
    print(f"\n{Colors.BOLD}Test: {name}{Colors.RESET}")
    print(f"Status: {status}")
    if details:
        print(f"Details: {details}")

def print_section(title):
    """Print section header"""
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.CYAN}{Colors.BOLD}{title}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")


def test_credibility_scorer_initialization():
    """Test CredibilityScorer can be initialized"""
    try:
        scorer = CredibilityScorer()
        assert scorer is not None
        assert len(scorer.tier1_domains) > 0
        assert len(scorer.tier2_domains) > 0
        assert len(scorer.tier3_domains) > 0
        print_test("CredibilityScorer Initialization", True,
                   f"Loaded {len(scorer.tier1_domains)} tier1, {len(scorer.tier2_domains)} tier2, {len(scorer.tier3_domains)} tier3 domains")
        return True
    except Exception as e:
        print_test("CredibilityScorer Initialization", False, str(e))
        return False


def test_domain_reputation_assessment():
    """Test domain reputation assessment"""
    scorer = CredibilityScorer()

    test_cases = [
        ('https://espn.com/article', 'tier1'),
        ('https://profootballtalk.com/post', 'tier2'),
        ('https://twitter.com/user/status', 'social'),
        ('https://reddit.com/r/nfl/comments', 'forum'),
        ('https://unknown-site.com', 'unknown')
    ]

    all_passed = True
    for url, expected in test_cases:
        result = scorer._assess_domain_reputation(url)
        passed = result == expected
        if not passed:
            print(f"{Colors.RED}  ✗ {url} -> Expected: {expected}, Got: {result}{Colors.RESET}")
            all_passed = False
        else:
            print(f"{Colors.GREEN}  ✓ {url} -> {result}{Colors.RESET}")

    print_test("Domain Reputation Assessment", all_passed)
    return all_passed


def test_verified_source_detection():
    """Test detection of verified sources"""
    scorer = CredibilityScorer()

    # Tier1 domain with direct quote should be VERIFIED
    source_data = {
        'url': 'https://espn.com/nfl/story',
        'title': 'Mina Kimes reveals MVP vote',
        'content': '"I\'m voting for Josh Allen as my MVP," said Kimes.',
        'source_type': 'news_article',
        'voter_name': 'Mina Kimes',
        'is_verified_account': False
    }

    result = scorer.assess_source_credibility(source_data)

    passed = result['credibility_tier'] in [CredibilityTier.VERIFIED, CredibilityTier.OFFICIAL]
    print_test("Verified Source Detection", passed,
               f"Tier: {result['credibility_tier']}, Score: {result['credibility_score']}")

    if passed:
        print(f"{Colors.CYAN}  - Has direct quote: {result['has_direct_quote']}{Colors.RESET}")
        print(f"{Colors.CYAN}  - Domain reputation: {result['domain_reputation']}{Colors.RESET}")
        print(f"{Colors.CYAN}  - Recommendation: {result['recommendation']}{Colors.RESET}")

    return passed


def test_speculation_detection():
    """Test detection of speculation language"""
    scorer = CredibilityScorer()

    source_data = {
        'url': 'https://reddit.com/r/nfl/comments/123',
        'title': 'MVP Speculation',
        'content': 'I think Mina Kimes will probably vote for Josh Allen',
        'source_type': 'reddit',
        'voter_name': 'Mina Kimes',
        'is_verified_account': False
    }

    result = scorer.assess_source_credibility(source_data)

    passed = (result['has_speculation_language'] and
              result['credibility_tier'] in [CredibilityTier.SPECULATION, CredibilityTier.UNVERIFIED])

    print_test("Speculation Detection", passed,
               f"Tier: {result['credibility_tier']}, Has speculation: {result['has_speculation_language']}")
    return passed


def test_direct_quote_detection():
    """Test detection of direct quotes"""
    scorer = CredibilityScorer()

    test_cases = [
        ('"I am voting for Josh Allen," Kimes said.', True),
        ('Mina Kimes stated that she is voting for Josh Allen.', True),
        ('Kimes might vote for Allen', False),
        ('I think she will pick Allen', False)
    ]

    all_passed = True
    for content, should_have_quote in test_cases:
        has_quote = scorer._check_direct_quotes(content, '')
        passed = has_quote == should_have_quote
        if not passed:
            print(f"{Colors.RED}  ✗ Expected quote={should_have_quote}, got {has_quote}{Colors.RESET}")
            all_passed = False
        else:
            print(f"{Colors.GREEN}  ✓ Correctly detected quote={has_quote}{Colors.RESET}")

    print_test("Direct Quote Detection", all_passed)
    return all_passed


def test_credibility_tier_hierarchy():
    """Test that credibility tiers are correctly assigned"""
    scorer = CredibilityScorer()

    test_scenarios = [
        {
            'name': 'Verified Twitter Account',
            'data': {
                'url': 'https://twitter.com/minakimes/status/123',
                'content': 'My MVP vote goes to Josh Allen #1',
                'source_type': 'social_media',
                'is_verified_account': True
            },
            'expected_tier': CredibilityTier.VERIFIED
        },
        {
            'name': 'ESPN with Direct Quote',
            'data': {
                'url': 'https://espn.com/article',
                'content': '"I voted for Josh Allen," said Peter King.',
                'source_type': 'news_article'
            },
            'expected_tier': [CredibilityTier.VERIFIED, CredibilityTier.OFFICIAL]  # Either is acceptable
        },
        {
            'name': 'Official NFL.com Article',
            'data': {
                'url': 'https://nfl.com/news/mvp-votes',
                'content': 'Peter King announces his MVP selection',
                'source_type': 'official'
            },
            'expected_tier': CredibilityTier.OFFICIAL
        },
        {
            'name': 'Reddit Speculation',
            'data': {
                'url': 'https://reddit.com/r/nfl',
                'content': 'I think he might vote for Allen',
                'source_type': 'reddit'
            },
            'expected_tier': CredibilityTier.SPECULATION
        }
    ]

    all_passed = True
    for scenario in test_scenarios:
        result = scorer.assess_source_credibility(scenario['data'])
        expected = scenario['expected_tier']

        # Handle both single tier and list of acceptable tiers
        if isinstance(expected, list):
            passed = result['credibility_tier'] in expected
        else:
            passed = result['credibility_tier'] == expected

        if not passed:
            print(f"{Colors.RED}  ✗ {scenario['name']}: Expected {expected}, got {result['credibility_tier']}{Colors.RESET}")
            all_passed = False
        else:
            print(f"{Colors.GREEN}  ✓ {scenario['name']}: {result['credibility_tier']} (score: {result['credibility_score']}){Colors.RESET}")

    print_test("Credibility Tier Hierarchy", all_passed)
    return all_passed


def test_credibility_badges():
    """Test credibility badge generation"""
    scorer = CredibilityScorer()

    tiers = [
        CredibilityTier.VERIFIED,
        CredibilityTier.OFFICIAL,
        CredibilityTier.RELIABLE,
        CredibilityTier.UNVERIFIED,
        CredibilityTier.SPECULATION
    ]

    all_passed = True
    for tier in tiers:
        # CredibilityTier is string constant, not enum
        tier_str = tier if isinstance(tier, str) else tier
        badge = scorer.get_credibility_badge(tier_str)
        passed = all([
            'color' in badge,
            'icon' in badge,
            'label' in badge,
            'description' in badge
        ])

        if not passed:
            print(f"{Colors.RED}  ✗ Badge for {tier_str} missing fields{Colors.RESET}")
            all_passed = False
        else:
            print(f"{Colors.GREEN}  ✓ {tier_str}: {badge['icon']} {badge['label']} ({badge['color']}){Colors.RESET}")

    print_test("Credibility Badge Generation", all_passed)
    return all_passed


def test_source_comparison():
    """Test comparing multiple sources"""
    scorer = CredibilityScorer()

    sources = [
        {
            'credibility_tier': CredibilityTier.VERIFIED,
            'credibility_score': 95.0
        },
        {
            'credibility_tier': CredibilityTier.OFFICIAL,
            'credibility_score': 85.0
        },
        {
            'credibility_tier': CredibilityTier.RELIABLE,
            'credibility_score': 70.0
        }
    ]

    result = scorer.compare_sources(sources)

    passed = (
        result['highest_tier'] == CredibilityTier.VERIFIED and
        result['num_sources'] == 3 and
        result['average_score'] > 80
    )

    print_test("Source Comparison", passed,
               f"Highest: {result['highest_tier']}, Avg: {result['average_score']}, Recommendation: {result['recommendation']}")
    return passed


def test_add_trusted_domain():
    """Test adding a new trusted domain"""
    scorer = CredibilityScorer()

    initial_count = len(scorer.tier3_domains)
    scorer.add_trusted_domain('newsite.com', 'tier3')
    new_count = len(scorer.tier3_domains)

    passed = new_count == initial_count + 1 and 'newsite.com' in scorer.tier3_domains
    print_test("Add Trusted Domain", passed,
               f"Added newsite.com to tier3 ({initial_count} -> {new_count} domains)")
    return passed


def test_api_endpoints():
    """Test credibility API endpoints"""
    try:
        import requests

        base_url = 'http://localhost:5000'

        # Test /api/credibility/badges endpoint
        try:
            response = requests.get(f'{base_url}/api/credibility/badges', timeout=5)
            if response.status_code == 200:
                badges = response.json()
                passed = len(badges) == 5  # Should have 5 tier badges
                print_test("API: /api/credibility/badges", passed,
                           f"Returned {len(badges)} badge definitions")
            else:
                print_test("API: /api/credibility/badges", False,
                           f"Status: {response.status_code}")
                return False
        except requests.exceptions.ConnectionError:
            print_test("API Endpoints", False,
                       "Backend server not running. Start with: cd backend && python3 app.py")
            return False

        # Test /api/credibility/domains endpoint
        response = requests.get(f'{base_url}/api/credibility/domains', timeout=5)
        passed = response.status_code == 200 and 'tier1' in response.json()
        print_test("API: /api/credibility/domains", passed,
                   f"Status: {response.status_code}")

        # Test /api/credibility/assess endpoint
        test_data = {
            'url': 'https://espn.com/test',
            'content': '"I vote for Josh Allen"',
            'source_type': 'news_article'
        }
        response = requests.post(f'{base_url}/api/credibility/assess',
                                json=test_data, timeout=5)
        passed = response.status_code == 200 and 'credibility_tier' in response.json()
        print_test("API: /api/credibility/assess", passed,
                   f"Status: {response.status_code}")

        return True

    except ImportError:
        print_test("API Endpoints", False,
                   "requests library not installed. Install with: pip install requests")
        return False
    except Exception as e:
        print_test("API Endpoints", False, str(e))
        return False


def test_database_migration():
    """Test that database migration can be run"""
    try:
        from database import get_engine
        from sqlalchemy import inspect

        engine = get_engine()
        inspector = inspect(engine)

        # Check if votes table has credibility fields
        votes_columns = [col['name'] for col in inspector.get_columns('votes')]
        expected_columns = ['credibility_tier', 'credibility_score',
                           'has_direct_quote', 'has_speculation_language']

        has_all_columns = all(col in votes_columns for col in expected_columns)

        if has_all_columns:
            print_test("Database Migration", True,
                       "All credibility columns exist in votes table")
            return True
        else:
            missing = [col for col in expected_columns if col not in votes_columns]
            print_test("Database Migration", False,
                       f"Missing columns: {missing}. Run: python3 backend/database/migrate_add_credibility.py")
            return False

    except Exception as e:
        print_test("Database Migration", False,
                   f"Error: {str(e)}")
        return False


def main():
    """Run all tests"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}╔═══════════════════════════════════════════════════════════╗{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}║   Feature #16: Source Credibility Tracking - Test Suite  ║{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}╚═══════════════════════════════════════════════════════════╝{Colors.RESET}\n")

    results = {}

    # Unit Tests
    print_section("Unit Tests - CredibilityScorer")
    results['initialization'] = test_credibility_scorer_initialization()
    results['domain_reputation'] = test_domain_reputation_assessment()
    results['verified_detection'] = test_verified_source_detection()
    results['speculation_detection'] = test_speculation_detection()
    results['quote_detection'] = test_direct_quote_detection()
    results['tier_hierarchy'] = test_credibility_tier_hierarchy()
    results['badges'] = test_credibility_badges()
    results['source_comparison'] = test_source_comparison()
    results['add_domain'] = test_add_trusted_domain()

    # Integration Tests
    print_section("Integration Tests")
    results['database_migration'] = test_database_migration()
    results['api_endpoints'] = test_api_endpoints()

    # Summary
    print_section("Test Summary")
    passed = sum(1 for r in results.values() if r)
    total = len(results)
    percentage = (passed / total * 100) if total > 0 else 0

    print(f"\n{Colors.BOLD}Results: {passed}/{total} tests passed ({percentage:.1f}%){Colors.RESET}\n")

    if passed == total:
        print(f"{Colors.GREEN}{Colors.BOLD}✓ All tests passed!{Colors.RESET}\n")
        return 0
    else:
        print(f"{Colors.YELLOW}{Colors.BOLD}⚠ Some tests failed{Colors.RESET}\n")
        print(f"{Colors.YELLOW}Failed tests:{Colors.RESET}")
        for name, result in results.items():
            if not result:
                print(f"  - {name}")
        print()
        return 1


if __name__ == '__main__':
    sys.exit(main())
