"""
Comprehensive test suite for Notification System - Feature #18
"""
import os
import sys
import json
import time
from datetime import datetime

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Colors for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'


def print_test(message, status='info'):
    """Print colored test message"""
    if status == 'success':
        print(f"{GREEN}✓{RESET} {message}")
    elif status == 'error':
        print(f"{RED}✗{RESET} {message}")
    elif status == 'info':
        print(f"{CYAN}ℹ{RESET} {message}")
    elif status == 'warning':
        print(f"{YELLOW}⚠{RESET} {message}")
    else:
        print(message)


def test_database_migration():
    """Test that database migration creates tables correctly"""
    print("\n" + "=" * 60)
    print("Test 1: Database Migration")
    print("=" * 60)

    try:
        from sqlalchemy import create_engine, inspect
        from database.models import Base, NotificationPreference, NotificationHistory

        engine = create_engine('sqlite:///../data/mvp_tracker.db')
        inspector = inspect(engine)

        # Check if tables exist
        tables = inspector.get_table_names()

        if 'notification_preferences' in tables:
            print_test("notification_preferences table exists", 'success')
        else:
            print_test("notification_preferences table NOT found", 'error')
            return False

        if 'notification_history' in tables:
            print_test("notification_history table exists", 'success')
        else:
            print_test("notification_history table NOT found", 'error')
            return False

        # Check columns in notification_preferences
        pref_columns = [col['name'] for col in inspector.get_columns('notification_preferences')]
        required_pref_cols = [
            'id', 'name', 'enabled', 'channel', 'notify_new_voter', 'notify_new_vote',
            'notify_full_ballot', 'email_address', 'webhook_url', 'created_at'
        ]

        for col in required_pref_cols:
            if col in pref_columns:
                print_test(f"  Column '{col}' exists in notification_preferences", 'success')
            else:
                print_test(f"  Column '{col}' MISSING in notification_preferences", 'error')
                return False

        # Check columns in notification_history
        hist_columns = [col['name'] for col in inspector.get_columns('notification_history')]
        required_hist_cols = [
            'id', 'event_type', 'title', 'message', 'channel', 'recipient',
            'status', 'voter_id', 'vote_id', 'sent_at', 'created_at'
        ]

        for col in required_hist_cols:
            if col in hist_columns:
                print_test(f"  Column '{col}' exists in notification_history", 'success')
            else:
                print_test(f"  Column '{col}' MISSING in notification_history", 'error')
                return False

        return True

    except Exception as e:
        print_test(f"Database migration test failed: {e}", 'error')
        return False


def test_create_notification_preference():
    """Test creating notification preferences"""
    print("\n" + "=" * 60)
    print("Test 2: Create Notification Preferences")
    print("=" * 60)

    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from database.models import NotificationPreference, NotificationChannel

        engine = create_engine('sqlite:///../data/mvp_tracker.db')
        Session = sessionmaker(bind=engine)
        session = Session()

        # Create console preference
        console_pref = NotificationPreference(
            name="Test Console Notifications",
            enabled=1,
            channel=NotificationChannel.CONSOLE,
            notify_new_voter=1,
            notify_new_vote=1,
            notify_full_ballot=1
        )
        session.add(console_pref)
        session.commit()

        print_test(f"Created console preference (ID: {console_pref.id})", 'success')

        # Create email preference (won't actually send emails in test)
        email_pref = NotificationPreference(
            name="Test Email Notifications",
            enabled=0,  # Disabled by default
            channel=NotificationChannel.EMAIL,
            email_address="test@example.com",
            email_from="noreply@mvptracker.com",
            notify_new_voter=1,
            notify_new_vote=1
        )
        session.add(email_pref)
        session.commit()

        print_test(f"Created email preference (ID: {email_pref.id})", 'success')

        # Verify preferences were created
        all_prefs = session.query(NotificationPreference).all()
        print_test(f"Total notification preferences: {len(all_prefs)}", 'info')

        session.close()
        return True

    except Exception as e:
        print_test(f"Create preference test failed: {e}", 'error')
        return False


def test_notification_service():
    """Test NotificationService functionality"""
    print("\n" + "=" * 60)
    print("Test 3: NotificationService")
    print("=" * 60)

    try:
        from notifications import NotificationService
        from database.models import NotificationEventType

        service = NotificationService()
        print_test("NotificationService initialized", 'success')

        # Test generic notification
        result = service.notify(
            NotificationEventType.NEW_VOTE_DISCLOSED,
            "Test Notification",
            "This is a test notification message",
            metadata={'test': True}
        )

        print_test(f"Sent test notification", 'success')
        print_test(f"  Notifications sent: {result['notifications_sent']}", 'info')
        print_test(f"  Notifications failed: {result['notifications_failed']}", 'info')

        if result['notifications_sent'] > 0:
            print_test("At least one notification was sent", 'success')
        else:
            print_test("No notifications were sent (check if preferences are enabled)", 'warning')

        return True

    except Exception as e:
        print_test(f"NotificationService test failed: {e}", 'error')
        return False


def test_notification_history():
    """Test notification history tracking"""
    print("\n" + "=" * 60)
    print("Test 4: Notification History")
    print("=" * 60)

    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from database.models import NotificationHistory

        engine = create_engine('sqlite:///../data/mvp_tracker.db')
        Session = sessionmaker(bind=engine)
        session = Session()

        # Get recent notification history
        history = session.query(NotificationHistory).order_by(
            NotificationHistory.created_at.desc()
        ).limit(10).all()

        print_test(f"Found {len(history)} notification history records", 'success')

        for h in history[:3]:  # Show first 3
            status_icon = "✓" if h.status == 'sent' else "✗"
            print_test(f"  {status_icon} {h.event_type.value if h.event_type else 'unknown'}: {h.title} ({h.status})", 'info')

        session.close()
        return True

    except Exception as e:
        print_test(f"Notification history test failed: {e}", 'error')
        return False


def test_voter_notification():
    """Test new voter notification"""
    print("\n" + "=" * 60)
    print("Test 5: New Voter Notification")
    print("=" * 60)

    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from database.models import Voter
        from notifications import NotificationService

        engine = create_engine('sqlite:///../data/mvp_tracker.db')
        Session = sessionmaker(bind=engine)
        session = Session()

        # Create a test voter
        test_voter = Voter(
            name=f"Test Voter {int(time.time())}",
            outlet="Test Outlet",
            twitter_handle="@testvoter"
        )
        session.add(test_voter)
        session.commit()

        print_test(f"Created test voter (ID: {test_voter.id})", 'success')

        # Send notification
        service = NotificationService()
        result = service.notify_new_voter(test_voter.id)

        print_test(f"Sent new voter notification", 'success')
        print_test(f"  Notifications sent: {result['notifications_sent']}", 'info')

        # Clean up test voter
        session.delete(test_voter)
        session.commit()
        print_test("Cleaned up test voter", 'info')

        session.close()
        return True

    except Exception as e:
        print_test(f"Voter notification test failed: {e}", 'error')
        return False


def test_vote_notification():
    """Test new vote notification"""
    print("\n" + "=" * 60)
    print("Test 6: New Vote Notification")
    print("=" * 60)

    try:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from database.models import Voter, Candidate, Vote, ConfidenceLevel, SourceType
        from notifications import NotificationService

        engine = create_engine('sqlite:///../data/mvp_tracker.db')
        Session = sessionmaker(bind=engine)
        session = Session()

        # Create test voter and candidate
        test_voter = Voter(
            name=f"Test Voter {int(time.time())}",
            outlet="Test Outlet"
        )
        session.add(test_voter)

        test_candidate = Candidate(
            name="Test Candidate",
            team="Test Team",
            position="QB",
            season="2024-25"
        )
        session.add(test_candidate)
        session.flush()

        # Create test vote
        test_vote = Vote(
            voter_id=test_voter.id,
            candidate_id=test_candidate.id,
            season="2024-25",
            ranking=1,
            confidence=ConfidenceLevel.HIGH,
            source_type=SourceType.OFFICIAL,
            verified=1
        )
        session.add(test_vote)
        session.commit()

        print_test(f"Created test vote (ID: {test_vote.id})", 'success')

        # Send notification
        service = NotificationService()
        result = service.notify_new_vote(test_vote.id)

        print_test(f"Sent new vote notification", 'success')
        print_test(f"  Notifications sent: {result['notifications_sent']}", 'info')

        # Test high confidence notification
        result2 = service.notify_high_confidence_vote(test_vote.id)
        print_test(f"Sent high confidence notification", 'success')
        print_test(f"  Notifications sent: {result2['notifications_sent']}", 'info')

        # Clean up
        session.delete(test_vote)
        session.delete(test_candidate)
        session.delete(test_voter)
        session.commit()
        print_test("Cleaned up test data", 'info')

        session.close()
        return True

    except Exception as e:
        print_test(f"Vote notification test failed: {e}", 'error')
        return False


def test_api_endpoints():
    """Test notification API endpoints"""
    print("\n" + "=" * 60)
    print("Test 7: API Endpoints")
    print("=" * 60)

    try:
        import requests

        base_url = "http://localhost:5000"

        # Test health check first
        try:
            response = requests.get(f"{base_url}/api/health", timeout=2)
            if response.status_code != 200:
                print_test("Backend server not running. Start it with: cd backend && python3 app.py", 'warning')
                return False
        except requests.exceptions.RequestException:
            print_test("Backend server not running. Start it with: cd backend && python3 app.py", 'warning')
            return False

        # Test GET preferences
        response = requests.get(f"{base_url}/api/notifications/preferences")
        if response.status_code == 200:
            prefs = response.json()
            print_test(f"GET /api/notifications/preferences returned {len(prefs)} preferences", 'success')
        else:
            print_test(f"GET preferences failed: {response.status_code}", 'error')
            return False

        # Test POST preference
        new_pref = {
            "name": "Test API Preference",
            "channel": "console",
            "notify_new_voter": True,
            "notify_new_vote": True
        }
        response = requests.post(
            f"{base_url}/api/notifications/preferences",
            json=new_pref
        )
        if response.status_code == 201:
            created = response.json()
            pref_id = created['id']
            print_test(f"POST /api/notifications/preferences created ID {pref_id}", 'success')

            # Test PUT preference
            update_data = {"enabled": False}
            response = requests.put(
                f"{base_url}/api/notifications/preferences/{pref_id}",
                json=update_data
            )
            if response.status_code == 200:
                print_test(f"PUT /api/notifications/preferences/{pref_id} succeeded", 'success')
            else:
                print_test(f"PUT preference failed: {response.status_code}", 'error')

            # Test DELETE preference
            response = requests.delete(f"{base_url}/api/notifications/preferences/{pref_id}")
            if response.status_code == 200:
                print_test(f"DELETE /api/notifications/preferences/{pref_id} succeeded", 'success')
            else:
                print_test(f"DELETE preference failed: {response.status_code}", 'error')

        else:
            print_test(f"POST preference failed: {response.status_code}", 'error')
            return False

        # Test notification history
        response = requests.get(f"{base_url}/api/notifications/history?limit=5")
        if response.status_code == 200:
            history = response.json()
            print_test(f"GET /api/notifications/history returned {len(history)} records", 'success')
        else:
            print_test(f"GET history failed: {response.status_code}", 'error')
            return False

        # Test test notification endpoint
        response = requests.post(
            f"{base_url}/api/notifications/test",
            json={"title": "API Test", "message": "Testing notification API"}
        )
        if response.status_code == 200:
            result = response.json()
            print_test(f"POST /api/notifications/test succeeded", 'success')
            print_test(f"  Notifications sent: {result.get('notifications_sent', 0)}", 'info')
        else:
            print_test(f"POST test notification failed: {response.status_code}", 'error')

        return True

    except Exception as e:
        print_test(f"API endpoints test failed: {e}", 'error')
        return False


def test_integration_with_votes():
    """Test notification integration with vote creation"""
    print("\n" + "=" * 60)
    print("Test 8: Integration with Vote Creation")
    print("=" * 60)

    try:
        import requests

        base_url = "http://localhost:5000"

        # Create a test vote (which should trigger notification)
        vote_data = {
            "voter_name": f"Integration Test Voter {int(time.time())}",
            "candidate_name": "Josh Allen",
            "candidate_team": "Buffalo Bills",
            "season": "2024-25",
            "ranking": 1,
            "confidence": "high",
            "source_type": "official"
        }

        response = requests.post(f"{base_url}/api/votes", json=vote_data)

        if response.status_code == 201:
            vote = response.json()
            print_test(f"Created vote ID {vote['id']} (should trigger notification)", 'success')

            # Check notification history for this vote
            time.sleep(0.5)  # Give it a moment
            response = requests.get(f"{base_url}/api/notifications/history?limit=5")
            if response.status_code == 200:
                history = response.json()
                recent = [h for h in history if h.get('vote_id') == vote['id']]
                if recent:
                    print_test(f"Found {len(recent)} notification(s) for this vote", 'success')
                else:
                    print_test("No notifications found (might be disabled)", 'warning')

            return True
        else:
            print_test(f"Vote creation failed: {response.status_code}", 'error')
            return False

    except Exception as e:
        print_test(f"Integration test failed: {e}", 'error')
        return False


def run_all_tests():
    """Run all notification system tests"""
    print("\n" + "=" * 70)
    print(" " * 15 + "NOTIFICATION SYSTEM TEST SUITE")
    print(" " * 20 + "Feature #18")
    print("=" * 70)

    tests = [
        ("Database Migration", test_database_migration),
        ("Create Preferences", test_create_notification_preference),
        ("NotificationService", test_notification_service),
        ("Notification History", test_notification_history),
        ("Voter Notifications", test_voter_notification),
        ("Vote Notifications", test_vote_notification),
        ("API Endpoints", test_api_endpoints),
        ("Integration Test", test_integration_with_votes),
    ]

    results = []
    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success))
        except Exception as e:
            print_test(f"Test '{name}' crashed: {e}", 'error')
            results.append((name, False))

    # Print summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)

    passed = sum(1 for _, success in results if success)
    total = len(results)

    for name, success in results:
        status = f"{GREEN}PASSED{RESET}" if success else f"{RED}FAILED{RESET}"
        print(f"  {name}: {status}")

    print("\n" + "=" * 70)
    if passed == total:
        print(f"{GREEN}All tests PASSED! ✓ ({passed}/{total}){RESET}")
    else:
        print(f"{YELLOW}Some tests failed: {passed}/{total} passed{RESET}")
    print("=" * 70 + "\n")

    return passed == total


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
