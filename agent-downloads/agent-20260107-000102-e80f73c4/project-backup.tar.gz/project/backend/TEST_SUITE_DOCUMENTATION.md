# NFL MVP Voter Tracker - Unit Test Suite Documentation
## Feature #29: Unit Tests for NLP Extraction and Data Validation

This document describes the comprehensive unit test suite for the NFL MVP Voter Tracker application, specifically covering NLP extraction and data validation.

---

## Overview

The test suite (`test_unit_nlp_validation.py`) provides comprehensive coverage of:

1. **NLP Extraction Components** (4 test classes, 24 tests)
   - VoterExtractor
   - CandidateExtractor
   - RankingExtractor
   - VoteExtractor (integration)

2. **Confidence Scoring System** (1 test class, 5 tests)
   - ConfidenceScorer validation

3. **Data Validation** (1 test class, 8 tests)
   - Input validation
   - Format checking
   - Constraint validation

4. **Database Constraints** (1 test class, 6 tests)
   - Uniqueness constraints
   - Foreign key relationships
   - Required fields
   - Enum validation

5. **Error Handling** (1 test class, 7 tests)
   - Edge cases
   - Malformed input
   - Unicode and special characters

**Total: 8 test classes, 58 unit tests**

---

## Test Classes

### 1. TestVoterExtraction

Tests the `VoterExtractor` class for extracting voter names from text.

**Tests:**
- `test_known_voter_extraction`: Extract known AP voters (e.g., Mina Kimes)
- `test_twitter_handle_extraction`: Extract voter from Twitter URL
- `test_first_person_declaration`: Detect first-person voting statements
- `test_byline_extraction`: Extract voters from article bylines
- `test_confidence_levels`: Verify confidence scoring (high/medium/low)
- `test_deduplication`: Ensure voters are deduplicated
- `test_empty_text`: Handle empty input gracefully
- `test_no_voters_found`: Return empty list when no voters present

**Example:**
```python
text = "Mina Kimes announced her MVP vote today."
voters = extractor.extract_voters_from_text(text)
# Returns: [{'name': 'Mina Kimes', 'confidence': 'high', ...}]
```

---

### 2. TestCandidateExtraction

Tests the `CandidateExtractor` class for extracting MVP candidate names.

**Tests:**
- `test_full_name_extraction`: Extract candidates by full name
- `test_partial_name_extraction`: Extract candidates by last name
- `test_multiple_candidates`: Extract multiple candidates from text
- `test_candidate_with_team`: Verify team information extraction
- `test_voting_context_confidence`: Higher confidence with voting keywords
- `test_deduplication`: Merge candidate name variations
- `test_unknown_candidate`: Ignore unknown players
- `test_empty_text`: Handle empty input

**Example:**
```python
text = "Josh Allen has been incredible this season."
candidates = extractor.extract_candidates_from_text(text)
# Returns: [{'name': 'Josh Allen', 'team': 'Buffalo Bills', 'position': 'QB', ...}]
```

---

### 3. TestRankingExtraction

Tests the `RankingExtractor` class for extracting vote rankings.

**Tests:**
- `test_numbered_list`: Extract from "1. Player, 2. Player" format
- `test_ordinal_words`: Extract from "First place: Player" format
- `test_ordinal_numbers`: Extract from "1st: Player" format
- `test_hashtag_rankings`: Extract from "#1 Player" format
- `test_full_ballot_extraction`: Extract complete 5-vote ballot
- `test_partial_ballot`: Extract partial ballots (1-4 votes)
- `test_ballot_validation`: Validate ballot completeness and correctness
- `test_confidence_scoring`: Verify ranking confidence levels
- `test_empty_text`: Handle empty input

**Example:**
```python
text = """
1. Josh Allen
2. Lamar Jackson
3. Saquon Barkley
"""
rankings = extractor.extract_rankings_from_text(text)
# Returns: [{'rank': 1, 'player_name': 'Josh Allen', 'confidence': 'high'}, ...]
```

---

### 4. TestVoteExtractionIntegration

Tests the complete `VoteExtractor` system (integration tests).

**Tests:**
- `test_complete_ballot_extraction`: Extract full 5-vote ballot
- `test_simple_vote_extraction`: Extract single vote
- `test_twitter_vote_extraction`: Extract from Twitter-style content
- `test_confidence_propagation`: Verify confidence scores propagate
- `test_source_metadata`: Verify source URL and type captured
- `test_multiple_voters_same_text`: Handle multiple voters in one text
- `test_edge_case_no_votes`: Handle text with no votes

**Example:**
```python
text = """
By Mina Kimes - January 5, 2025
My MVP ballot:
1. Josh Allen
2. Lamar Jackson
"""
votes = extractor.extract_votes_from_text(text, "https://espn.com/mvp", "news_article")
# Returns: [
#   {'voter_name': 'Mina Kimes', 'candidate_name': 'Josh Allen', 'ranking': 1, ...},
#   {'voter_name': 'Mina Kimes', 'candidate_name': 'Lamar Jackson', 'ranking': 2, ...}
# ]
```

---

### 5. TestConfidenceScoring

Tests the `ConfidenceScorer` class for vote confidence calculation.

**Tests:**
- `test_high_confidence_vote`: Score > 75 for verified votes
- `test_medium_confidence_vote`: Score 50-74 for moderate confidence
- `test_low_confidence_vote`: Score < 50 for speculation
- `test_factor_breakdown`: Verify individual factor scores returned
- `test_batch_confidence_calculation`: Process multiple votes at once

**Example:**
```python
vote_data = {
    'voter_name': 'Mina Kimes',
    'voter_confidence': 'high',
    'candidate_name': 'Josh Allen',
    'ranking': 1,
    'source_type': 'official'
}
result = scorer.calculate_vote_confidence(vote_data)
# Returns: {'numeric_score': 85.5, 'confidence_level': 'high', 'recommendation': 'auto_approve', ...}
```

---

### 6. TestDataValidation

Tests input data validation rules.

**Tests:**
- `test_voter_name_validation`: Name must be non-empty string
- `test_ranking_validation`: Ranking must be 1-5
- `test_confidence_level_validation`: Confidence must be high/medium/low
- `test_confidence_score_validation`: Score must be 0-100
- `test_source_type_validation`: Source type must be valid enum
- `test_url_format_validation`: URL must start with http:// or https://
- `test_season_format_validation`: Season must match YYYY-YY pattern
- `test_twitter_handle_format`: Handle must start with @

**Example:**
```python
# Valid ranking
ranking = 3
assert 1 <= ranking <= 5  # Pass

# Invalid ranking
ranking = 6
assert 1 <= ranking <= 5  # Fail
```

---

### 7. TestDatabaseConstraints

Tests database schema constraints and validation.

**Tests:**
- `test_voter_unique_constraint`: Voter names must be unique
- `test_voter_name_required`: Voter name is required field
- `test_vote_foreign_key_constraints`: Vote requires valid voter and candidate
- `test_vote_season_required`: Vote season is required field
- `test_candidate_name_required`: Candidate name is required field
- `test_enum_validation`: Enum fields accept valid values

**Example:**
```python
# Create voter
voter = Voter(name="Mina Kimes", outlet="ESPN")
session.add(voter)
session.commit()  # Success

# Try to create duplicate
duplicate = Voter(name="Mina Kimes", outlet="NBC")
session.add(duplicate)
session.commit()  # Raises IntegrityError (UNIQUE constraint)
```

---

### 8. TestErrorHandling

Tests error handling for edge cases and malformed input.

**Tests:**
- `test_malformed_text_handling`: Handle None, empty, whitespace-only
- `test_very_long_text_handling`: Handle very long text (10,000+ words)
- `test_special_characters_handling`: Handle <>, [], (), etc.
- `test_unicode_handling`: Handle emojis and unicode characters
- `test_mixed_language_handling`: Handle non-English text
- `test_incomplete_ballot_handling`: Handle incomplete ballots gracefully
- `test_ambiguous_ranking_handling`: Handle duplicate or tied rankings

**Example:**
```python
# Malformed input
extractor.extract_votes_from_text("")  # Returns: []
extractor.extract_votes_from_text(None)  # Handled gracefully

# Special characters
text = "Mina Kimes' #1: Josh Allen (!!!) [MVP]"
votes = extractor.extract_votes_from_text(text)  # Extracts successfully

# Unicode
text = "Mina Kimes votes for Josh Allen 🏈 MVP 🏆"
votes = extractor.extract_votes_from_text(text)  # Extracts successfully
```

---

## Running the Tests

### Run Complete Test Suite

```bash
cd backend
python3 test_unit_nlp_validation.py
```

**Expected Output:**
```
================================================================================
NFL MVP TRACKER - COMPREHENSIVE UNIT TESTS
Feature #29: Unit Tests for NLP Extraction and Data Validation
================================================================================
Database tables created successfully!

test_byline_extraction ... ok
test_confidence_levels ... ok
[... 56 more tests ...]

----------------------------------------------------------------------
Ran 58 tests in 0.311s

OK

================================================================================
TEST SUMMARY
================================================================================
Tests run: 58
Successes: 58
Failures: 0
Errors: 0

✅ ALL TESTS PASSED! ✅
```

### Run Specific Test Class

```bash
cd backend
python3 -m unittest test_unit_nlp_validation.TestVoterExtraction
```

### Run Specific Test

```bash
cd backend
python3 -m unittest test_unit_nlp_validation.TestVoterExtraction.test_known_voter_extraction
```

---

## Test Coverage

The test suite provides comprehensive coverage of:

### NLP Extraction (24 tests)
- ✅ Known voter extraction
- ✅ Twitter handle extraction
- ✅ First-person declarations
- ✅ Byline extraction
- ✅ Confidence scoring
- ✅ Full candidate extraction (name, team, position)
- ✅ Multiple candidate handling
- ✅ Ranking extraction (multiple formats)
- ✅ Full ballot extraction
- ✅ Ballot validation
- ✅ Complete vote extraction pipeline
- ✅ Source metadata capture

### Confidence Scoring (5 tests)
- ✅ High confidence votes (>75)
- ✅ Medium confidence votes (50-74)
- ✅ Low confidence votes (<50)
- ✅ Factor breakdown (6 factors)
- ✅ Batch confidence calculation

### Data Validation (8 tests)
- ✅ Voter name validation
- ✅ Ranking validation (1-5)
- ✅ Confidence level validation
- ✅ Confidence score validation (0-100)
- ✅ Source type validation
- ✅ URL format validation
- ✅ Season format validation (YYYY-YY)
- ✅ Twitter handle format

### Database Constraints (6 tests)
- ✅ Voter unique constraint
- ✅ Required fields validation
- ✅ Foreign key relationships
- ✅ Enum field validation
- ✅ Data integrity

### Error Handling (7 tests)
- ✅ Malformed input (None, empty, whitespace)
- ✅ Very long text (10,000+ words)
- ✅ Special characters (<>, [], (), etc.)
- ✅ Unicode characters (emojis)
- ✅ Mixed language text
- ✅ Incomplete ballots
- ✅ Ambiguous rankings

---

## Test Design Principles

### 1. Isolation
- Each test is independent and can run alone
- Database tests use in-memory SQLite
- Unique identifiers prevent test interference

### 2. Comprehensive Coverage
- Test both success and failure cases
- Test edge cases and error conditions
- Test data validation at multiple levels

### 3. Clear Assertions
- Each test has clear, specific assertions
- Descriptive error messages
- Proper use of unittest assertion methods

### 4. Documentation
- Each test has descriptive docstring
- Test names clearly describe what is tested
- Code comments explain complex scenarios

### 5. Real-World Examples
- Tests use realistic voter names (Mina Kimes, Peter King)
- Tests use actual MVP candidates (Josh Allen, Lamar Jackson)
- Tests simulate real tweet and article formats

---

## Integration with CI/CD

This test suite is designed to be integrated into continuous integration pipelines:

```yaml
# Example GitHub Actions workflow
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: |
          cd backend
          pip install -r requirements.txt
      - name: Run tests
        run: |
          cd backend
          python3 test_unit_nlp_validation.py
```

---

## Future Enhancements

Potential additions to the test suite:

1. **Performance Tests**
   - Test extraction speed on large documents
   - Test batch processing performance
   - Memory usage profiling

2. **Mock External Services**
   - Mock Twitter API for voter handle extraction
   - Mock news sites for article scraping
   - Test offline functionality

3. **Property-Based Testing**
   - Use hypothesis library for fuzz testing
   - Generate random valid/invalid inputs
   - Test invariants and properties

4. **Integration Tests**
   - End-to-end scraping → extraction → database pipeline
   - API endpoint tests with mock data
   - Frontend integration tests

5. **Regression Tests**
   - Test cases for previously found bugs
   - Golden output files for comparison
   - Version-specific behavior tests

---

## Troubleshooting

### Test Failures

**Foreign Key Constraint Errors:**
- SQLite may not enforce foreign keys by default
- Tests are written to work with both SQLite and PostgreSQL
- Production should use PostgreSQL for proper constraint enforcement

**Duplicate Voter Names:**
- Tests use unique identifiers to prevent collisions
- Each test increments a counter for unique names
- Database is in-memory and cleared between test classes

**Import Errors:**
- Ensure you're running from the backend directory
- Check that all dependencies are installed: `pip install -r requirements.txt`
- Verify Python path includes the backend directory

### Debugging Tests

**Run Single Test with Verbose Output:**
```bash
python3 -m unittest -v test_unit_nlp_validation.TestVoterExtraction.test_known_voter_extraction
```

**Run with Python Debugger:**
```bash
python3 -m pdb test_unit_nlp_validation.py
```

**Add Print Statements:**
```python
def test_known_voter_extraction(self):
    text = "Mina Kimes announced her MVP vote today."
    voters = self.extractor.extract_voters_from_text(text)
    print(f"DEBUG: Extracted voters: {voters}")  # Add debugging
    self.assertGreater(len(voters), 0)
```

---

## Related Documentation

- **EXTENDING_SCRAPERS.md**: Guide to extending the system
- **backend/nlp/README.md**: NLP module documentation
- **backend/nlp/CONFIDENCE_SCORING.md**: Confidence scoring system
- **backend/database/models.py**: Database schema
- **backend/LOGGING_SYSTEM.md**: Logging system documentation

---

## Summary

The comprehensive unit test suite provides:

- ✅ **58 unit tests** covering all major components
- ✅ **100% pass rate** with proper setup
- ✅ **8 test classes** organized by functionality
- ✅ **Edge case coverage** for error handling
- ✅ **Database constraint validation** for data integrity
- ✅ **Clear documentation** with examples
- ✅ **CI/CD ready** for automated testing

This test suite ensures the NFL MVP Voter Tracker application maintains high quality and reliability as it evolves.
