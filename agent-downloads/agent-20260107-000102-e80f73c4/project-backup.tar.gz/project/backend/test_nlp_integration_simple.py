"""
Simple integration test for NLP extraction
Tests with sample realistic texts without external dependencies
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from nlp import VoteExtractor


def test_sample_texts():
    """Test NLP with various realistic sample texts"""
    print("="*70)
    print("NLP EXTRACTION - INTEGRATION TEST WITH REALISTIC SAMPLES")
    print("="*70)

    extractor = VoteExtractor()

    test_cases = [
        {
            'name': 'Twitter-style ballot announcement',
            'text': """
            @minakimes
            OK fine, here's my MVP ballot:
            1. Josh Allen
            2. Saquon Barkley
            3. Lamar Jackson
            4. Jared Goff
            5. Joe Burrow

            Allen has been the most complete QB this season. No question.
            """,
            'url': 'https://twitter.com/minakimes/status/123',
            'source_type': 'twitter'
        },
        {
            'name': 'ESPN news article excerpt',
            'text': """
            By Peter King | ESPN.com

            I've submitted my MVP ballot for the 2024-25 season. After watching
            every game carefully, here's how I voted:

            First place: Josh Allen (Buffalo Bills)
            Second place: Lamar Jackson (Baltimore Ravens)
            Third place: Saquon Barkley (Philadelphia Eagles)
            Fourth place: Jared Goff (Detroit Lions)
            Fifth place: Joe Burrow (Cincinnati Bengals)

            Allen gets my top vote because of how he's elevated everyone around him.
            The Bills simply don't make the playoffs without his MVP-caliber play.
            """,
            'url': 'https://espn.com/nfl/story/mvp-ballot-2024',
            'source_type': 'news_article'
        },
        {
            'name': 'Reddit comment with hashtag rankings',
            'text': """
            Just submitted my official AP MVP ballot. Here's how I ranked them:

            #1: Lamar Jackson - He's been absolutely dominant
            #2: Josh Allen - Close second, incredible season
            #3: Saquon Barkley - Best RB performance in years
            #4: Jared Goff - Quietly elite all year
            #5: Joe Burrow - Clutch when it matters

            Was really tough choosing between Lamar and Josh for #1, but Lamar
            edged it out with his dual-threat dominance.
            """,
            'url': 'https://reddit.com/r/nfl/comments/mvp_ballot',
            'source_type': 'reddit'
        },
        {
            'name': 'Simple Twitter announcement',
            'text': """
            Tom Brady @tombrady
            My MVP vote is going to Josh Allen. What he's done for the Bills
            this year has been phenomenal. Most valuable to his team, hands down.
            """,
            'url': 'https://twitter.com/tombrady/status/456',
            'source_type': 'twitter'
        },
        {
            'name': 'Multi-voter article',
            'text': """
            Several AP voters have revealed their picks:

            Mina Kimes said she's voting for Josh Allen at the top of her ballot.
            Meanwhile, Peter King announced he's going with Lamar Jackson for first place.
            Tom Brady also weighed in, saying Saquon Barkley deserves serious MVP consideration.

            The race appears tight between Allen, Jackson, and Barkley as the top three candidates.
            """,
            'url': 'https://nfl.com/news/mvp-voters-reveal-picks',
            'source_type': 'news_article'
        },
        {
            'name': 'ProFootballTalk article',
            'text': """
            Mike Florio - ProFootballTalk

            I've made my decision on MVP. My ballot:

            1) Josh Allen
            2) Lamar Jackson
            3) Saquon Barkley
            4) Jared Goff
            5) Joe Burrow

            Allen separated himself down the stretch with clutch performances
            when his team needed him most.
            """,
            'url': 'https://profootballtalk.com/mvp-ballot-revealed',
            'source_type': 'news_article'
        },
    ]

    total_votes = 0
    total_voters = set()
    total_candidates = set()

    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{'='*70}")
        print(f"Test Case {i}: {test_case['name']}")
        print('='*70)
        print(f"Source: {test_case['url']}")
        print(f"Type: {test_case['source_type']}")
        print()

        votes = extractor.extract_votes_from_text(
            test_case['text'],
            test_case['url'],
            source_type=test_case['source_type']
        )

        print(f"✓ Votes extracted: {len(votes)}")
        print()

        if votes:
            # Group by voter
            voters_dict = {}
            for vote in votes:
                voter = vote['voter_name']
                if voter not in voters_dict:
                    voters_dict[voter] = []
                voters_dict[voter].append(vote)

            for voter, voter_votes in voters_dict.items():
                print(f"  {voter}:")
                for vote in sorted(voter_votes, key=lambda v: v.get('ranking', 999)):
                    rank = vote.get('ranking', '?')
                    candidate = vote['candidate_name']
                    team = vote['candidate_team']
                    confidence = vote['overall_confidence']

                    print(f"    Rank {rank}: {candidate} ({team}) - confidence: {confidence}")

                total_voters.add(voter)

            for vote in votes:
                total_candidates.add(vote['candidate_name'])

        total_votes += len(votes)

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print('='*70)
    print(f"Total votes extracted: {total_votes}")
    print(f"Unique voters identified: {len(total_voters)}")
    print(f"Unique candidates mentioned: {len(total_candidates)}")
    print()

    if total_voters:
        print("Voters:")
        for voter in sorted(total_voters):
            print(f"  - {voter}")
        print()

    if total_candidates:
        print("Candidates:")
        for candidate in sorted(total_candidates):
            print(f"  - {candidate}")
        print()

    # Verify we got reasonable results
    assert total_votes >= 15, f"Expected at least 15 votes, got {total_votes}"
    assert len(total_voters) >= 4, f"Expected at least 4 voters, got {len(total_voters)}"
    assert len(total_candidates) >= 3, f"Expected at least 3 candidates, got {len(total_candidates)}"

    print("✓ All assertions passed!")
    print("\n" + "="*70)
    print("🎉 INTEGRATION TEST COMPLETED SUCCESSFULLY! 🎉")
    print("="*70)

    return True


if __name__ == "__main__":
    success = test_sample_texts()
    sys.exit(0 if success else 1)
