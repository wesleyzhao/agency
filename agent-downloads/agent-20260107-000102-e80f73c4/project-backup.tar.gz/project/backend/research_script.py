#!/usr/bin/env python3
"""
NFL MVP Voter Research Script - Feature #26

This script performs comprehensive research to discover NFL MVP voters and their
publicly disclosed votes for the 2024-25 season. It uses all available scrapers,
NLP extraction, and saves results to the database.

Usage:
    python3 research_script.py --season 2024-25 --mode full
    python3 research_script.py --mode quick
    python3 research_script.py --voter "Mina Kimes"
    python3 research_script.py --sources reddit,google
"""

import argparse
import sys
import time
from datetime import datetime
from typing import Dict, List, Any

# Import scrapers
from scrapers import (
    ScraperOrchestrator,
    NewsAggregator,
    EnhancedScraper
)

# Import NLP
from nlp import VoteExtractor

# Import database utilities
from database import get_session, VoterDB, VoteDB, CandidateDB, SourceDB

# Import logging
from logging_config import (
    scraping_logger,
    nlp_logger,
    database_logger,
    general_logger,
    log_scraping_activity,
    log_extraction_activity,
    log_database_operation
)

# Import notifications
from notifications import NotificationService
from database.models import NotificationEventType


class ResearchSession:
    """Manages a research session to discover NFL MVP voters and votes."""

    def __init__(self, season: str = "2024-25", mode: str = "full",
                 sources: List[str] = None, specific_voter: str = None):
        """
        Initialize a research session.

        Args:
            season: NFL season (e.g., "2024-25")
            mode: Research mode - "full", "quick", "news_only"
            sources: List of sources to use (reddit, google, news)
            specific_voter: Search for a specific voter only
        """
        self.season = season
        self.mode = mode
        self.sources = sources or ["reddit", "google", "news"]
        self.specific_voter = specific_voter

        # Initialize components
        self.orchestrator = ScraperOrchestrator(use_db_deduplication=True)
        self.news_aggregator = NewsAggregator()
        self.vote_extractor = VoteExtractor()
        self.notification_service = NotificationService()
        self.db_session = get_session()

        # Database utility classes (use static methods)
        self.voter_db = VoterDB
        self.vote_db = VoteDB
        self.candidate_db = CandidateDB
        self.source_db = SourceDB

        # Session statistics
        self.stats = {
            "start_time": datetime.now(),
            "sources_scraped": 0,
            "articles_found": 0,
            "voters_discovered": 0,
            "votes_extracted": 0,
            "votes_saved": 0,
            "errors": 0,
            "duplicates_skipped": 0
        }

        general_logger.info(f"Research session initialized: season={season}, mode={mode}, sources={sources}")

    def run(self) -> Dict[str, Any]:
        """
        Run the complete research process.

        Returns:
            Dictionary with session statistics
        """
        try:
            print("\n" + "="*70)
            print(f"NFL MVP VOTER RESEARCH - Season {self.season}")
            print(f"Mode: {self.mode.upper()}")
            print(f"Sources: {', '.join(self.sources)}")
            if self.specific_voter:
                print(f"Searching for: {self.specific_voter}")
            print("="*70 + "\n")

            # Step 1: Gather articles and posts
            all_results = self._gather_sources()

            # Step 2: Extract votes from results
            self._extract_and_save_votes(all_results)

            # Step 3: Generate final report
            self._generate_report()

            # Step 4: Send completion notification
            self._send_completion_notification()

            return self.stats

        except Exception as e:
            general_logger.error(f"Research session failed: {e}", exc_info=True)
            self.stats["errors"] += 1
            raise
        finally:
            self.db_session.close()
            general_logger.info(f"Research session completed: {self.stats}")

    def _gather_sources(self) -> List[Dict[str, Any]]:
        """
        Gather articles and posts from all configured sources.

        Returns:
            List of results from all sources
        """
        print("\n[Step 1/3] Gathering sources...\n")
        all_results = []

        # Reddit scraping
        if "reddit" in self.sources:
            print("🔍 Searching Reddit...")
            try:
                if self.specific_voter:
                    reddit_results = self.orchestrator.search_specific_voter(self.specific_voter)
                else:
                    reddit_results = self.orchestrator.run_comprehensive_search(
                        season=self.season,
                        sources=["reddit"]
                    )
                all_results.extend(reddit_results.get("reddit", []))
                self.stats["sources_scraped"] += 1
                print(f"   ✓ Found {len(reddit_results.get('reddit', []))} Reddit posts")

                log_scraping_activity(
                    scraping_logger,
                    source="reddit",
                    url="multiple_subreddits",
                    status="success",
                    posts_found=len(reddit_results.get("reddit", []))
                )
            except Exception as e:
                scraping_logger.error(f"Reddit scraping failed: {e}", exc_info=True)
                self.stats["errors"] += 1
                print(f"   ✗ Reddit scraping failed: {e}")

        # Google News scraping
        if "google" in self.sources:
            print("\n🔍 Searching Google News...")
            try:
                if self.specific_voter:
                    google_results = self.orchestrator.search_specific_voter(self.specific_voter)
                else:
                    google_results = self.orchestrator.run_comprehensive_search(
                        season=self.season,
                        sources=["google"]
                    )
                all_results.extend(google_results.get("google", []))
                self.stats["sources_scraped"] += 1
                print(f"   ✓ Found {len(google_results.get('google', []))} Google results")

                log_scraping_activity(
                    scraping_logger,
                    source="google",
                    url="multiple_queries",
                    status="success",
                    posts_found=len(google_results.get("google", []))
                )
            except Exception as e:
                scraping_logger.error(f"Google scraping failed: {e}", exc_info=True)
                self.stats["errors"] += 1
                print(f"   ✗ Google scraping failed: {e}")

        # News aggregator
        if "news" in self.sources:
            print("\n🔍 Aggregating news articles...")
            try:
                news_results = self.news_aggregator.get_recent_articles(days=7)
                # Convert news articles to standard format
                for article in news_results:
                    all_results.append({
                        "title": article.get("title", ""),
                        "url": article.get("url", ""),
                        "text": article.get("text", ""),
                        "source": article.get("source", "news"),
                        "published_date": article.get("published_date")
                    })
                self.stats["sources_scraped"] += 1
                self.stats["articles_found"] += len(news_results)
                print(f"   ✓ Found {len(news_results)} news articles")

                log_scraping_activity(
                    scraping_logger,
                    source="news",
                    url="multiple_sources",
                    status="success",
                    posts_found=len(news_results)
                )
            except Exception as e:
                scraping_logger.error(f"News aggregation failed: {e}", exc_info=True)
                self.stats["errors"] += 1
                print(f"   ✗ News aggregation failed: {e}")

        print(f"\n✓ Total sources gathered: {len(all_results)}")
        return all_results

    def _extract_and_save_votes(self, results: List[Dict[str, Any]]) -> None:
        """
        Extract votes from all results and save to database.

        Args:
            results: List of articles/posts to process
        """
        print("\n[Step 2/3] Extracting and saving votes...\n")

        for idx, result in enumerate(results, 1):
            try:
                text = result.get("text", "") or result.get("title", "")
                source_url = result.get("url", "")
                source_type = result.get("source", "speculation")

                if not text:
                    continue

                # Extract votes using NLP
                extracted_votes = self.vote_extractor.extract_votes_from_text(
                    text=text,
                    source_url=source_url,
                    source_type=source_type
                )

                if extracted_votes:
                    print(f"   [{idx}/{len(results)}] Found {len(extracted_votes)} votes in: {result.get('title', 'Untitled')[:60]}...")

                    log_extraction_activity(
                        nlp_logger,
                        text_length=len(text),
                        voters_found=len(set(v["voter_name"] for v in extracted_votes)),
                        votes_found=len(extracted_votes),
                        confidence="high" if any(v.get("confidence") == "high" for v in extracted_votes) else "medium",
                        source_url=source_url,
                        source_type=source_type
                    )
                else:
                    continue

                # Save each vote
                for vote in extracted_votes:
                    try:
                        saved = self._save_vote(vote)
                        if saved:
                            self.stats["votes_saved"] += 1
                        else:
                            self.stats["duplicates_skipped"] += 1
                    except Exception as e:
                        nlp_logger.error(f"Failed to save vote: {e}", exc_info=True)
                        self.stats["errors"] += 1

                self.stats["votes_extracted"] += len(extracted_votes)

            except Exception as e:
                nlp_logger.error(f"Failed to process result: {e}", exc_info=True)
                self.stats["errors"] += 1

        print(f"\n✓ Votes extracted: {self.stats['votes_extracted']}")
        print(f"✓ Votes saved: {self.stats['votes_saved']}")
        print(f"⊘ Duplicates skipped: {self.stats['duplicates_skipped']}")

    def _save_vote(self, vote_data: Dict[str, Any]) -> bool:
        """
        Save a vote to the database.

        Args:
            vote_data: Extracted vote information

        Returns:
            True if saved, False if duplicate
        """
        try:
            # Import models for queries
            from database.models import Voter, Candidate, Vote as VoteModel

            # Check if voter is new (before add_vote creates them)
            is_new_voter = self.db_session.query(Voter).filter_by(name=vote_data["voter_name"]).first() is None

            # Count votes before adding (to detect duplicates)
            voter_obj = self.db_session.query(Voter).filter_by(name=vote_data["voter_name"]).first()
            if voter_obj:
                # Count existing votes for this voter-candidate-season-ranking combo
                existing_count = self.db_session.query(VoteModel).filter_by(
                    voter_id=voter_obj.id,
                    season=self.season,
                    ranking=vote_data.get("ranking", 1)
                ).count()
            else:
                existing_count = 0

            # Add vote (this automatically creates voter and candidate if needed)
            # Note: VoteDB.add_vote() will update if duplicate exists
            vote = self.vote_db.add_vote(
                self.db_session,
                voter_name=vote_data["voter_name"],
                candidate_name=vote_data["candidate_name"],
                season=self.season,
                ranking=vote_data.get("ranking", 1),
                source_url=vote_data.get("source_url"),
                source_type=vote_data.get("source_type", "speculation"),
                confidence=vote_data.get("confidence", "medium"),
                confidence_score=vote_data.get("confidence_numeric", 50.0),
                verified=False,  # Requires manual verification
                extracted_text=vote_data.get("extracted_text")
            )

            # Refresh session to get accurate counts
            self.db_session.flush()

            # Check if this was a new vote or an update
            is_new_vote = existing_count == 0

            # Track if we discovered a new voter
            if is_new_voter:
                self.stats["voters_discovered"] += 1
                print(f"      → New voter discovered: {vote_data['voter_name']}")

                log_database_operation(
                    database_logger,
                    operation="INSERT",
                    table="voters",
                    affected_rows=1,
                    voter_name=vote_data["voter_name"]
                )

                # Send notification (non-blocking)
                try:
                    voter = self.db_session.query(Voter).filter_by(name=vote_data["voter_name"]).first()
                    if voter:
                        self.notification_service.notify_new_voter(voter.id)
                except Exception as e:
                    general_logger.warning(f"Failed to send new voter notification: {e}")

            if is_new_vote:
                print(f"      → Vote saved: {vote_data['voter_name']} → #{vote_data.get('ranking', 1)} {vote_data['candidate_name']}")

                log_database_operation(
                    database_logger,
                    operation="INSERT",
                    table="votes",
                    affected_rows=1,
                    voter_name=vote_data["voter_name"],
                    candidate_name=vote_data["candidate_name"],
                    ranking=vote_data.get("ranking", 1)
                )

                # Send notification (non-blocking)
                try:
                    self.notification_service.notify_new_vote(vote.id)
                except Exception as e:
                    general_logger.warning(f"Failed to send new vote notification: {e}")

            return is_new_vote

        except Exception as e:
            database_logger.error(f"Failed to save vote: {e}", exc_info=True)
            raise

    def _generate_report(self) -> None:
        """Generate and display final research report."""
        print("\n[Step 3/3] Generating report...\n")
        print("="*70)
        print("RESEARCH SESSION REPORT")
        print("="*70)

        duration = (datetime.now() - self.stats["start_time"]).total_seconds()

        print(f"\nSession Duration: {duration:.1f} seconds")
        print(f"\nSources:")
        print(f"  Sources scraped: {self.stats['sources_scraped']}")
        print(f"  Articles/posts found: {len(self.stats)}")

        print(f"\nExtraction:")
        print(f"  Voters discovered: {self.stats['voters_discovered']}")
        print(f"  Votes extracted: {self.stats['votes_extracted']}")
        print(f"  Votes saved to database: {self.stats['votes_saved']}")
        print(f"  Duplicates skipped: {self.stats['duplicates_skipped']}")

        print(f"\nErrors:")
        print(f"  Errors encountered: {self.stats['errors']}")

        # Query current database state
        from database.models import Voter, Vote as VoteModel
        all_voters = self.db_session.query(Voter).all()
        all_votes = self.db_session.query(VoteModel).filter_by(season=self.season).all()

        print(f"\nCurrent Database State:")
        print(f"  Total voters in database: {len(all_voters)}")
        print(f"  Total votes for {self.season}: {len(all_votes)}")
        print(f"  Voters with disclosed votes: {len([v for v in all_voters if v.votes])}")

        print("\n" + "="*70)

        # Display some discovered voters
        if self.stats['voters_discovered'] > 0:
            print("\nNewly Discovered Voters:")
            for voter in all_voters[-self.stats['voters_discovered']:]:
                vote_count = len(voter.votes)
                print(f"  • {voter.name} ({voter.outlet or 'Unknown outlet'}) - {vote_count} votes")

        print("\n")

    def _send_completion_notification(self) -> None:
        """Send completion notification with research results."""
        try:
            message = f"""Research session completed for {self.season} season:

Sources scraped: {self.stats['sources_scraped']}
Voters discovered: {self.stats['voters_discovered']}
Votes extracted: {self.stats['votes_extracted']}
Votes saved: {self.stats['votes_saved']}
Duplicates skipped: {self.stats['duplicates_skipped']}
Errors: {self.stats['errors']}

Duration: {(datetime.now() - self.stats['start_time']).total_seconds():.1f} seconds"""

            self.notification_service.notify(
                event_type=NotificationEventType.SCRAPING_COMPLETE,
                title=f"Research Session Complete - {self.season}",
                message=message,
                metadata=self.stats
            )
        except Exception as e:
            general_logger.error(f"Failed to send completion notification: {e}", exc_info=True)


def main():
    """Main entry point for research script."""
    parser = argparse.ArgumentParser(
        description="NFL MVP Voter Research Script - Discover voters and their publicly disclosed votes"
    )

    parser.add_argument(
        "--season",
        type=str,
        default="2024-25",
        help="NFL season (default: 2024-25)"
    )

    parser.add_argument(
        "--mode",
        type=str,
        choices=["full", "quick", "news_only"],
        default="full",
        help="Research mode (default: full)"
    )

    parser.add_argument(
        "--sources",
        type=str,
        help="Comma-separated list of sources (reddit,google,news)"
    )

    parser.add_argument(
        "--voter",
        type=str,
        help="Search for a specific voter (e.g., 'Mina Kimes')"
    )

    args = parser.parse_args()

    # Parse sources
    sources = None
    if args.sources:
        sources = [s.strip() for s in args.sources.split(",")]
    elif args.mode == "news_only":
        sources = ["news"]
    elif args.mode == "quick":
        sources = ["news", "google"]

    # Create and run research session
    try:
        session = ResearchSession(
            season=args.season,
            mode=args.mode,
            sources=sources,
            specific_voter=args.voter
        )

        stats = session.run()

        # Exit with appropriate code
        if stats["errors"] > 0:
            sys.exit(1)
        else:
            sys.exit(0)

    except KeyboardInterrupt:
        print("\n\nResearch session interrupted by user.")
        sys.exit(130)
    except Exception as e:
        print(f"\n\nFatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
