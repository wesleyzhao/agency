#!/usr/bin/env python3
"""
Test Script for Database Seeding

This script tests the database seeding functionality to ensure voters,
candidates, and votes are correctly added to the database.

Usage:
    python3 test_seed_database.py
"""

import sys
import os
from datetime import datetime

# Add backend directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.models import Voter, Candidate, Vote
from database.connection import get_session
from database.utils import VoterDB, CandidateDB, VoteDB

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

def print_test_header(title):
    """Print formatted test header"""
    print(f"\n{CYAN}{'='*60}")
    print(f"{title}")
    print(f"{'='*60}{RESET}\n")

def print_success(message):
    """Print success message"""
    print(f"{GREEN}✓ {message}{RESET}")

def print_error(message):
    """Print error message"""
    print(f"{RED}✗ {message}{RESET}")

def print_info(message):
    """Print info message"""
    print(f"{CYAN}ℹ {message}{RESET}")

def test_database_connection():
    """Test 1: Verify database connection"""
    print_test_header("Test 1: Database Connection")

    try:
        session = get_session()
        # Try a simple query
        voter_count = session.query(Voter).count()
        session.close()
        print_success(f"Database connection successful")
        print_info(f"Current voter count: {voter_count}")
        return True
    except Exception as e:
        print_error(f"Database connection failed: {str(e)}")
        return False

def test_seed_script_exists():
    """Test 2: Verify seed script exists"""
    print_test_header("Test 2: Seed Script Existence")

    seed_script = os.path.join(os.path.dirname(__file__), 'seed_database.py')
    if os.path.exists(seed_script):
        print_success(f"Seed script found: {seed_script}")

        # Check if it's executable
        if os.access(seed_script, os.X_OK):
            print_success("Seed script is executable")
        else:
            print_info("Seed script exists but is not marked as executable")

        return True
    else:
        print_error(f"Seed script not found: {seed_script}")
        return False

def test_seed_data_structure():
    """Test 3: Verify seed data structure is valid"""
    print_test_header("Test 3: Seed Data Structure Validation")

    try:
        # Import seed data
        from seed_database import CONFIRMED_VOTERS, MVP_CANDIDATES, CONFIRMED_VOTES

        # Test voters data
        print_info(f"Checking {len(CONFIRMED_VOTERS)} voters...")
        required_voter_fields = ['name', 'outlet']
        for i, voter in enumerate(CONFIRMED_VOTERS, 1):
            for field in required_voter_fields:
                if field not in voter:
                    print_error(f"Voter {i} missing required field: {field}")
                    return False
        print_success(f"All {len(CONFIRMED_VOTERS)} voters have required fields")

        # Test candidates data
        print_info(f"Checking {len(MVP_CANDIDATES)} candidates...")
        required_candidate_fields = ['name', 'team', 'position', 'season']
        for i, candidate in enumerate(MVP_CANDIDATES, 1):
            for field in required_candidate_fields:
                if field not in candidate:
                    print_error(f"Candidate {i} missing required field: {field}")
                    return False
        print_success(f"All {len(MVP_CANDIDATES)} candidates have required fields")

        # Test votes data
        print_info(f"Checking {len(CONFIRMED_VOTES)} votes...")
        required_vote_fields = ['voter_name', 'candidate_name', 'ranking', 'season']
        for i, vote in enumerate(CONFIRMED_VOTES, 1):
            for field in required_vote_fields:
                if field not in vote:
                    print_error(f"Vote {i} missing required field: {field}")
                    return False
        print_success(f"All {len(CONFIRMED_VOTES)} votes have required fields")

        return True

    except Exception as e:
        print_error(f"Failed to validate seed data structure: {str(e)}")
        return False

def test_run_seeding():
    """Test 4: Run database seeding"""
    print_test_header("Test 4: Database Seeding Execution")

    try:
        print_info("Running seed_database.py...")

        # Import and run seeding functions
        from seed_database import seed_voters, seed_candidates, seed_votes

        print_info("\n--- Seeding Voters ---")
        voters_added, voters_skipped = seed_voters()
        print_success(f"Voters: {voters_added} added, {voters_skipped} skipped")

        print_info("\n--- Seeding Candidates ---")
        candidates_added, candidates_skipped = seed_candidates()
        print_success(f"Candidates: {candidates_added} added, {candidates_skipped} skipped")

        print_info("\n--- Seeding Votes ---")
        votes_added, votes_skipped = seed_votes()
        print_success(f"Votes: {votes_added} added, {votes_skipped} skipped")

        if voters_added > 0 or candidates_added > 0 or votes_added > 0:
            print_success("\nSeeding completed with additions")
            return True
        elif voters_skipped > 0 or candidates_skipped > 0 or votes_skipped > 0:
            print_success("\nSeeding completed (all data already exists)")
            return True
        else:
            print_error("\nNo data was added or skipped")
            return False

    except Exception as e:
        print_error(f"Seeding execution failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_verify_seeded_data():
    """Test 5: Verify seeded data in database"""
    print_test_header("Test 5: Verify Seeded Data")

    try:
        session = get_session()

        # Check voters
        voter_count = session.query(Voter).count()
        print_info(f"Total voters in database: {voter_count}")
        if voter_count >= 5:
            print_success(f"Voters seeded successfully ({voter_count} voters)")
        else:
            print_error(f"Expected at least 5 voters, found {voter_count}")
            return False

        # Check specific voters
        test_voters = ["Tom Brady", "Mina Kimes", "Peter King"]
        for voter_name in test_voters:
            voter = session.query(Voter).filter(Voter.name == voter_name).first()
            if voter:
                print_success(f"Found voter: {voter_name} ({voter.outlet})")
            else:
                print_error(f"Voter not found: {voter_name}")

        # Check candidates
        candidate_count = session.query(Candidate).count()
        print_info(f"\nTotal candidates in database: {candidate_count}")
        if candidate_count >= 10:
            print_success(f"Candidates seeded successfully ({candidate_count} candidates)")
        else:
            print_error(f"Expected at least 10 candidates, found {candidate_count}")
            return False

        # Check specific candidates
        test_candidates = ["Josh Allen", "Lamar Jackson", "Saquon Barkley"]
        for candidate_name in test_candidates:
            candidate = session.query(Candidate).filter(
                Candidate.name == candidate_name,
                Candidate.season == "2024-25"
            ).first()
            if candidate:
                print_success(f"Found candidate: {candidate_name} ({candidate.team} - {candidate.position})")
            else:
                print_error(f"Candidate not found: {candidate_name}")

        # Check votes
        vote_count = session.query(Vote).count()
        print_info(f"\nTotal votes in database: {vote_count}")
        if vote_count > 0:
            print_success(f"Votes seeded successfully ({vote_count} votes)")

            # Get a sample vote
            sample_vote = session.query(Vote).first()
            if sample_vote:
                voter = session.query(Voter).filter(Voter.id == sample_vote.voter_id).first()
                candidate = session.query(Candidate).filter(Candidate.id == sample_vote.candidate_id).first()
                print_info(f"Sample vote: {voter.name} → {candidate.name} (#{sample_vote.ranking})")
                print_info(f"  Source: {sample_vote.source_type}")
                print_info(f"  Confidence: {sample_vote.confidence}")
                print_info(f"  Verified: {sample_vote.verified}")
        else:
            print_info("No votes seeded yet (this is expected if CONFIRMED_VOTES is empty)")

        session.close()
        return True

    except Exception as e:
        print_error(f"Failed to verify seeded data: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_database_integrity():
    """Test 6: Verify database integrity and relationships"""
    print_test_header("Test 6: Database Integrity")

    try:
        session = get_session()

        # Check for duplicate voters
        voter_names = session.query(Voter.name).all()
        voter_name_list = [v[0] for v in voter_names]
        if len(voter_name_list) == len(set(voter_name_list)):
            print_success("No duplicate voter names found")
        else:
            print_error("Duplicate voter names detected!")
            return False

        # Check for duplicate candidates (name + season)
        candidates = session.query(Candidate.name, Candidate.season).all()
        candidate_tuples = [(c[0], c[1]) for c in candidates]
        if len(candidate_tuples) == len(set(candidate_tuples)):
            print_success("No duplicate candidates found (name + season)")
        else:
            print_error("Duplicate candidates detected!")
            return False

        # Check vote relationships
        votes = session.query(Vote).all()
        for vote in votes:
            # Verify voter exists
            voter = session.query(Voter).filter(Voter.id == vote.voter_id).first()
            if not voter:
                print_error(f"Vote {vote.id} has invalid voter_id: {vote.voter_id}")
                return False

            # Verify candidate exists
            candidate = session.query(Candidate).filter(Candidate.id == vote.candidate_id).first()
            if not candidate:
                print_error(f"Vote {vote.id} has invalid candidate_id: {vote.candidate_id}")
                return False

        print_success(f"All {len(votes)} votes have valid relationships")

        # Check ranking validity (1-5)
        invalid_rankings = session.query(Vote).filter(
            (Vote.ranking < 1) | (Vote.ranking > 5)
        ).count()
        if invalid_rankings == 0:
            print_success("All vote rankings are valid (1-5)")
        else:
            print_error(f"Found {invalid_rankings} votes with invalid rankings!")
            return False

        session.close()
        return True

    except Exception as e:
        print_error(f"Integrity check failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_idempotency():
    """Test 7: Verify seeding is idempotent (can run multiple times)"""
    print_test_header("Test 7: Idempotency Test")

    try:
        session = get_session()

        # Get counts before second seeding
        voters_before = session.query(Voter).count()
        candidates_before = session.query(Candidate).count()
        votes_before = session.query(Vote).count()
        session.close()

        print_info(f"Before re-seeding:")
        print_info(f"  Voters: {voters_before}")
        print_info(f"  Candidates: {candidates_before}")
        print_info(f"  Votes: {votes_before}")

        # Run seeding again
        from seed_database import seed_voters, seed_candidates, seed_votes

        print_info("\nRunning seeding again...")
        voters_added, voters_skipped = seed_voters()
        candidates_added, candidates_skipped = seed_candidates()
        votes_added, votes_skipped = seed_votes()

        # Get counts after second seeding
        session = get_session()
        voters_after = session.query(Voter).count()
        candidates_after = session.query(Candidate).count()
        votes_after = session.query(Vote).count()
        session.close()

        print_info(f"\nAfter re-seeding:")
        print_info(f"  Voters: {voters_after}")
        print_info(f"  Candidates: {candidates_after}")
        print_info(f"  Votes: {votes_after}")

        # Verify counts are the same (idempotent)
        if voters_before == voters_after and candidates_before == candidates_after and votes_before == votes_after:
            print_success("Seeding is idempotent (no duplicates created)")
            print_info(f"  Skipped: {voters_skipped} voters, {candidates_skipped} candidates, {votes_skipped} votes")
            return True
        else:
            print_error("Seeding created duplicates!")
            return False

    except Exception as e:
        print_error(f"Idempotency test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def print_final_summary():
    """Print final database summary"""
    print_test_header("Final Database Summary")

    try:
        session = get_session()

        voter_count = session.query(Voter).count()
        candidate_count = session.query(Candidate).count()
        vote_count = session.query(Vote).count()
        verified_count = session.query(Vote).filter(Vote.verified == True).count()

        voters_with_votes = session.query(Voter).join(Vote).distinct().count()
        candidates_with_votes = session.query(Candidate).join(Vote).distinct().count()

        print_info(f"Total Voters: {voter_count}")
        print_info(f"Total Candidates: {candidate_count}")
        print_info(f"Total Votes: {vote_count}")
        print_info(f"Verified Votes: {verified_count}")
        print_info(f"Voters with Disclosed Votes: {voters_with_votes}")
        print_info(f"Candidates with Votes: {candidates_with_votes}")

        # Sample voters
        print_info("\nSample Voters:")
        sample_voters = session.query(Voter).limit(5).all()
        for voter in sample_voters:
            vote_count_for_voter = session.query(Vote).filter(Vote.voter_id == voter.id).count()
            print_info(f"  - {voter.name} ({voter.outlet}) - {vote_count_for_voter} votes")

        session.close()

    except Exception as e:
        print_error(f"Failed to generate summary: {str(e)}")

def main():
    """Run all tests"""
    print_info("\n" + "="*60)
    print_info("NFL MVP VOTER TRACKER - DATABASE SEEDING TESTS")
    print_info("="*60)

    tests = [
        ("Database Connection", test_database_connection),
        ("Seed Script Exists", test_seed_script_exists),
        ("Seed Data Structure", test_seed_data_structure),
        ("Database Seeding", test_run_seeding),
        ("Verify Seeded Data", test_verify_seeded_data),
        ("Database Integrity", test_database_integrity),
        ("Idempotency", test_idempotency)
    ]

    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print_error(f"Test {test_name} crashed: {str(e)}")
            results.append((test_name, False))

    # Print summary
    print_test_header("Test Summary")

    passed = sum(1 for _, result in results if result)
    failed = len(results) - passed

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print_info(f"\nTotal: {passed} passed, {failed} failed out of {len(results)} tests")

    # Print final database summary
    print_final_summary()

    if failed == 0:
        print_success("\n✓ All tests PASSED!")
        print_info("\nThe database has been seeded successfully.")
        print_info("You can now:")
        print_info("  1. Start the backend: cd backend && python3 app.py")
        print_info("  2. Start the frontend: cd frontend && npm start")
        print_info("  3. View the dashboard at http://localhost:3000")
        return 0
    else:
        print_error(f"\n✗ {failed} test(s) FAILED")
        return 1

if __name__ == "__main__":
    sys.exit(main())
