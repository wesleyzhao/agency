#!/usr/bin/env python3
"""
Test script for Statistics API endpoint - Feature #13
Tests comprehensive summary statistics including candidate breakdown,
source distribution, confidence levels, and timeline data.
"""
import requests
import json
import sys

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033[0m'

BASE_URL = 'http://localhost:5000'


def print_success(message):
    print(f"{GREEN}✓ {message}{RESET}")


def print_error(message):
    print(f"{RED}✗ {message}{RESET}")


def print_info(message):
    print(f"{YELLOW}{message}{RESET}")


def print_data(message):
    print(f"{CYAN}{message}{RESET}")


def test_health_check():
    """Test that backend server is running"""
    try:
        response = requests.get(f'{BASE_URL}/api/health')
        if response.status_code == 200:
            print_success("Backend server is running")
            return True
        else:
            print_error(f"Backend returned status code: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print_error("Could not connect to backend server")
        print_info("Make sure the backend is running: cd backend && python3 app.py")
        return False


def test_statistics_endpoint():
    """Test the /api/statistics endpoint"""
    print_info("\n============================================================")
    print_info("Testing Statistics API Endpoint - Feature #13")
    print_info("============================================================\n")

    # Test health check first
    if not test_health_check():
        return False

    try:
        # Get statistics
        response = requests.get(f'{BASE_URL}/api/statistics?season=2024-25')

        if response.status_code != 200:
            print_error(f"Statistics endpoint returned status code: {response.status_code}")
            print_error(f"Response: {response.text}")
            return False

        print_success("Statistics endpoint returned 200 OK")

        data = response.json()

        # Validate response structure
        required_fields = [
            'season',
            'overview',
            'candidate_breakdown',
            'top_candidates',
            'source_distribution',
            'confidence_distribution',
            'disclosure_breakdown',
            'timeline',
            'recent_activity'
        ]

        for field in required_fields:
            if field in data:
                print_success(f"Response contains '{field}' field")
            else:
                print_error(f"Response missing '{field}' field")
                return False

        # Display overview statistics
        print_info("\n=== Overview Statistics ===")
        overview = data['overview']
        print_data(f"  Season: {data['season']}")
        print_data(f"  Total Voters: {overview['total_voters']}")
        print_data(f"  Known Voters: {overview['known_voters']}")
        print_data(f"  Voters with Disclosed Votes: {overview['voters_with_disclosed_votes']}")
        print_data(f"  Total Votes Disclosed: {overview['total_votes_disclosed']}")
        print_data(f"  First Place Votes Disclosed: {overview['first_place_votes_disclosed']}")
        print_data(f"  Verified Votes: {overview['verified_votes']}")
        print_data(f"  Completion: {overview['completion_percentage']}%")

        # Display candidate breakdown
        print_info("\n=== Candidate Breakdown (Top 5) ===")
        if data['candidate_breakdown']:
            for i, candidate in enumerate(data['top_candidates'], 1):
                print_data(f"  {i}. {candidate['name']} ({candidate['team']})")
                print_data(f"     Position: {candidate['position']}")
                print_data(f"     1st Place Votes: {candidate['first_place_votes']}")
                print_data(f"     2nd Place: {candidate['second_place_votes']}, 3rd: {candidate['third_place_votes']}")
                print_data(f"     Total Mentions: {candidate['total_mentions']}")
                print_data(f"     Weighted Points: {candidate['weighted_points']}")
                print()
        else:
            print_data("  No candidates found")

        # Display source distribution
        print_info("=== Source Type Distribution ===")
        if data['source_distribution']:
            for source_type, count in data['source_distribution'].items():
                print_data(f"  {source_type}: {count}")
        else:
            print_data("  No source data available")

        # Display confidence distribution
        print_info("\n=== Confidence Level Distribution ===")
        conf_dist = data['confidence_distribution']
        print_data(f"  High: {conf_dist['high']}")
        print_data(f"  Medium: {conf_dist['medium']}")
        print_data(f"  Low: {conf_dist['low']}")
        print_data(f"  Unknown: {conf_dist['unknown']}")

        # Display disclosure breakdown
        print_info("\n=== Voter Disclosure Status ===")
        disclosure = data['disclosure_breakdown']
        print_data(f"  Full Ballot (5 votes): {disclosure['full_ballot']}")
        print_data(f"  Partial Ballot (1-4 votes): {disclosure['partial_ballot']}")
        print_data(f"  First Place Only: {disclosure['first_place_only']}")
        print_data(f"  No Disclosure: {disclosure['no_disclosure']}")

        # Display timeline
        print_info("\n=== Vote Announcement Timeline ===")
        if data['timeline']:
            print_data(f"  Total dates with announcements: {len(data['timeline'])}")
            for entry in data['timeline'][-5:]:  # Show last 5 dates
                print_data(f"  {entry['date']}: {entry['count']} vote(s)")
        else:
            print_data("  No timeline data available")

        # Display recent activity
        print_info("\n=== Recent Activity (Last 5) ===")
        if data['recent_activity']:
            for activity in data['recent_activity'][:5]:
                voter = activity['voter_name']
                candidate = activity['candidate_name']
                ranking = activity['ranking']
                verified = '✓' if activity['verified'] else '✗'
                confidence = activity['confidence']
                print_data(f"  {voter} → #{ranking} {candidate} [{confidence}, verified: {verified}]")
        else:
            print_data("  No recent activity")

        print_success("\n✓ All statistics fields validated successfully!")
        return True

    except Exception as e:
        print_error(f"Error testing statistics endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_season_filtering():
    """Test that season filtering works"""
    print_info("\n=== Testing Season Filtering ===")

    try:
        # Test with different season
        response = requests.get(f'{BASE_URL}/api/statistics?season=2023-24')

        if response.status_code == 200:
            data = response.json()
            if data['season'] == '2023-24':
                print_success("Season filtering works correctly")
                return True
            else:
                print_error(f"Expected season 2023-24, got {data['season']}")
                return False
        else:
            print_error(f"Season filtering request failed: {response.status_code}")
            return False

    except Exception as e:
        print_error(f"Error testing season filtering: {str(e)}")
        return False


def main():
    """Run all tests"""
    print_info("\n" + "="*60)
    print_info("NFL MVP Voter Tracker - Statistics API Tests")
    print_info("Feature #13: Summary Statistics Page")
    print_info("="*60)

    all_passed = True

    # Test statistics endpoint
    if not test_statistics_endpoint():
        all_passed = False

    # Test season filtering
    if not test_season_filtering():
        all_passed = False

    # Summary
    print_info("\n" + "="*60)
    if all_passed:
        print_success("All tests PASSED! ✓")
        print_info("\nNext steps:")
        print_info("1. Start the frontend: cd frontend && npm start")
        print_info("2. Navigate to http://localhost:3000/statistics")
        print_info("3. View comprehensive summary statistics")
    else:
        print_error("Some tests FAILED! ✗")
        print_info("\nTroubleshooting:")
        print_info("1. Ensure backend is running: cd backend && python3 app.py")
        print_info("2. Check database exists: ls data/mvp_tracker.db")
        print_info("3. Verify some data exists in database")
        sys.exit(1)

    print_info("="*60 + "\n")


if __name__ == '__main__':
    main()
