"""
Automated web crawler for periodically searching for NFL MVP voter information

This module provides scheduled scraping capabilities to automatically discover
new voter announcements and update the database.
"""
import logging
import os
import sys
from typing import Optional, Dict, List
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from scrapers.scraper_orchestrator import ScraperOrchestrator
from database.connection import session_scope
from database.utils import SourceDB, ScrapingLogDB
from database.models import SourceType, ConfidenceLevel


class AutomatedCrawler:
    """
    Automated crawler that periodically searches for NFL MVP voter information
    and stores results in the database
    """

    def __init__(
        self,
        season: str = "2024-25",
        scrape_interval_hours: int = 6,
        enable_google: bool = True,
        enable_reddit: bool = True,
        enable_news: bool = True,
        output_dir: str = './data/scraping_results'
    ):
        """
        Initialize automated crawler

        Args:
            season: NFL season to track (e.g., "2024-25")
            scrape_interval_hours: Hours between scraping runs
            enable_google: Enable Google search scraping
            enable_reddit: Enable Reddit scraping
            enable_news: Enable news site scraping
            output_dir: Directory for saving raw scraping results
        """
        self.season = season
        self.scrape_interval_hours = scrape_interval_hours
        self.enable_google = enable_google
        self.enable_reddit = enable_reddit
        self.enable_news = enable_news
        self.output_dir = output_dir

        # Setup logging
        self.logger = logging.getLogger(__name__)
        self._setup_logging()

        # Initialize scraper orchestrator
        self.orchestrator = ScraperOrchestrator(output_dir=output_dir)

        # Initialize scheduler
        self.scheduler = BackgroundScheduler()
        self.is_running = False

        # Statistics
        self.stats = {
            'total_runs': 0,
            'successful_runs': 0,
            'failed_runs': 0,
            'last_run': None,
            'next_run': None,
            'total_urls_found': 0,
            'new_sources_added': 0
        }

        self.logger.info(f"Automated crawler initialized for {season} season")
        self.logger.info(f"Scrape interval: {scrape_interval_hours} hours")
        self.logger.info(f"Sources enabled - Google: {enable_google}, "
                        f"Reddit: {enable_reddit}, News: {enable_news}")

    def _setup_logging(self):
        """Setup comprehensive logging for crawler"""
        log_dir = './data/logs'
        os.makedirs(log_dir, exist_ok=True)

        # Create file handler for crawler logs
        log_file = os.path.join(log_dir, 'automated_crawler.log')
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)

        # Create console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers to logger
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        self.logger.setLevel(logging.INFO)

    def run_scraping_cycle(self):
        """
        Execute one complete scraping cycle across all enabled sources
        and store results in the database
        """
        self.logger.info("=" * 80)
        self.logger.info(f"Starting automated scraping cycle at {datetime.utcnow().isoformat()}")
        self.logger.info("=" * 80)

        self.stats['total_runs'] += 1
        self.stats['last_run'] = datetime.utcnow()

        scraping_log_id = None

        try:
            # Create scraping log entry
            with session_scope() as session:
                log = ScrapingLogDB.create_log(
                    session,
                    source='automated_crawler',
                    search_query=f'Comprehensive search for {self.season} MVP voters'
                )
                scraping_log_id = log.id

            # Run comprehensive search
            results = self.orchestrator.run_comprehensive_search(
                season=self.season,
                include_google=self.enable_google,
                include_reddit=self.enable_reddit,
                include_news=self.enable_news
            )

            # Process and store results
            urls_found, new_sources = self._process_and_store_results(results)

            # Update statistics
            self.stats['successful_runs'] += 1
            self.stats['total_urls_found'] += urls_found
            self.stats['new_sources_added'] += new_sources

            # Update scraping log
            with session_scope() as session:
                ScrapingLogDB.update_log(
                    session,
                    log_id=scraping_log_id,
                    urls_found=urls_found,
                    votes_extracted=0  # Will be updated by NLP extraction in future
                )

            self.logger.info(f"✓ Scraping cycle completed successfully")
            self.logger.info(f"  - URLs found: {urls_found}")
            self.logger.info(f"  - New sources added to DB: {new_sources}")

        except Exception as e:
            self.stats['failed_runs'] += 1
            self.logger.error(f"✗ Scraping cycle failed: {e}", exc_info=True)

            # Update scraping log with error
            if scraping_log_id:
                with session_scope() as session:
                    ScrapingLogDB.update_log(
                        session,
                        log_id=scraping_log_id,
                        errors=str(e)
                    )

        finally:
            self.logger.info("=" * 80)
            self._print_stats()

    def _process_and_store_results(self, results: Dict) -> tuple:
        """
        Process scraping results and store new sources in database

        Args:
            results: Dictionary with scraping results from orchestrator

        Returns:
            Tuple of (total_urls_found, new_sources_added)
        """
        total_urls = 0
        new_sources = 0

        with session_scope() as session:
            # Process Google results
            for result in results.get('google', []):
                url = result.get('url')
                title = result.get('title', '')

                if url and not SourceDB.is_url_processed(session, url):
                    SourceDB.add_source(
                        session,
                        url=url,
                        title=title,
                        content_hash=result.get('content_hash')
                    )
                    new_sources += 1
                total_urls += 1

            # Process Reddit results
            for result in results.get('reddit', []):
                url = result.get('url')
                title = result.get('title', '')

                if url and not SourceDB.is_url_processed(session, url):
                    SourceDB.add_source(
                        session,
                        url=url,
                        title=title,
                        content_hash=result.get('content_hash')
                    )
                    new_sources += 1
                total_urls += 1

            # Process news results
            for result in results.get('news', []):
                url = result.get('url')
                title = result.get('title', '')

                if url and not SourceDB.is_url_processed(session, url):
                    SourceDB.add_source(
                        session,
                        url=url,
                        title=title,
                        content_hash=result.get('content_hash')
                    )
                    new_sources += 1
                total_urls += 1

        self.logger.info(f"Processed {total_urls} URLs, added {new_sources} new sources to database")

        return total_urls, new_sources

    def start(self, run_immediately: bool = False):
        """
        Start the automated crawler

        Args:
            run_immediately: If True, run one scraping cycle immediately before starting scheduler
        """
        if self.is_running:
            self.logger.warning("Crawler is already running")
            return

        self.logger.info("Starting automated crawler...")

        # Run immediately if requested
        if run_immediately:
            self.logger.info("Running initial scraping cycle...")
            self.run_scraping_cycle()

        # Schedule periodic scraping
        self.scheduler.add_job(
            func=self.run_scraping_cycle,
            trigger=IntervalTrigger(hours=self.scrape_interval_hours),
            id='scraping_cycle',
            name=f'NFL MVP Scraping Cycle ({self.scrape_interval_hours}h interval)',
            replace_existing=True
        )

        # Start scheduler
        self.scheduler.start()
        self.is_running = True

        # Calculate next run time
        next_run = datetime.utcnow() + timedelta(hours=self.scrape_interval_hours)
        self.stats['next_run'] = next_run

        self.logger.info(f"✓ Automated crawler started successfully")
        self.logger.info(f"  - Next scheduled run: {next_run.isoformat()}")

    def stop(self):
        """Stop the automated crawler"""
        if not self.is_running:
            self.logger.warning("Crawler is not running")
            return

        self.logger.info("Stopping automated crawler...")
        self.scheduler.shutdown()
        self.is_running = False
        self.logger.info("✓ Automated crawler stopped")

    def schedule_daily_at(self, hour: int = 6, minute: int = 0):
        """
        Schedule scraping to run daily at a specific time

        Args:
            hour: Hour of day (0-23)
            minute: Minute of hour (0-59)
        """
        if self.is_running:
            self.logger.warning("Removing existing hourly schedule...")
            self.scheduler.remove_job('scraping_cycle')

        self.scheduler.add_job(
            func=self.run_scraping_cycle,
            trigger=CronTrigger(hour=hour, minute=minute),
            id='scraping_cycle',
            name=f'NFL MVP Daily Scraping ({hour:02d}:{minute:02d} UTC)',
            replace_existing=True
        )

        if not self.is_running:
            self.scheduler.start()
            self.is_running = True

        self.logger.info(f"✓ Scheduled daily scraping at {hour:02d}:{minute:02d} UTC")

    def run_now(self):
        """Manually trigger a scraping cycle immediately"""
        self.logger.info("Manual scraping cycle triggered")
        self.run_scraping_cycle()

    def get_stats(self) -> Dict:
        """
        Get crawler statistics

        Returns:
            Dictionary with crawler statistics
        """
        return {
            **self.stats,
            'is_running': self.is_running,
            'season': self.season,
            'scrape_interval_hours': self.scrape_interval_hours,
            'sources_enabled': {
                'google': self.enable_google,
                'reddit': self.enable_reddit,
                'news': self.enable_news
            }
        }

    def _print_stats(self):
        """Print current statistics"""
        stats = self.get_stats()
        self.logger.info("\nCrawler Statistics:")
        self.logger.info(f"  Total runs: {stats['total_runs']}")
        self.logger.info(f"  Successful: {stats['successful_runs']}")
        self.logger.info(f"  Failed: {stats['failed_runs']}")
        self.logger.info(f"  Total URLs found: {stats['total_urls_found']}")
        self.logger.info(f"  New sources added: {stats['new_sources_added']}")
        if stats['last_run']:
            self.logger.info(f"  Last run: {stats['last_run'].isoformat()}")
        if stats['next_run']:
            self.logger.info(f"  Next run: {stats['next_run'].isoformat()}")


def main():
    """Main function for testing the automated crawler"""
    # Setup basic logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Create crawler with 6-hour interval
    crawler = AutomatedCrawler(
        season="2024-25",
        scrape_interval_hours=6,
        enable_google=True,
        enable_reddit=True,
        enable_news=True
    )

    # Run immediately and start scheduler
    crawler.start(run_immediately=True)

    # Keep running
    try:
        import time
        while True:
            time.sleep(60)  # Sleep for 1 minute
    except KeyboardInterrupt:
        print("\nShutting down crawler...")
        crawler.stop()


if __name__ == '__main__':
    main()
