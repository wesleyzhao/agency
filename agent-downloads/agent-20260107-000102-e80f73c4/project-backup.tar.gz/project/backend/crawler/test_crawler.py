"""
Test script for automated crawler functionality
"""
import sys
import os
import logging
import time
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from crawler.automated_crawler import AutomatedCrawler
from database.connection import init_db, session_scope
from database.utils import ScrapingLogDB, SourceDB


def setup_test_environment():
    """Setup test environment"""
    print("=" * 80)
    print("NFL MVP Voter Tracker - Automated Crawler Test")
    print("=" * 80)

    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Initialize database
    print("\n[1/6] Initializing database...")
    try:
        init_db()
        print("✓ Database initialized")
    except Exception as e:
        print(f"✓ Database already exists: {e}")


def test_crawler_creation():
    """Test crawler creation"""
    print("\n[2/6] Testing crawler creation...")

    try:
        crawler = AutomatedCrawler(
            season="2024-25",
            scrape_interval_hours=1,  # Short interval for testing
            enable_google=True,
            enable_reddit=True,
            enable_news=False  # Disable news for faster testing
        )
        print("✓ Crawler created successfully")
        return crawler
    except Exception as e:
        print(f"✗ Failed to create crawler: {e}")
        raise


def test_scraping_cycle(crawler):
    """Test a single scraping cycle"""
    print("\n[3/6] Testing scraping cycle...")

    try:
        # Get initial source count
        with session_scope() as session:
            initial_count = len(session.query(
                __import__('database.models', fromlist=['Source']).Source
            ).all())

        print(f"Initial sources in database: {initial_count}")

        # Run scraping cycle
        print("Running scraping cycle (this may take a few minutes)...")
        crawler.run_scraping_cycle()

        # Get new source count
        with session_scope() as session:
            new_count = len(session.query(
                __import__('database.models', fromlist=['Source']).Source
            ).all())

        print(f"Sources after scraping: {new_count}")
        print(f"New sources added: {new_count - initial_count}")
        print("✓ Scraping cycle completed")

        return True
    except Exception as e:
        print(f"✗ Scraping cycle failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_database_integration():
    """Test database integration"""
    print("\n[4/6] Testing database integration...")

    try:
        with session_scope() as session:
            # Check scraping logs
            logs = ScrapingLogDB.get_recent_logs(session, limit=5)
            print(f"✓ Found {len(logs)} recent scraping logs")

            if logs:
                latest = logs[0]
                print(f"  Latest log: {latest.source} - {latest.urls_found} URLs found")

            # Check sources
            from database.models import Source
            sources = session.query(Source).limit(5).all()
            print(f"✓ Found {len(sources)} sources in database")

            if sources:
                print("  Sample sources:")
                for src in sources[:3]:
                    print(f"    - {src.url[:60]}...")

        return True
    except Exception as e:
        print(f"✗ Database integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_crawler_stats(crawler):
    """Test crawler statistics"""
    print("\n[5/6] Testing crawler statistics...")

    try:
        stats = crawler.get_stats()

        print("Crawler Statistics:")
        print(f"  Total runs: {stats['total_runs']}")
        print(f"  Successful runs: {stats['successful_runs']}")
        print(f"  Failed runs: {stats['failed_runs']}")
        print(f"  Total URLs found: {stats['total_urls_found']}")
        print(f"  New sources added: {stats['new_sources_added']}")
        print(f"  Is running: {stats['is_running']}")
        print(f"  Season: {stats['season']}")

        print("✓ Statistics retrieved successfully")
        return True
    except Exception as e:
        print(f"✗ Statistics test failed: {e}")
        return False


def test_scheduler(crawler):
    """Test scheduler functionality (brief test)"""
    print("\n[6/6] Testing scheduler...")

    try:
        print("Starting crawler with scheduler...")
        crawler.start(run_immediately=False)

        print("✓ Scheduler started")
        print(f"  Next run scheduled for: {crawler.stats.get('next_run', 'Unknown')}")

        # Let it run for a few seconds
        print("Waiting 5 seconds...")
        time.sleep(5)

        # Stop the crawler
        print("Stopping crawler...")
        crawler.stop()
        print("✓ Crawler stopped successfully")

        return True
    except Exception as e:
        print(f"✗ Scheduler test failed: {e}")
        try:
            crawler.stop()
        except:
            pass
        return False


def print_summary(results):
    """Print test summary"""
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)

    total = len(results)
    passed = sum(1 for r in results if r)
    failed = total - passed

    print(f"Total tests: {total}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")

    if failed == 0:
        print("\n✓ All tests passed!")
    else:
        print(f"\n✗ {failed} test(s) failed")

    print("=" * 80)


def main():
    """Main test function"""
    results = []
    crawler = None

    try:
        # Setup
        setup_test_environment()

        # Test 1: Crawler creation
        crawler = test_crawler_creation()
        results.append(crawler is not None)

        if crawler is None:
            print("\nCannot continue tests without crawler")
            return

        # Test 2: Scraping cycle
        results.append(test_scraping_cycle(crawler))

        # Test 3: Database integration
        results.append(test_database_integration())

        # Test 4: Statistics
        results.append(test_crawler_stats(crawler))

        # Test 5: Scheduler
        results.append(test_scheduler(crawler))

    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
        if crawler and crawler.is_running:
            crawler.stop()
    except Exception as e:
        print(f"\n\nUnexpected error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Print summary
        print_summary(results)


if __name__ == '__main__':
    main()
