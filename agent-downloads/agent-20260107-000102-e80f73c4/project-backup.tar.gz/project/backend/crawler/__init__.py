"""
Automated crawler module for NFL MVP Voter Tracker
"""
from .automated_crawler import AutomatedCrawler

__all__ = ['AutomatedCrawler']
