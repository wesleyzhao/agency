# Automated Crawler for NFL MVP Voter Tracker

## Overview

The automated crawler module provides scheduled scraping capabilities to automatically discover new NFL MVP voter announcements and update the database. It integrates with the web scraping modules and database to provide a complete end-to-end solution.

## Features

- **Scheduled Scraping**: Automatically run scraping cycles at configurable intervals
- **Multiple Scheduling Options**:
  - Interval-based (e.g., every 6 hours)
  - Daily at specific time (e.g., 6:00 AM UTC)
- **Database Integration**: Automatically stores discovered sources in the database
- **Deduplication**: Tracks processed URLs to avoid duplicate work
- **Comprehensive Logging**: Detailed logs of all crawler activities
- **Statistics Tracking**: Monitor crawler performance and results
- **Manual Triggers**: Ability to manually trigger scraping cycles
- **Configurable Sources**: Enable/disable Google, Reddit, and news scraping independently

## Installation

The automated crawler requires the `APScheduler` library:

```bash
pip install apscheduler
```

All other dependencies are inherited from the scraper modules.

## Basic Usage

### Simple Example

```python
from crawler import AutomatedCrawler

# Create crawler with 6-hour interval
crawler = AutomatedCrawler(
    season="2024-25",
    scrape_interval_hours=6,
    enable_google=True,
    enable_reddit=True,
    enable_news=True
)

# Start crawler (run immediately and then on schedule)
crawler.start(run_immediately=True)

# Let it run...
# The crawler will now run every 6 hours automatically
```

### Advanced Usage

```python
from crawler import AutomatedCrawler

# Create crawler with custom configuration
crawler = AutomatedCrawler(
    season="2024-25",
    scrape_interval_hours=12,  # Run every 12 hours
    enable_google=True,
    enable_reddit=True,
    enable_news=False,  # Disable news scraping
    output_dir='./custom_data_dir'
)

# Start without running immediately
crawler.start(run_immediately=False)

# Manually trigger a scraping cycle
crawler.run_now()

# Get statistics
stats = crawler.get_stats()
print(f"Total runs: {stats['total_runs']}")
print(f"New sources found: {stats['new_sources_added']}")

# Stop the crawler
crawler.stop()
```

### Daily Scheduling

```python
from crawler import AutomatedCrawler

crawler = AutomatedCrawler(season="2024-25")

# Schedule to run daily at 6:00 AM UTC
crawler.schedule_daily_at(hour=6, minute=0)

# Or at 2:30 PM UTC
crawler.schedule_daily_at(hour=14, minute=30)
```

## Configuration Options

### Constructor Parameters

- **season** (str): NFL season to track (default: "2024-25")
- **scrape_interval_hours** (int): Hours between scraping runs (default: 6)
- **enable_google** (bool): Enable Google search scraping (default: True)
- **enable_reddit** (bool): Enable Reddit scraping (default: True)
- **enable_news** (bool): Enable news site scraping (default: True)
- **output_dir** (str): Directory for saving raw results (default: './data/scraping_results')

## Methods

### start(run_immediately=False)
Start the automated crawler with scheduled scraping cycles.

**Parameters:**
- `run_immediately` (bool): If True, run one scraping cycle before starting scheduler

### stop()
Stop the automated crawler and shut down the scheduler.

### run_now()
Manually trigger a scraping cycle immediately (can be called even while scheduler is running).

### schedule_daily_at(hour, minute)
Schedule scraping to run daily at a specific time (UTC).

**Parameters:**
- `hour` (int): Hour of day (0-23)
- `minute` (int): Minute of hour (0-59)

### get_stats()
Get current crawler statistics.

**Returns:**
Dictionary with statistics including:
- `total_runs`: Total number of scraping cycles run
- `successful_runs`: Number of successful cycles
- `failed_runs`: Number of failed cycles
- `last_run`: Timestamp of last run
- `next_run`: Timestamp of next scheduled run
- `total_urls_found`: Total URLs discovered
- `new_sources_added`: New sources added to database
- `is_running`: Whether crawler is currently active
- `sources_enabled`: Which data sources are enabled

## How It Works

1. **Scheduling**: Uses APScheduler to schedule periodic scraping tasks
2. **Scraping**: Calls ScraperOrchestrator to search across all enabled sources
3. **Processing**: Extracts URLs and metadata from scraping results
4. **Deduplication**: Checks database to avoid processing duplicate URLs
5. **Storage**: Saves new sources to database for later processing
6. **Logging**: Records all activities to database and log files

## Database Integration

The crawler automatically:
- Creates entries in the `sources` table for new URLs
- Creates entries in the `scraping_logs` table for each scraping cycle
- Checks for duplicate URLs before adding to database
- Tracks which sources have been processed

## Logging

Logs are saved to:
- **File**: `./data/logs/automated_crawler.log`
- **Console**: Standard output

Log entries include:
- Timestamps for all operations
- Success/failure status
- Statistics for each scraping cycle
- Error messages with stack traces

## Running as a Background Service

### Option 1: Run in Python Script

```python
from crawler import AutomatedCrawler
import time

crawler = AutomatedCrawler(season="2024-25", scrape_interval_hours=6)
crawler.start(run_immediately=True)

# Keep running
try:
    while True:
        time.sleep(60)
except KeyboardInterrupt:
    crawler.stop()
```

### Option 2: Run with systemd (Linux)

Create `/etc/systemd/system/mvp-crawler.service`:

```ini
[Unit]
Description=NFL MVP Voter Crawler
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/path/to/project
ExecStart=/path/to/python backend/crawler/automated_crawler.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl enable mvp-crawler
sudo systemctl start mvp-crawler
sudo systemctl status mvp-crawler
```

### Option 3: Run with Docker

See the main project README for Docker deployment instructions.

## Monitoring

### Check Crawler Status

```python
stats = crawler.get_stats()
print(f"Running: {stats['is_running']}")
print(f"Last run: {stats['last_run']}")
print(f"Next run: {stats['next_run']}")
```

### Check Database Logs

```python
from database.connection import session_scope
from database.utils import ScrapingLogDB

with session_scope() as session:
    recent_logs = ScrapingLogDB.get_recent_logs(session, limit=10)
    for log in recent_logs:
        print(f"{log.started_at}: {log.source} - {log.urls_found} URLs found")
```

## Best Practices

1. **Interval Selection**:
   - 6-12 hours is recommended for regular monitoring
   - Daily scraping during active MVP voting season
   - Less frequent (24+ hours) during off-season

2. **Error Handling**:
   - Crawler automatically logs errors and continues running
   - Check logs regularly for any issues

3. **Resource Management**:
   - News scraping is the most resource-intensive
   - Consider disabling news scraping if running on limited resources
   - Rate limiting is built into scrapers to avoid being blocked

4. **Database Maintenance**:
   - Regularly check database size
   - Archive old scraping logs if needed
   - Monitor for duplicate entries

## Troubleshooting

### Crawler Not Starting

Check if database is initialized:
```python
from database.connection import init_db
init_db()
```

### No New Sources Found

- Check if scrapers are working individually
- Verify internet connectivity
- Check rate limiting delays
- Review scraping logs for errors

### High Memory Usage

- Reduce scrape interval
- Disable news scraping
- Limit number of URLs processed per cycle

## Future Enhancements

The crawler is designed to integrate with:
- NLP extraction module (Feature #8) - to extract voter/vote information
- Notification system (Feature #18) - to alert on new findings
- Admin interface (Feature #21) - for manual verification

## Examples

### Example 1: Conservative Scraping (Daily)

```python
crawler = AutomatedCrawler(
    season="2024-25",
    scrape_interval_hours=24,  # Once per day
    enable_google=True,
    enable_reddit=True,
    enable_news=False  # Skip resource-intensive news scraping
)
crawler.start(run_immediately=True)
```

### Example 2: Aggressive Scraping (Every 3 Hours)

```python
crawler = AutomatedCrawler(
    season="2024-25",
    scrape_interval_hours=3,  # Every 3 hours
    enable_google=True,
    enable_reddit=True,
    enable_news=True
)
crawler.start(run_immediately=True)
```

### Example 3: Reddit-Only Monitoring

```python
crawler = AutomatedCrawler(
    season="2024-25",
    scrape_interval_hours=2,  # Every 2 hours
    enable_google=False,
    enable_reddit=True,  # Only Reddit
    enable_news=False
)
crawler.start(run_immediately=True)
```

## License

Part of the NFL MVP Voter Tracker project.
