"""
Integration test for confidence scoring with VoteExtractor

Tests that the VoteExtractor properly integrates with ConfidenceScorer
and returns votes with comprehensive confidence scores.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nlp import VoteExtractor


def test_vote_extraction_with_confidence():
    """Test that VoteExtractor returns votes with confidence scores"""
    print("\n=== Integration Test: VoteExtractor with ConfidenceScorer ===")

    extractor = VoteExtractor()

    # Test with a high-quality extraction scenario
    text = """
    By Mina Kimes - ESPN

    Here is my official AP MVP ballot for the 2024-25 season:

    1. Josh Allen - Buffalo Bills QB
    2. Lamar Jackson - Baltimore Ravens QB
    3. Saquon Barkley - Philadelphia Eagles RB
    4. Joe Burrow - Cincinnati Bengals QB
    5. Jalen Hurts - Philadelphia Eagles QB

    Josh Allen has been the most valuable player this season with his
    incredible performance leading the Bills to the playoffs.
    """

    votes = extractor.extract_votes_from_text(
        text=text,
        source_url="https://twitter.com/minakimes/status/123456",
        source_type="social_media"
    )

    print(f"\nExtracted {len(votes)} votes")

    # Verify we got votes
    assert len(votes) > 0, "Should extract at least one vote"

    # Test first vote (Josh Allen, rank 1)
    vote = votes[0]
    print(f"\n--- Vote 1 Details ---")
    print(f"Voter: {vote.get('voter_name')}")
    print(f"Candidate: {vote.get('candidate_name')}")
    print(f"Ranking: {vote.get('ranking')}")
    print(f"Source Type: {vote.get('source_type')}")

    # Check for legacy confidence field
    assert 'overall_confidence' in vote, "Should have legacy overall_confidence"
    print(f"Legacy Confidence: {vote['overall_confidence']}")

    # Check for new comprehensive confidence fields
    assert 'confidence_numeric' in vote, "Should have confidence_numeric"
    assert 'confidence_level' in vote, "Should have confidence_level"
    assert 'confidence_factors' in vote, "Should have confidence_factors"
    assert 'recommendation' in vote, "Should have recommendation"

    print(f"\n--- Comprehensive Confidence Scores ---")
    print(f"Numeric Score: {vote['confidence_numeric']}")
    print(f"Confidence Level: {vote['confidence_level']}")
    print(f"Recommendation: {vote['recommendation']}")
    print(f"\nFactor Breakdown:")
    for factor, score in vote['confidence_factors'].items():
        print(f"  {factor}: {score:.1f}")

    # Assertions
    assert isinstance(vote['confidence_numeric'], (int, float)), "Numeric score should be a number"
    assert 0 <= vote['confidence_numeric'] <= 100, "Numeric score should be 0-100"
    assert vote['confidence_level'] in ['high', 'medium', 'low'], "Level should be high/medium/low"
    assert vote['recommendation'] in [
        'auto_approve', 'review_recommended', 'verification_required', 'hold_for_review'
    ], "Recommendation should be valid"

    # For this high-quality scenario, we expect high confidence
    assert vote['confidence_numeric'] >= 65, "This scenario should have medium-high or high confidence"

    print("\n✓ Integration test passed!")
    return True


def test_low_confidence_extraction():
    """Test extraction with low confidence scenario"""
    print("\n=== Integration Test: Low Confidence Scenario ===")

    extractor = VoteExtractor()

    # Vague text with minimal information
    text = "I think Allen should get it this year"

    votes = extractor.extract_votes_from_text(
        text=text,
        source_url="https://reddit.com/r/nfl/comments/abc123",
        source_type="reddit"
    )

    if len(votes) > 0:
        vote = votes[0]
        print(f"Extracted vote with confidence: {vote['confidence_numeric']}")
        print(f"Level: {vote['confidence_level']}")
        print(f"Recommendation: {vote['recommendation']}")

        # Low confidence scenarios should score lower
        assert vote['confidence_numeric'] < 70, "Vague extraction should have lower confidence"
        print("✓ Low confidence test passed!")
    else:
        print("✓ No votes extracted from vague text (expected)")

    return True


def test_multiple_votes_batch_confidence():
    """Test that multiple votes all get confidence scores"""
    print("\n=== Integration Test: Batch Vote Confidence ===")

    extractor = VoteExtractor()

    text = """
    Peter King's MVP Ballot:
    1. Josh Allen
    2. Lamar Jackson
    3. Saquon Barkley
    4. Joe Burrow
    5. Jalen Hurts
    """

    votes = extractor.extract_votes_from_text(
        text=text,
        source_url="https://si.com/nfl/mvp-ballots",
        source_type="news_article"
    )

    print(f"\nExtracted {len(votes)} votes")

    # All votes should have confidence scores
    for i, vote in enumerate(votes):
        print(f"\nVote {i+1}: {vote.get('candidate_name')} (Rank {vote.get('ranking')})")
        print(f"  Confidence: {vote['confidence_numeric']} ({vote['confidence_level']})")

        assert 'confidence_numeric' in vote
        assert 'confidence_level' in vote
        assert 'recommendation' in vote

    print("\n✓ Batch confidence test passed!")
    return True


def run_integration_tests():
    """Run all integration tests"""
    print("=" * 60)
    print("CONFIDENCE SCORING INTEGRATION TESTS")
    print("=" * 60)

    tests = [
        test_vote_extraction_with_confidence,
        test_low_confidence_extraction,
        test_multiple_votes_batch_confidence,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            if test():
                passed += 1
        except AssertionError as e:
            print(f"✗ Test failed: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ Test error: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_integration_tests()
    sys.exit(0 if success else 1)
