# Statistics API Documentation - Feature #13

## Overview

The Statistics API endpoint provides comprehensive summary statistics about the NFL MVP voter tracker.

## Endpoint

**GET** `/api/statistics?season=2024-25`

Returns comprehensive summary statistics including:
- Overview (total voters, known voters, completion %)
- Candidate breakdown with weighted points (1st=10pts, 2nd=7pts, 3rd=5pts, 4th=3pts, 5th=1pt)
- Source type distribution (official, social_media, news_article, reddit, speculation)
- Confidence level distribution (high, medium, low, unknown)
- Voter disclosure status (full ballot, partial, first place only, none)
- Timeline of vote announcements
- Recent activity (last 20 votes)

## Testing

```bash
cd backend
python3 test_statistics.py
```

## Frontend

Access at: `http://localhost:3000/statistics`

Features:
- Overview statistics cards
- Top 5 MVP leaders
- Complete candidate breakdown table
- Source and confidence distributions
- Voter disclosure breakdown
- Timeline visualization
- Recent activity feed
