"""
Main Flask application for NFL MVP Voter Tracker API
"""
from flask import Flask, jsonify, request, send_file, Response
from flask_cors import CORS
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os
import csv
import io
import json
from datetime import datetime

from database.models import Base, Voter, Candidate, Vote, ConfidenceLevel, SourceType

app = Flask(__name__)
CORS(app)

# Database setup
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///../data/mvp_tracker.db')
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)


@app.route('/api/voters', methods=['GET'])
def get_voters():
    """
    Get all voters with pagination, sorting, and filtering - Feature #19

    Query Parameters:
    - page (int): Page number (default: 1)
    - per_page (int): Items per page (default: 50, max: 100)
    - sort_by (string): Field to sort by (name, outlet, vote_count, created_at)
    - order (string): Sort order (asc, desc) (default: asc)
    - outlet (string): Filter by outlet (partial match)
    - has_voted (boolean): Filter by whether voter has disclosed votes
    - season (string): Season for vote count calculation (default: 2024-25)
    """
    session = Session()

    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 50, type=int), 100)  # Max 100 per page
        sort_by = request.args.get('sort_by', 'name')
        order = request.args.get('order', 'asc').lower()
        outlet_filter = request.args.get('outlet', '').strip()
        has_voted_filter = request.args.get('has_voted', '').strip().lower()
        season = request.args.get('season', '2024-25')

        # Build query
        query = session.query(Voter)

        # Apply filters
        if outlet_filter:
            query = query.filter(Voter.outlet.ilike(f'%{outlet_filter}%'))

        # Apply sorting
        if sort_by == 'name':
            sort_column = Voter.name
        elif sort_by == 'outlet':
            sort_column = Voter.outlet
        elif sort_by == 'created_at':
            sort_column = Voter.created_at
        else:
            sort_column = Voter.name  # Default to name

        if order == 'desc':
            query = query.order_by(sort_column.desc())
        else:
            query = query.order_by(sort_column.asc())

        # Get total count before pagination
        total_count = query.count()

        # Apply pagination
        offset = (page - 1) * per_page
        voters = query.offset(offset).limit(per_page).all()

        # Build result with vote counts for the season
        result = []
        for v in voters:
            votes = [vote for vote in v.votes if vote.season == season]
            has_voted = len(votes) > 0

            # Apply has_voted filter if specified
            if has_voted_filter:
                if has_voted_filter == 'true' and not has_voted:
                    continue
                elif has_voted_filter == 'false' and has_voted:
                    continue

            result.append({
                'id': v.id,
                'name': v.name,
                'outlet': v.outlet,
                'twitter_handle': v.twitter_handle,
                'location': v.location,
                'vote_count': len(votes),
                'has_voted': has_voted,
                'created_at': v.created_at.isoformat() if v.created_at else None
            })

        # If has_voted filter was applied, recalculate count
        if has_voted_filter:
            total_count = len(result)

        # Calculate pagination metadata
        total_pages = (total_count + per_page - 1) // per_page

        return jsonify({
            'voters': result,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total_count': total_count,
                'total_pages': total_pages,
                'has_next': page < total_pages,
                'has_prev': page > 1
            },
            'filters': {
                'outlet': outlet_filter if outlet_filter else None,
                'has_voted': has_voted_filter if has_voted_filter else None,
                'season': season
            },
            'sorting': {
                'sort_by': sort_by,
                'order': order
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/voters/<int:voter_id>', methods=['GET'])
def get_voter(voter_id):
    """Get comprehensive voter details with votes and statistics - Feature #12"""
    session = Session()
    season = request.args.get('season', '2024-25')

    voter = session.query(Voter).get(voter_id)

    if not voter:
        session.close()
        return jsonify({'error': 'Voter not found'}), 404

    # Get votes for this season
    votes = [v for v in voter.votes if v.season == season]
    votes.sort(key=lambda x: x.ranking if x.ranking else 999)

    # Format full ballot with all details
    ballot = []
    for vote in votes:
        ballot.append({
            'id': vote.id,
            'ranking': vote.ranking,
            'candidate': vote.candidate.name if vote.candidate else 'Unknown',
            'team': vote.candidate.team if vote.candidate else None,
            'position': vote.candidate.position if vote.candidate else None,
            'source_url': vote.source_url,
            'source_type': vote.source_type.value if vote.source_type else None,
            'confidence': vote.confidence.value if vote.confidence else 'unknown',
            'confidence_score': vote.confidence_score,
            'verified': bool(vote.verified),
            'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None,
            'created_at': vote.created_at.isoformat() if vote.created_at else None,
            'extracted_text': vote.extracted_text,
            # Feature #16: Credibility tracking
            'credibility_tier': vote.credibility_tier.value if hasattr(vote, 'credibility_tier') and vote.credibility_tier else 'unverified',
            'credibility_score': vote.credibility_score if hasattr(vote, 'credibility_score') else None,
            'has_direct_quote': bool(vote.has_direct_quote) if hasattr(vote, 'has_direct_quote') else False,
            'has_speculation_language': bool(vote.has_speculation_language) if hasattr(vote, 'has_speculation_language') else False
        })

    # Calculate confidence statistics
    high_conf_votes = len([v for v in votes if v.confidence and v.confidence.value == 'high'])
    verified_votes = len([v for v in votes if v.verified])

    # Get all votes across all seasons for historical view
    all_votes = [{
        'season': v.season,
        'candidate': v.candidate.name if v.candidate else 'Unknown',
        'ranking': v.ranking
    } for v in voter.votes]

    result = {
        'id': voter.id,
        'name': voter.name,
        'outlet': voter.outlet,
        'twitter_handle': voter.twitter_handle,
        'location': voter.location,
        'bio': voter.bio,
        'created_at': voter.created_at.isoformat() if voter.created_at else None,
        'ballot': ballot,
        'statistics': {
            'total_votes': len(ballot),
            'verified_votes': verified_votes,
            'high_confidence_votes': high_conf_votes,
            'has_full_ballot': len(ballot) >= 5,
            'first_place_pick': ballot[0]['candidate'] if len(ballot) > 0 and ballot[0]['ranking'] == 1 else None
        },
        'all_seasons': all_votes,
        'season': season
    }

    session.close()
    return jsonify(result)


@app.route('/api/candidates', methods=['GET'])
def get_candidates():
    """Get all candidates"""
    session = Session()
    season = request.args.get('season', '2024-25')
    
    candidates = session.query(Candidate).filter_by(season=season).all()
    
    result = [{
        'id': c.id,
        'name': c.name,
        'team': c.team,
        'position': c.position,
        'vote_count': len([v for v in c.votes if v.ranking == 1])
    } for c in candidates]
    
    session.close()
    return jsonify(result)


@app.route('/api/votes', methods=['GET'])
def get_votes():
    """
    Get all votes with pagination, sorting, and filtering - Feature #19

    Query Parameters:
    - page (int): Page number (default: 1)
    - per_page (int): Items per page (default: 50, max: 100)
    - season (string): Filter by season (default: 2024-25)
    - voter_id (int): Filter by voter ID
    - candidate_id (int): Filter by candidate ID
    - ranking (int): Filter by ranking (1-5)
    - confidence (string): Filter by confidence level (high, medium, low)
    - verified (boolean): Filter by verification status
    - source_type (string): Filter by source type
    - sort_by (string): Field to sort by (ranking, created_at, announcement_date)
    - order (string): Sort order (asc, desc) (default: asc)
    """
    session = Session()

    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 50, type=int), 100)
        season = request.args.get('season', '2024-25')
        voter_id = request.args.get('voter_id', type=int)
        candidate_id = request.args.get('candidate_id', type=int)
        ranking = request.args.get('ranking', type=int)
        confidence_filter = request.args.get('confidence', '').strip()
        verified_filter = request.args.get('verified', '').strip().lower()
        source_type_filter = request.args.get('source_type', '').strip()
        sort_by = request.args.get('sort_by', 'ranking')
        order = request.args.get('order', 'asc').lower()

        # Build query
        query = session.query(Vote).filter_by(season=season)

        # Apply filters
        if voter_id:
            query = query.filter(Vote.voter_id == voter_id)
        if candidate_id:
            query = query.filter(Vote.candidate_id == candidate_id)
        if ranking:
            query = query.filter(Vote.ranking == ranking)
        if confidence_filter:
            try:
                conf_enum = ConfidenceLevel[confidence_filter.upper()]
                query = query.filter(Vote.confidence == conf_enum)
            except KeyError:
                pass
        if verified_filter:
            if verified_filter == 'true':
                query = query.filter(Vote.verified == 1)
            elif verified_filter == 'false':
                query = query.filter(Vote.verified == 0)
        if source_type_filter:
            try:
                source_enum = SourceType[source_type_filter.upper()]
                query = query.filter(Vote.source_type == source_enum)
            except KeyError:
                pass

        # Apply sorting
        if sort_by == 'ranking':
            sort_column = Vote.ranking
        elif sort_by == 'created_at':
            sort_column = Vote.created_at
        elif sort_by == 'announcement_date':
            sort_column = Vote.announcement_date
        else:
            sort_column = Vote.ranking

        if order == 'desc':
            query = query.order_by(sort_column.desc())
        else:
            query = query.order_by(sort_column.asc())

        # Get total count
        total_count = query.count()

        # Apply pagination
        offset = (page - 1) * per_page
        votes = query.offset(offset).limit(per_page).all()

        # Build result
        result = []
        for v in votes:
            result.append({
                'id': v.id,
                'voter_id': v.voter_id,
                'voter_name': v.voter.name if v.voter else 'Unknown',
                'candidate_id': v.candidate_id,
                'candidate_name': v.candidate.name if v.candidate else 'Unknown',
                'ranking': v.ranking,
                'season': v.season,
                'source_type': v.source_type.value if v.source_type else None,
                'source_url': v.source_url,
                'confidence': v.confidence.value if v.confidence else None,
                'confidence_score': v.confidence_score,
                'verified': bool(v.verified),
                'announcement_date': v.announcement_date.isoformat() if v.announcement_date else None,
                'created_at': v.created_at.isoformat() if v.created_at else None
            })

        # Calculate pagination metadata
        total_pages = (total_count + per_page - 1) // per_page

        return jsonify({
            'votes': result,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total_count': total_count,
                'total_pages': total_pages,
                'has_next': page < total_pages,
                'has_prev': page > 1
            },
            'filters': {
                'season': season,
                'voter_id': voter_id,
                'candidate_id': candidate_id,
                'ranking': ranking,
                'confidence': confidence_filter if confidence_filter else None,
                'verified': verified_filter if verified_filter else None,
                'source_type': source_type_filter if source_type_filter else None
            },
            'sorting': {
                'sort_by': sort_by,
                'order': order
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get summary statistics"""
    session = Session()
    season = request.args.get('season', '2024-25')
    
    total_voters = 50  # AP has 50 voters
    known_voters = session.query(Voter).count()
    votes_disclosed = session.query(Vote).filter_by(season=season, verified=1).count()
    
    result = {
        'total_voters': total_voters,
        'known_voters': known_voters,
        'votes_disclosed': votes_disclosed,
        'completion_percentage': (known_voters / total_voters) * 100
    }
    
    session.close()
    return jsonify(result)


@app.route('/api/dashboard', methods=['GET'])
def get_dashboard():
    """Get comprehensive dashboard data - Feature #11"""
    session = Session()
    season = request.args.get('season', '2024-25')

    try:
        # Summary statistics
        total_voters = 50  # AP has 50 voters
        known_voters_count = session.query(Voter).count()

        # Count voters with at least one vote disclosed
        voters_with_votes = session.query(Vote.voter_id).filter_by(season=season).distinct().count()

        # Total votes disclosed (counting first place votes)
        first_place_votes = session.query(Vote).filter_by(season=season, ranking=1).count()

        # All voters with their vote information
        voters = session.query(Voter).all()
        voter_list = []

        for voter in voters:
            # Get votes for this season
            votes = [v for v in voter.votes if v.season == season]

            # Sort votes by ranking
            votes.sort(key=lambda x: x.ranking if x.ranking else 999)

            # Format ballot
            ballot = []
            for vote in votes:
                ballot.append({
                    'ranking': vote.ranking,
                    'candidate': vote.candidate.name if vote.candidate else 'Unknown',
                    'team': vote.candidate.team if vote.candidate else None,
                    'confidence': vote.confidence.value if vote.confidence else 'unknown',
                    'verified': bool(vote.verified),
                    'source_url': vote.source_url
                })

            voter_data = {
                'id': voter.id,
                'name': voter.name,
                'outlet': voter.outlet,
                'twitter_handle': voter.twitter_handle,
                'location': voter.location,
                'has_voted': len(votes) > 0,
                'vote_count': len(votes),
                'ballot': ballot,
                'status': 'disclosed' if len(votes) > 0 else 'not_disclosed'
            }
            voter_list.append(voter_data)

        # Get candidate vote distribution
        candidates = session.query(Candidate).filter_by(season=season).all()
        candidate_stats = []

        for candidate in candidates:
            first_place = len([v for v in candidate.votes if v.ranking == 1 and v.season == season])
            total_mentions = len([v for v in candidate.votes if v.season == season])

            candidate_stats.append({
                'name': candidate.name,
                'team': candidate.team,
                'position': candidate.position,
                'first_place_votes': first_place,
                'total_mentions': total_mentions
            })

        # Sort candidates by first place votes
        candidate_stats.sort(key=lambda x: x['first_place_votes'], reverse=True)

        # Recent activity (last 10 votes added)
        recent_votes = session.query(Vote).filter_by(season=season).order_by(Vote.created_at.desc()).limit(10).all()
        recent_activity = []

        for vote in recent_votes:
            recent_activity.append({
                'voter_name': vote.voter.name if vote.voter else 'Unknown',
                'candidate_name': vote.candidate.name if vote.candidate else 'Unknown',
                'ranking': vote.ranking,
                'date': vote.announcement_date.isoformat() if vote.announcement_date else None,
                'created_at': vote.created_at.isoformat() if vote.created_at else None
            })

        result = {
            'stats': {
                'total_voters': total_voters,
                'known_voters': known_voters_count,
                'voters_with_disclosed_votes': voters_with_votes,
                'first_place_votes_disclosed': first_place_votes,
                'completion_percentage': round((voters_with_votes / total_voters) * 100, 1)
            },
            'voters': voter_list,
            'candidate_stats': candidate_stats,
            'recent_activity': recent_activity,
            'season': season
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """Get comprehensive summary statistics - Feature #13"""
    session = Session()
    season = request.args.get('season', '2024-25')

    try:
        # Overall voter statistics
        total_voters = 50  # AP has 50 voters
        known_voters_count = session.query(Voter).count()
        voters_with_votes = session.query(Vote.voter_id).filter_by(season=season).distinct().count()

        # Vote statistics
        total_votes = session.query(Vote).filter_by(season=season).count()
        first_place_votes = session.query(Vote).filter_by(season=season, ranking=1).count()
        verified_votes = session.query(Vote).filter(
            Vote.season == season,
            Vote.verified == 1
        ).count()

        # Completion percentage
        completion_percentage = round((voters_with_votes / total_voters) * 100, 1)

        # Candidate breakdown - votes per candidate
        candidates = session.query(Candidate).filter_by(season=season).all()
        candidate_breakdown = []

        for candidate in candidates:
            votes = [v for v in candidate.votes if v.season == season]
            first_place = len([v for v in votes if v.ranking == 1])
            second_place = len([v for v in votes if v.ranking == 2])
            third_place = len([v for v in votes if v.ranking == 3])
            fourth_place = len([v for v in votes if v.ranking == 4])
            fifth_place = len([v for v in votes if v.ranking == 5])
            total_mentions = len(votes)

            # Calculate weighted points (1st=10pts, 2nd=7pts, 3rd=5pts, 4th=3pts, 5th=1pt)
            points = (first_place * 10) + (second_place * 7) + (third_place * 5) + (fourth_place * 3) + (fifth_place * 1)

            candidate_breakdown.append({
                'name': candidate.name,
                'team': candidate.team,
                'position': candidate.position,
                'first_place_votes': first_place,
                'second_place_votes': second_place,
                'third_place_votes': third_place,
                'fourth_place_votes': fourth_place,
                'fifth_place_votes': fifth_place,
                'total_mentions': total_mentions,
                'weighted_points': points
            })

        # Sort by weighted points
        candidate_breakdown.sort(key=lambda x: x['weighted_points'], reverse=True)

        # Source type distribution
        source_distribution = {}
        all_votes = session.query(Vote).filter_by(season=season).all()

        for vote in all_votes:
            source_type = vote.source_type.value if vote.source_type else 'unknown'
            source_distribution[source_type] = source_distribution.get(source_type, 0) + 1

        # Confidence level distribution
        confidence_distribution = {
            'high': 0,
            'medium': 0,
            'low': 0,
            'unknown': 0
        }

        for vote in all_votes:
            conf = vote.confidence.value if vote.confidence else 'unknown'
            confidence_distribution[conf] = confidence_distribution.get(conf, 0) + 1

        # Timeline of vote announcements (grouped by date)
        timeline = {}
        for vote in all_votes:
            if vote.announcement_date:
                date_str = vote.announcement_date.strftime('%Y-%m-%d')
                timeline[date_str] = timeline.get(date_str, 0) + 1

        # Convert timeline to sorted list
        timeline_list = [{'date': date, 'count': count} for date, count in sorted(timeline.items())]

        # Voter disclosure status breakdown
        voters = session.query(Voter).all()
        disclosure_breakdown = {
            'full_ballot': 0,      # 5 votes
            'partial_ballot': 0,   # 1-4 votes
            'first_place_only': 0, # Only rank 1
            'no_disclosure': 0     # 0 votes
        }

        for voter in voters:
            votes = [v for v in voter.votes if v.season == season]
            vote_count = len(votes)

            if vote_count == 0:
                disclosure_breakdown['no_disclosure'] += 1
            elif vote_count >= 5:
                disclosure_breakdown['full_ballot'] += 1
            elif vote_count == 1 and votes[0].ranking == 1:
                disclosure_breakdown['first_place_only'] += 1
            else:
                disclosure_breakdown['partial_ballot'] += 1

        # Top 5 candidates by first place votes
        top_candidates = candidate_breakdown[:5]

        # Recent activity (last 20 votes added)
        recent_votes = session.query(Vote).filter_by(season=season).order_by(Vote.created_at.desc()).limit(20).all()
        recent_activity = []

        for vote in recent_votes:
            recent_activity.append({
                'voter_name': vote.voter.name if vote.voter else 'Unknown',
                'candidate_name': vote.candidate.name if vote.candidate else 'Unknown',
                'ranking': vote.ranking,
                'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None,
                'created_at': vote.created_at.isoformat() if vote.created_at else None,
                'confidence': vote.confidence.value if vote.confidence else 'unknown',
                'verified': bool(vote.verified)
            })

        result = {
            'season': season,
            'overview': {
                'total_voters': total_voters,
                'known_voters': known_voters_count,
                'voters_with_disclosed_votes': voters_with_votes,
                'total_votes_disclosed': total_votes,
                'first_place_votes_disclosed': first_place_votes,
                'verified_votes': verified_votes,
                'completion_percentage': completion_percentage
            },
            'candidate_breakdown': candidate_breakdown,
            'top_candidates': top_candidates,
            'source_distribution': source_distribution,
            'confidence_distribution': confidence_distribution,
            'disclosure_breakdown': disclosure_breakdown,
            'timeline': timeline_list,
            'recent_activity': recent_activity
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical', methods=['GET'])
def get_historical_data():
    """Get historical MVP voting data by season - Feature #17"""
    session = Session()

    try:
        # Get season parameter (optional - returns all seasons if not specified)
        season = request.args.get('season')

        # Get all available seasons
        seasons_query = session.query(Vote.season).distinct().all()
        all_seasons = sorted([s[0] for s in seasons_query if s[0]], reverse=True)

        if season:
            # Get data for specific season
            seasons_to_query = [season]
        else:
            # Get data for all seasons
            seasons_to_query = all_seasons

        historical_data = []

        for season_name in seasons_to_query:
            # Get all votes for this season
            votes = session.query(Vote).filter_by(season=season_name).all()

            # Get all candidates for this season
            candidates = session.query(Candidate).filter_by(season=season_name).all()

            # Calculate final results (vote distribution)
            candidate_results = {}
            for candidate in candidates:
                candidate_votes = [v for v in votes if v.candidate_id == candidate.id]

                # Count votes by ranking
                rankings = {"1st": 0, "2nd": 0, "3rd": 0, "4th": 0, "5th": 0}
                for vote in candidate_votes:
                    if vote.ranking == 1:
                        rankings["1st"] += 1
                    elif vote.ranking == 2:
                        rankings["2nd"] += 1
                    elif vote.ranking == 3:
                        rankings["3rd"] += 1
                    elif vote.ranking == 4:
                        rankings["4th"] += 1
                    elif vote.ranking == 5:
                        rankings["5th"] += 1

                # Calculate weighted points (10-7-5-3-1)
                points = (rankings["1st"] * 10 + rankings["2nd"] * 7 +
                         rankings["3rd"] * 5 + rankings["4th"] * 3 + rankings["5th"] * 1)

                if rankings["1st"] > 0 or rankings["2nd"] > 0 or rankings["3rd"] > 0:
                    candidate_results[candidate.name] = {
                        "name": candidate.name,
                        "team": candidate.team,
                        "position": candidate.position,
                        "first_place_votes": rankings["1st"],
                        "second_place_votes": rankings["2nd"],
                        "third_place_votes": rankings["3rd"],
                        "fourth_place_votes": rankings["4th"],
                        "fifth_place_votes": rankings["5th"],
                        "total_points": points,
                        "total_mentions": sum(rankings.values())
                    }

            # Sort candidates by points
            sorted_candidates = sorted(
                candidate_results.values(),
                key=lambda x: x["total_points"],
                reverse=True
            )

            # Determine winner (most first place votes or points)
            winner = sorted_candidates[0]["name"] if sorted_candidates else None

            # Get voter ballots for this season
            voter_ballots = []
            voters = session.query(Voter).join(Vote).filter(Vote.season == season_name).distinct().all()

            for voter in voters:
                voter_votes = session.query(Vote).join(Candidate).filter(
                    Vote.voter_id == voter.id,
                    Vote.season == season_name
                ).order_by(Vote.ranking).all()

                if voter_votes:
                    ballot = []
                    for vote in voter_votes:
                        ballot.append({
                            "ranking": vote.ranking,
                            "candidate": vote.candidate.name,
                            "team": vote.candidate.team,
                            "position": vote.candidate.position
                        })

                    voter_ballots.append({
                        "voter_name": voter.name,
                        "outlet": voter.outlet,
                        "twitter_handle": voter.twitter_handle,
                        "ballot": ballot
                    })

            # Compile season data
            season_data = {
                "season": season_name,
                "winner": winner,
                "total_voters": len(voter_ballots),
                "candidates": sorted_candidates,
                "voter_ballots": voter_ballots
            }

            historical_data.append(season_data)

        session.close()

        return jsonify({
            "historical_data": historical_data,
            "all_seasons": all_seasons,
            "requested_season": season
        })

    except Exception as e:
        session.close()
        return jsonify({"error": str(e)}), 500


@app.route('/api/search', methods=['GET'])
def search():
    """Search and filter voters, candidates, and votes - Feature #14"""
    session = Session()
    season = request.args.get('season', '2024-25')

    try:
        # Get search parameters
        query = request.args.get('q', '').strip().lower()
        voter_name = request.args.get('voter_name', '').strip().lower()
        outlet = request.args.get('outlet', '').strip().lower()
        candidate_name = request.args.get('candidate_name', '').strip().lower()
        confidence = request.args.get('confidence', '').strip().lower()
        verified_only = request.args.get('verified_only', '').lower() == 'true'
        has_ballot = request.args.get('has_ballot', '').strip().lower()

        # Start with all voters
        voters = session.query(Voter).all()
        results = []

        for voter in voters:
            # Get votes for this season
            votes = [v for v in voter.votes if v.season == season]

            # Apply filters
            should_include = True

            # General search query (searches name, outlet, twitter)
            if query:
                voter_text = f"{voter.name} {voter.outlet or ''} {voter.twitter_handle or ''}".lower()
                if query not in voter_text:
                    should_include = False

            # Voter name filter
            if voter_name and voter_name not in voter.name.lower():
                should_include = False

            # Outlet filter
            if outlet and (not voter.outlet or outlet not in voter.outlet.lower()):
                should_include = False

            # Candidate filter - check if voter voted for this candidate
            if candidate_name:
                voted_for_candidate = False
                for vote in votes:
                    if vote.candidate and candidate_name in vote.candidate.name.lower():
                        voted_for_candidate = True
                        break
                if not voted_for_candidate:
                    should_include = False

            # Confidence filter - check if voter has any votes with this confidence level
            if confidence:
                has_confidence = False
                for vote in votes:
                    if vote.confidence and vote.confidence.value.lower() == confidence:
                        has_confidence = True
                        break
                if not has_confidence:
                    should_include = False

            # Verified only filter
            if verified_only:
                has_verified = False
                for vote in votes:
                    if vote.verified:
                        has_verified = True
                        break
                if not has_verified:
                    should_include = False

            # Ballot status filter
            if has_ballot:
                vote_count = len(votes)
                if has_ballot == 'full' and vote_count < 5:
                    should_include = False
                elif has_ballot == 'partial' and (vote_count == 0 or vote_count >= 5):
                    should_include = False
                elif has_ballot == 'none' and vote_count > 0:
                    should_include = False
                elif has_ballot == 'any' and vote_count == 0:
                    should_include = False

            # If voter passes all filters, include them
            if should_include:
                # Sort votes by ranking
                votes.sort(key=lambda x: x.ranking if x.ranking else 999)

                # Format ballot
                ballot = []
                for vote in votes:
                    ballot.append({
                        'ranking': vote.ranking,
                        'candidate': vote.candidate.name if vote.candidate else 'Unknown',
                        'team': vote.candidate.team if vote.candidate else None,
                        'confidence': vote.confidence.value if vote.confidence else 'unknown',
                        'verified': bool(vote.verified),
                        'source_url': vote.source_url
                    })

                voter_data = {
                    'id': voter.id,
                    'name': voter.name,
                    'outlet': voter.outlet,
                    'twitter_handle': voter.twitter_handle,
                    'location': voter.location,
                    'has_voted': len(votes) > 0,
                    'vote_count': len(votes),
                    'ballot': ballot,
                    'status': 'disclosed' if len(votes) > 0 else 'not_disclosed'
                }
                results.append(voter_data)

        # Return results with metadata
        return jsonify({
            'results': results,
            'count': len(results),
            'season': season,
            'filters_applied': {
                'query': query if query else None,
                'voter_name': voter_name if voter_name else None,
                'outlet': outlet if outlet else None,
                'candidate_name': candidate_name if candidate_name else None,
                'confidence': confidence if confidence else None,
                'verified_only': verified_only,
                'has_ballot': has_ballot if has_ballot else None
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'NFL MVP Voter Tracker'})


# ============================================================
# Manual Entry Endpoints - Feature #10
# ============================================================

@app.route('/api/voters', methods=['POST'])
def create_voter():
    """Manually create a new voter"""
    session = Session()
    try:
        data = request.get_json()

        # Validate required fields
        if not data.get('name'):
            return jsonify({'error': 'name is required'}), 400

        # Check if voter already exists
        existing = session.query(Voter).filter_by(name=data['name']).first()
        if existing:
            return jsonify({'error': 'Voter with this name already exists', 'voter_id': existing.id}), 409

        # Create new voter
        voter = Voter(
            name=data['name'],
            outlet=data.get('outlet'),
            twitter_handle=data.get('twitter_handle'),
            location=data.get('location'),
            bio=data.get('bio')
        )

        session.add(voter)
        session.commit()

        # Send notification for new voter (Feature #18)
        try:
            from notifications import NotificationService
            notification_service = NotificationService()
            notification_service.notify_new_voter(voter.id)
        except Exception as notif_error:
            # Don't fail the voter creation if notification fails
            print(f"Notification error: {notif_error}")

        result = {
            'id': voter.id,
            'name': voter.name,
            'outlet': voter.outlet,
            'twitter_handle': voter.twitter_handle,
            'location': voter.location,
            'bio': voter.bio,
            'message': 'Voter created successfully'
        }

        return jsonify(result), 201

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/voters/<int:voter_id>', methods=['PUT'])
def update_voter(voter_id):
    """Update an existing voter"""
    session = Session()
    try:
        voter = session.query(Voter).get(voter_id)

        if not voter:
            return jsonify({'error': 'Voter not found'}), 404

        data = request.get_json()

        # Update fields if provided
        if 'name' in data:
            voter.name = data['name']
        if 'outlet' in data:
            voter.outlet = data['outlet']
        if 'twitter_handle' in data:
            voter.twitter_handle = data['twitter_handle']
        if 'location' in data:
            voter.location = data['location']
        if 'bio' in data:
            voter.bio = data['bio']

        session.commit()

        result = {
            'id': voter.id,
            'name': voter.name,
            'outlet': voter.outlet,
            'twitter_handle': voter.twitter_handle,
            'location': voter.location,
            'bio': voter.bio,
            'message': 'Voter updated successfully'
        }

        return jsonify(result), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/voters/<int:voter_id>', methods=['DELETE'])
def delete_voter(voter_id):
    """Delete a voter"""
    session = Session()
    try:
        voter = session.query(Voter).get(voter_id)

        if not voter:
            return jsonify({'error': 'Voter not found'}), 404

        voter_name = voter.name
        session.delete(voter)
        session.commit()

        return jsonify({'message': f'Voter "{voter_name}" deleted successfully'}), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/candidates', methods=['POST'])
def create_candidate():
    """Manually create a new candidate"""
    session = Session()
    try:
        data = request.get_json()

        # Validate required fields
        if not data.get('name'):
            return jsonify({'error': 'name is required'}), 400
        if not data.get('season'):
            return jsonify({'error': 'season is required'}), 400

        # Check if candidate already exists
        existing = session.query(Candidate).filter_by(
            name=data['name'],
            season=data['season']
        ).first()
        if existing:
            return jsonify({'error': 'Candidate already exists for this season', 'candidate_id': existing.id}), 409

        # Create new candidate
        candidate = Candidate(
            name=data['name'],
            team=data.get('team'),
            position=data.get('position'),
            season=data['season']
        )

        session.add(candidate)
        session.commit()

        result = {
            'id': candidate.id,
            'name': candidate.name,
            'team': candidate.team,
            'position': candidate.position,
            'season': candidate.season,
            'message': 'Candidate created successfully'
        }

        return jsonify(result), 201

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/candidates/<int:candidate_id>', methods=['PUT'])
def update_candidate(candidate_id):
    """Update an existing candidate"""
    session = Session()
    try:
        candidate = session.query(Candidate).get(candidate_id)

        if not candidate:
            return jsonify({'error': 'Candidate not found'}), 404

        data = request.get_json()

        # Update fields if provided
        if 'name' in data:
            candidate.name = data['name']
        if 'team' in data:
            candidate.team = data['team']
        if 'position' in data:
            candidate.position = data['position']

        session.commit()

        result = {
            'id': candidate.id,
            'name': candidate.name,
            'team': candidate.team,
            'position': candidate.position,
            'season': candidate.season,
            'message': 'Candidate updated successfully'
        }

        return jsonify(result), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/candidates/<int:candidate_id>', methods=['DELETE'])
def delete_candidate(candidate_id):
    """Delete a candidate"""
    session = Session()
    try:
        candidate = session.query(Candidate).get(candidate_id)

        if not candidate:
            return jsonify({'error': 'Candidate not found'}), 404

        candidate_name = candidate.name
        session.delete(candidate)
        session.commit()

        return jsonify({'message': f'Candidate "{candidate_name}" deleted successfully'}), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/votes', methods=['POST'])
def create_vote():
    """Manually create a new vote"""
    session = Session()
    try:
        data = request.get_json()

        # Validate required fields
        if not data.get('voter_id') and not data.get('voter_name'):
            return jsonify({'error': 'voter_id or voter_name is required'}), 400
        if not data.get('candidate_id') and not data.get('candidate_name'):
            return jsonify({'error': 'candidate_id or candidate_name is required'}), 400
        if not data.get('season'):
            return jsonify({'error': 'season is required'}), 400

        # Get or create voter
        if data.get('voter_id'):
            voter = session.query(Voter).get(data['voter_id'])
            if not voter:
                return jsonify({'error': 'Voter not found'}), 404
        else:
            voter = session.query(Voter).filter_by(name=data['voter_name']).first()
            if not voter:
                # Create new voter on the fly
                voter = Voter(name=data['voter_name'])
                session.add(voter)
                session.flush()

        # Get or create candidate
        if data.get('candidate_id'):
            candidate = session.query(Candidate).get(data['candidate_id'])
            if not candidate:
                return jsonify({'error': 'Candidate not found'}), 404
        else:
            candidate = session.query(Candidate).filter_by(
                name=data['candidate_name'],
                season=data['season']
            ).first()
            if not candidate:
                # Create new candidate on the fly
                candidate = Candidate(
                    name=data['candidate_name'],
                    season=data['season'],
                    team=data.get('candidate_team'),
                    position=data.get('candidate_position')
                )
                session.add(candidate)
                session.flush()

        # Check if vote already exists
        existing_vote = session.query(Vote).filter_by(
            voter_id=voter.id,
            candidate_id=candidate.id,
            season=data['season'],
            ranking=data.get('ranking', 1)
        ).first()

        if existing_vote:
            return jsonify({'error': 'Vote already exists', 'vote_id': existing_vote.id}), 409

        # Parse confidence level if provided
        confidence = None
        if data.get('confidence'):
            try:
                confidence = ConfidenceLevel[data['confidence'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid confidence level. Use: high, medium, or low'}), 400

        # Parse source type if provided
        source_type = None
        if data.get('source_type'):
            try:
                source_type = SourceType[data['source_type'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid source type'}), 400

        # Create new vote
        vote = Vote(
            voter_id=voter.id,
            candidate_id=candidate.id,
            season=data['season'],
            ranking=data.get('ranking', 1),
            source_url=data.get('source_url'),
            source_type=source_type or SourceType.SPECULATION,
            confidence=confidence or ConfidenceLevel.MEDIUM,
            confidence_score=data.get('confidence_score'),
            announcement_date=data.get('announcement_date'),
            extracted_text=data.get('extracted_text'),
            verified=data.get('verified', 1)  # Manual entries are verified by default
        )

        session.add(vote)
        session.commit()

        # Send notification for new vote (Feature #18)
        try:
            from notifications import NotificationService
            notification_service = NotificationService()
            notification_service.notify_new_vote(vote.id)

            # Check if this completes a full ballot (5 votes)
            voter_votes = [v for v in voter.votes if v.season == data['season']]
            if len(voter_votes) == 5:
                notification_service.notify_full_ballot(voter.id)

            # Check if this is a high-confidence vote
            if vote.confidence and vote.confidence.value == 'high':
                notification_service.notify_high_confidence_vote(vote.id)
        except Exception as notif_error:
            # Don't fail the vote creation if notification fails
            print(f"Notification error: {notif_error}")

        result = {
            'id': vote.id,
            'voter': voter.name,
            'candidate': candidate.name,
            'ranking': vote.ranking,
            'season': vote.season,
            'source_url': vote.source_url,
            'confidence': vote.confidence.value if vote.confidence else None,
            'confidence_score': vote.confidence_score,
            'verified': bool(vote.verified),
            'message': 'Vote created successfully'
        }

        return jsonify(result), 201

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/votes/<int:vote_id>', methods=['PUT'])
def update_vote(vote_id):
    """Update an existing vote"""
    session = Session()
    try:
        vote = session.query(Vote).get(vote_id)

        if not vote:
            return jsonify({'error': 'Vote not found'}), 404

        data = request.get_json()

        # Update fields if provided
        if 'ranking' in data:
            vote.ranking = data['ranking']
        if 'source_url' in data:
            vote.source_url = data['source_url']
        if 'confidence' in data:
            try:
                vote.confidence = ConfidenceLevel[data['confidence'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid confidence level'}), 400
        if 'confidence_score' in data:
            vote.confidence_score = data['confidence_score']
        if 'source_type' in data:
            try:
                vote.source_type = SourceType[data['source_type'].upper()]
            except KeyError:
                return jsonify({'error': 'Invalid source type'}), 400
        if 'verified' in data:
            vote.verified = 1 if data['verified'] else 0
        if 'extracted_text' in data:
            vote.extracted_text = data['extracted_text']
        if 'announcement_date' in data:
            vote.announcement_date = data['announcement_date']

        session.commit()

        result = {
            'id': vote.id,
            'voter': vote.voter.name,
            'candidate': vote.candidate.name,
            'ranking': vote.ranking,
            'season': vote.season,
            'source_url': vote.source_url,
            'confidence': vote.confidence.value if vote.confidence else None,
            'confidence_score': vote.confidence_score,
            'verified': bool(vote.verified),
            'message': 'Vote updated successfully'
        }

        return jsonify(result), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/votes/<int:vote_id>', methods=['DELETE'])
def delete_vote(vote_id):
    """Delete a vote"""
    session = Session()
    try:
        vote = session.query(Vote).get(vote_id)

        if not vote:
            return jsonify({'error': 'Vote not found'}), 404

        voter_name = vote.voter.name if vote.voter else 'Unknown'
        candidate_name = vote.candidate.name if vote.candidate else 'Unknown'
        session.delete(vote)
        session.commit()

        return jsonify({'message': f'Vote from "{voter_name}" for "{candidate_name}" deleted successfully'}), 200

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/export/voters', methods=['GET'])
def export_voters():
    """Export all voters data in CSV or JSON format - Feature #15"""
    session = Session()
    format_type = request.args.get('format', 'json').lower()
    season = request.args.get('season', '2024-25')

    try:
        voters = session.query(Voter).all()

        # Prepare data with vote counts for the season
        voters_data = []
        for voter in voters:
            votes = [v for v in voter.votes if v.season == season]
            voters_data.append({
                'id': voter.id,
                'name': voter.name,
                'outlet': voter.outlet,
                'twitter_handle': voter.twitter_handle,
                'location': voter.location,
                'bio': voter.bio,
                'vote_count': len(votes),
                'has_voted': len(votes) > 0,
                'created_at': voter.created_at.isoformat() if voter.created_at else None
            })

        if format_type == 'csv':
            # Create CSV in memory
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=['id', 'name', 'outlet', 'twitter_handle', 'location', 'bio', 'vote_count', 'has_voted', 'created_at'])
            writer.writeheader()
            writer.writerows(voters_data)

            # Return as downloadable file
            response = Response(output.getvalue(), mimetype='text/csv')
            response.headers['Content-Disposition'] = f'attachment; filename=voters_{season}.csv'
            return response
        else:
            # Return as JSON
            response = Response(json.dumps(voters_data, indent=2), mimetype='application/json')
            response.headers['Content-Disposition'] = f'attachment; filename=voters_{season}.json'
            return response

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/export/votes', methods=['GET'])
def export_votes():
    """Export all votes data in CSV or JSON format - Feature #15"""
    session = Session()
    format_type = request.args.get('format', 'json').lower()
    season = request.args.get('season', '2024-25')

    try:
        votes = session.query(Vote).filter_by(season=season).all()

        # Prepare data
        votes_data = []
        for vote in votes:
            votes_data.append({
                'id': vote.id,
                'voter_name': vote.voter.name if vote.voter else 'Unknown',
                'voter_outlet': vote.voter.outlet if vote.voter else None,
                'candidate_name': vote.candidate.name if vote.candidate else 'Unknown',
                'candidate_team': vote.candidate.team if vote.candidate else None,
                'candidate_position': vote.candidate.position if vote.candidate else None,
                'ranking': vote.ranking,
                'season': vote.season,
                'source_url': vote.source_url,
                'source_type': vote.source_type.value if vote.source_type else None,
                'confidence': vote.confidence.value if vote.confidence else None,
                'confidence_score': vote.confidence_score,
                'verified': bool(vote.verified),
                'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None,
                'created_at': vote.created_at.isoformat() if vote.created_at else None
            })

        if format_type == 'csv':
            # Create CSV in memory
            output = io.StringIO()
            fieldnames = ['id', 'voter_name', 'voter_outlet', 'candidate_name', 'candidate_team',
                         'candidate_position', 'ranking', 'season', 'source_url', 'source_type',
                         'confidence', 'confidence_score', 'verified', 'announcement_date', 'created_at']
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(votes_data)

            # Return as downloadable file
            response = Response(output.getvalue(), mimetype='text/csv')
            response.headers['Content-Disposition'] = f'attachment; filename=votes_{season}.csv'
            return response
        else:
            # Return as JSON
            response = Response(json.dumps(votes_data, indent=2), mimetype='application/json')
            response.headers['Content-Disposition'] = f'attachment; filename=votes_{season}.json'
            return response

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/export/candidates', methods=['GET'])
def export_candidates():
    """Export candidates with vote statistics in CSV or JSON format - Feature #15"""
    session = Session()
    format_type = request.args.get('format', 'json').lower()
    season = request.args.get('season', '2024-25')

    try:
        candidates = session.query(Candidate).filter_by(season=season).all()

        # Prepare data with vote statistics
        candidates_data = []
        for candidate in candidates:
            votes = [v for v in candidate.votes if v.season == season]
            first_place = len([v for v in votes if v.ranking == 1])
            second_place = len([v for v in votes if v.ranking == 2])
            third_place = len([v for v in votes if v.ranking == 3])
            fourth_place = len([v for v in votes if v.ranking == 4])
            fifth_place = len([v for v in votes if v.ranking == 5])

            # Calculate weighted points (10-7-5-3-1)
            weighted_points = (first_place * 10) + (second_place * 7) + (third_place * 5) + (fourth_place * 3) + (fifth_place * 1)

            candidates_data.append({
                'id': candidate.id,
                'name': candidate.name,
                'team': candidate.team,
                'position': candidate.position,
                'season': candidate.season,
                'first_place_votes': first_place,
                'second_place_votes': second_place,
                'third_place_votes': third_place,
                'fourth_place_votes': fourth_place,
                'fifth_place_votes': fifth_place,
                'total_mentions': len(votes),
                'weighted_points': weighted_points
            })

        # Sort by weighted points
        candidates_data.sort(key=lambda x: x['weighted_points'], reverse=True)

        if format_type == 'csv':
            # Create CSV in memory
            output = io.StringIO()
            fieldnames = ['id', 'name', 'team', 'position', 'season', 'first_place_votes',
                         'second_place_votes', 'third_place_votes', 'fourth_place_votes',
                         'fifth_place_votes', 'total_mentions', 'weighted_points']
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(candidates_data)

            # Return as downloadable file
            response = Response(output.getvalue(), mimetype='text/csv')
            response.headers['Content-Disposition'] = f'attachment; filename=candidates_{season}.csv'
            return response
        else:
            # Return as JSON
            response = Response(json.dumps(candidates_data, indent=2), mimetype='application/json')
            response.headers['Content-Disposition'] = f'attachment; filename=candidates_{season}.json'
            return response

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/export/full-report', methods=['GET'])
def export_full_report():
    """Export comprehensive report with all data in JSON format - Feature #15"""
    session = Session()
    format_type = request.args.get('format', 'json').lower()
    season = request.args.get('season', '2024-25')

    try:
        # Gather all data
        voters = session.query(Voter).all()
        candidates = session.query(Candidate).filter_by(season=season).all()
        votes = session.query(Vote).filter_by(season=season).all()

        # Build comprehensive report
        report = {
            'metadata': {
                'season': season,
                'export_date': datetime.now().isoformat(),
                'total_voters': 50,
                'known_voters': len(voters),
                'total_votes': len(votes),
                'total_candidates': len(candidates)
            },
            'statistics': {
                'voters_with_disclosed_votes': len(set([v.voter_id for v in votes])),
                'first_place_votes_disclosed': len([v for v in votes if v.ranking == 1]),
                'verified_votes': len([v for v in votes if v.verified]),
                'high_confidence_votes': len([v for v in votes if v.confidence and v.confidence.value == 'high']),
                'completion_percentage': (len(set([v.voter_id for v in votes])) / 50) * 100
            },
            'voters': [],
            'candidates': [],
            'votes': []
        }

        # Add voter data with their ballots
        for voter in voters:
            voter_votes = [v for v in voter.votes if v.season == season]
            voter_votes.sort(key=lambda x: x.ranking if x.ranking else 999)

            ballot = []
            for vote in voter_votes:
                ballot.append({
                    'ranking': vote.ranking,
                    'candidate': vote.candidate.name if vote.candidate else 'Unknown',
                    'team': vote.candidate.team if vote.candidate else None,
                    'confidence': vote.confidence.value if vote.confidence else None,
                    'confidence_score': vote.confidence_score,
                    'verified': bool(vote.verified),
                    'source_url': vote.source_url
                })

            report['voters'].append({
                'id': voter.id,
                'name': voter.name,
                'outlet': voter.outlet,
                'twitter_handle': voter.twitter_handle,
                'location': voter.location,
                'vote_count': len(ballot),
                'ballot': ballot
            })

        # Add candidate data with vote breakdowns
        for candidate in candidates:
            cand_votes = [v for v in candidate.votes if v.season == season]
            first_place = len([v for v in cand_votes if v.ranking == 1])
            second_place = len([v for v in cand_votes if v.ranking == 2])
            third_place = len([v for v in cand_votes if v.ranking == 3])
            fourth_place = len([v for v in cand_votes if v.ranking == 4])
            fifth_place = len([v for v in cand_votes if v.ranking == 5])

            weighted_points = (first_place * 10) + (second_place * 7) + (third_place * 5) + (fourth_place * 3) + (fifth_place * 1)

            report['candidates'].append({
                'id': candidate.id,
                'name': candidate.name,
                'team': candidate.team,
                'position': candidate.position,
                'first_place_votes': first_place,
                'second_place_votes': second_place,
                'third_place_votes': third_place,
                'fourth_place_votes': fourth_place,
                'fifth_place_votes': fifth_place,
                'total_mentions': len(cand_votes),
                'weighted_points': weighted_points
            })

        # Sort candidates by weighted points
        report['candidates'].sort(key=lambda x: x['weighted_points'], reverse=True)

        # Add individual vote records
        for vote in votes:
            report['votes'].append({
                'id': vote.id,
                'voter': vote.voter.name if vote.voter else 'Unknown',
                'candidate': vote.candidate.name if vote.candidate else 'Unknown',
                'ranking': vote.ranking,
                'source_url': vote.source_url,
                'source_type': vote.source_type.value if vote.source_type else None,
                'confidence': vote.confidence.value if vote.confidence else None,
                'confidence_score': vote.confidence_score,
                'verified': bool(vote.verified),
                'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None
            })

        # Return as JSON (CSV not suitable for nested data)
        response = Response(json.dumps(report, indent=2), mimetype='application/json')
        response.headers['Content-Disposition'] = f'attachment; filename=mvp_full_report_{season}.json'
        return response

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


# ============================================================
# CREDIBILITY TRACKING ENDPOINTS - Feature #16
# ============================================================

@app.route('/api/credibility/assess', methods=['POST'])
def assess_credibility():
    """
    Assess the credibility of a source URL or text content

    POST /api/credibility/assess
    Body: {
        "url": "https://...",
        "title": "Article title",
        "content": "Text content",
        "source_type": "news_article|social_media|etc",
        "voter_name": "Optional voter name",
        "is_verified_account": false
    }

    Returns:
        {
            "credibility_tier": "verified|official|reliable|unverified|speculation",
            "credibility_score": 85.5,
            "domain_reputation": "tier1|tier2|tier3|social|forum|unknown",
            "has_direct_quote": true,
            "has_speculation_language": false,
            "verification_indicators": [...],
            "confidence_boost": 10.0,
            "recommendation": "highly_trustworthy|trustworthy|...",
            "reasoning": [...],
            "badge": {
                "color": "#10b981",
                "icon": "✓",
                "label": "Verified Source",
                "description": "..."
            }
        }
    """
    try:
        from nlp import CredibilityScorer

        data = request.get_json()

        # Validate required fields
        if not data.get('url') and not data.get('content'):
            return jsonify({'error': 'Either url or content is required'}), 400

        # Initialize credibility scorer
        scorer = CredibilityScorer()

        # Prepare source data
        source_data = {
            'url': data.get('url', ''),
            'title': data.get('title', ''),
            'content': data.get('content', ''),
            'source_type': data.get('source_type', 'unknown'),
            'voter_name': data.get('voter_name', ''),
            'is_verified_account': data.get('is_verified_account', False),
            'num_corroborating_sources': data.get('num_corroborating_sources', 0)
        }

        # Assess credibility
        result = scorer.assess_source_credibility(source_data)

        # Add badge information
        result['badge'] = scorer.get_credibility_badge(result['credibility_tier'])

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/credibility/domains', methods=['GET'])
def get_domain_reputation():
    """
    Get list of trusted domains organized by reputation tier

    GET /api/credibility/domains

    Returns:
        {
            "tier1": ["ap.org", "espn.com", ...],
            "tier2": ["profootballtalk.com", ...],
            "tier3": [...],
            "social": ["twitter.com", "x.com", ...],
            "forums": ["reddit.com", ...]
        }
    """
    try:
        from nlp import CredibilityScorer

        scorer = CredibilityScorer()
        domains = scorer.get_domain_reputation_list()

        return jsonify(domains)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/credibility/domains', methods=['POST'])
def add_trusted_domain():
    """
    Add a new trusted domain to the reputation database

    POST /api/credibility/domains
    Body: {
        "domain": "example.com",
        "tier": "tier1|tier2|tier3"
    }

    Returns:
        {
            "message": "Domain added successfully",
            "domain": "example.com",
            "tier": "tier2"
        }
    """
    try:
        from nlp import CredibilityScorer

        data = request.get_json()

        # Validate required fields
        if not data.get('domain'):
            return jsonify({'error': 'domain is required'}), 400

        tier = data.get('tier', 'tier3')
        if tier not in ['tier1', 'tier2', 'tier3']:
            return jsonify({'error': 'tier must be tier1, tier2, or tier3'}), 400

        scorer = CredibilityScorer()
        scorer.add_trusted_domain(data['domain'], tier)

        return jsonify({
            'message': 'Domain added successfully',
            'domain': data['domain'],
            'tier': tier
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/credibility/compare', methods=['POST'])
def compare_sources():
    """
    Compare multiple sources for the same vote to determine overall credibility

    POST /api/credibility/compare
    Body: {
        "sources": [
            {
                "url": "https://...",
                "credibility_tier": "verified",
                "credibility_score": 90.0
            },
            ...
        ]
    }

    Returns:
        {
            "highest_tier": "verified",
            "average_score": 85.5,
            "consensus": true,
            "num_sources": 3,
            "recommendation": "highly_confident|confident|..."
        }
    """
    try:
        from nlp import CredibilityScorer

        data = request.get_json()

        # Validate required fields
        if not data.get('sources') or not isinstance(data['sources'], list):
            return jsonify({'error': 'sources array is required'}), 400

        scorer = CredibilityScorer()
        result = scorer.compare_sources(data['sources'])

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/credibility/badges', methods=['GET'])
def get_credibility_badges():
    """
    Get all credibility badge definitions for display

    GET /api/credibility/badges

    Returns:
        {
            "verified": {
                "color": "#10b981",
                "icon": "✓",
                "label": "Verified Source",
                "description": "..."
            },
            ...
        }
    """
    try:
        from nlp import CredibilityScorer, CredibilityTier

        scorer = CredibilityScorer()

        badges = {}
        for tier in [CredibilityTier.VERIFIED, CredibilityTier.OFFICIAL,
                     CredibilityTier.RELIABLE, CredibilityTier.UNVERIFIED,
                     CredibilityTier.SPECULATION]:
            badges[tier.value] = scorer.get_credibility_badge(tier.value)

        return jsonify(badges)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/historical/seasons', methods=['GET'])
def get_historical_seasons():
    """Get list of all seasons with vote data - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        seasons = HistoricalDB.get_seasons(session)

        return jsonify({
            'seasons': seasons,
            'total_seasons': len(seasons)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical/voter/<voter_name>', methods=['GET'])
def get_voter_history(voter_name):
    """Get complete voting history for a voter across all seasons - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        history = HistoricalDB.get_voter_history(session, voter_name)

        if not history:
            return jsonify({'error': 'Voter not found'}), 404

        return jsonify(history)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical/candidate/<candidate_name>', methods=['GET'])
def get_candidate_history(candidate_name):
    """Get vote history for a candidate across all seasons - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        history = HistoricalDB.get_candidate_history(session, candidate_name)

        if not history:
            return jsonify({'error': 'Candidate not found'}), 404

        return jsonify(history)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical/compare', methods=['GET'])
def compare_seasons():
    """Compare voting patterns between two seasons - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        season1 = request.args.get('season1')
        season2 = request.args.get('season2')

        if not season1 or not season2:
            return jsonify({'error': 'Both season1 and season2 parameters are required'}), 400

        comparison = HistoricalDB.compare_seasons(session, season1, season2)

        return jsonify(comparison)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical/winner/<season>', methods=['GET'])
def get_season_winner(season):
    """Get MVP winner and vote breakdown for a season - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        winner_data = HistoricalDB.get_season_winner(session, season)

        if not winner_data['winner']:
            return jsonify({'error': 'No vote data found for this season'}), 404

        return jsonify(winner_data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/historical/trends/<voter_name>', methods=['GET'])
def get_voter_trends(voter_name):
    """Analyze voting trends for a specific voter across seasons - Feature #17"""
    session = Session()
    try:
        from database.utils import HistoricalDB

        trends = HistoricalDB.get_voter_trends(session, voter_name)

        if not trends:
            return jsonify({'error': 'Voter not found'}), 404

        return jsonify(trends)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


# ============================================================================
# Notification API Endpoints - Feature #18
# ============================================================================

@app.route('/api/notifications/preferences', methods=['GET'])
def get_notification_preferences():
    """Get all notification preferences - Feature #18"""
    session = Session()
    try:
        from database.models import NotificationPreference

        prefs = session.query(NotificationPreference).all()

        result = [{
            'id': p.id,
            'name': p.name,
            'enabled': bool(p.enabled),
            'channel': p.channel.value if p.channel else None,
            'notify_new_voter': bool(p.notify_new_voter),
            'notify_new_vote': bool(p.notify_new_vote),
            'notify_full_ballot': bool(p.notify_full_ballot),
            'notify_high_confidence': bool(p.notify_high_confidence),
            'notify_verified_vote': bool(p.notify_verified_vote),
            'notify_scraping_complete': bool(p.notify_scraping_complete),
            'notify_scraping_error': bool(p.notify_scraping_error),
            'email_address': p.email_address if p.channel and p.channel.value == 'email' else None,
            'webhook_url': p.webhook_url if p.channel and p.channel.value == 'webhook' else None,
            'min_interval_minutes': p.min_interval_minutes,
            'batch_notifications': bool(p.batch_notifications),
            'created_at': p.created_at.isoformat() if p.created_at else None,
            'updated_at': p.updated_at.isoformat() if p.updated_at else None
        } for p in prefs]

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/notifications/preferences', methods=['POST'])
def create_notification_preference():
    """Create a new notification preference - Feature #18"""
    session = Session()
    try:
        from database.models import NotificationPreference, NotificationChannel

        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Validate required fields
        if 'name' not in data or 'channel' not in data:
            return jsonify({'error': 'name and channel are required'}), 400

        # Validate channel
        try:
            channel = NotificationChannel(data['channel'])
        except ValueError:
            return jsonify({'error': f'Invalid channel: {data["channel"]}'}), 400

        # Channel-specific validation
        if channel == NotificationChannel.EMAIL and not data.get('email_address'):
            return jsonify({'error': 'email_address required for email channel'}), 400
        if channel == NotificationChannel.WEBHOOK and not data.get('webhook_url'):
            return jsonify({'error': 'webhook_url required for webhook channel'}), 400

        # Create preference
        pref = NotificationPreference(
            name=data['name'],
            enabled=data.get('enabled', 1),
            channel=channel,
            notify_new_voter=data.get('notify_new_voter', 1),
            notify_new_vote=data.get('notify_new_vote', 1),
            notify_full_ballot=data.get('notify_full_ballot', 1),
            notify_high_confidence=data.get('notify_high_confidence', 1),
            notify_verified_vote=data.get('notify_verified_vote', 1),
            notify_scraping_complete=data.get('notify_scraping_complete', 0),
            notify_scraping_error=data.get('notify_scraping_error', 1),
            email_address=data.get('email_address'),
            email_from=data.get('email_from'),
            webhook_url=data.get('webhook_url'),
            webhook_secret=data.get('webhook_secret'),
            min_interval_minutes=data.get('min_interval_minutes', 0),
            batch_notifications=data.get('batch_notifications', 0)
        )

        session.add(pref)
        session.commit()

        return jsonify({
            'id': pref.id,
            'name': pref.name,
            'channel': pref.channel.value,
            'enabled': bool(pref.enabled)
        }), 201

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/notifications/preferences/<int:pref_id>', methods=['PUT'])
def update_notification_preference(pref_id):
    """Update a notification preference - Feature #18"""
    session = Session()
    try:
        from database.models import NotificationPreference

        pref = session.query(NotificationPreference).get(pref_id)
        if not pref:
            return jsonify({'error': 'Preference not found'}), 404

        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Update fields
        if 'name' in data:
            pref.name = data['name']
        if 'enabled' in data:
            pref.enabled = 1 if data['enabled'] else 0
        if 'notify_new_voter' in data:
            pref.notify_new_voter = 1 if data['notify_new_voter'] else 0
        if 'notify_new_vote' in data:
            pref.notify_new_vote = 1 if data['notify_new_vote'] else 0
        if 'notify_full_ballot' in data:
            pref.notify_full_ballot = 1 if data['notify_full_ballot'] else 0
        if 'notify_high_confidence' in data:
            pref.notify_high_confidence = 1 if data['notify_high_confidence'] else 0
        if 'notify_verified_vote' in data:
            pref.notify_verified_vote = 1 if data['notify_verified_vote'] else 0
        if 'notify_scraping_complete' in data:
            pref.notify_scraping_complete = 1 if data['notify_scraping_complete'] else 0
        if 'notify_scraping_error' in data:
            pref.notify_scraping_error = 1 if data['notify_scraping_error'] else 0
        if 'email_address' in data:
            pref.email_address = data['email_address']
        if 'email_from' in data:
            pref.email_from = data['email_from']
        if 'webhook_url' in data:
            pref.webhook_url = data['webhook_url']
        if 'webhook_secret' in data:
            pref.webhook_secret = data['webhook_secret']
        if 'min_interval_minutes' in data:
            pref.min_interval_minutes = data['min_interval_minutes']
        if 'batch_notifications' in data:
            pref.batch_notifications = 1 if data['batch_notifications'] else 0

        session.commit()

        return jsonify({
            'id': pref.id,
            'name': pref.name,
            'enabled': bool(pref.enabled),
            'message': 'Preference updated successfully'
        })

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/notifications/preferences/<int:pref_id>', methods=['DELETE'])
def delete_notification_preference(pref_id):
    """Delete a notification preference - Feature #18"""
    session = Session()
    try:
        from database.models import NotificationPreference

        pref = session.query(NotificationPreference).get(pref_id)
        if not pref:
            return jsonify({'error': 'Preference not found'}), 404

        session.delete(pref)
        session.commit()

        return jsonify({'message': 'Preference deleted successfully'})

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/notifications/history', methods=['GET'])
def get_notification_history():
    """Get notification history - Feature #18"""
    session = Session()
    try:
        from database.models import NotificationHistory

        limit = request.args.get('limit', 50, type=int)
        status = request.args.get('status')  # sent, failed, pending

        query = session.query(NotificationHistory)

        if status:
            query = query.filter(NotificationHistory.status == status)

        history = query.order_by(
            NotificationHistory.created_at.desc()
        ).limit(limit).all()

        result = [{
            'id': h.id,
            'event_type': h.event_type.value if h.event_type else None,
            'title': h.title,
            'message': h.message,
            'channel': h.channel.value if h.channel else None,
            'recipient': h.recipient,
            'status': h.status,
            'error_message': h.error_message,
            'voter_id': h.voter_id,
            'vote_id': h.vote_id,
            'candidate_id': h.candidate_id,
            'sent_at': h.sent_at.isoformat() if h.sent_at else None,
            'created_at': h.created_at.isoformat() if h.created_at else None
        } for h in history]

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/notifications/test', methods=['POST'])
def test_notification():
    """Send a test notification - Feature #18"""
    try:
        from notifications import NotificationService
        from database.models import NotificationEventType

        data = request.json or {}
        title = data.get('title', 'Test Notification')
        message = data.get('message', 'This is a test notification from the NFL MVP Voter Tracker.')

        service = NotificationService()
        result = service.notify(
            NotificationEventType.NEW_VOTE_DISCLOSED,
            title,
            message,
            metadata={'test': True}
        )

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# =============================================================================
# ADMIN INTERFACE - Feature #21
# Admin endpoints to verify/edit/approve automatically extracted information
# =============================================================================

@app.route('/api/admin/unverified', methods=['GET'])
def get_unverified_data():
    """
    Get all unverified votes that need admin review - Feature #21

    Query Parameters:
    - season (string): Filter by season (default: 2024-25)
    - confidence (string): Filter by confidence level (high, medium, low)
    - source_type (string): Filter by source type
    - limit (int): Maximum results (default: 50)
    """
    session = Session()

    try:
        season = request.args.get('season', '2024-25')
        confidence_filter = request.args.get('confidence', '').strip().lower()
        source_type_filter = request.args.get('source_type', '').strip().lower()
        limit = request.args.get('limit', 50, type=int)

        # Query unverified votes
        query = session.query(Vote).filter(
            Vote.verified == 0,
            Vote.season == season
        )

        # Apply filters
        if confidence_filter:
            try:
                conf_level = ConfidenceLevel(confidence_filter)
                query = query.filter(Vote.confidence == conf_level)
            except ValueError:
                pass

        if source_type_filter:
            try:
                src_type = SourceType(source_type_filter)
                query = query.filter(Vote.source_type == src_type)
            except ValueError:
                pass

        # Order by confidence score (lowest first for review priority)
        query = query.order_by(Vote.confidence_score.asc().nullslast())
        query = query.limit(limit)

        votes = query.all()

        result = []
        for vote in votes:
            result.append({
                'id': vote.id,
                'voter': {
                    'id': vote.voter.id,
                    'name': vote.voter.name,
                    'outlet': vote.voter.outlet,
                    'twitter_handle': vote.voter.twitter_handle
                },
                'candidate': {
                    'id': vote.candidate.id,
                    'name': vote.candidate.name,
                    'team': vote.candidate.team,
                    'position': vote.candidate.position
                },
                'ranking': vote.ranking,
                'season': vote.season,
                'source_url': vote.source_url,
                'source_type': vote.source_type.value if vote.source_type else None,
                'confidence': vote.confidence.value if vote.confidence else None,
                'confidence_score': vote.confidence_score,
                'credibility_tier': vote.credibility_tier.value if vote.credibility_tier else None,
                'credibility_score': vote.credibility_score,
                'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None,
                'extracted_text': vote.extracted_text,
                'created_at': vote.created_at.isoformat() if vote.created_at else None
            })

        return jsonify({
            'unverified_votes': result,
            'count': len(result),
            'season': season
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/admin/votes/<int:vote_id>/verify', methods=['POST'])
def verify_vote(vote_id):
    """
    Verify/approve a vote - Feature #21

    Body Parameters:
    - verified (boolean): Set verification status (required)
    - credibility_tier (string): Update credibility tier (optional)
    - notes (string): Admin notes about verification (optional)
    """
    session = Session()

    try:
        data = request.json
        if data is None or 'verified' not in data:
            return jsonify({'error': 'verified field is required'}), 400

        vote = session.query(Vote).filter(Vote.id == vote_id).first()
        if not vote:
            return jsonify({'error': 'Vote not found'}), 404

        # Update verification status
        vote.verified = 1 if data['verified'] else 0
        vote.updated_at = datetime.utcnow()

        # Optionally update credibility tier
        if 'credibility_tier' in data:
            try:
                from database.models import CredibilityTier
                vote.credibility_tier = CredibilityTier(data['credibility_tier'])
                # Update credibility score based on tier
                tier_scores = {
                    'verified': 95,
                    'official': 85,
                    'reliable': 70,
                    'unverified': 50,
                    'speculation': 25
                }
                vote.credibility_score = tier_scores.get(data['credibility_tier'], 50)
            except (ValueError, KeyError):
                pass

        session.commit()

        # Trigger notification if verified
        if vote.verified:
            try:
                from notifications import NotificationService
                from database.models import NotificationEventType
                service = NotificationService()
                service.notify(
                    NotificationEventType.VERIFIED_VOTE,
                    f'Vote Verified: {vote.voter.name} → {vote.candidate.name}',
                    f'An admin has verified the MVP vote:\n'
                    f'Voter: {vote.voter.name} ({vote.voter.outlet})\n'
                    f'Candidate: {vote.candidate.name} ({vote.candidate.team})\n'
                    f'Ranking: #{vote.ranking}\n'
                    f'Credibility: {vote.credibility_tier.value if vote.credibility_tier else "unknown"}',
                    metadata={'vote_id': vote.id}
                )
            except Exception as notif_error:
                # Non-blocking - continue even if notification fails
                print(f"Notification error: {notif_error}")

        return jsonify({
            'message': 'Vote verification status updated',
            'vote_id': vote.id,
            'verified': bool(vote.verified),
            'credibility_tier': vote.credibility_tier.value if vote.credibility_tier else None
        })

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/admin/votes/<int:vote_id>', methods=['PUT'])
def update_vote_admin(vote_id):
    """
    Admin update of vote details - Feature #21

    Body Parameters (all optional):
    - ranking (int): Update ranking (1-5)
    - candidate_id (int): Update candidate
    - source_url (string): Update source URL
    - source_type (string): Update source type
    - confidence (string): Update confidence level
    - confidence_score (float): Update confidence score
    - credibility_tier (string): Update credibility tier
    - announcement_date (string): Update announcement date (ISO format)
    - extracted_text (string): Update extracted text
    - verified (boolean): Update verification status
    """
    session = Session()

    try:
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        vote = session.query(Vote).filter(Vote.id == vote_id).first()
        if not vote:
            return jsonify({'error': 'Vote not found'}), 404

        # Update fields if provided
        if 'ranking' in data:
            ranking = data['ranking']
            if not isinstance(ranking, int) or ranking < 1 or ranking > 5:
                return jsonify({'error': 'Ranking must be 1-5'}), 400
            vote.ranking = ranking

        if 'candidate_id' in data:
            candidate = session.query(Candidate).filter(Candidate.id == data['candidate_id']).first()
            if not candidate:
                return jsonify({'error': 'Candidate not found'}), 404
            vote.candidate_id = data['candidate_id']

        if 'source_url' in data:
            vote.source_url = data['source_url']

        if 'source_type' in data:
            try:
                vote.source_type = SourceType(data['source_type'])
            except ValueError:
                return jsonify({'error': 'Invalid source_type'}), 400

        if 'confidence' in data:
            try:
                vote.confidence = ConfidenceLevel(data['confidence'])
            except ValueError:
                return jsonify({'error': 'Invalid confidence level'}), 400

        if 'confidence_score' in data:
            score = data['confidence_score']
            if not isinstance(score, (int, float)) or score < 0 or score > 100:
                return jsonify({'error': 'Confidence score must be 0-100'}), 400
            vote.confidence_score = score

        if 'credibility_tier' in data:
            try:
                from database.models import CredibilityTier
                vote.credibility_tier = CredibilityTier(data['credibility_tier'])
            except ValueError:
                return jsonify({'error': 'Invalid credibility_tier'}), 400

        if 'announcement_date' in data:
            try:
                vote.announcement_date = datetime.fromisoformat(data['announcement_date'].replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                return jsonify({'error': 'Invalid announcement_date format (use ISO 8601)'}), 400

        if 'extracted_text' in data:
            vote.extracted_text = data['extracted_text']

        if 'verified' in data:
            vote.verified = 1 if data['verified'] else 0

        vote.updated_at = datetime.utcnow()
        session.commit()

        return jsonify({
            'message': 'Vote updated successfully',
            'vote_id': vote.id,
            'voter': vote.voter.name,
            'candidate': vote.candidate.name,
            'ranking': vote.ranking,
            'verified': bool(vote.verified)
        })

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/admin/votes/<int:vote_id>', methods=['DELETE'])
def delete_vote_admin(vote_id):
    """
    Admin delete of a vote (for false positives) - Feature #21
    """
    session = Session()

    try:
        vote = session.query(Vote).filter(Vote.id == vote_id).first()
        if not vote:
            return jsonify({'error': 'Vote not found'}), 404

        voter_name = vote.voter.name
        candidate_name = vote.candidate.name

        session.delete(vote)
        session.commit()

        return jsonify({
            'message': 'Vote deleted successfully',
            'vote_id': vote_id,
            'voter': voter_name,
            'candidate': candidate_name
        })

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/admin/voters/<int:voter_id>', methods=['PUT'])
def update_voter_admin(voter_id):
    """
    Admin update of voter details - Feature #21

    Body Parameters (all optional):
    - name (string): Update voter name
    - outlet (string): Update outlet
    - twitter_handle (string): Update Twitter handle
    - location (string): Update location
    - bio (string): Update bio
    """
    session = Session()

    try:
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        voter = session.query(Voter).filter(Voter.id == voter_id).first()
        if not voter:
            return jsonify({'error': 'Voter not found'}), 404

        # Check for name uniqueness if updating name
        if 'name' in data:
            existing = session.query(Voter).filter(
                Voter.name == data['name'],
                Voter.id != voter_id
            ).first()
            if existing:
                return jsonify({'error': 'Voter with this name already exists'}), 409
            voter.name = data['name']

        if 'outlet' in data:
            voter.outlet = data['outlet']

        if 'twitter_handle' in data:
            voter.twitter_handle = data['twitter_handle']

        if 'location' in data:
            voter.location = data['location']

        if 'bio' in data:
            voter.bio = data['bio']

        voter.updated_at = datetime.utcnow()
        session.commit()

        return jsonify({
            'message': 'Voter updated successfully',
            'voter_id': voter.id,
            'name': voter.name,
            'outlet': voter.outlet
        })

    except Exception as e:
        session.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    """
    Get admin dashboard statistics - Feature #21

    Query Parameters:
    - season (string): Filter by season (default: 2024-25)
    """
    session = Session()

    try:
        season = request.args.get('season', '2024-25')

        # Count total votes
        total_votes = session.query(Vote).filter(Vote.season == season).count()

        # Count verified votes
        verified_votes = session.query(Vote).filter(
            Vote.season == season,
            Vote.verified == 1
        ).count()

        # Count unverified votes
        unverified_votes = total_votes - verified_votes

        # Count by confidence level
        high_confidence = session.query(Vote).filter(
            Vote.season == season,
            Vote.confidence == ConfidenceLevel.HIGH
        ).count()

        medium_confidence = session.query(Vote).filter(
            Vote.season == season,
            Vote.confidence == ConfidenceLevel.MEDIUM
        ).count()

        low_confidence = session.query(Vote).filter(
            Vote.season == season,
            Vote.confidence == ConfidenceLevel.LOW
        ).count()

        # Count by source type
        source_breakdown = {}
        for source_type in SourceType:
            count = session.query(Vote).filter(
                Vote.season == season,
                Vote.source_type == source_type
            ).count()
            source_breakdown[source_type.value] = count

        # Count by credibility tier
        from database.models import CredibilityTier
        credibility_breakdown = {}
        for tier in CredibilityTier:
            count = session.query(Vote).filter(
                Vote.season == season,
                Vote.credibility_tier == tier
            ).count()
            credibility_breakdown[tier.value] = count

        # Recent unverified votes (last 10)
        recent_unverified = session.query(Vote).filter(
            Vote.season == season,
            Vote.verified == 0
        ).order_by(Vote.created_at.desc()).limit(10).all()

        recent_list = []
        for vote in recent_unverified:
            recent_list.append({
                'id': vote.id,
                'voter_name': vote.voter.name,
                'candidate_name': vote.candidate.name,
                'ranking': vote.ranking,
                'confidence': vote.confidence.value if vote.confidence else None,
                'confidence_score': vote.confidence_score,
                'source_type': vote.source_type.value if vote.source_type else None,
                'created_at': vote.created_at.isoformat() if vote.created_at else None
            })

        verification_rate = (verified_votes / total_votes * 100) if total_votes > 0 else 0

        return jsonify({
            'season': season,
            'total_votes': total_votes,
            'verified_votes': verified_votes,
            'unverified_votes': unverified_votes,
            'verification_rate': round(verification_rate, 1),
            'confidence_breakdown': {
                'high': high_confidence,
                'medium': medium_confidence,
                'low': low_confidence
            },
            'source_breakdown': source_breakdown,
            'credibility_breakdown': credibility_breakdown,
            'recent_unverified': recent_list
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


@app.route('/api/timeline', methods=['GET'])
def get_timeline():
    """
    Get chronological timeline of vote announcements - Feature #23

    Query Parameters:
    - season (string): Season to filter by (default: 2024-25)
    - group_by (string): Group by 'day', 'week', 'month' (default: day)
    - limit (int): Maximum number of timeline entries (default: 100)

    Returns timeline data with:
    - Timeline entries grouped by date
    - Vote details for each entry
    - Statistics per time period
    """
    session = Session()

    try:
        season = request.args.get('season', '2024-25')
        group_by = request.args.get('group_by', 'day').lower()
        limit = request.args.get('limit', 100, type=int)

        # Query all votes for the season, ordered by announcement date
        votes = session.query(Vote).filter(
            Vote.season == season,
            Vote.announcement_date.isnot(None)
        ).order_by(Vote.announcement_date.desc()).limit(limit).all()

        # Group votes by date
        timeline_dict = {}
        for vote in votes:
            # Format date based on group_by parameter
            if group_by == 'month':
                date_key = vote.announcement_date.strftime('%Y-%m') if vote.announcement_date else 'Unknown'
                display_date = vote.announcement_date.strftime('%B %Y') if vote.announcement_date else 'Unknown'
            elif group_by == 'week':
                date_key = vote.announcement_date.strftime('%Y-W%U') if vote.announcement_date else 'Unknown'
                display_date = vote.announcement_date.strftime('Week of %b %d, %Y') if vote.announcement_date else 'Unknown'
            else:  # day (default)
                date_key = vote.announcement_date.strftime('%Y-%m-%d') if vote.announcement_date else 'Unknown'
                display_date = vote.announcement_date.strftime('%B %d, %Y') if vote.announcement_date else 'Unknown'

            if date_key not in timeline_dict:
                timeline_dict[date_key] = {
                    'date': date_key,
                    'display_date': display_date,
                    'votes': [],
                    'stats': {
                        'total_votes': 0,
                        'first_place_votes': 0,
                        'unique_voters': set(),
                        'unique_candidates': set(),
                        'verified_votes': 0
                    }
                }

            # Add vote to timeline
            timeline_dict[date_key]['votes'].append({
                'id': vote.id,
                'voter_id': vote.voter_id,
                'voter_name': vote.voter.name,
                'voter_outlet': vote.voter.outlet,
                'voter_twitter': vote.voter.twitter_handle,
                'candidate_id': vote.candidate_id,
                'candidate_name': vote.candidate.name,
                'candidate_team': vote.candidate.team,
                'candidate_position': vote.candidate.position,
                'ranking': vote.ranking,
                'source_url': vote.source_url,
                'source_type': vote.source_type.value if vote.source_type else None,
                'confidence': vote.confidence.value if vote.confidence else None,
                'confidence_score': vote.confidence_score,
                'verified': vote.verified,
                'announcement_date': vote.announcement_date.isoformat() if vote.announcement_date else None
            })

            # Update stats
            timeline_dict[date_key]['stats']['total_votes'] += 1
            if vote.ranking == 1:
                timeline_dict[date_key]['stats']['first_place_votes'] += 1
            timeline_dict[date_key]['stats']['unique_voters'].add(vote.voter.name)
            timeline_dict[date_key]['stats']['unique_candidates'].add(vote.candidate.name)
            if vote.verified:
                timeline_dict[date_key]['stats']['verified_votes'] += 1

        # Convert sets to counts for JSON serialization
        timeline_list = []
        for entry in timeline_dict.values():
            entry['stats']['unique_voters'] = len(entry['stats']['unique_voters'])
            entry['stats']['unique_candidates'] = len(entry['stats']['unique_candidates'])
            timeline_list.append(entry)

        # Sort by date (most recent first)
        timeline_list.sort(key=lambda x: x['date'], reverse=True)

        # Calculate overall stats
        total_entries = len(timeline_list)
        total_votes_sum = sum(entry['stats']['total_votes'] for entry in timeline_list)
        total_first_place = sum(entry['stats']['first_place_votes'] for entry in timeline_list)

        # Get unique voters and candidates across all timeline
        all_voters = set()
        all_candidates = set()
        for entry in timeline_list:
            for vote in entry['votes']:
                all_voters.add(vote['voter_name'])
                all_candidates.add(vote['candidate_name'])

        return jsonify({
            'season': season,
            'group_by': group_by,
            'timeline': timeline_list,
            'summary': {
                'total_timeline_entries': total_entries,
                'total_votes': total_votes_sum,
                'total_first_place_votes': total_first_place,
                'unique_voters': len(all_voters),
                'unique_candidates': len(all_candidates),
                'earliest_announcement': timeline_list[-1]['display_date'] if timeline_list else None,
                'latest_announcement': timeline_list[0]['display_date'] if timeline_list else None
            }
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        session.close()


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
