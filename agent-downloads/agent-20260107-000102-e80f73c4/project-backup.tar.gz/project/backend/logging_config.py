"""
Comprehensive Logging Configuration for NFL MVP Voter Tracker

This module provides a centralized logging system for all scraping, extraction,
and application activities with file rotation, multiple log levels, and structured output.

Features:
- Multiple log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Separate log files by module (scraping, nlp, api, database)
- Rotating file handlers to prevent huge log files
- Console output for development
- Structured JSON logging for production analysis
- Context-aware logging with metadata
- Performance timing decorators
"""

import logging
import logging.handlers
import os
import json
import time
from datetime import datetime
from functools import wraps
from typing import Dict, Any, Optional
import traceback


# Log directory
LOG_DIR = os.path.join(os.path.dirname(__file__), 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

# Log levels
LOG_LEVELS = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}


class StructuredFormatter(logging.Formatter):
    """
    Custom formatter that outputs structured JSON logs for production analysis.
    """

    def format(self, record):
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }

        # Add exception info if present
        if record.exc_info:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__,
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exception(*record.exc_info)
            }

        # Add custom fields if present
        if hasattr(record, 'extra_data'):
            log_data['extra'] = record.extra_data

        return json.dumps(log_data)


class ColoredConsoleFormatter(logging.Formatter):
    """
    Custom formatter that adds colors to console output for better readability.
    """

    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
        'RESET': '\033[0m'
    }

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']

        # Format timestamp
        timestamp = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')

        # Build colored log message
        log_msg = f"{color}[{record.levelname}]{reset} {timestamp} - {record.name} - {record.getMessage()}"

        # Add exception info if present
        if record.exc_info:
            log_msg += f"\n{self.formatException(record.exc_info)}"

        return log_msg


class LoggerFactory:
    """
    Factory class to create and configure loggers for different modules.
    """

    _loggers = {}

    @classmethod
    def get_logger(cls, name: str, log_to_console: bool = True,
                   log_to_file: bool = True, structured: bool = False,
                   level: str = 'INFO') -> logging.Logger:
        """
        Get or create a logger with the specified configuration.

        Args:
            name: Logger name (e.g., 'scraping', 'nlp', 'api')
            log_to_console: Whether to log to console
            log_to_file: Whether to log to file
            structured: Whether to use structured JSON logging
            level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

        Returns:
            Configured logger instance
        """

        # Return existing logger if already created
        if name in cls._loggers:
            return cls._loggers[name]

        # Create new logger
        logger = logging.getLogger(name)
        logger.setLevel(LOG_LEVELS.get(level, logging.INFO))
        logger.propagate = False  # Prevent duplicate logs

        # Console handler
        if log_to_console:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(LOG_LEVELS.get(level, logging.INFO))
            console_formatter = ColoredConsoleFormatter()
            console_handler.setFormatter(console_formatter)
            logger.addHandler(console_handler)

        # File handler with rotation
        if log_to_file:
            log_file = os.path.join(LOG_DIR, f'{name}.log')

            # Rotating file handler (10MB per file, keep 5 backups)
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=10 * 1024 * 1024,  # 10MB
                backupCount=5
            )
            file_handler.setLevel(LOG_LEVELS.get(level, logging.INFO))

            if structured:
                file_formatter = StructuredFormatter()
            else:
                file_formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                )

            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)

        # Store logger
        cls._loggers[name] = logger

        return logger

    @classmethod
    def log_with_context(cls, logger: logging.Logger, level: str,
                        message: str, **context):
        """
        Log a message with additional context data.

        Args:
            logger: Logger instance
            level: Log level
            message: Log message
            **context: Additional context data
        """
        log_record = logger.makeRecord(
            logger.name, LOG_LEVELS[level], '', 0, message, (), None
        )
        log_record.extra_data = context
        logger.handle(log_record)


def log_execution_time(logger: logging.Logger):
    """
    Decorator to log function execution time.

    Usage:
        @log_execution_time(scraping_logger)
        def my_function():
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed_time = time.time() - start_time
                logger.info(
                    f"{func.__name__} completed in {elapsed_time:.2f}s",
                    extra={'extra_data': {
                        'function': func.__name__,
                        'duration_seconds': elapsed_time,
                        'status': 'success'
                    }}
                )
                return result
            except Exception as e:
                elapsed_time = time.time() - start_time
                logger.error(
                    f"{func.__name__} failed after {elapsed_time:.2f}s: {str(e)}",
                    exc_info=True,
                    extra={'extra_data': {
                        'function': func.__name__,
                        'duration_seconds': elapsed_time,
                        'status': 'error',
                        'error': str(e)
                    }}
                )
                raise
        return wrapper
    return decorator


def log_scraping_activity(logger: logging.Logger, source: str,
                          url: str, status: str, **metadata):
    """
    Log scraping activity with structured metadata.

    Args:
        logger: Logger instance
        source: Source name (e.g., 'reddit', 'google', 'news')
        url: URL being scraped
        status: Status (success, error, skipped)
        **metadata: Additional metadata
    """
    context = {
        'source': source,
        'url': url,
        'status': status,
        **metadata
    }

    if status == 'success':
        LoggerFactory.log_with_context(
            logger, 'INFO',
            f"Scraped {source}: {url}",
            **context
        )
    elif status == 'error':
        LoggerFactory.log_with_context(
            logger, 'ERROR',
            f"Failed to scrape {source}: {url}",
            **context
        )
    else:
        LoggerFactory.log_with_context(
            logger, 'DEBUG',
            f"Skipped {source}: {url}",
            **context
        )


def log_extraction_activity(logger: logging.Logger, text_length: int,
                           voters_found: int, votes_found: int,
                           confidence: str, **metadata):
    """
    Log NLP extraction activity with structured metadata.

    Args:
        logger: Logger instance
        text_length: Length of text analyzed
        voters_found: Number of voters extracted
        votes_found: Number of votes extracted
        confidence: Overall confidence level
        **metadata: Additional metadata
    """
    context = {
        'text_length': text_length,
        'voters_found': voters_found,
        'votes_found': votes_found,
        'confidence': confidence,
        **metadata
    }

    LoggerFactory.log_with_context(
        logger, 'INFO',
        f"Extracted {votes_found} votes from {voters_found} voters (confidence: {confidence})",
        **context
    )


def log_database_operation(logger: logging.Logger, operation: str,
                          table: str, affected_rows: int, **metadata):
    """
    Log database operations with structured metadata.

    Args:
        logger: Logger instance
        operation: Operation type (INSERT, UPDATE, DELETE, SELECT)
        table: Table name
        affected_rows: Number of rows affected
        **metadata: Additional metadata
    """
    context = {
        'operation': operation,
        'table': table,
        'affected_rows': affected_rows,
        **metadata
    }

    LoggerFactory.log_with_context(
        logger, 'INFO',
        f"{operation} on {table}: {affected_rows} rows affected",
        **context
    )


def log_api_request(logger: logging.Logger, method: str, endpoint: str,
                   status_code: int, duration: float, **metadata):
    """
    Log API requests with structured metadata.

    Args:
        logger: Logger instance
        method: HTTP method (GET, POST, PUT, DELETE)
        endpoint: API endpoint
        status_code: HTTP status code
        duration: Request duration in seconds
        **metadata: Additional metadata
    """
    context = {
        'method': method,
        'endpoint': endpoint,
        'status_code': status_code,
        'duration_seconds': duration,
        **metadata
    }

    level = 'INFO' if 200 <= status_code < 400 else 'WARNING'

    LoggerFactory.log_with_context(
        logger, level,
        f"{method} {endpoint} - {status_code} ({duration:.2f}s)",
        **context
    )


# Pre-configured loggers for different modules
scraping_logger = LoggerFactory.get_logger('scraping', level='INFO')
nlp_logger = LoggerFactory.get_logger('nlp', level='INFO')
api_logger = LoggerFactory.get_logger('api', level='INFO')
database_logger = LoggerFactory.get_logger('database', level='INFO')
notification_logger = LoggerFactory.get_logger('notifications', level='INFO')
general_logger = LoggerFactory.get_logger('general', level='INFO')


# Example usage
if __name__ == '__main__':
    # Test different log levels
    scraping_logger.debug("Debug message - detailed scraping info")
    scraping_logger.info("Info message - scraping started")
    scraping_logger.warning("Warning message - rate limit approaching")
    scraping_logger.error("Error message - failed to fetch URL")
    scraping_logger.critical("Critical message - scraping service down")

    # Test with context
    log_scraping_activity(
        scraping_logger,
        source='reddit',
        url='https://reddit.com/r/nfl',
        status='success',
        posts_found=10,
        votes_extracted=3
    )

    # Test extraction logging
    log_extraction_activity(
        nlp_logger,
        text_length=500,
        voters_found=1,
        votes_found=1,
        confidence='high',
        source_url='https://example.com'
    )

    # Test execution time decorator
    @log_execution_time(scraping_logger)
    def slow_function():
        time.sleep(1)
        return "Done"

    slow_function()

    print(f"\nLogs written to: {LOG_DIR}")
    print("Check the following log files:")
    print("  - scraping.log")
    print("  - nlp.log")
    print("  - api.log")
    print("  - database.log")
    print("  - notifications.log")
    print("  - general.log")
