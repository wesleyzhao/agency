"""
Test suite for confidence scoring system (Feature #9)

Tests the comprehensive confidence scoring module to ensure accurate
confidence calculations based on multiple factors.
"""
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nlp.confidence_scorer import ConfidenceScorer


def test_high_confidence_vote():
    """Test a high confidence vote scenario"""
    print("\n=== Test 1: High Confidence Vote ===")

    scorer = ConfidenceScorer()

    # Simulate a high-quality vote extraction
    vote_data = {
        'voter_name': 'Mina Kimes',
        'voter_confidence': 'high',
        'voter_source': 'known_voter_list',
        'voter_context': 'Mina Kimes announced her MVP ballot today',
        'twitter_handle': '@minakimes',
        'candidate_name': 'Josh Allen',
        'candidate_team': 'Buffalo Bills',
        'candidate_position': 'QB',
        'ranking': 1,
        'ranking_confidence': 'high',
        'source_url': 'https://twitter.com/minakimes/status/123456',
        'source_type': 'social_media',
        'extracted_text': '1. Josh Allen - My MVP pick for 2024',
        'verified': True,
    }

    result = scorer.calculate_vote_confidence(vote_data)

    print(f"Voter: {vote_data['voter_name']} -> {vote_data['candidate_name']}")
    print(f"Numeric Score: {result['numeric_score']}")
    print(f"Confidence Level: {result['confidence_level']}")
    print(f"Recommendation: {result['recommendation']}")
    print(f"Factor Scores:")
    for factor, score in result['factor_scores'].items():
        print(f"  - {factor}: {score:.1f}")

    # Assertions
    assert result['numeric_score'] >= 75, "High confidence vote should score >= 75"
    assert result['confidence_level'] == 'high', "Should be categorized as 'high'"
    assert result['recommendation'] == 'auto_approve', "High confidence should auto-approve"

    print("✓ Test 1 passed")
    return True


def test_medium_confidence_vote():
    """Test a medium confidence vote scenario"""
    print("\n=== Test 2: Medium Confidence Vote ===")

    scorer = ConfidenceScorer()

    # Simulate a medium-quality vote extraction
    vote_data = {
        'voter_name': 'John Smith',
        'voter_confidence': 'medium',
        'voter_context': 'Posted by John Smith on ESPN',
        'candidate_name': 'Lamar Jackson',
        'candidate_team': 'Baltimore Ravens',
        'candidate_position': 'QB',
        'ranking': 1,
        'ranking_confidence': 'medium',
        'source_url': 'https://espn.com/article/mvp-votes',
        'source_type': 'news_article',
        'extracted_text': 'I think Lamar Jackson deserves the MVP',
        'verified': False,
    }

    result = scorer.calculate_vote_confidence(vote_data)

    print(f"Voter: {vote_data['voter_name']} -> {vote_data['candidate_name']}")
    print(f"Numeric Score: {result['numeric_score']}")
    print(f"Confidence Level: {result['confidence_level']}")
    print(f"Recommendation: {result['recommendation']}")

    # Assertions
    assert 40 <= result['numeric_score'] < 75, "Medium confidence should score 40-74"
    assert result['confidence_level'] in ['medium', 'low'], "Should be medium or low"

    print("✓ Test 2 passed")
    return True


def test_low_confidence_vote():
    """Test a low confidence vote scenario"""
    print("\n=== Test 3: Low Confidence Vote ===")

    scorer = ConfidenceScorer()

    # Simulate a low-quality vote extraction
    vote_data = {
        'voter_name': 'Unknown User',
        'voter_confidence': 'low',
        'voter_context': '',
        'candidate_name': 'Barkley',  # Last name only
        'ranking': 0,  # No clear ranking
        'ranking_confidence': 'low',
        'source_url': 'https://reddit.com/r/nfl/comments/abc123',
        'source_type': 'reddit',
        'extracted_text': 'Barkley should win',
        'verified': False,
    }

    result = scorer.calculate_vote_confidence(vote_data)

    print(f"Voter: {vote_data['voter_name']} -> {vote_data['candidate_name']}")
    print(f"Numeric Score: {result['numeric_score']}")
    print(f"Confidence Level: {result['confidence_level']}")
    print(f"Recommendation: {result['recommendation']}")

    # Assertions
    assert result['numeric_score'] < 50, "Low confidence vote should score < 50"
    assert result['confidence_level'] == 'low', "Should be categorized as 'low'"
    assert result['recommendation'] in ['verification_required', 'hold_for_review'], \
        "Low confidence should require review"

    print("✓ Test 3 passed")
    return True


def test_official_source_bonus():
    """Test that official sources get higher scores"""
    print("\n=== Test 4: Official Source Bonus ===")

    scorer = ConfidenceScorer()

    # Same vote from official source
    official_vote = {
        'voter_name': 'Peter King',
        'voter_confidence': 'high',
        'voter_source': 'known_voter_list',
        'candidate_name': 'Josh Allen',
        'candidate_team': 'Buffalo Bills',
        'candidate_position': 'QB',
        'ranking': 1,
        'ranking_confidence': 'high',
        'source_url': 'https://ap.org/article/mvp-votes',
        'source_type': 'official',
        'extracted_text': 'My official AP MVP ballot: 1. Josh Allen',
        'verified': True,
    }

    # Same vote from speculation
    speculation_vote = official_vote.copy()
    speculation_vote['source_type'] = 'speculation'
    speculation_vote['source_url'] = 'https://reddit.com/r/nfl/comments/xyz'
    speculation_vote['verified'] = False

    official_result = scorer.calculate_vote_confidence(official_vote)
    speculation_result = scorer.calculate_vote_confidence(speculation_vote)

    print(f"Official source score: {official_result['numeric_score']}")
    print(f"Speculation source score: {speculation_result['numeric_score']}")
    print(f"Difference: {official_result['numeric_score'] - speculation_result['numeric_score']}")

    # Assertions
    assert official_result['numeric_score'] > speculation_result['numeric_score'], \
        "Official source should score higher than speculation"

    print("✓ Test 4 passed")
    return True


def test_batch_confidence_calculation():
    """Test batch confidence calculation"""
    print("\n=== Test 5: Batch Confidence Calculation ===")

    scorer = ConfidenceScorer()

    votes = [
        {
            'voter_name': 'Mina Kimes',
            'voter_confidence': 'high',
            'candidate_name': 'Josh Allen',
            'candidate_team': 'Bills',
            'candidate_position': 'QB',
            'ranking': 1,
            'ranking_confidence': 'high',
            'source_type': 'social_media',
            'source_url': 'https://twitter.com/minakimes',
            'extracted_text': '1. Josh Allen',
            'verified': True,
        },
        {
            'voter_name': 'Tom Brady',
            'voter_confidence': 'high',
            'candidate_name': 'Lamar Jackson',
            'candidate_team': 'Ravens',
            'candidate_position': 'QB',
            'ranking': 1,
            'ranking_confidence': 'high',
            'source_type': 'social_media',
            'source_url': 'https://twitter.com/tombrady',
            'extracted_text': '1. Lamar Jackson',
            'verified': False,
        },
        {
            'voter_name': 'Unknown',
            'voter_confidence': 'low',
            'candidate_name': 'Allen',
            'ranking': 0,
            'ranking_confidence': 'low',
            'source_type': 'reddit',
            'source_url': 'https://reddit.com/r/nfl',
            'extracted_text': 'Allen for MVP',
            'verified': False,
        }
    ]

    result = scorer.calculate_batch_confidence(votes)

    print(f"Total votes: {result['summary']['total_votes']}")
    print(f"Average confidence: {result['summary']['average_confidence']}")
    print(f"Confidence distribution: {result['summary']['confidence_distribution']}")
    print(f"Recommendation distribution: {result['summary']['recommendation_distribution']}")

    # Assertions
    assert result['summary']['total_votes'] == 3, "Should process all 3 votes"
    assert result['summary']['confidence_distribution']['high'] >= 1, "Should have at least 1 high confidence vote"
    assert result['summary']['confidence_distribution']['low'] >= 1, "Should have at least 1 low confidence vote"

    print("✓ Test 5 passed")
    return True


def test_weight_adjustment():
    """Test adjusting factor weights"""
    print("\n=== Test 6: Weight Adjustment ===")

    scorer = ConfidenceScorer()

    # Get original weights
    original_weights = scorer.get_factor_importance()
    print(f"Original weights: {original_weights['weights']}")

    # Adjust weights (emphasize source type more)
    new_weights = {
        'voter_confidence': 0.20,
        'candidate_confidence': 0.15,
        'ranking_confidence': 0.10,
        'source_type': 0.35,  # Increased from 0.20
        'context_quality': 0.10,
        'verification': 0.10,
    }

    scorer.adjust_weights(new_weights)
    updated_weights = scorer.get_factor_importance()
    print(f"Updated weights: {updated_weights['weights']}")

    # Assertions
    assert scorer.weights['source_type'] == 0.35, "Source type weight should be updated"
    assert abs(sum(scorer.weights.values()) - 1.0) < 0.01, "Weights should sum to 1.0"

    print("✓ Test 6 passed")
    return True


def test_context_quality_scoring():
    """Test that context quality affects scoring"""
    print("\n=== Test 7: Context Quality Impact ===")

    scorer = ConfidenceScorer()

    # Vote with rich context
    rich_context_vote = {
        'voter_name': 'Peter King',
        'voter_confidence': 'high',
        'candidate_name': 'Josh Allen',
        'candidate_team': 'Bills',
        'candidate_position': 'QB',
        'ranking': 1,
        'ranking_confidence': 'high',
        'source_type': 'news_article',
        'source_url': 'https://si.com/article',
        'extracted_text': 'My MVP vote goes to Josh Allen. Here is my complete ballot: 1. Josh Allen 2. Lamar Jackson 3. Saquon Barkley 4. Joe Burrow 5. Jalen Hurts',
        'voter_context': 'By Peter King - My official AP MVP ballot for the 2024-25 season',
        'verified': False,
    }

    # Same vote with minimal context
    minimal_context_vote = rich_context_vote.copy()
    minimal_context_vote['extracted_text'] = 'Josh Allen'
    minimal_context_vote['voter_context'] = ''

    rich_result = scorer.calculate_vote_confidence(rich_context_vote)
    minimal_result = scorer.calculate_vote_confidence(minimal_context_vote)

    print(f"Rich context score: {rich_result['numeric_score']}")
    print(f"Minimal context score: {minimal_result['numeric_score']}")
    print(f"Context quality impact:")
    print(f"  Rich: {rich_result['factor_scores']['context_quality']}")
    print(f"  Minimal: {minimal_result['factor_scores']['context_quality']}")

    # Assertions
    assert rich_result['factor_scores']['context_quality'] > minimal_result['factor_scores']['context_quality'], \
        "Rich context should score higher in context quality"

    print("✓ Test 7 passed")
    return True


def run_all_tests():
    """Run all confidence scoring tests"""
    print("=" * 60)
    print("CONFIDENCE SCORING SYSTEM TEST SUITE")
    print("=" * 60)

    tests = [
        test_high_confidence_vote,
        test_medium_confidence_vote,
        test_low_confidence_vote,
        test_official_source_bonus,
        test_batch_confidence_calculation,
        test_weight_adjustment,
        test_context_quality_scoring,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            if test():
                passed += 1
        except AssertionError as e:
            print(f"✗ Test failed: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ Test error: {e}")
            failed += 1

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
