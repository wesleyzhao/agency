"""
Test suite for News Aggregator (Feature #24)
Tests RSS feed fetching, NewsAPI integration, and article aggregation
"""
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.scrapers.news_aggregator import NewsAggregator
import json


# Color codes for terminal output
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    END = '\033[0m'


def print_success(message):
    print(f"{Colors.GREEN}✓ {message}{Colors.END}")


def print_error(message):
    print(f"{Colors.RED}✗ {message}{Colors.END}")


def print_info(message):
    print(f"{Colors.CYAN}ℹ {message}{Colors.END}")


def print_warning(message):
    print(f"{Colors.YELLOW}⚠ {message}{Colors.END}")


def print_header(message):
    print(f"\n{Colors.BLUE}{'=' * 60}")
    print(f"{message}")
    print(f"{'=' * 60}{Colors.END}\n")


def test_news_aggregator_initialization():
    """Test 1: NewsAggregator initialization"""
    print_header("Test 1: NewsAggregator Initialization")

    try:
        # Initialize without API key
        aggregator = NewsAggregator()
        print_success("NewsAggregator initialized successfully")

        # Check RSS feeds configured
        print_info(f"Configured RSS feeds: {len(aggregator.rss_feeds)}")
        for source_name in aggregator.rss_feeds.keys():
            print(f"  - {source_name}")

        # Check MVP keywords
        print_info(f"MVP keywords configured: {len(aggregator.mvp_keywords)}")
        print(f"  Keywords: {', '.join(aggregator.mvp_keywords[:5])}...")

        # Check candidate names
        print_info(f"Candidate names tracked: {len(aggregator.candidate_names)}")
        print(f"  Candidates: {', '.join(aggregator.candidate_names[:5])}...")

        print_success("All configuration loaded correctly")
        return True

    except Exception as e:
        print_error(f"Initialization failed: {e}")
        return False


def test_rss_feed_fetching():
    """Test 2: RSS feed fetching"""
    print_header("Test 2: RSS Feed Fetching")

    try:
        aggregator = NewsAggregator(rate_limit_delay=1.0)

        # Test fetching a single RSS feed (ESPN)
        print_info("Fetching ESPN NFL RSS feed...")
        espn_url = aggregator.rss_feeds.get('espn_nfl')
        articles = aggregator.fetch_rss_feed(espn_url, 'espn_nfl')

        print_success(f"Fetched {len(articles)} MVP-related articles from ESPN RSS")

        if articles:
            # Display first article
            first_article = articles[0]
            print(f"\n  Sample Article:")
            print(f"    Title: {first_article.get('title', 'N/A')[:80]}...")
            print(f"    URL: {first_article.get('url', 'N/A')[:80]}...")
            print(f"    Source: {first_article.get('source', 'N/A')}")
            print(f"    Published: {first_article.get('published', 'N/A')}")

            # Check required fields
            required_fields = ['url', 'title', 'source', 'source_type', 'discovered_at']
            missing_fields = [f for f in required_fields if f not in first_article]

            if missing_fields:
                print_warning(f"Missing fields: {missing_fields}")
            else:
                print_success("All required fields present")
        else:
            print_warning("No MVP-related articles found in ESPN feed (this is OK, depends on current news)")

        return True

    except Exception as e:
        print_error(f"RSS feed fetching failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_all_rss_feeds():
    """Test 3: Fetch all RSS feeds"""
    print_header("Test 3: Fetch All RSS Feeds")

    try:
        aggregator = NewsAggregator(rate_limit_delay=1.0)

        print_info("Fetching all configured RSS feeds...")
        print_warning("This may take 20-30 seconds due to rate limiting...")

        articles = aggregator.fetch_all_rss_feeds()

        print_success(f"Fetched {len(articles)} unique articles from all RSS feeds")

        # Group by source
        by_source = {}
        for article in articles:
            source = article.get('source', 'unknown')
            by_source[source] = by_source.get(source, 0) + 1

        print_info("Articles by source:")
        for source, count in sorted(by_source.items(), key=lambda x: x[1], reverse=True):
            print(f"  {source}: {count} articles")

        # Check for duplicates
        urls = [a.get('url') for a in articles]
        if len(urls) != len(set(urls)):
            print_error("Duplicate URLs found!")
            return False
        else:
            print_success("No duplicate URLs (deduplication working)")

        return True

    except Exception as e:
        print_error(f"All RSS feeds test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_google_news_search():
    """Test 4: Google News search"""
    print_header("Test 4: Google News Search")

    try:
        aggregator = NewsAggregator(rate_limit_delay=1.0)

        print_info("Searching Google News for 'NFL MVP 2024'...")
        articles = aggregator.search_google_news('NFL MVP 2024')

        print_success(f"Found {len(articles)} articles from Google News")

        if articles:
            # Display first 3 articles
            print_info("Sample articles:")
            for i, article in enumerate(articles[:3], 1):
                print(f"\n  {i}. {article.get('title', 'N/A')[:70]}...")
                print(f"     Source: {article.get('source', 'N/A')}")
                print(f"     URL: {article.get('url', 'N/A')[:70]}...")
        else:
            print_warning("No articles found (Google News scraping may need selector updates)")

        return True

    except Exception as e:
        print_error(f"Google News search failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_newsapi_integration():
    """Test 5: NewsAPI integration"""
    print_header("Test 5: NewsAPI Integration")

    # Check for API key in environment
    import os
    newsapi_key = os.environ.get('NEWSAPI_KEY')

    if not newsapi_key:
        print_warning("NEWSAPI_KEY environment variable not set")
        print_info("Skipping NewsAPI test (optional feature)")
        print_info("To enable: export NEWSAPI_KEY=your_api_key_here")
        return True

    try:
        aggregator = NewsAggregator(newsapi_key=newsapi_key, rate_limit_delay=1.0)

        print_info("Searching NewsAPI for 'NFL MVP'...")
        articles = aggregator.search_newsapi('NFL MVP', days_back=7)

        print_success(f"Found {len(articles)} articles from NewsAPI")

        if articles:
            # Display first 3 articles
            print_info("Sample articles:")
            for i, article in enumerate(articles[:3], 1):
                print(f"\n  {i}. {article.get('title', 'N/A')[:70]}...")
                print(f"     Source: {article.get('source', 'N/A')}")
                print(f"     Published: {article.get('published_date', 'N/A')}")
        else:
            print_warning("No MVP-related articles found in last 7 days")

        return True

    except Exception as e:
        print_error(f"NewsAPI integration failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_article_filtering():
    """Test 6: Recent article filtering"""
    print_header("Test 6: Recent Article Filtering")

    try:
        aggregator = NewsAggregator()

        # Create test articles with different dates
        from datetime import datetime, timedelta

        test_articles = [
            {
                'title': 'Recent article 1',
                'url': 'https://example.com/1',
                'published_date': (datetime.utcnow() - timedelta(days=2)).isoformat()
            },
            {
                'title': 'Old article',
                'url': 'https://example.com/2',
                'published_date': (datetime.utcnow() - timedelta(days=30)).isoformat()
            },
            {
                'title': 'Recent article 2',
                'url': 'https://example.com/3',
                'published_date': (datetime.utcnow() - timedelta(days=5)).isoformat()
            },
            {
                'title': 'No date article',
                'url': 'https://example.com/4'
            }
        ]

        # Filter to last 7 days
        filtered = aggregator.filter_recent_articles(test_articles, days=7)

        print_info(f"Input: {len(test_articles)} articles")
        print_info(f"Output: {len(filtered)} recent articles (last 7 days)")

        # Should have 3 articles (2 recent + 1 no date)
        # Old article should be filtered out
        filtered_titles = [a['title'] for a in filtered]

        if 'Old article' in filtered_titles:
            print_error("Old article not filtered out!")
            return False
        else:
            print_success("Old articles filtered correctly")

        if len(filtered) == 3:
            print_success("Correct number of articles retained")
        else:
            print_warning(f"Expected 3 articles, got {len(filtered)}")

        return True

    except Exception as e:
        print_error(f"Article filtering failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_full_aggregation():
    """Test 7: Full aggregation from all sources"""
    print_header("Test 7: Full Aggregation from All Sources")

    try:
        # Check for NewsAPI key
        import os
        newsapi_key = os.environ.get('NEWSAPI_KEY')

        aggregator = NewsAggregator(newsapi_key=newsapi_key, rate_limit_delay=1.0)

        print_info("Running full aggregation from all sources...")
        print_warning("This may take 30-60 seconds due to rate limiting...")

        result = aggregator.aggregate_all_sources(
            days_back=7,
            include_newsapi=bool(newsapi_key),
            include_google_news=True
        )

        # Validate result structure
        print_success("Aggregation complete")

        # Check metadata
        metadata = result.get('metadata', {})
        articles = result.get('articles', [])

        print_info(f"\nAggregation Results:")
        print(f"  Total unique articles: {metadata.get('total_articles', 0)}")
        print(f"  Sources used: {', '.join(metadata.get('sources_used', []))}")
        print(f"  Days searched: {metadata.get('days_searched', 0)}")
        print(f"  Duplicates removed: {metadata.get('duplicates_removed', 0)}")

        # Validate structure
        required_metadata = ['total_articles', 'sources_used', 'days_searched', 'searched_at']
        missing = [f for f in required_metadata if f not in metadata]

        if missing:
            print_error(f"Missing metadata fields: {missing}")
            return False
        else:
            print_success("All metadata fields present")

        # Check article structure
        if articles:
            first_article = articles[0]
            print_info(f"\nMost recent article:")
            print(f"  Title: {first_article.get('title', 'N/A')[:80]}...")
            print(f"  Source: {first_article.get('source', 'N/A')}")
            print(f"  Published: {first_article.get('published_date', first_article.get('published', 'N/A'))}")
            print(f"  URL: {first_article.get('url', 'N/A')[:80]}...")

        # Group by source type
        by_source_type = {}
        for article in articles:
            source_type = article.get('source_type', 'unknown')
            by_source_type[source_type] = by_source_type.get(source_type, 0) + 1

        print_info("\nArticles by source type:")
        for source_type, count in sorted(by_source_type.items()):
            print(f"  {source_type}: {count} articles")

        print_success("Full aggregation test completed successfully")
        return True

    except Exception as e:
        print_error(f"Full aggregation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_mvp_relevance_detection():
    """Test 8: MVP relevance detection"""
    print_header("Test 8: MVP Relevance Detection")

    try:
        aggregator = NewsAggregator()

        # Test MVP-related content
        mvp_texts = [
            "Josh Allen is the clear MVP favorite this season",
            "NFL MVP race heats up with Lamar Jackson and Saquon Barkley",
            "My MVP ballot: 1. Allen, 2. Jackson, 3. Barkley",
            "AP NFL Most Valuable Player voting begins next week"
        ]

        # Test non-MVP content
        non_mvp_texts = [
            "Tom Brady announces retirement from NFL",
            "Patriots sign new defensive coordinator",
            "NFL schedule release date announced",
            "Fantasy football rankings for week 10"
        ]

        print_info("Testing MVP-related content detection:")
        mvp_detected = 0
        for text in mvp_texts:
            if aggregator.is_mvp_related(text):
                mvp_detected += 1
                print(f"  ✓ '{text[:50]}...' - Detected as MVP-related")
            else:
                print(f"  ✗ '{text[:50]}...' - NOT detected")

        print_info("\nTesting non-MVP content rejection:")
        non_mvp_rejected = 0
        for text in non_mvp_texts:
            if not aggregator.is_mvp_related(text):
                non_mvp_rejected += 1
                print(f"  ✓ '{text[:50]}...' - Correctly rejected")
            else:
                print(f"  ✗ '{text[:50]}...' - Incorrectly detected as MVP")

        # Calculate accuracy
        total = len(mvp_texts) + len(non_mvp_texts)
        correct = mvp_detected + non_mvp_rejected
        accuracy = (correct / total) * 100

        print_info(f"\nAccuracy: {accuracy:.1f}% ({correct}/{total} correct)")

        if accuracy >= 80:
            print_success("MVP relevance detection working well")
            return True
        else:
            print_warning("MVP relevance detection needs improvement")
            return False

    except Exception as e:
        print_error(f"MVP relevance detection test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("\n" + "=" * 60)
    print("Testing News Aggregator - Feature #24")
    print("=" * 60)

    tests = [
        ("Initialization", test_news_aggregator_initialization),
        ("RSS Feed Fetching", test_rss_feed_fetching),
        ("All RSS Feeds", test_all_rss_feeds),
        ("Google News Search", test_google_news_search),
        ("NewsAPI Integration", test_newsapi_integration),
        ("Article Filtering", test_article_filtering),
        ("Full Aggregation", test_full_aggregation),
        ("MVP Relevance Detection", test_mvp_relevance_detection),
    ]

    results = []

    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print_error(f"Test '{test_name}' crashed: {e}")
            results.append((test_name, False))

    # Summary
    print_header("Test Summary")

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        if result:
            print_success(f"{test_name}")
        else:
            print_error(f"{test_name}")

    print(f"\n{Colors.BLUE}{'=' * 60}{Colors.END}")
    if passed == total:
        print_success(f"All tests passed! ({passed}/{total})")
    else:
        print_warning(f"Some tests failed: {passed}/{total} passed")
    print(f"{Colors.BLUE}{'=' * 60}{Colors.END}\n")

    print_info("Note: Some tests may return fewer results depending on current news cycle")
    print_info("This is normal - the aggregator is working correctly")

    if passed == total:
        print_success("\n✓ Feature #24 (News Aggregator Integration) is working correctly!")
    else:
        print_warning("\n⚠ Some tests failed, but this may be due to external factors (network, API availability)")


if __name__ == "__main__":
    main()
