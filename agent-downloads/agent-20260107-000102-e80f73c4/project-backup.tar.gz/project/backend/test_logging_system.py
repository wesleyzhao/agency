"""
Comprehensive Test Suite for Logging System - Feature #25

Tests all logging functionality including file creation, log levels,
structured logging, context logging, and decorator functionality.
"""

import os
import sys
import json
import time
import shutil
from datetime import datetime

# Color codes for terminal output
GREEN = '\033[32m'
RED = '\033[31m'
YELLOW = '\033[33m'
CYAN = '\033[36m'
RESET = '\033[0m'

def print_test(message):
    print(f"{CYAN}[TEST]{RESET} {message}")

def print_success(message):
    print(f"{GREEN}✓{RESET} {message}")

def print_error(message):
    print(f"{RED}✗{RESET} {message}")

def print_info(message):
    print(f"{YELLOW}ℹ{RESET} {message}")


def test_logger_creation():
    """Test 1: Logger Creation and Configuration"""
    print_test("Test 1: Logger Creation and Configuration")

    from logging_config import LoggerFactory, LOG_DIR

    try:
        # Create loggers
        scraping_logger = LoggerFactory.get_logger('test_scraping', level='DEBUG')
        nlp_logger = LoggerFactory.get_logger('test_nlp', level='INFO')

        # Check if loggers were created
        assert scraping_logger is not None, "Failed to create scraping logger"
        assert nlp_logger is not None, "Failed to create NLP logger"

        # Check if log directory exists
        assert os.path.exists(LOG_DIR), f"Log directory not created: {LOG_DIR}"

        # Check if log files were created
        scraping_log = os.path.join(LOG_DIR, 'test_scraping.log')
        nlp_log = os.path.join(LOG_DIR, 'test_nlp.log')

        # Write test messages
        scraping_logger.info("Test scraping message")
        nlp_logger.info("Test NLP message")

        # Give it a moment to write
        time.sleep(0.1)

        # Check if files exist
        assert os.path.exists(scraping_log), "Scraping log file not created"
        assert os.path.exists(nlp_log), "NLP log file not created"

        print_success("Logger creation and configuration successful")
        print_info(f"Log directory: {LOG_DIR}")
        return True

    except AssertionError as e:
        print_error(f"Logger creation test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_log_levels():
    """Test 2: Different Log Levels"""
    print_test("Test 2: Different Log Levels")

    from logging_config import LoggerFactory

    try:
        logger = LoggerFactory.get_logger('test_levels', level='DEBUG')

        # Write messages at all levels
        logger.debug("Debug level message")
        logger.info("Info level message")
        logger.warning("Warning level message")
        logger.error("Error level message")
        logger.critical("Critical level message")

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_levels.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if all levels are present
        assert 'DEBUG' in content, "DEBUG level not logged"
        assert 'INFO' in content, "INFO level not logged"
        assert 'WARNING' in content, "WARNING level not logged"
        assert 'ERROR' in content, "ERROR level not logged"
        assert 'CRITICAL' in content, "CRITICAL level not logged"

        print_success("All log levels working correctly")
        return True

    except AssertionError as e:
        print_error(f"Log levels test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_scraping_activity_logging():
    """Test 3: Scraping Activity Logging"""
    print_test("Test 3: Scraping Activity Logging")

    from logging_config import LoggerFactory, log_scraping_activity

    try:
        logger = LoggerFactory.get_logger('test_scraping_activity', level='DEBUG')

        # Log different scraping activities
        log_scraping_activity(
            logger,
            source='reddit',
            url='https://reddit.com/r/nfl',
            status='success',
            posts_found=10,
            votes_extracted=3
        )

        log_scraping_activity(
            logger,
            source='google',
            url='https://google.com/search?q=mvp',
            status='error',
            error='Rate limit exceeded'
        )

        log_scraping_activity(
            logger,
            source='news',
            url='https://espn.com/article',
            status='skipped',
            reason='Already processed'
        )

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_scraping_activity.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if activities were logged
        assert 'reddit' in content, "Reddit scraping not logged"
        assert 'google' in content, "Google scraping not logged"
        assert 'news' in content, "News scraping not logged"
        assert 'success' in content or 'Scraped' in content, "Success status not logged"

        print_success("Scraping activity logging working correctly")
        print_info(f"Logged 3 scraping activities (success, error, skipped)")
        return True

    except AssertionError as e:
        print_error(f"Scraping activity logging test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_extraction_activity_logging():
    """Test 4: NLP Extraction Activity Logging"""
    print_test("Test 4: NLP Extraction Activity Logging")

    from logging_config import LoggerFactory, log_extraction_activity

    try:
        logger = LoggerFactory.get_logger('test_extraction', level='INFO')

        # Log extraction activities
        log_extraction_activity(
            logger,
            text_length=500,
            voters_found=1,
            votes_found=1,
            confidence='high',
            source_url='https://twitter.com/minakimes/status/123'
        )

        log_extraction_activity(
            logger,
            text_length=200,
            voters_found=0,
            votes_found=0,
            confidence='low',
            source_url='https://reddit.com/r/nfl/comments/abc'
        )

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_extraction.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if extractions were logged
        assert 'Extracted' in content, "Extraction not logged"
        assert 'voters' in content or 'votes' in content, "Vote/voter count not logged"

        print_success("Extraction activity logging working correctly")
        print_info(f"Logged 2 extraction activities with different confidence levels")
        return True

    except AssertionError as e:
        print_error(f"Extraction activity logging test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_database_operation_logging():
    """Test 5: Database Operation Logging"""
    print_test("Test 5: Database Operation Logging")

    from logging_config import LoggerFactory, log_database_operation

    try:
        logger = LoggerFactory.get_logger('test_database', level='INFO')

        # Log database operations
        log_database_operation(
            logger,
            operation='INSERT',
            table='voters',
            affected_rows=1,
            voter_name='Mina Kimes'
        )

        log_database_operation(
            logger,
            operation='UPDATE',
            table='votes',
            affected_rows=3,
            field='verified',
            new_value=True
        )

        log_database_operation(
            logger,
            operation='DELETE',
            table='sources',
            affected_rows=5,
            reason='Duplicate URLs'
        )

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_database.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if operations were logged
        assert 'INSERT' in content, "INSERT operation not logged"
        assert 'UPDATE' in content, "UPDATE operation not logged"
        assert 'DELETE' in content, "DELETE operation not logged"
        assert 'voters' in content, "Table name not logged"

        print_success("Database operation logging working correctly")
        print_info(f"Logged 3 database operations (INSERT, UPDATE, DELETE)")
        return True

    except AssertionError as e:
        print_error(f"Database operation logging test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_api_request_logging():
    """Test 6: API Request Logging"""
    print_test("Test 6: API Request Logging")

    from logging_config import LoggerFactory, log_api_request

    try:
        logger = LoggerFactory.get_logger('test_api', level='INFO')

        # Log API requests
        log_api_request(
            logger,
            method='GET',
            endpoint='/api/voters',
            status_code=200,
            duration=0.15,
            user_id='admin'
        )

        log_api_request(
            logger,
            method='POST',
            endpoint='/api/votes',
            status_code=201,
            duration=0.25,
            body_size=500
        )

        log_api_request(
            logger,
            method='DELETE',
            endpoint='/api/votes/123',
            status_code=404,
            duration=0.05,
            error='Vote not found'
        )

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_api.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if requests were logged
        assert 'GET' in content, "GET request not logged"
        assert 'POST' in content, "POST request not logged"
        assert 'DELETE' in content, "DELETE request not logged"
        assert '200' in content, "Status code not logged"

        print_success("API request logging working correctly")
        print_info(f"Logged 3 API requests with different methods and status codes")
        return True

    except AssertionError as e:
        print_error(f"API request logging test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_execution_time_decorator():
    """Test 7: Execution Time Decorator"""
    print_test("Test 7: Execution Time Decorator")

    from logging_config import LoggerFactory, log_execution_time

    try:
        logger = LoggerFactory.get_logger('test_decorator', level='INFO')

        @log_execution_time(logger)
        def slow_function():
            time.sleep(0.5)
            return "Done"

        @log_execution_time(logger)
        def fast_function():
            return "Quick"

        # Call functions
        result1 = slow_function()
        result2 = fast_function()

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_decorator.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if execution times were logged
        assert 'slow_function' in content, "Slow function not logged"
        assert 'fast_function' in content, "Fast function not logged"
        assert 'completed' in content or 'seconds' in content or 's' in content, "Execution time not logged"

        print_success("Execution time decorator working correctly")
        print_info(f"Logged execution times for 2 functions")
        return True

    except AssertionError as e:
        print_error(f"Execution time decorator test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_exception_logging():
    """Test 8: Exception Logging"""
    print_test("Test 8: Exception Logging")

    from logging_config import LoggerFactory

    try:
        logger = LoggerFactory.get_logger('test_exceptions', level='ERROR')

        # Log exceptions
        try:
            raise ValueError("Test error message")
        except ValueError as e:
            logger.error("An error occurred", exc_info=True)

        try:
            1 / 0
        except ZeroDivisionError as e:
            logger.critical("Critical error occurred", exc_info=True)

        time.sleep(0.1)

        # Read log file
        log_file = os.path.join('logs', 'test_exceptions.log')
        with open(log_file, 'r') as f:
            content = f.read()

        # Check if exceptions were logged with traceback
        assert 'ValueError' in content or 'error' in content.lower(), "ValueError not logged"
        assert 'Traceback' in content or 'ZeroDivisionError' in content, "Exception traceback not logged"

        print_success("Exception logging working correctly")
        print_info(f"Logged 2 exceptions with full tracebacks")
        return True

    except AssertionError as e:
        print_error(f"Exception logging test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def test_pre_configured_loggers():
    """Test 9: Pre-configured Loggers"""
    print_test("Test 9: Pre-configured Loggers")

    try:
        from logging_config import (
            scraping_logger,
            nlp_logger,
            api_logger,
            database_logger,
            notification_logger,
            general_logger
        )

        # Check if all loggers exist
        assert scraping_logger is not None, "Scraping logger not configured"
        assert nlp_logger is not None, "NLP logger not configured"
        assert api_logger is not None, "API logger not configured"
        assert database_logger is not None, "Database logger not configured"
        assert notification_logger is not None, "Notification logger not configured"
        assert general_logger is not None, "General logger not configured"

        # Test each logger
        scraping_logger.info("Test scraping log")
        nlp_logger.info("Test NLP log")
        api_logger.info("Test API log")
        database_logger.info("Test database log")
        notification_logger.info("Test notification log")
        general_logger.info("Test general log")

        time.sleep(0.1)

        # Check if log files were created
        log_files = [
            'scraping.log',
            'nlp.log',
            'api.log',
            'database.log',
            'notifications.log',
            'general.log'
        ]

        for log_file in log_files:
            log_path = os.path.join('logs', log_file)
            assert os.path.exists(log_path), f"Log file not created: {log_file}"

        print_success("All pre-configured loggers working correctly")
        print_info(f"Created {len(log_files)} log files:")
        for log_file in log_files:
            print_info(f"  - {log_file}")
        return True

    except AssertionError as e:
        print_error(f"Pre-configured loggers test failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False


def cleanup_test_logs():
    """Clean up test log files"""
    print_info("\nCleaning up test log files...")

    test_log_files = [
        'test_scraping.log',
        'test_nlp.log',
        'test_levels.log',
        'test_scraping_activity.log',
        'test_extraction.log',
        'test_database.log',
        'test_api.log',
        'test_decorator.log',
        'test_exceptions.log'
    ]

    cleaned = 0
    for log_file in test_log_files:
        log_path = os.path.join('logs', log_file)
        if os.path.exists(log_path):
            os.remove(log_path)
            cleaned += 1

    print_info(f"Cleaned up {cleaned} test log files")


def run_all_tests():
    """Run all tests"""
    print("\n" + "=" * 60)
    print("Testing Comprehensive Logging System - Feature #25")
    print("=" * 60 + "\n")

    tests = [
        test_logger_creation,
        test_log_levels,
        test_scraping_activity_logging,
        test_extraction_activity_logging,
        test_database_operation_logging,
        test_api_request_logging,
        test_execution_time_decorator,
        test_exception_logging,
        test_pre_configured_loggers
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print_error(f"Test crashed: {str(e)}")
            failed += 1
        print()

    # Summary
    print("=" * 60)
    print(f"Test Summary: {passed} passed, {failed} failed")
    print("=" * 60)

    if failed == 0:
        print_success("\nAll tests PASSED! ✓")
    else:
        print_error(f"\n{failed} test(s) FAILED! ✗")

    # Cleanup
    cleanup_test_logs()

    # Show log directory
    print_info(f"\nProduction log files location: {os.path.abspath('logs')}")
    print_info("Log files created:")
    if os.path.exists('logs'):
        for log_file in os.listdir('logs'):
            if log_file.endswith('.log'):
                file_path = os.path.join('logs', log_file)
                file_size = os.path.getsize(file_path)
                print_info(f"  - {log_file} ({file_size} bytes)")

    return failed == 0


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
