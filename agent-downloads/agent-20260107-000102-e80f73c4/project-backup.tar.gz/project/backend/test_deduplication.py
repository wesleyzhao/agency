"""
Test script to verify URL deduplication and source tracking functionality
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import logging
from backend.database import (
    get_session, init_db,
    SourceDB, VoteSourceDB, VoteDB, VoterDB, CandidateDB,
    Source, VoteSource
)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_source_deduplication():
    """Test URL and content deduplication"""
    logger.info("\n" + "=" * 80)
    logger.info("TEST 1: Source Deduplication")
    logger.info("=" * 80)

    session = get_session()

    try:
        # Test 1: Add a source
        logger.info("\n1. Adding first source...")
        source1 = SourceDB.add_source(
            session,
            url="https://example.com/article1",
            title="Test Article 1",
            content="This is the content of article 1 about MVP voting.",
            source_type="test"
        )
        logger.info(f"   ✓ Added source: ID={source1.id}, URL={source1.url}")

        # Test 2: Try to add same URL again (should return existing)
        logger.info("\n2. Attempting to add duplicate URL...")
        source2 = SourceDB.add_source(
            session,
            url="https://example.com/article1",
            title="Test Article 1 (Different Title)",
            content="Different content",
            source_type="test"
        )
        assert source1.id == source2.id, "Should return same source for duplicate URL"
        logger.info(f"   ✓ Correctly returned existing source: ID={source2.id}")

        # Test 3: Add different URL with same content (should be marked as processed)
        logger.info("\n3. Adding different URL with duplicate content...")
        source3 = SourceDB.add_source(
            session,
            url="https://example.com/article2",
            title="Test Article 2",
            content="This is the content of article 1 about MVP voting.",  # Same content
            source_type="test"
        )
        logger.info(f"   ✓ Added new URL: ID={source3.id}")
        assert source3.id != source1.id, "Should create new source for different URL"
        assert source3.processed == 1, "Should be marked as processed (duplicate content)"
        logger.info(f"   ✓ Correctly marked as processed (duplicate content)")

        # Test 4: Content hash detection
        logger.info("\n4. Testing content hash detection...")
        content_hash = SourceDB.generate_content_hash("Test content for hashing")
        logger.info(f"   Generated hash: {content_hash}")
        assert len(content_hash) == 32, "Hash should be 32 characters (MD5)"
        logger.info(f"   ✓ Hash generation working correctly")

        # Test 5: Check if URL is processed
        logger.info("\n5. Testing URL processed check...")
        is_processed = SourceDB.is_url_processed(session, "https://example.com/article1")
        assert is_processed, "Should detect URL as processed"
        logger.info(f"   ✓ Correctly identified processed URL")

        is_new = SourceDB.is_url_processed(session, "https://example.com/new-article")
        assert not is_new, "Should detect new URL"
        logger.info(f"   ✓ Correctly identified new URL")

        # Test 6: Get source stats
        logger.info("\n6. Getting source statistics...")
        stats = SourceDB.get_source_stats(session)
        logger.info(f"   Total sources: {stats['total']}")
        logger.info(f"   Processed: {stats['processed']}")
        logger.info(f"   Unprocessed: {stats['unprocessed']}")
        logger.info(f"   By type: {stats['by_type']}")
        assert stats['total'] >= 2, "Should have at least 2 sources"
        logger.info(f"   ✓ Statistics retrieved successfully")

        logger.info("\n✅ All source deduplication tests passed!")
        return True

    except Exception as e:
        logger.error(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        session.close()


def test_vote_source_linking():
    """Test linking votes to sources"""
    logger.info("\n" + "=" * 80)
    logger.info("TEST 2: Vote-Source Linking")
    logger.info("=" * 80)

    session = get_session()

    try:
        # Create test voter and candidate
        logger.info("\n1. Creating test voter and candidate...")
        voter = VoterDB.get_or_create_voter(
            session,
            name="Test Voter",
            outlet="Test Outlet"
        )
        logger.info(f"   ✓ Created voter: {voter.name} (ID={voter.id})")

        candidate = CandidateDB.get_or_create_candidate(
            session,
            name="Josh Allen",
            season="2024-25",
            team="Buffalo Bills",
            position="QB"
        )
        logger.info(f"   ✓ Created candidate: {candidate.name} (ID={candidate.id})")

        # Create a vote
        logger.info("\n2. Creating test vote...")
        vote = VoteDB.add_vote(
            session,
            voter_name="Test Voter",
            candidate_name="Josh Allen",
            season="2024-25",
            ranking=1,
            source_url="https://example.com/article1"
        )
        logger.info(f"   ✓ Created vote: ID={vote.id}")

        # Create sources
        logger.info("\n3. Creating test sources...")
        source1 = SourceDB.add_source(
            session,
            url="https://twitter.com/test/status/123",
            title="Tweet about MVP vote",
            content="I'm voting for Josh Allen as MVP",
            source_type="twitter"
        )
        logger.info(f"   ✓ Created source 1: ID={source1.id}")

        source2 = SourceDB.add_source(
            session,
            url="https://example.com/article3",
            title="Article confirming vote",
            content="Test Voter confirms MVP choice",
            source_type="news"
        )
        logger.info(f"   ✓ Created source 2: ID={source2.id}")

        # Link vote to sources
        logger.info("\n4. Linking vote to sources...")
        link1 = VoteSourceDB.link_vote_to_source(session, vote.id, source1.id)
        logger.info(f"   ✓ Linked vote to source 1: {link1}")

        link2 = VoteSourceDB.link_vote_to_source(session, vote.id, source2.id)
        logger.info(f"   ✓ Linked vote to source 2: {link2}")

        # Try to link again (should return existing)
        logger.info("\n5. Testing duplicate link prevention...")
        link1_dup = VoteSourceDB.link_vote_to_source(session, vote.id, source1.id)
        assert link1.id == link1_dup.id, "Should return existing link"
        logger.info(f"   ✓ Correctly prevented duplicate link")

        # Get sources for vote
        logger.info("\n6. Retrieving sources for vote...")
        sources = VoteSourceDB.get_sources_for_vote(session, vote.id)
        logger.info(f"   Found {len(sources)} sources:")
        for src in sources:
            logger.info(f"   - {src.url} ({src.source_type})")
        assert len(sources) == 2, "Should have 2 sources linked to vote"
        logger.info(f"   ✓ Retrieved all sources for vote")

        # Get votes from source
        logger.info("\n7. Retrieving votes from source...")
        votes = VoteSourceDB.get_votes_from_source(session, source1.id)
        logger.info(f"   Found {len(votes)} votes from source")
        assert len(votes) == 1, "Should have 1 vote from source"
        assert votes[0].id == vote.id, "Should be the correct vote"
        logger.info(f"   ✓ Retrieved votes from source")

        logger.info("\n✅ All vote-source linking tests passed!")
        return True

    except Exception as e:
        logger.error(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        session.close()


def test_source_tracker():
    """Test SourceTracker class"""
    logger.info("\n" + "=" * 80)
    logger.info("TEST 3: SourceTracker Functionality")
    logger.info("=" * 80)

    from backend.scrapers.source_tracker import SourceTracker

    session = get_session()

    try:
        # Create tracker
        logger.info("\n1. Creating SourceTracker...")
        tracker = SourceTracker(session, source_type="test_tracker")
        logger.info(f"   ✓ Created tracker for source type: test_tracker")

        # Test URL checking
        logger.info("\n2. Testing URL freshness check...")
        new_url = "https://example.com/brand-new-article"
        is_new = tracker.is_url_new(new_url)
        assert is_new, "Should identify new URL"
        logger.info(f"   ✓ Correctly identified new URL")

        # Add the URL
        logger.info("\n3. Adding source via tracker...")
        source_id = tracker.add_source(
            new_url,
            title="Brand New Article",
            content="Fresh content about MVP race"
        )
        logger.info(f"   ✓ Added source: ID={source_id}")

        # Check again (should now be processed)
        is_new_again = tracker.is_url_new(new_url)
        assert not is_new_again, "Should now identify URL as processed"
        logger.info(f"   ✓ Correctly cached processed URL")

        # Test batch filtering
        logger.info("\n4. Testing batch URL filtering...")
        test_urls = [
            "https://example.com/article1",  # Duplicate
            "https://example.com/new1",       # New
            "https://example.com/new2",       # New
            new_url                            # Duplicate
        ]
        filtered = tracker.filter_new_urls(test_urls)
        logger.info(f"   Filtered {len(test_urls)} URLs -> {len(filtered)} new URLs")
        assert len(filtered) == 2, "Should filter to 2 new URLs"
        logger.info(f"   ✓ Batch filtering working correctly")

        # Test content deduplication
        logger.info("\n5. Testing content deduplication...")
        test_items = [
            {"url": "https://example.com/item1", "content": "Unique content 1"},
            {"url": "https://example.com/item2", "content": "Unique content 2"},
            {"url": "https://example.com/item3", "content": "Unique content 1"},  # Duplicate
        ]
        unique_items = tracker.deduplicate_by_content(test_items, content_key='content')
        logger.info(f"   Deduplicated {len(test_items)} items -> {len(unique_items)} unique")
        assert len(unique_items) == 2, "Should have 2 unique items"
        logger.info(f"   ✓ Content deduplication working correctly")

        # Test stats
        logger.info("\n6. Getting tracker stats...")
        stats = tracker.get_stats()
        logger.info(f"   Total sources in DB: {stats['total']}")
        logger.info(f"   ✓ Stats retrieved successfully")

        logger.info("\n✅ All SourceTracker tests passed!")
        return True

    except Exception as e:
        logger.error(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        session.close()


def cleanup_test_data():
    """Clean up test data"""
    logger.info("\n" + "=" * 80)
    logger.info("Cleaning up test data...")
    logger.info("=" * 80)

    session = get_session()

    try:
        # Delete test sources
        deleted = session.query(Source).filter(
            Source.source_type.in_(['test', 'test_tracker', 'twitter'])
        ).delete(synchronize_session=False)
        session.commit()
        logger.info(f"Deleted {deleted} test sources")

        # Delete test voters
        from backend.database.models import Voter
        deleted = session.query(Voter).filter(
            Voter.name == "Test Voter"
        ).delete(synchronize_session=False)
        session.commit()
        logger.info(f"Deleted {deleted} test voters")

        logger.info("✓ Cleanup complete")

    except Exception as e:
        logger.error(f"Cleanup error: {e}")
        session.rollback()
    finally:
        session.close()


def main():
    """Run all tests"""
    logger.info("\n" + "=" * 80)
    logger.info("DEDUPLICATION FEATURE TEST SUITE")
    logger.info("=" * 80)

    # Initialize database if needed
    try:
        init_db()
        logger.info("✓ Database initialized")
    except Exception as e:
        logger.warning(f"Database initialization: {e}")

    # Run migration first
    logger.info("\nRunning migration...")
    try:
        from backend.database.migrate_add_deduplication import migrate
        migrate()
    except Exception as e:
        logger.warning(f"Migration: {e}")

    # Run tests
    results = []
    results.append(("Source Deduplication", test_source_deduplication()))
    results.append(("Vote-Source Linking", test_vote_source_linking()))
    results.append(("SourceTracker", test_source_tracker()))

    # Print summary
    logger.info("\n" + "=" * 80)
    logger.info("TEST SUMMARY")
    logger.info("=" * 80)

    all_passed = True
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info(f"{test_name}: {status}")
        if not passed:
            all_passed = False

    # Cleanup
    cleanup_test_data()

    logger.info("\n" + "=" * 80)
    if all_passed:
        logger.info("🎉 ALL TESTS PASSED!")
    else:
        logger.info("❌ SOME TESTS FAILED")
    logger.info("=" * 80)

    return 0 if all_passed else 1


if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)
