# NFL MVP Voter Tracker

**Comprehensive system to track and aggregate publicly disclosed NFL MVP votes from the 50 AP voters**

---

## Table of Contents

1. [Overview](#overview)
2. [Features](#features)
3. [Architecture](#architecture)
4. [Installation](#installation)
5. [Quick Start](#quick-start)
6. [Usage Guide](#usage-guide)
7. [API Documentation](#api-documentation)
8. [Extending the System](#extending-the-system)
9. [Testing](#testing)
10. [Deployment](#deployment)
11. [Project Structure](#project-structure)
12. [Contributing](#contributing)

---

## Overview

The NFL MVP Voter Tracker is a comprehensive web application that helps identify and track the 50 Associated Press (AP) voters who determine the NFL Most Valuable Player (MVP) award, and monitors their publicly disclosed votes throughout the season.

### The Problem

- The AP doesn't publicly release the list of 50 MVP voters until after the award is announced
- Some voters announce their picks on social media (Twitter/X), articles, or podcasts
- It's difficult to track who has disclosed their vote and for whom they voted
- There's no centralized place to see the aggregated voting data in real-time

### The Solution

This application:
- **Scrapes** multiple sources (Reddit, Twitter/X, news sites, RSS feeds) for MVP voter information
- **Extracts** voter names, candidates, and rankings using Natural Language Processing
- **Stores** all data in a structured database with source attribution and deduplication
- **Displays** aggregated voting data through a professional web interface
- **Notifies** users when new voter information is discovered
- **Provides** admin tools to verify and manage extracted data

### Current Status (2024-25 Season)

As of January 7, 2026, we have identified:
- **4 confirmed voters** with publicly disclosed votes
- **Josh Allen won** with 383 points (27 first-place votes)
- **Lamar Jackson** came second with 362 points (23 first-place votes)

**Confirmed Voters:**
1. **Tom Brady** - Voted: Lamar Jackson (1st), Josh Allen (2nd), Saquon Barkley (3rd), Ja'Marr Chase (4th), Joe Burrow (5th)
2. **Mina Kimes** - Voted: Lamar Jackson (1st), Josh Allen (2nd), Joe Burrow (3rd), Saquon Barkley (4th), Jayden Daniels (5th)
3. **Tony Dungy** - Voted for Lamar Jackson (1st place)
4. **Tedy Bruschi** - Voted for Lamar Jackson (1st place)

---

## Features

### ✅ Completed Features

1. **Web Scraping System**
   - Reddit API integration (PRAW)
   - Google Search integration
   - News site scraping (ESPN, NFL.com, ProFootballTalk, SI, CBS, Yahoo, The Athletic)
   - RSS feed aggregation (8 major NFL news sources)
   - NewsAPI integration (70,000+ news sources)
   - Rate limiting and response caching to avoid being blocked

2. **Natural Language Processing**
   - Voter name extraction (37+ known AP voters)
   - MVP candidate extraction (15+ 2024-25 candidates)
   - Vote ranking extraction (1st through 5th place)
   - Confidence scoring (high/medium/low) with numeric scores (0-100)
   - Multi-factor confidence calculation (voter, candidate, ranking, source, context, verification)

3. **Database System**
   - SQLAlchemy ORM with SQLite (upgradeable to PostgreSQL)
   - Voter tracking (name, outlet, Twitter handle, location, bio)
   - Vote tracking (voter, candidate, ranking, confidence, source, verification status)
   - Source tracking with URL deduplication and content hashing
   - Vote-source linking for cross-verification
   - Historical vote tracking across multiple seasons

4. **REST API**
   - Voter CRUD operations
   - Vote CRUD operations
   - Candidate management
   - Dashboard data aggregation
   - Statistics endpoint
   - Search and filter functionality
   - Export to CSV/JSON
   - Timeline data
   - Admin endpoints for verification

5. **Web Interface**
   - Dashboard showing all 50 AP voters (known and unknown)
   - Voter detail pages with complete ballot and source links
   - Statistics page with comprehensive analytics
   - Visualizations with Chart.js (6 different charts)
   - Timeline view showing chronological vote announcements
   - Admin panel for verifying and editing extracted data
   - Search and filter functionality
   - Export functionality (CSV/JSON)
   - Responsive design (mobile and desktop)

6. **Notification System**
   - Multiple channels: Email (SMTP), Webhook (Slack/Discord), Console
   - Event types: New voter found, new vote disclosed, full ballot complete, high confidence vote, verified vote, scraping complete/error
   - Configurable preferences per channel
   - Rate limiting to prevent spam
   - Complete notification history with audit trail

7. **Logging System**
   - Comprehensive logging for all components (scraping, NLP, database, API, notifications)
   - Multiple log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
   - Color-coded console output for development
   - Structured JSON logs for production parsing
   - File rotation (10MB per file, 5 backups)
   - Performance tracking with execution time decorator
   - Exception tracking with full tracebacks

8. **Data Quality Tools**
   - URL deduplication to avoid processing same source twice
   - Content hash deduplication for syndicated articles
   - Confidence scoring to prioritize high-quality data
   - Source credibility tracking (verified, official, reliable, unverified, speculation)
   - Admin verification workflow for manual review
   - Batch operations for efficient processing

---

## Architecture

### System Overview

```
┌───────────────────────────────────────────────────────────────┐
│                     Frontend (React)                          │
│  - Dashboard        - Statistics       - Visualizations       │
│  - VoterDetail      - Timeline         - Admin Panel          │
└───────────────────────┬───────────────────────────────────────┘
                        │ HTTP/REST API
┌───────────────────────▼───────────────────────────────────────┐
│                 Flask Backend (Python)                         │
│  - REST API Endpoints                                         │
│  - Request handling and validation                            │
└───────────────────────┬───────────────────────────────────────┘
                        │
        ┌───────────────┴──────────────────┐
        │                                  │
┌───────▼──────────┐          ┌───────────▼──────────┐
│  Database Layer  │          │   NLP Extractors     │
│  - SQLAlchemy    │          │   - VoteExtractor    │
│  - Models        │          │   - VoterExtractor   │
│  - Utilities     │          │   - CandidateEx...   │
└───────┬──────────┘          │   - RankingEx...     │
        │                     │   - ConfidenceScorer │
        │                     └───────────┬──────────┘
        │                                 │
        │         ┌───────────────────────┘
        │         │
┌───────▼─────────▼──────────────────────────────────────────┐
│                    Scrapers & Aggregators                   │
│  - EnhancedScraper (base with rate limiting + caching)     │
│  - RedditScraper                                           │
│  - GoogleScraper                                           │
│  - NewsScraper                                             │
│  - NewsAggregator (RSS + NewsAPI)                         │
│  - ScraperOrchestrator                                    │
└───────────────────────┬────────────────────────────────────┘
                        │
┌───────────────────────▼────────────────────────────────────┐
│                  External Data Sources                     │
│  Reddit | Twitter/X | ESPN | NFL.com | NewsAPI | RSS      │
└────────────────────────────────────────────────────────────┘
```

### Technology Stack

**Backend:**
- Python 3.8+
- Flask (REST API)
- SQLAlchemy (ORM)
- SQLite (database, upgradeable to PostgreSQL)
- BeautifulSoup4 (HTML parsing)
- PRAW (Reddit API)
- newspaper3k (article extraction)
- feedparser (RSS feeds)

**Frontend:**
- React 18
- React Router (navigation)
- Chart.js (visualizations)
- react-chartjs-2 (React Chart.js wrapper)
- CSS3 (styling)

**Infrastructure:**
- Rate limiting and request throttling
- Response caching with LRU eviction
- File-based logging with rotation
- SMTP/Webhook notifications

---

## Installation

### Prerequisites

- Python 3.8 or higher
- Node.js 14 or higher
- npm 6 or higher
- Git

### Backend Setup

1. **Clone the repository:**

```bash
git clone <repository-url>
cd nfl-mvp-tracker
```

2. **Create virtual environment:**

```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install Python dependencies:**

```bash
pip install flask flask-cors sqlalchemy beautifulsoup4 requests praw newspaper3k lxml_html_clean feedparser python-dateutil
```

4. **Set up environment variables (optional):**

Create `.env` file in `backend/` directory:

```bash
# Reddit API (for RedditScraper)
REDDIT_CLIENT_ID=your_client_id
REDDIT_CLIENT_SECRET=your_client_secret
REDDIT_USER_AGENT=NFL_MVP_Tracker/1.0

# NewsAPI (optional, for NewsAggregator)
NEWSAPI_KEY=your_newsapi_key

# SMTP (for email notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_USE_TLS=true

# Flask
FLASK_ENV=development
FLASK_DEBUG=1
```

5. **Initialize the database:**

```bash
python3 -c "from database.models import Base, engine; Base.metadata.create_all(engine)"
```

6. **Run database migrations:**

```bash
# Add deduplication tables
python3 database/migrate_add_deduplication.py

# Add confidence scoring
python3 database/migrate_add_confidence_score.py

# Add notifications
python3 database/migrate_add_notifications.py
```

7. **Seed the database:**

```bash
# Add known voters and candidates from 2024-25 season
python3 seed_database.py
```

### Frontend Setup

1. **Navigate to frontend directory:**

```bash
cd frontend
```

2. **Install dependencies:**

```bash
npm install
```

3. **Set up environment variables (optional):**

Create `.env` file in `frontend/` directory:

```bash
REACT_APP_API_URL=http://localhost:5000
```

---

## Quick Start

### Start the Backend Server

```bash
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
python3 app.py
```

Backend will run on: **http://localhost:5000**

### Start the Frontend Development Server

```bash
cd frontend
npm start
```

Frontend will open in browser at: **http://localhost:3000**

### Access the Application

- **Dashboard**: http://localhost:3000/
- **Statistics**: http://localhost:3000/statistics
- **Visualizations**: http://localhost:3000/visualizations
- **Timeline**: http://localhost:3000/timeline
- **Admin Panel**: http://localhost:3000/admin

---

## Usage Guide

### 1. Manual Entry

**Add a known voter and their vote:**

```bash
# Via API
curl -X POST http://localhost:5000/api/votes \
  -H "Content-Type: application/json" \
  -d '{
    "voter_name": "Mina Kimes",
    "candidate_name": "Saquon Barkley",
    "candidate_team": "Philadelphia Eagles",
    "season": "2024-25",
    "ranking": 1,
    "source_url": "https://x.com/minakimes/status/...",
    "confidence": "high",
    "confidence_score": 90.0
  }'
```

Or use the web interface at http://localhost:3000/admin

### 2. Web Scraping

**Run comprehensive search across all sources:**

```python
from scrapers import ScraperOrchestrator

orchestrator = ScraperOrchestrator(use_db_deduplication=True)
results = orchestrator.run_comprehensive_search(season="2024-25")

print(f"Found {len(results)} results")
```

### 3. News Aggregation

**Fetch recent MVP articles:**

```python
from scrapers import NewsAggregator

aggregator = NewsAggregator()
articles = aggregator.aggregate_all_sources(days=7)

print(f"Found {len(articles)} MVP-related articles")
```

### 4. NLP Extraction

**Extract votes from text:**

```python
from nlp import VoteExtractor

extractor = VoteExtractor()

text = """
My MVP ballot for 2024:
1. Saquon Barkley
2. Josh Allen
3. Lamar Jackson
"""

votes = extractor.extract_votes_from_text(
    text=text,
    source_url="https://twitter.com/...",
    source_type="social_media"
)

for vote in votes:
    print(f"{vote['voter_name']} voted for {vote['candidate_name']} at #{vote['ranking']}")
```

### 5. Admin Verification

**Access admin panel:**

```bash
open http://localhost:3000/admin
```

Filter by confidence level, verify votes, edit details, or delete false positives.

### 6. Export Data

**Export to CSV:**

```bash
# Via web interface: Dashboard → Export → Voters (CSV)

# Or via API:
curl http://localhost:5000/api/export/voters?format=csv > voters.csv
```

---

## API Documentation

### Base URL

```
http://localhost:5000/api
```

### Key Endpoints

- `GET /api/dashboard?season=2024-25` - Complete dashboard data
- `GET /api/statistics?season=2024-25` - Comprehensive statistics
- `GET /api/voters` - List all voters
- `GET /api/votes` - List all votes
- `POST /api/votes` - Create vote (auto-creates voter/candidate if needed)
- `GET /api/search?query=...` - Search voters
- `GET /api/export/voters?format=csv` - Export data
- `GET /api/admin/unverified` - Get unverified votes for review

**Full API documentation**: See `backend/MANUAL_ENTRY_API.md`, `backend/SEARCH_FILTER_API.md`, `backend/EXPORT_API.md`, `backend/ADMIN_API.md`

---

## Extending the System

### Adding a New Data Source

See complete guide: **`backend/scrapers/EXTENDING_SCRAPERS.md`**

**Quick example:**

```python
from scrapers.enhanced_scraper import EnhancedScraper

class MyNewScraper(EnhancedScraper):
    def __init__(self):
        super().__init__(name="my_scraper", rate_limit_delay=2.0)

    def search_mvp_votes(self, season="2024-25"):
        # Your scraping logic
        pass
```

---

## Testing

### Backend Tests

```bash
cd backend

# Run all scraper tests
python3 test_scrapers.py
python3 test_news_aggregator.py

# Run all NLP tests
python3 test_nlp_extraction.py
python3 test_confidence_scoring.py

# Run all API tests
python3 test_dashboard.py
python3 test_statistics.py
python3 test_admin.py
```

### Frontend Tests

```bash
cd frontend
npm test
```

---

## Deployment

### Production Deployment

**Backend (Flask with Gunicorn):**

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

**Frontend (React build):**

```bash
cd frontend
npm run build
# Serve build/ directory with nginx or Apache
```

---

## Project Structure

```
nfl-mvp-tracker/
├── backend/
│   ├── app.py                          # Flask REST API
│   ├── logging_config.py               # Logging configuration
│   ├── seed_database.py                # Database seeding script
│   │
│   ├── database/                       # Database layer
│   │   ├── models.py                   # SQLAlchemy models
│   │   ├── utils.py                    # Database utilities
│   │   └── nfl_mvp_tracker.db          # SQLite database
│   │
│   ├── scrapers/                       # Web scraping modules
│   │   ├── enhanced_scraper.py         # Base scraper with rate limiting
│   │   ├── reddit_scraper.py           # Reddit API integration
│   │   ├── news_aggregator.py          # RSS + NewsAPI aggregation
│   │   ├── scraper_orchestrator.py     # Coordinates all scrapers
│   │   └── EXTENDING_SCRAPERS.md       # Extension guide ⭐
│   │
│   ├── nlp/                            # NLP extraction modules
│   │   ├── vote_extractor.py           # Main vote extractor
│   │   ├── confidence_scorer.py        # Confidence scoring
│   │   └── CONFIDENCE_SCORING.md       # Scoring guide
│   │
│   ├── notifications/                  # Notification system
│   │   ├── notification_service.py     # Notification service
│   │   └── README.md                   # Notification guide
│   │
│   └── logs/                           # Log files
│       ├── scraping.log
│       └── api.log
│
├── frontend/
│   └── src/
│       ├── App.js                      # Main app
│       ├── Dashboard.js                # Dashboard component
│       ├── Statistics.js               # Statistics component
│       ├── Visualizations.js           # Charts component
│       ├── Admin.js                    # Admin panel
│       └── Timeline.js                 # Timeline view
│
├── feature_list.json                   # Feature tracking
├── claude-progress.txt                 # Development log
└── README.md                           # This file ⭐
```

---

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Test thoroughly
4. Update documentation
5. Submit a pull request

---

## Acknowledgments

- **BeautifulSoup**: HTML parsing
- **PRAW**: Reddit API wrapper
- **newspaper3k**: Article extraction
- **Flask**: Web framework
- **React**: Frontend framework
- **Chart.js**: Data visualization

---

## Disclaimer

This tool aggregates publicly available information. Vote tallies are unofficial until announced by the Associated Press.

---

**Last Updated**: January 7, 2026
**Version**: 1.0.0
**Status**: Production Ready

For detailed documentation on extending the system, see: **`backend/scrapers/EXTENDING_SCRAPERS.md`**
